import bpy,json,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
src=out/'source/Summoners_Rift_Structure_Study_49.blend'
import sys
tag=sys.argv[-2]
glb=out/sys.argv[-1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sh=sha(src);gh=sha(glb)
bpy.ops.wm.open_mainfile(filepath=str(src));s=bpy.context.scene
for o in list(bpy.data.objects):
 if o.type=='MESH':bpy.data.objects.remove(o,do_unlink=True)
bpy.ops.import_scene.gltf(filepath=str(glb))
s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=12;s.cycles.seed=0;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=2;s.render.resolution_x=1000;s.render.resolution_y=850;s.render.resolution_percentage=100
from mathutils import Vector
for name,loc,target,scale in [('Bramble_Wide',(19,14,30),(-3,38,1),26),('Fungi_Close',(10,21,15),(-1,33.5,3),13)]:
 cam=bpy.data.cameras.new(name);obj=bpy.data.objects.new(name,cam);s.collection.objects.link(obj);obj.location=loc;obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler();cam.type='ORTHO';cam.ortho_scale=scale

 s.camera=bpy.data.objects[name];s.render.filepath=str(out/(tag+'-'+name+'.png'));bpy.ops.render.render(write_still=True)
(out/(tag+'-provenance.json')).write_text(json.dumps({'blend':sh,'glb':gh,'actualGLB':True,'samples':s.cycles.samples,'seed':s.cycles.seed,'denoise':s.cycles.use_denoising,'resolution':[s.render.resolution_x,s.render.resolution_y],'engine':s.render.engine,'device':s.cycles.device,'views':['Bramble_Wide','Fungi_Close']},indent=2))
assert sha(src)==sh and sha(glb)==gh
