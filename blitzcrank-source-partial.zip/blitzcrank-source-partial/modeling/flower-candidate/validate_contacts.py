import bpy,json,hashlib
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from pathlib import Path
w=Path(__file__).resolve().parent
bpy.ops.wm.open_mainfile(filepath=str(w/'Red_Bramble_Flowers_Candidate.blend'));o=bpy.data.objects['Red_Bramble_Flowers_Independent'];m=o.data;m.calc_loop_triangles();P=[o.matrix_world@v.co for v in m.vertices];T=[tuple(t.vertices)for t in m.loop_triangles];tree=BVHTree.FromPolygons(P,T,all_triangles=True);raw=json.load(open(w/'validation/model-proof.json'));s={'roots':[{'root':r}for r in raw['roots']]};G=[{'id':i,'vertexStart':i*180,'vertexEnd':(i+1)*180}for i in range(3)];byv={v:i for i,g in enumerate(G)for v in range(g['vertexStart'],g['vertexEnd'])};tg=[byv[t[0]]for t in T]
selfhits=[(a,b)for a,b in tree.overlap(tree)if a<b and not set(T[a])&set(T[b])];lo=Vector(tuple(min(p[i]for p in P)for i in range(3)));hi=Vector(tuple(max(p[i]for p in P)for i in range(3)));overlaps=[]
for old in bpy.data.objects:
 if old.type!='MESH'or old==o:continue
 bb=[old.matrix_world@Vector(p)for p in old.bound_box]
 if any(max(p[i]for p in bb)<lo[i]or min(p[i]for p in bb)>hi[i]for i in range(3)):continue
 old.data.calc_loop_triangles();ov=[old.matrix_world@v.co for v in old.data.vertices];ot=[tuple(t.vertices)for t in old.data.loop_triangles];tr=BVHTree.FromPolygons(ov,ot,all_triangles=True);pairs=tree.overlap(tr)
 if pairs:
  ts=sorted(set(a for a,b in pairs));maxd=max((P[v]-Vector(s['roots'][tg[t]]['root'])).length for t in ts for v in T[t]);overlaps.append({'object':old.name,'pairs':len(pairs),'maxDistanceFromRoot':maxd})
sv=[];sf=[]
for name in ['Fractured_Cliff_Boulders','Continuous_Cliff_Walls']:
 stone=bpy.data.objects[name];stone.data.calc_loop_triangles();offset=len(sv);sv.extend(stone.matrix_world@v.co for v in stone.data.vertices);sf.extend(tuple(offset+v for v in t.vertices)for t in stone.data.loop_triangles)
st=BVHTree.FromPolygons(sv,sf,all_triangles=True);roots=[]
for g in G:
 ds=[]
 for p in P[g['vertexStart']:g['vertexStart']+30]:
  q,n,fi,d=st.find_nearest(p);ds.append((p-q).dot(n))
 roots.append({'id':g['id'],'signedRootRingDistances':ds,'anchoredBelowSurface':max(ds)<0})
rec={'status':'PASS'if not selfhits and all(r['anchoredBelowSurface']for r in roots)and all(x['object']in ['Fractured_Cliff_Boulders','Continuous_Cliff_Walls']and x['maxDistanceFromRoot']<.2 for x in overlaps)else'FAIL','candidateSHA256':hashlib.sha256((w/'Red_Bramble_Flowers_Candidate.blend').read_bytes()).hexdigest(),'selfIntersections':selfhits,'supportIntersections':overlaps,'rootSupports':roots,'intentionalContactScope':'Stem basal faces penetrate only supporting cliff or boulder within0.2 of planted base; all other surfaces must not intersect.'};(w/'validation/flower-contact-proof.json').write_text(json.dumps(rec,indent=2));print(json.dumps(rec,indent=2))
