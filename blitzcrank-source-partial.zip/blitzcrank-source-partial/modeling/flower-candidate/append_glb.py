from pathlib import Path
import struct,json,copy,numpy as np,hashlib
out=Path(__file__).parent;raw=(out/'source/Summoners_Rift_Structure_Study_49.glb').read_bytes();jl=struct.unpack_from('<I',raw,12)[0];j=json.loads(raw[20:20+jl]);old=copy.deepcopy(j);bl=struct.unpack_from('<I',raw,20+jl)[0];oldbin=raw[28+jl:28+jl+bl];buf=bytearray(oldbin);d=json.load(open(out/'new-mesh.json'));R=np.array([[1,0,0],[0,0,1],[0,-1,0]]);P=[];N=[];C=[]
for tri,n,colors in zip(d['triangles'],d['normals'],d['colors']):
 for vi,c in zip(tri,colors):P.append(R@np.array(d['vertices'][vi]));N.append(R@np.array(n));C.append(np.rint(np.array(c)*255))
P=np.array(P,dtype='<f4');N=np.array(N,dtype='<f4');C=np.array(C,dtype='u1');I=np.arange(len(P),dtype='<u2')
def add(data,ct,typ,normalized=False):
 buf.extend(b'\0'*((-len(buf))%4));bv=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':data.nbytes});buf.extend(data.tobytes());ai=len(j['accessors']);a={'bufferView':bv,'componentType':ct,'count':len(data),'type':typ}
 if typ=='VEC3':a.update(min=data.min(0).tolist(),max=data.max(0).tolist())
 if normalized:a['normalized']=True
 j['accessors'].append(a);return ai
p=add(P,5126,'VEC3');n=add(N,5126,'VEC3');c=add(C,5121,'VEC4',True);i=add(I,5123,'SCALAR');mat=next(k for k,m in enumerate(j['materials'])if m['name']=='Study_Vertex_Palette');mi=len(j['meshes']);j['meshes'].append({'name':'Red_Bramble_Flowers_Independent','primitives':[{'attributes':{'POSITION':p,'NORMAL':n,'COLOR_0':c},'indices':i,'material':mat,'mode':4}]});ni=len(j['nodes']);j['nodes'].append({'mesh':mi,'name':'Red_Bramble_Flowers_Independent'});j['scenes'][j.get('scene',0)]['nodes'].append(ni);buf.extend(b'\0'*((-len(buf))%4));j['buffers'][0]['byteLength']=len(buf)
for k in ['materials','textures','images','samplers']:assert j.get(k)==old.get(k)
assert bytes(buf[:len(oldbin)])==oldbin
for k in ['accessors','bufferViews','meshes','nodes']:assert j[k][:len(old[k])]==old[k]
js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);data=struct.pack('<III',0x46546c67,2,28+len(js)+len(buf))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(buf),0x004e4942)+buf;(out/'Red_Bramble_Flowers_Candidate.glb').write_bytes(data)
(out/'glb-proof.json').write_text(json.dumps({'status':'PASS','oldBinaryExactPrefix':True,'allOldNodesMeshesAccessorsViewsExact':True,'allMaterialsTexturesExact':True,'addedTriangles':len(I)//3,'addedPrimitives':1,'addedAttributeBytes':len(buf)-len(oldbin),'sha256':hashlib.sha256(data).hexdigest()},indent=2))
