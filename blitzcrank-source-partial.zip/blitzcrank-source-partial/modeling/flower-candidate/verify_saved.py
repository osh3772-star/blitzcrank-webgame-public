import bpy,json,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
def plain(v):
 if hasattr(v,'to_dict'):return plain(v.to_dict())
 if hasattr(v,'to_list'):return plain(v.to_list())
 if isinstance(v,dict):return {k:plain(x)for k,x in v.items()}
 if isinstance(v,(tuple,list)):return [plain(x)for x in v]
 if v is None or isinstance(v,(str,int,float,bool)):return v
 raise TypeError(type(v))
def signatures():
 result={}
 for o in bpy.data.objects:
  rec={'type':o.type,'matrix':[list(row)for row in o.matrix_world],'data':o.data.name if o.data else None,'props':plain(dict(o.items()))}
  if o.type=='MESH':
   m=o.data;rec.update(vertices=[list(v.co)for v in m.vertices],polygons=[list(p.vertices)for p in m.polygons],materials=[m.name for m in m.materials],colors={a.name:[list(d.color)for d in a.data]for a in m.color_attributes})
  result[o.name]=hashlib.sha256(json.dumps(rec,sort_keys=True).encode()).hexdigest()
 return result

bpy.ops.wm.open_mainfile(filepath=str(out/'source/Summoners_Rift_Structure_Study_49.blend'));expected=signatures();bpy.ops.wm.open_mainfile(filepath=str(out/'Red_Bramble_Flowers_Candidate.blend'));actual=signatures();different=[k for k,v in expected.items()if actual[k]!=v];print('DIFFERENT',different);assert not different;assert set(actual)-set(expected)=={'Red_Bramble_Flowers_Independent'};(out/'validation/saved-native-proof.json').write_text(json.dumps({'pass':True,'originalObjectsVerified':len(expected),'additionalObjects':1},indent=2))
