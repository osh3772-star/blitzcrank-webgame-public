import bpy,bmesh,math,json,hashlib
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
out=Path(__file__).resolve().parent;src=out/'source/Summoners_Rift_Structure_Study_49.blend';bpy.ops.wm.open_mainfile(filepath=str(src))
def plain(v):
 if hasattr(v,'to_dict'):return plain(v.to_dict())
 if hasattr(v,'to_list'):return plain(v.to_list())
 if isinstance(v,dict):return {k:plain(x)for k,x in v.items()}
 if isinstance(v,(tuple,list)):return [plain(x)for x in v]
 if v is None or isinstance(v,(str,int,float,bool)):return v
 raise TypeError(type(v))
def signatures():
 result={}
 for o in bpy.data.objects:
  rec={'type':o.type,'matrix':[list(row)for row in o.matrix_world],'data':o.data.name if o.data else None,'props':plain(dict(o.items()))}
  if o.type=='MESH':
   m=o.data;rec.update(vertices=[list(v.co)for v in m.vertices],polygons=[list(p.vertices)for p in m.polygons],materials=[m.name for m in m.materials],colors={a.name:[list(d.color)for d in a.data]for a in m.color_attributes})
  result[o.name]=hashlib.sha256(json.dumps(rec,sort_keys=True).encode()).hexdigest()
 return result
before=signatures();print('SOURCE_SIGNATURES',len(before),flush=True);trees={};sv=[];st=[]
for o in bpy.data.objects:
 if o.type!='MESH':continue
 o.data.calc_loop_triangles();v=[o.matrix_world@p.co for p in o.data.vertices];t=[tuple(t.vertices)for t in o.data.loop_triangles];trees[o.name]=BVHTree.FromPolygons(v,t,all_triangles=True)
 if o.name in ['Fractured_Cliff_Boulders','Continuous_Cliff_Walls']:
  off=len(sv);sv.extend(v);st.extend(tuple(off+i for i in q)for q in t)
support=BVHTree.FromPolygons(sv,st,all_triangles=True);V=[];F=[];C=[];roots=[];rejected=[]
for x,y in [(-1.9,31.45),(-2.25,31.8),(-2.3,31.2),(-.05,31.3),(.3,31.6),(-1.7,30.8),(-2.7,31.4),(-.1,30.8),(-2.6,32.2),(-3,31.7),(-2.7,30.8),(-3.2,31.3)]:
 if len(roots)==3:break
 hit,n,face,d=support.ray_cast(Vector((x,y,15)),Vector((0,0,-1)),20)
 if hit is None or n.z<.65:continue
 if any((hit-Vector(q)).length<.42 for q in roots):continue
 k=len(roots);h=[.42,.34,.51][k];r=[.19,.15,.18][k];v=[];f=[];colors=[];profile=[(.10,-.12),(.11,.03),(.095,.65),(.52,.76),(1,.88),(.2,.94)]
 for ri,(rr,z) in enumerate(profile):
  for j in range(30):
   a=j*math.tau/30;lobes=(.73+.27*math.cos(5*a+k*.7)) if ri==4 else 1
   v.append(hit+Vector((r*rr*lobes*math.cos(a)+.02*z*z,r*rr*lobes*math.sin(a),h*z)))
 for ri in range(5):
  for j in range(30):
   a=ri*30+j;b=ri*30+(j+1)%30;c=b+30;dd=a+30;f.extend([(a,b,c),(a,c,dd)]);col=(.12,.20,.055,1)if ri<2 else(.38,.065+.02*k,.018,1);colors.extend([col,col])
 f.append(tuple(reversed(range(30))));colors.append((.10,.14,.04,1));f.append(tuple(150+j for j in range(30)));colors.append((.54,.28,.025,1))
 bad=[]
 for point in v[:30]:
  q,normal,fi,d=support.find_nearest(point)
  if (point-q).dot(normal)>=0:bad.append('root-not-inside-support');break
 tree=BVHTree.FromPolygons(v,f,all_triangles=False)
 for name,old in trees.items():
  pairs=tree.overlap(old)
  if pairs:
   # BVH polygon IDs are input faces; only buried basal rings may contact supports.
   maxdist=max((v[i]-hit).length for a,b in pairs for i in f[a])
   if name not in ['Fractured_Cliff_Boulders','Continuous_Cliff_Walls'] or maxdist>.09:bad.append(name)
 if bad:rejected.append({'xy':[x,y],'objects':bad});continue
 off=len(V);V.extend(v);F.extend(tuple(i+off for i in q)for q in f);C.extend(colors);roots.append(list(hit))
assert len(roots)==3,{'roots':roots,'rejected':rejected}
m=bpy.data.meshes.new('Red_Bramble_Flowers_Independent');m.from_pydata(V,[],F);m.update();o=bpy.data.objects.new('Red_Bramble_Flowers_Independent',m);bpy.context.scene.collection.objects.link(o);m.materials.append(bpy.data.materials['Study_Vertex_Palette']);col=m.color_attributes.new(name='StudyColor',type='BYTE_COLOR',domain='CORNER')
for poly,color in zip(m.polygons,C):
 for li in poly.loop_indices:col.data[li].color=color
m.color_attributes.active_color=col;bm=bmesh.new();bm.from_mesh(m);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);assert all(e.is_manifold for e in bm.edges);bm.to_mesh(m);bm.free();m.calc_loop_triangles();col=m.color_attributes['StudyColor']
o['purpose']='Independent red bramble decorative flower candidate; not official v50, no gameplay or collision change.'
after=signatures();assert all(after[name]==digest for name,digest in before.items());print('OLD_OBJECTS_PRESERVED',flush=True)
(out/'new-mesh.json').write_text(json.dumps({'vertices':[list(v.co)for v in m.vertices],'triangles':[list(t.vertices)for t in m.loop_triangles],'normals':[list(t.normal)for t in m.loop_triangles],'colors':[[list(col.data[li].color)for li in t.loops]for t in m.loop_triangles]}))
(out/'validation/model-proof.json').write_text(json.dumps({'originalObjects':len(before),'originalObjectSignatures':before,'sourceSHA':hashlib.sha256(src.read_bytes()).hexdigest(),'roots':roots,'rejectedSites':rejected,'vertices':len(m.vertices),'triangles':len(m.loop_triangles),'closedManifold':True,'originalObjectDataUnchanged':True,'officialPromoted':False},indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(out/'Red_Bramble_Flowers_Candidate.blend'),relative_remap=False)
