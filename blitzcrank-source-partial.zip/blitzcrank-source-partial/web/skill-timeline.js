/** Simulation-time animation events; never use wall-clock time for skill casts. */
export function createSkillTimeline({onEvent=()=>{},onComplete=()=>{}}={}) {
  let current=null, sequence=0;
  function emit(from,to,includeStart=false) {
    const active=current;
    if(!active)return;
    for(const event of active.events) {
      if((event.time>from||(includeStart&&event.time===0))&&event.time<=to) {
        onEvent({...event,clip:active.name,sequence:active.sequence});
        // Handlers may cancel this cast or replace it with the next phase.
        if(current!==active)return;
      }
    }
  }
  return {
    play(clip,{events=clip.events??[],loop=clip.loop??false}={}) {
      if(!clip?.name||!Number.isFinite(clip.duration)||clip.duration<=0)throw new Error('Invalid skill timeline');
      const valid=events.map(e=>({...e})).sort((a,b)=>a.time-b.time);
      if(valid.some(e=>!Number.isFinite(e.time)||e.time<0||e.time>clip.duration))throw new Error('Skill event outside clip');
      current={name:clip.name,duration:clip.duration,time:0,loop,events:valid,sequence:++sequence};
      emit(0,0,true);return sequence;
    },
    step(dt) {
      if(!current||!Number.isFinite(dt)||dt<=0)return;
      const active=current;
      // A delayed frame must not replay an unbounded backlog of looping VFX.
      const total=active.time+dt;let next=Math.min(total,active.duration);
      // Snap only floating-point noise at authored boundaries. Otherwise .4s
      // can remain .39999999999999997 and arrive a whole frame after a .3s
      // impact that began .1s later. Storing the snapped time prevents replay.
      const epsilon=16*Number.EPSILON*Math.max(1,active.duration);
      for(const boundary of [...active.events.map(event=>event.time),active.duration])if(Math.abs(next-boundary)<=epsilon)next=boundary;
      emit(active.time,next);
      if(current!==active)return;
      active.time=next;
      if(next>=active.duration) {
        if(active.loop){active.time=total%active.duration;if(active.time<=epsilon||active.duration-active.time<=epsilon)active.time=0;emit(0,active.time,true);}
        else {current=null;onComplete({name:active.name,sequence:active.sequence});}
      }
    },
    stop(){current=null;sequence++;},
    get state(){return current?{name:current.name,time:current.time,duration:current.duration,sequence:current.sequence}:null;}
  };
}
