import {createOnlineView} from './online-duel-view.js';
import {createOnlineDuelWorld,ONLINE_DT} from './online-duel-world.js';
import {createManualPeer,parseSignal} from './online-duel-peer.js';
import {createOnlineSession} from './online-duel-session.js';
import {ONLINE_ACTIONS as A,makeInput} from './online-duel-protocol.js';
const $=id=>document.getElementById(id),canvas=$('arena'),keys=new Set();
let view,peer,session,world,latest,local='human',seq=0,yaw=0,pitch=0,actions=0,moveX=0,moveZ=0,accumulator=0,previousTime=0,lastEpoch=-1,canControl=false,touch=false,pendingReady=false,connectionGeneration=0,drag=null,padId=null;
let lastStateAt=null,lastStateAgeText='';
let readyAttempt=0,pendingLockPromise=false,controlTouch=false,pendingUnlock=false;
function cancelReady(){pendingReady=false;pendingLockPromise=false;readyAttempt++;}
function releaseMouse(){
 if(document.pointerLockElement!==canvas||pendingUnlock)return;
 pendingUnlock=true;document.exitPointerLock();
}
function updateStateAge(){
 let text='경기 상태를 기다리는 중';
 if(latest?.closed)text='연결 종료 · 새 연결이 필요합니다';
 else if(latest&&local==='human')text='방장 로컬 판정 · 지연 미측정';
 else if(latest&&lastStateAt!==null){
  const elapsed=Math.max(0,performance.now()-lastStateAt);
  text=`경기 상태 수신 ${(Math.floor(elapsed/100)/10).toFixed(1)}초 전${elapsed>=500?' · 수신 대기':''}`;
 }
 if(text!==lastStateAgeText){$('state-age').textContent=text;lastStateAgeText=text;}
}
const status=text=>{ $('status').textContent=text; $('connection-status').textContent=text; };
const codeStatus=text=>{ $('code-status').textContent=text; };
function networkDiagnostics(d){
 const label=(map,key,fallback)=>Object.hasOwn(map,key)?map[key]:fallback;
 const stages={'idle':'연결 전','creating-offer':'초대 준비','setting-offer':'초대 적용','setting-answer':'응답 적용','gathering':'주소 수집 중','offer-ready':'응답 코드 대기','answer-ready':'방장의 응답 적용 대기','connecting':'직접 연결 확인 중','connected':'데이터 연결됨','closed':'연결 종료'};
 const count=value=>Number.isInteger(value)&&value>=0&&value<=4096?String(value):'?';
 const local=d?.localCandidates,remote=d?.remoteCandidates;
 const candidates=local?.available?`내 후보 ${count(local.total)} (직접 ${count(local.host)} / 서버 확인 ${count(local.srflx)} / 중계 ${count(local.relay)})`:'내 후보 미확인';
 const ice=label({new:'ICE 대기',checking:'ICE 확인 중',connected:'ICE 연결',completed:'ICE 완료',disconnected:'ICE 중단',failed:'ICE 실패',closed:'ICE 종료'},d?.ice,'ICE 미확인');
 const gathering=label({new:'주소 수집 전',gathering:'주소 수집 중',complete:'주소 수집 완료'},d?.gathering,'주소 수집 미확인');
 const rtt=d?.statsState==='available'&&Number.isInteger(d.roundTripMs)&&d.roundTripMs>=0&&d.roundTripMs<=60000?`연결 점검 왕복 ${d.roundTripMs}ms`:'왕복 지연 미측정';
 const text=`외부 연결 서버 없음 · ${label(stages,d?.stage,'연결 전')} · ${gathering} · ${candidates} · 상대 후보 ${remote?.available?count(remote.total):'?'} · ${ice} · ${rtt}`;
 $('network-diagnostics').textContent=$('network-diagnostics-hud').textContent=text;
}
function lobbyRole(role){
 $('incoming-label').textContent=role==='host'?'참가자에게 받은 응답 코드':role==='guest'?'방장에게 받은 초대 코드':'상대에게 받은 코드';
 $('outgoing-label').textContent=role==='host'?'참가자에게 보낼 초대 코드 (15분 유효)':role==='guest'?'방장에게 보낼 응답 코드 (15분 유효)':'상대에게 보낼 코드 (15분 유효)';
}
function incomingCode(kind){
 const code=$('incoming').value;
 // Keep the original length for parseSignal's unchanged size limit.
 if(!code.trim()){$('incoming').focus?.();throw Error(kind+' 코드를 먼저 아래 입력칸에 붙여 넣어 주세요.');}
 return code;
}
function endedMessage(reason){
 const messages={
  'invitation-expired':'코드의 15분 유효 시간이 지났습니다.',
  'gathering-timeout':'15초 동안 연결 주소 수집이 끝나지 않았습니다. 브라우저와 네트워크 상태를 확인해 주세요.',
  'unsupported-browser':'이 브라우저는 WebRTC 데이터 연결을 지원하지 않습니다. WebRTC를 지원하는 브라우저에서 열어 주세요.',
  'connection-establishment-timeout':'응답 적용 후 30초 동안 연결되지 않았습니다. 두 사람의 네트워크나 방화벽이 직접 연결을 막을 수 있습니다. 이 시험에는 중계 서버가 없습니다.',
  'connection-timeout':'상대의 응답이 8초 이상 없어 연결을 종료했습니다. 양쪽의 인터넷 연결과 열린 게임 화면을 확인해 주세요.',
  'peer-failed':'브라우저가 직접 연결에 실패했습니다. 서로 다른 네트워크에서는 현재 연결 방식이 동작하지 않을 수 있습니다.',
  'channel-error':'데이터 연결에서 오류가 발생했습니다.',
  'channel-closed':'상대 또는 브라우저가 데이터 연결을 닫았습니다.',
  'negotiation-failed':'연결 주소를 준비하거나 받은 응답을 적용하지 못했습니다.',
  'invalid-state':'검증을 통과하지 못한 경기 상태를 받아 중단했습니다. (invalid-state)',
  'invalid-message':'검증을 통과하지 못한 연결 메시지를 받아 중단했습니다.',
  'left':'연결을 종료했습니다.',
 };
 return (messages[reason]||'연결이 종료됐습니다.')+' 새 연결을 눌러 양쪽 모두 새 코드를 교환해 주세요. 이전 점수는 이어지지 않습니다.';
}
function clear(){
 keys.clear();moveX=moveZ=actions=0;const oldDrag=drag,oldPad=padId;drag=null;padId=null;
 releaseContact(canvas,oldDrag?.id);releaseContact($('pad'),oldPad);
}
function ownsContact(element,id){try{return id!==null&&id!==undefined&&element.hasPointerCapture(id);}catch{return false;}}
function captureContact(element,id){try{element.setPointerCapture(id);return ownsContact(element,id);}catch{return false;}}
function releaseContact(element,id){try{if(ownsContact(element,id))element.releasePointerCapture(id);}catch{/* Cleanup must still pause or close the session. */}}
function pruneContacts(){
 if(drag&&!ownsContact(canvas,drag.id))drag=null;
 if(padId!==null&&!ownsContact($('pad'),padId)){padId=null;moveX=moveZ=0;}
}
function resetRoom(){
 if(!view)return;
 // A new explicit invitation is a new match, never an automatic reconnect.
 connectionGeneration++;cancelReady();canControl=false;clear();
 const oldPeer=peer,oldSession=session;peer=session=world=latest=null;
 oldPeer?.close('new-room');oldSession?.disconnect('new-room');
 local='human';seq=0;yaw=pitch=accumulator=previousTime=0;lastEpoch=-1;lastStateAt=null;updateStateAge();
 view.reset();releaseMouse();
 $('incoming').value=$('outgoing').value='';codeStatus('');networkDiagnostics(null);lobbyRole(null);$('host').disabled=$('join').disabled=false;
 $('accept').disabled=$('copy').disabled=$('ready').disabled=true;
 $('lobby').hidden=false;$('hud').hidden=true;$('resume').hidden=true;$('rematch').hidden=true;$('rematch').textContent='재대결 동의';
 $('score').textContent='0 : 0';$('phase').textContent=$('cooldowns').textContent='';
 status('새 연결을 준비했습니다. 이전 경기는 이어지지 않으며 양쪽 모두 새 코드로 참가해 주세요.');
}
function interrupt(reason='일시정지'){cancelReady();canControl=false;clear();session?.interrupt(reason);view?.pauseAudio();releaseMouse();$('resume').hidden=!session||!peer?.connected||!!latest?.closed;}
function receiveState(s){
 latest=s;lastStateAt=performance.now();updateStateAge();$('ready').disabled=false;if(s.epoch!==lastEpoch){lastEpoch=s.epoch;clear();$('rematch').textContent='재대결 동의';yaw=s.actors[local].yaw;pitch=s.actors[local].pitch;}
 view.show(s,local,{remoteSmoothing:local==='bot'&&$('smooth-remote').checked,localPaused:!canControl});const mine=local==='human'?0:1,other=1-mine;$('score').textContent=`${s.match.scores[mine].points} : ${s.match.scores[other].points}`;
 const resultText=s.match.phase==='matchComplete'?(s.match.winnerId===local?'승리!':'상대 승리'):null;
 const text=s.closed?(resultText?resultText+' · 연결 종료':'연결 종료 · 추가 득점 없음'):s.paused?'두 플레이어의 준비를 기다리는 중':s.match.phase==='countdown'?`준비 ${Math.ceil(s.match.remainingMs/1000)}`:s.match.phase==='roundReset'?`다음 판까지 ${Math.ceil(s.match.remainingMs/1000)}초`:s.match.phase==='matchComplete'?(s.match.winnerId===local?'승리!':'상대 승리'):s.pendingGrab?'그랩 · 끌어오는 중':s.tieRemaining?'동시 명중 · 재시도':'Q / E / R 적중 +1 · 먼저 3승';
 $('phase').textContent=text;const a=s.actors[local],k=a.skills;$('cooldowns').textContent=`Q ${a.qCooldown.toFixed(1)} · W ${k.cooldown.W.toFixed(1)} · E ${k.phase==='E_Hold'?'강화됨':k.cooldown.E.toFixed(1)} · R ${k.cooldown.R.toFixed(1)} · 점멸 ${a.flash.remaining.toFixed(1)}`;
 $('resume').hidden=s.closed||(!s.paused&&canControl);$('rematch').hidden=!(s.resultReady&&!s.closed);$('rematch').disabled=s.paused||s.closed;if(s.closed){canControl=false;clear();}
}
function ensureSession(){
 if(session)return;local=peer.role==='host'?'human':'bot';
 if(local==='human')world=createOnlineDuelWorld({session:peer.session,skillClips:view.skillClips,obstacles:view.obstacles,aimMode:'third',socketProvider:(id,a)=>view.socket(id,a)});
 const generation=connectionGeneration;
 session=createOnlineSession({role:peer.role,session:peer.session,world,send:value=>generation===connectionGeneration&&peer.send(value),onState:s=>{if(generation===connectionGeneration)receiveState(s);},onStatus:reason=>{if(generation!==connectionGeneration)return;status('대전 중단: '+reason);cancelReady();canControl=false;clear();$('resume').hidden=false;if(['invalid-state','remote-closed'].includes(reason))peer?.close(reason);}});
 $('ready').disabled=!latest;status('연결됐습니다. 양쪽 모두 준비를 눌러 주세요.');
 if(world)session.step();
}
function createPeer(){
 if(peer)throw Error('새 연결 버튼을 누른 뒤 새 초대를 만들어 주세요.');
 const generation=connectionGeneration;
 peer=createManualPeer({onDiagnostics:value=>{if(generation===connectionGeneration)networkDiagnostics(value);},onMessage:value=>{if(generation!==connectionGeneration)return;ensureSession();session.receive(value); /* Late round/input packets are dropped. */},onStatus:event=>{if(generation!==connectionGeneration)return;if(event.state==='connected')ensureSession();else if(event.state==='closed'){session?.disconnect(event.detail);status(endedMessage(event.detail));codeStatus('이 연결의 코드는 더 이상 사용할 수 없습니다. 새 연결에서 코드를 다시 만들어 주세요.');$('copy').disabled=true;cancelReady();canControl=false;clear();view?.pauseAudio();$('ready').disabled=$('accept').disabled=true;$('resume').hidden=true;releaseMouse();}else if(event.state==='interrupted')interrupt(event.detail);}});
 return peer;
}
$('smooth-remote').onchange=()=>{if(latest)view.show(latest,local,{remoteSmoothing:local==='bot'&&$('smooth-remote').checked,localPaused:!canControl});};
async function guarded(fn){const generation=connectionGeneration;try{await fn();}catch(error){if(generation===connectionGeneration&&!peer?.closed)status(error.message);}}
$('host').onclick=()=>guarded(async()=>{const p=createPeer();lobbyRole('host');codeStatus('');$('host').disabled=$('join').disabled=true;status('초대 코드를 만드는 중입니다. 잠시 기다려 주세요.');const code=await p.host();if(p!==peer||p.closed)return;$('outgoing').value=code;$('copy').disabled=false;$('accept').disabled=false;status('1. 초대 코드를 참가자에게 보내세요. 2. 참가자에게 받은 응답 코드를 입력하고 적용하세요.');});
$('join').onclick=()=>guarded(async()=>{const invite=incomingCode('방장의 초대');parseSignal(invite,{type:'offer'});const p=createPeer();lobbyRole('guest');codeStatus('');$('host').disabled=$('join').disabled=true;status('응답 코드를 만드는 중입니다. 잠시 기다려 주세요.');const code=await p.join(invite);if(p!==peer||p.closed)return;$('outgoing').value=code;$('copy').disabled=false;status('응답 코드를 방장에게 보내 주세요. 방장이 적용한 뒤 연결되면 양쪽 모두 준비를 눌러 주세요.');});
$('accept').onclick=()=>guarded(async()=>{
 const p=peer;if(!p)return;$('accept').disabled=true;
 try{await p.accept(incomingCode('참가자의 응답'));}catch(error){
  if(p===peer){if(p.closed)return;$('accept').disabled=false;}throw error;
 }
 if(p!==peer||p.closed)return;
 if(!p.connected)status('상대 연결을 기다리는 중…');
});
$('copy').onclick=async()=>{
 const p=peer,field=$('outgoing'),code=field.value,generation=connectionGeneration;
 if($('copy').disabled||!code||!p||p.closed)return;
 $('copy').disabled=true;
 const current=()=>generation===connectionGeneration&&p===peer&&!p.closed&&field.value===code;
 try{
  if(typeof navigator.clipboard?.writeText!=='function')throw Error('clipboard-unavailable');
  await navigator.clipboard.writeText(code);
  if(current())codeStatus('코드를 복사했습니다. 연결할 상대에게만 보내 주세요.');
 }catch{
  if(!current())return;
  let selected=false;
  try{field.focus();field.select();field.setSelectionRange(0,code.length);selected=field.selectionStart===0&&field.selectionEnd===code.length;}catch{/* Manual selection remains available. */}
  codeStatus((selected?'자동 복사를 사용할 수 없어 코드 전체를 선택했습니다.':'자동 복사를 사용할 수 없습니다. 보낼 코드 칸을 직접 선택해 주세요.')+' Ctrl+C 또는 ⌘C로 복사하거나, 모바일에서는 길게 눌러 복사해 주세요. 상대에게만 보내 주세요.');
 }finally{if(current())$('copy').disabled=false;}
};
function activate(usesTouch=false){cancelReady();clear();if(!session?.ready(true)){interrupt('준비를 완료하지 못했습니다. 연결 상태를 확인한 뒤 다시 준비를 눌러 주세요.');return;}controlTouch=usesTouch;canControl=true;$('lobby').hidden=true;$('hud').hidden=false;$('resume').hidden=!latest?.paused;}
function ready(){
 if(!session||!peer.connected||pendingReady)return;
 // An intentional asynchronous unlock is not a new mouse capture. Wait for
 // its completion and another explicit gesture rather than send false ready.
 if(!touch&&pendingUnlock){status('마우스 고정 해제가 끝난 뒤 다시 계속하기를 눌러 주세요.');return;}
 // Request capture in the same trusted gesture, not after an audio fetch.
 view.unlock();
 if(touch){activate(true);return;}
 const generation=connectionGeneration,attempt=++readyAttempt;pendingReady=true;pendingLockPromise=false;
 const current=()=>generation===connectionGeneration&&attempt===readyAttempt&&pendingReady;
 try{
  const request=canvas.requestPointerLock();
  if(request&&typeof request.then==='function'){
   if(current())pendingLockPromise=true;
   // Promise results belong to this attempt, not merely to its connection.
   request.then(()=>{if(current()&&document.pointerLockElement===canvas)activate();},()=>{if(current())interrupt('마우스 고정이 필요합니다. 다시 계속하기를 눌러 주세요.');});
  }
  if(current()&&document.pointerLockElement===canvas)activate();
 }catch{if(current())interrupt('마우스 고정이 필요합니다. 다시 계속하기를 눌러 주세요.');}
}
$('ready').onclick=$('resume').onclick=()=>guarded(ready);$('pause').onclick=()=>interrupt();$('rematch').onclick=()=>{if(session?.rematch())$('rematch').textContent='상대 재대결 동의 대기';};$('leave').onclick=()=>{peer?.close('left');session?.disconnect();status('종료했습니다. 새 연결 버튼으로 다시 시작할 수 있습니다.');};$('new-room').onclick=resetRoom;
const keyActions={KeyQ:A.Q,ShiftLeft:A.W,ShiftRight:A.W,KeyE:A.E,KeyR:A.R,KeyF:A.FLASH,Space:A.JUMP};
addEventListener('keydown',e=>{if(['INPUT','TEXTAREA'].includes(e.target?.tagName)||(e.target?.tagName==='BUTTON'&&['Enter','Space'].includes(e.code)))return;if(e.code==='Escape'){interrupt();return;}if(!canControl||e.repeat)return;if(['KeyW','KeyA','KeyS','KeyD'].includes(e.code))keys.add(e.code);if(keyActions[e.code]){e.preventDefault();actions|=keyActions[e.code];}});addEventListener('keyup',e=>keys.delete(e.code));
addEventListener('mousemove',e=>{if(document.pointerLockElement===canvas&&canControl){yaw-=e.movementX*.0021;pitch=Math.max(-1.25,Math.min(1.25,pitch-e.movementY*.0021));}});
canvas.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')return;if(canControl&&document.pointerLockElement===canvas&&e.button===0){e.preventDefault();actions|=A.PUNCH;}});
canvas.addEventListener('contextmenu',e=>e.preventDefault());document.addEventListener('pointerlockchange',()=>{const locked=document.pointerLockElement===canvas;if(!locked)pendingUnlock=false;if(pendingReady&&locked&&!pendingUnlock)activate();else if(!pendingReady&&(!canControl||controlTouch)&&locked)releaseMouse();else if(!controlTouch&&canControl&&!locked)interrupt('마우스 고정 해제');});document.addEventListener('pointerlockerror',()=>{if(pendingReady&&!pendingLockPromise)interrupt('마우스 고정 요청 실패');});
addEventListener('blur',()=>interrupt('화면 이탈'));addEventListener('pagehide',()=>interrupt('페이지 이탈'));document.addEventListener('visibilitychange',()=>{if(document.hidden)interrupt('화면 숨김');});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();interrupt('그래픽 연결 중단');status('그래픽 연결이 중단됐습니다. 페이지를 다시 열어 주세요.');peer?.close('graphics-lost');});
canvas.addEventListener('pointerdown',e=>{pruneContacts();if(e.pointerType!=='touch'||!canControl||drag)return;if(!captureContact(canvas,e.pointerId))return;drag={id:e.pointerId,x:e.clientX,y:e.clientY};});canvas.addEventListener('pointermove',e=>{pruneContacts();if(!drag||drag.id!==e.pointerId||!canControl)return;yaw-=(e.clientX-drag.x)*.0021;pitch=Math.max(-1.25,Math.min(1.25,pitch-(e.clientY-drag.y)*.0021));drag={id:e.pointerId,x:e.clientX,y:e.clientY};});for(const type of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(type,e=>{if(drag?.id===e.pointerId)drag=null;});
const pad=$('pad');function movePad(e){const r=pad.getBoundingClientRect();moveX=Math.max(-1,Math.min(1,(e.clientX-r.left-r.width/2)/38));moveZ=Math.max(-1,Math.min(1,(e.clientY-r.top-r.height/2)/38));}
pad.onpointerdown=e=>{pruneContacts();if(!canControl||padId!==null||(e.button!==undefined&&e.button!==0))return;if(!captureContact(pad,e.pointerId))return;padId=e.pointerId;movePad(e);};pad.onpointermove=e=>{pruneContacts();if(e.pointerId===padId&&canControl)movePad(e);};for(const type of ['pointerup','pointercancel','lostpointercapture'])pad.addEventListener(type,e=>{if(e.pointerId===padId){padId=null;moveX=moveZ=0;}});
for(const button of document.querySelectorAll('[data-action]'))button.onpointerdown=e=>{if(e.button!==undefined&&e.button!==0)return;e.preventDefault();if(canControl)actions|=A[button.dataset.action];};
// A hybrid device may switch back to a mouse for its next explicit ready.
document.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')touch=true;else if(e.pointerType==='mouse'&&(e.button===undefined||e.button===0))touch=false;},true);
addEventListener('resize',()=>{clear();drag=null;padId=null;view?.resize();});
function frame(time){requestAnimationFrame(frame);const dt=previousTime?Math.min(.1,(time-previousTime)/1000):0;previousTime=time;if(!view)return;pruneContacts();
 accumulator+=dt;let count=0;
 while(accumulator>=ONLINE_DT&&count++<5){accumulator-=ONLINE_DT;
  if(session&&peer.connected){
   if(canControl&&latest){if(latest.active&&!latest.paused&&!latest.closed){yaw=Math.atan2(Math.sin(yaw),Math.cos(yaw));session.input(makeInput({session:peer.session,epoch:latest.epoch,seq:seq++,x:Math.max(-1,Math.min(1,(keys.has('KeyD')?1:0)-(keys.has('KeyA')?1:0)+moveX)),z:Math.max(-1,Math.min(1,(keys.has('KeyS')?1:0)-(keys.has('KeyW')?1:0)+moveZ)),yaw,pitch,actions}));}actions=0;}
   if(world)session.step();
  }
 }
 if(count>5)accumulator=0;
 updateStateAge();if(latest)view.camera(yaw,pitch,latest);view.render();
}
requestAnimationFrame(frame);
try{view=await createOnlineView(canvas);$('host').disabled=$('join').disabled=$('new-room').disabled=false;status('준비됐습니다. 방장은 초대를 만들고 상대는 받은 초대로 참가하세요.');window.__ONLINE_DUEL__={get state(){return latest;},get inspection(){return view.inspect();}};}catch(error){status('게임 준비 실패: '+error.message);}
