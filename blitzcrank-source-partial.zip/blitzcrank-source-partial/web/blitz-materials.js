// Source colors and emissive values are linear RGB, matching Blender's material
// data. Do not run them through an additional sRGB-to-linear conversion.
export function blitzMaterialProperties(part, defaults={}) {
 const m=part.material??{}, color=part.color?.slice(0,3)??[.6,.4,.16];
 const scalar=(value,fallback)=>Number.isFinite(value)?value:fallback;
 return {color,metalness:Math.min(1,Math.max(0,scalar(m.metalness,defaults.metalness??.73))),roughness:Math.min(1,Math.max(0,scalar(m.roughness,defaults.roughness??.38))),emissive:m.emissive?.slice(0,3)??[0,0,0],emissiveIntensity:Math.max(0,scalar(m.emissiveIntensity,1))};
}
// Lossless transport encoding; original authored file and model references stay intact.
const baseColorTransport={'./assets/blitz-materials/aged-yellow-basecolor.46f000102005e744.png':'./assets/blitz-materials/aged-yellow-basecolor.934272f6b63ea94b.png'};
const roughnessTransport={'./assets/blitz-materials/aged-yellow-roughness.de1e87c13e16d312.png':'./assets/blitz-materials/aged-yellow-roughness.5ab56dca175fc5e2.png'};
const textureFields={baseColorTexture:'color',roughnessTexture:'roughness'};
export async function loadBlitzTextures(THREE,data,bank=new Map(),loader=new THREE.TextureLoader()) {
 const tasks=[];
 for(const part of data.parts)for(const [field,usage] of Object.entries(textureFields)) {
  const path=part.material?.[field];if(!path)continue;
  // Player artwork is bundled locally; material files cannot point at trackers
  // or unrelated remote origins.
  if(!/^\.\/assets\/blitz-materials\/[A-Za-z0-9_.-]+\.png$/.test(path))throw new Error('Invalid player texture path: '+path);
  const key=usage+':'+path;
  if(!bank.has(key))bank.set(key,loader.loadAsync(baseColorTransport[path]??roughnessTransport[path]??path).then(texture=>{texture.colorSpace=usage==='color'?THREE.SRGBColorSpace:THREE.NoColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.anisotropy=4;bank.set(key,texture);return texture;}).catch(error=>{bank.delete(key);throw error;}));
  tasks.push(bank.get(key));
 }
 await Promise.all(tasks);return bank;
}
export function attachBlitzUV(THREE,geometry,part) {
 if(!part.uvs){if(part.material?.baseColorTexture||part.material?.roughnessTexture)throw new Error('Textured part has no UVs: '+part.name);return;}
 if(part.uvs.length!==geometry.attributes.position.count*2||!part.uvs.every(Number.isFinite))throw new Error('Invalid player UVs: '+part.name);
 geometry.setAttribute('uv',new THREE.Float32BufferAttribute(part.uvs,2));
}
export function blitzMaterialKey(part, defaults) {return JSON.stringify([blitzMaterialProperties(part,defaults),part.material?.baseColorTexture??null,part.material?.roughnessTexture??null]);}
export function createBlitzMaterial(THREE,part,defaults,bank=new Map()) {
 const p=blitzMaterialProperties(part,defaults);
 const textures={};for(const [field,usage] of Object.entries(textureFields)){const path=part.material?.[field];if(!path)continue;const texture=bank.get(usage+':'+path);if(!texture?.isTexture)throw new Error('Player texture not ready: '+path);textures[usage==='color'?'map':'roughnessMap']=texture;}
 return new THREE.MeshStandardMaterial({...p,...textures,color:new THREE.Color(...p.color),emissive:new THREE.Color(...p.emissive)});
}
