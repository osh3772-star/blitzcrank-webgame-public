// Presentation only. Never predicts, mutates snapshots, or supplies hit sockets.
// Delays ordinary remote grounded movement by 3 authority ticks (50 ms).
export const REMOTE_DELAY_TICKS=3;
const STEP_MS=1000/60,MAX_SAMPLES=24,MAX_GAP_TICKS=12,MAX_GAP_MS=250;
const copy=p=>({x:p.x,y:p.y,z:p.z});
function clearSegment(a,b,obstacles){
 for(const o of obstacles){
  if(Math.min(a.y,b.y)-1.7>=o.max.y)continue;
  let low=0,high=1,miss=false;
  for(const axis of ['x','z']){
   const lo=o.min[axis]-.42,hi=o.max[axis]+.42,d=b[axis]-a[axis];
   if(d===0){if(a[axis]<=lo||a[axis]>=hi){miss=true;break;}}
   else {const u=(lo-a[axis])/d,v=(hi-a[axis])/d;low=Math.max(low,Math.min(u,v));high=Math.min(high,Math.max(u,v));}
  }
  if(!miss&&low<high&&high>0&&low<1)return false;
 }
 return true;
}
function eligible(s,id){
 const a=s.actors[id],k=a.skills;
 return s.active&&!s.paused&&!s.closed&&!s.pendingGrab&&!s.tieRemaining&&s.match.phase==='active'&&a.grounded&&!a.knockup&&!a.hook&&!s.actors[id==='human'?'bot':'human'].hook&&a.punchTime===0&&!k.animation&&k.boost===0&&k.slow===0&&k.armed===0;
}
export function createRemoteSmoothing({obstacles=[]}={}){
 let samples=[],session=null,epoch=-1,remote=null,offset=0,cursor=0,lastNow=0,lastArrival=0,enabled=false;
 function reset(){samples=[];session=null;epoch=-1;remote=null;enabled=false;}
 function snap(s,id,now,allow){const a=s.actors[id];samples=[{tick:s.tick,position:copy(a.position),yaw:a.yaw,flash:a.flash.remaining}];session=s.session;epoch=s.epoch;remote=id;offset=now-s.tick*STEP_MS;cursor=s.tick;lastNow=lastArrival=now;enabled=allow;}
 function push(s,id,now,{smooth=true}={}){
  if(!Number.isFinite(now))throw TypeError('Finite presentation clock required');
  if(session===s.session&&s.epoch<epoch)return false;
  const previous=samples.at(-1),same=session===s.session&&epoch===s.epoch&&remote===id;
  if(same&&s.tick<previous.tick)return false;
  const allow=smooth&&eligible(s,id),a=s.actors[id];
  const flash=s.events.some(e=>e.type==='cast'&&e.id===id&&e.skill==='FLASH');
  if(!same||!allow||!enabled||flash||now<lastArrival||now-lastArrival>MAX_GAP_MS||s.tick-previous.tick>MAX_GAP_TICKS||a.flash.remaining>previous.flash+1e-6||Math.hypot(a.position.x-previous.position.x,a.position.y-previous.position.y,a.position.z-previous.position.z)>1.25||!clearSegment(previous.position,a.position,obstacles)){
   snap(s,id,now,allow);return true;
  }
  if(s.tick===previous.tick)return false;
  samples.push({tick:s.tick,position:copy(a.position),yaw:a.yaw,flash:a.flash.remaining});lastArrival=now;offset=Math.min(offset,now-s.tick*STEP_MS);
  while(samples.length>MAX_SAMPLES)samples.shift();return true;
 }
 function sample(now){
  if(!samples.length)return null;if(!Number.isFinite(now))throw TypeError('Finite presentation clock required');
  const newest=samples.at(-1);
  // An ordered burst after a stall must not replay a long obsolete path.
  if(newest.tick-cursor>MAX_GAP_TICKS){samples=[newest];cursor=newest.tick;offset=now-newest.tick*STEP_MS;lastNow=now;}
  const first=samples[0];
  const dt=Math.max(0,now-lastNow)/STEP_MS;lastNow=Math.max(lastNow,now);
  // Never move beyond received data. A stalled link freezes at the last point.
  const desired=Math.min(newest.tick,Math.max(first.tick,(now-offset)/STEP_MS-REMOTE_DELAY_TICKS));
  cursor=Math.max(first.tick,Math.min(newest.tick,cursor+Math.min(Math.max(0,desired-cursor),dt*1.1)));
  let a=first,b=first;for(let i=1;i<samples.length;i++){b=samples[i];if(cursor<=b.tick)break;a=b;}
  const t=b.tick>a.tick?Math.max(0,Math.min(1,(cursor-a.tick)/(b.tick-a.tick))):0;
  const yaw=a.yaw+Math.atan2(Math.sin(b.yaw-a.yaw),Math.cos(b.yaw-a.yaw))*t;
  const position={x:a.position.x+(b.position.x-a.position.x)*t,y:a.position.y+(b.position.y-a.position.y)*t,z:a.position.z+(b.position.z-a.position.z)*t};
  while(samples.length>2&&samples[1].tick<cursor)samples.shift();
  return {position,yaw,tick:cursor,authorityTick:newest.tick,smoothing:enabled&&cursor<newest.tick};
 }
 return {push,sample,reset,inspect:()=>({samples:samples.length,enabled,remote,session,epoch,cursor})};
}
