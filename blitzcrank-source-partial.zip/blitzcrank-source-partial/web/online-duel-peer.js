// Manual, invite-only signaling. No external ICE or signaling provider is used.
// A trusted host is not an anti-cheat server; cross-network reachability is not guaranteed.
import {ONLINE_PROTOCOL,boundedJSON,isSessionId} from './online-duel-protocol.js';
export const SIGNAL_MAX=120000;
export const SIGNAL_TTL_MS=15*60*1000;
export const CONNECT_TIMEOUT_MS=30000;
export const DIAGNOSTICS_INTERVAL_MS=2000;
const candidateType=value=>['host','srflx','prflx','relay'].includes(value)?value:'unknown';
const transportType=value=>['udp','tcp'].includes(value)?value:'unknown';
const enumValue=(value,allowed)=>allowed.includes(value)?value:'unknown';
// Counts only: never retain/return SDP, candidate addresses, mDNS names or ports.
export function summarizeIceCandidates(sdp){
 const result={available:typeof sdp==='string'&&sdp.length<=70000,total:0,host:0,srflx:0,prflx:0,relay:0,unknown:0};
 if(!result.available)return result;
 for(const line of sdp.split(/\r?\n/))if(line.startsWith('a=candidate:')){const fields=line.trim().split(/\s+/),kind=fields[6]==='typ'?candidateType(fields[7]):'unknown';result[kind]++;result.total++;}
 return result;
}
// Read only the explicitly selected successful pair. A nominated or succeeded
// pair is not proof that it carries the data channel. Missing stats stay unknown.
export function summarizeSelectedPair(report){
 const empty={roundTripMs:null,protocol:'unknown',localType:'unknown',remoteType:'unknown'};
 if(!report||typeof report.values!=='function'||typeof report.get!=='function')return empty;
 const ids=new Set();let entries=0;
 for(const item of report.values()){if(++entries>4096)return empty;if(item?.type==='transport'&&typeof item.selectedCandidatePairId==='string')ids.add(item.selectedCandidatePairId);}
 if(ids.size!==1)return empty;
 const pair=report.get([...ids][0]);if(pair?.type!=='candidate-pair'||pair.state!=='succeeded')return empty;
 const local=report.get(pair.localCandidateId),remote=report.get(pair.remoteCandidateId),seconds=pair.currentRoundTripTime;
 return {roundTripMs:typeof seconds==='number'&&Number.isFinite(seconds)&&seconds>=0&&seconds<=60?Math.round(seconds*1000):null,protocol:local?.type==='local-candidate'?transportType(local.protocol):'unknown',localType:local?.type==='local-candidate'?candidateType(local.candidateType):'unknown',remoteType:remote?.type==='remote-candidate'?candidateType(remote.candidateType):'unknown'};
}
class GatheringTimeoutError extends Error {}
class PeerUnavailableError extends Error {}
// Bounded reliable-channel recovery burst, with unchanged sustained message rate.
// 544 covers the 8-second timeout plus its 500ms polling edge at 60Hz
// with heartbeats and a small control-message margin. A separate UTF-8 byte
// budget prevents large packets from exploiting that recovery allowance.
export const RECEIVE_BUDGET=Object.freeze({initialMessages:240,maxMessages:544,messagesPerSecond:240,maxBytes:524288,bytesPerSecond:262144});
const b64=s=>btoa(String.fromCharCode(...new TextEncoder().encode(s)));
const decode=s=>new TextDecoder('utf-8',{fatal:true}).decode(Uint8Array.from(atob(s),c=>c.charCodeAt(0)));
const defaultClock={now:()=>performance.now(),setTimeout:(fn,n)=>setTimeout(fn,n),clearTimeout:id=>clearTimeout(id),setInterval:(fn,n)=>setInterval(fn,n),clearInterval:id=>clearInterval(id)};
export function encodeSignal({session,description,created=Date.now()}){
 const object={protocol:ONLINE_PROTOCOL,session,created,description:{type:description.type,sdp:description.sdp}};
 if(!isSessionId(session)||!['offer','answer'].includes(description.type)||typeof description.sdp!=='string'||description.sdp.length>70000)throw Error('Invalid signaling data');
 const code=b64(JSON.stringify(object));if(code.length>SIGNAL_MAX)throw Error('Signaling data is too large');return code;
}
export function parseSignal(code,{type,session,now=Date.now()}={}){
 if(typeof code!=='string'||code.length>SIGNAL_MAX)throw Error('초대 코드가 너무 큽니다.');
 let value;try{value=JSON.parse(decode(code.trim()));}catch{throw Error('초대 코드 형식을 확인해 주세요.');}
 if(value?.protocol!==ONLINE_PROTOCOL||!isSessionId(value.session)||!Number.isFinite(value.created)||Math.abs(now-value.created)>SIGNAL_TTL_MS||value.description?.type!==type||typeof value.description.sdp!=='string'||value.description.sdp.length>70000||!value.description.sdp.includes('a=fingerprint:')||(session&&session!==value.session))throw Error('초대가 만료됐거나 다른 방의 코드입니다.');
 return value;
}
export function createManualPeer({PeerConnection=globalThis.RTCPeerConnection,cryptoImpl=globalThis.crypto,clock=defaultClock,onMessage=()=>{},onStatus=()=>{},onDiagnostics=()=>{}}={}){
 let pc=null,channel=null,session=null,role=null,ended=false,heartbeat=null,deadline=null,gatherCancel=null;
 let lastReceive=0,lastPing=0,pressured=false,silent=false,budgetAt=0,messageBudget=RECEIVE_BUDGET.initialMessages,byteBudget=RECEIVE_BUDGET.maxBytes;
 let acceptingAnswer=false,answerAccepted=false;
 let stage='idle',statsState='unavailable',statsInFlight=false,statsGeneration=0,lastStatsAt=-Infinity,pairStats=summarizeSelectedPair(null);
 function diagnostics(){return {mode:'direct-only',externalIceServers:0,stage,closed:ended,gathering:enumValue(pc?.iceGatheringState,['new','gathering','complete']),ice:enumValue(pc?.iceConnectionState,['new','checking','connected','completed','disconnected','failed','closed']),connection:enumValue(pc?.connectionState,['new','connecting','connected','disconnected','failed','closed']),localCandidates:summarizeIceCandidates(pc?.localDescription?.sdp),remoteCandidates:summarizeIceCandidates(pc?.remoteDescription?.sdp),statsState,...pairStats};}
 function publishDiagnostics(nextStage){if(nextStage)stage=nextStage;try{onDiagnostics(diagnostics());}catch{/* Optional diagnostics cannot interrupt the match. */}}
 const notify=(state,detail='')=>{publishDiagnostics(['connected','offer-ready','answer-ready','connecting','closed'].includes(state)?state:undefined);onStatus({state,detail,session,role});};
 const transportInterrupted=()=>['disconnected','failed','closed'].includes(pc?.connectionState)||['disconnected','failed','closed'].includes(pc?.iceConnectionState);
 function invalidateStats(){statsGeneration++;pairStats=summarizeSelectedPair(null);statsState='unavailable';}
 function refreshStats(){
  if(ended||transportInterrupted()||channel?.readyState!=='open'||statsInFlight||clock.now()-lastStatsAt<DIAGNOSTICS_INTERVAL_MS||typeof pc?.getStats!=='function')return;
  lastStatsAt=clock.now();statsInFlight=true;const generation=++statsGeneration;statsState='pending';pairStats=summarizeSelectedPair(null);publishDiagnostics();
  const current=()=>!ended&&!transportInterrupted()&&generation===statsGeneration&&channel?.readyState==='open';
  Promise.resolve().then(()=>{if(current())return pc.getStats();}).then(report=>{if(!current())return;pairStats=summarizeSelectedPair(report);statsState=pairStats.roundTripMs===null?'unavailable':'available';}).catch(()=>{if(current()){pairStats=summarizeSelectedPair(null);statsState='unavailable';}}).finally(()=>{statsInFlight=false;if(!ended)publishDiagnostics();});
 }
 const assertOpen=()=>{if(ended)throw Error('연결이 종료됐습니다. 새 초대로 다시 시작해 주세요.');};
 const assertFresh=()=>{if(pc||ended)throw Error('새 연결을 시작하려면 먼저 새 연결 버튼을 눌러 주세요.');};
 function close(reason='closed'){
  if(ended)return;
  ended=true;statsGeneration++;statsInFlight=false;statsState='unavailable';pairStats=summarizeSelectedPair(null);clock.clearInterval(heartbeat);clock.clearTimeout(deadline);
  const cancel=gatherCancel;gatherCancel=null;cancel?.(Error('연결 주소 수집이 취소됐습니다.'));
  channel?.close();pc?.close();notify('closed',reason);
 }
 function expireAfter(ms,reason){clock.clearTimeout(deadline);deadline=clock.setTimeout(()=>close(reason),ms);}
 function bind(c){
  if(ended){c.close();return;}
  if(channel&&channel!==c){c.close();close('unexpected-channel');return;}
  if(c.label!=='rocket-hand-v1'||!c.ordered){c.close();close('invalid-channel');return;}
  channel=c;
  c.onopen=()=>{
   if(ended){c.close();return;}
   clock.clearTimeout(deadline);clock.clearInterval(heartbeat);
   lastReceive=lastPing=budgetAt=clock.now();messageBudget=RECEIVE_BUDGET.initialMessages;byteBudget=RECEIVE_BUDGET.maxBytes;silent=false;
   notify('connected');
   if(ended)return;
   refreshStats();
   heartbeat=clock.setInterval(()=>{
    const now=clock.now();
    if(now-lastReceive>8000){close('connection-timeout');return;}
    if(now-lastReceive>3500&&!silent){silent=true;notify('interrupted','응답이 없어 대전을 멈췄습니다.');}
    if(now-lastPing>=1000){send({type:'ping',protocol:ONLINE_PROTOCOL,session});lastPing=now;}
    refreshStats();
   },500);
  };
  c.onclose=()=>close('channel-closed');c.onerror=()=>close('channel-error');
  c.onmessage=e=>{
   if(ended)return;
   const now=clock.now(),elapsed=Math.max(0,now-budgetAt)/1000;budgetAt=Math.max(now,budgetAt);
   messageBudget=Math.min(RECEIVE_BUDGET.maxMessages,messageBudget+elapsed*RECEIVE_BUDGET.messagesPerSecond);
   byteBudget=Math.min(RECEIVE_BUDGET.maxBytes,byteBudget+elapsed*RECEIVE_BUDGET.bytesPerSecond);
   if(typeof e.data!=='string'||e.data.length>65536){close('invalid-message');return;}
   const bytes=new TextEncoder().encode(e.data).length;
   if(messageBudget+1e-9<1){close('message-rate-limit');return;}
   if(byteBudget+1e-6<bytes){close('message-byte-rate-limit');return;}
   // Clamp sub-ULP refill residue at quota boundaries, not an extra message.
   messageBudget=Math.max(0,messageBudget-1);byteBudget=Math.max(0,byteBudget-bytes);
   const value=boundedJSON(e.data);
   if(!value||value.protocol!==ONLINE_PROTOCOL||value.session!==session||(value.type==='input'&&e.data.length>4096)){close('invalid-message');return;}
   lastReceive=now;silent=false;if(value.type==='ping')return;onMessage(value);
  };
 }
 function init(nextRole,nextSession){
  if(pc||ended)throw Error('새 연결을 시작하려면 먼저 창을 새로 열어 주세요.');
  if(typeof PeerConnection!=='function')throw new PeerUnavailableError('이 브라우저는 WebRTC 데이터 연결을 지원하지 않습니다.');
  role=nextRole;session=nextSession;
  pc=new PeerConnection({iceServers:[],iceTransportPolicy:'all'});
  pc.onconnectionstatechange=()=>{if(ended)return;if(['failed','closed'].includes(pc.connectionState))close('peer-'+pc.connectionState);else if(pc.connectionState==='disconnected'){invalidateStats();notify('interrupted','연결이 끊겨 대전을 멈췄습니다.');}else publishDiagnostics();};
  pc.oniceconnectionstatechange=()=>{if(ended)return;if(transportInterrupted())invalidateStats();publishDiagnostics();};
  pc.onicegatheringstatechange=()=>{if(!ended)publishDiagnostics();};
  pc.ondatachannel=e=>{if(ended||role==='host'){e.channel.close();if(!ended)close('unexpected-channel');}else bind(e.channel);};
 }
 async function gathered(){
  assertOpen();publishDiagnostics('gathering');if(pc.iceGatheringState==='complete')return;
  await new Promise((resolve,reject)=>{
   let timeout,done=false;
   const finish=error=>{if(done)return;done=true;clock.clearTimeout(timeout);pc.removeEventListener('icegatheringstatechange',changed);gatherCancel=null;error?reject(error):resolve();};
   const changed=()=>{if(pc.iceGatheringState==='complete')finish();};
   gatherCancel=finish;pc.addEventListener('icegatheringstatechange',changed);timeout=clock.setTimeout(()=>finish(new GatheringTimeoutError('연결 주소 수집 시간이 초과됐습니다.')),15000);changed();
  });
  assertOpen();
 }
 function send(value){
  if(ended||channel?.readyState!=='open')return false;
  if(channel.bufferedAmount>262144){if(!pressured){pressured=true;notify('interrupted','전송 지연으로 대전을 멈췄습니다.');}return false;}
  pressured=false;
  let text;try{text=JSON.stringify(value);}catch{return false;}
  if(typeof text!=='string'||text.length>65536)return false;
  try{channel.send(text);return true;}catch{close('send-failed');return false;}
 }
 async function negotiate(work){try{return await work();}catch(error){
  if(ended)throw Error('연결이 종료되거나 취소됐습니다. 새 연결에서 다시 시작해 주세요.');
  const reason=error instanceof GatheringTimeoutError?'gathering-timeout':error instanceof PeerUnavailableError?'unsupported-browser':'negotiation-failed';close(reason);
  // Native exceptions can contain rejected SDP/addresses. Only fixed messages
  // leave this boundary; the terminal status keeps the recovery instructions.
  throw Error(reason==='gathering-timeout'?'연결 주소 수집 시간이 초과됐습니다.':reason==='unsupported-browser'?'이 브라우저는 WebRTC 데이터 연결을 지원하지 않습니다.':'연결 준비에 실패했습니다. 새 연결에서 코드를 다시 교환해 주세요.');
 }}
 return {
  async host(){
   assertFresh();
   return negotiate(async()=>{const bytes=new Uint8Array(16);cryptoImpl.getRandomValues(bytes);init('host',Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join(''));bind(pc.createDataChannel('rocket-hand-v1',{ordered:true}));publishDiagnostics('creating-offer');const offer=await pc.createOffer();assertOpen();await pc.setLocalDescription(offer);await gathered();assertOpen();expireAfter(SIGNAL_TTL_MS,'invitation-expired');notify('offer-ready');return encodeSignal({session,description:pc.localDescription});});
  },
  async join(code){
   const invite=parseSignal(code,{type:'offer'});
   assertFresh();
   return negotiate(async()=>{init('guest',invite.session);publishDiagnostics('setting-offer');await pc.setRemoteDescription(invite.description);assertOpen();const answer=await pc.createAnswer();assertOpen();await pc.setLocalDescription(answer);await gathered();assertOpen();expireAfter(SIGNAL_TTL_MS,'invitation-expired');notify('answer-ready');return encodeSignal({session,description:pc.localDescription});});
  },
  async accept(code){
   if(role!=='host'||!pc)throw Error('먼저 방을 만들어 주세요.');assertOpen();
   // Repeating an answer is not a new negotiation. Reject it before entering
   // the close-on-native-failure path so it cannot kill the first valid attempt.
   if(acceptingAnswer||answerAccepted)throw Error('응답 코드는 이미 적용 중이거나 적용됐습니다.');
   const answer=parseSignal(code,{type:'answer',session});acceptingAnswer=true;
   try{return await negotiate(async()=>{
    publishDiagnostics('setting-answer');
    await pc.setRemoteDescription(answer.description);assertOpen();answerAccepted=true;
    // The channel may open before setRemoteDescription's promise completes.
    if(channel?.readyState!=='open'){expireAfter(CONNECT_TIMEOUT_MS,'connection-establishment-timeout');notify('connecting');}
   });}finally{acceptingAnswer=false;}
  },
  send,close,get diagnostics(){return diagnostics();},get closed(){return ended;},get session(){return session;},get role(){return role;},get connected(){return !ended&&channel?.readyState==='open';}
 };
}
