import {HOOK_TRIAL} from './rift-v39-hook.js';
export function createAuditedHookCollider({auditSegment}={}){
 if(typeof auditSegment!=='function')throw Error('Monotone prefix segment audit required');
 const point=p=>Array.isArray(p)&&p.length===2&&p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024);
 function check(a,b){const r=auditSegment(a.slice(),b.slice());if(!r||typeof r.pass!=='boolean')throw Error('Explicit audit pass required');return r;}
 const mix=(a,b,t)=>a.map((x,i)=>x+(b[i]-x)*t);
 return Object.freeze({sweep(a,b){
  if(!point(a)||!point(b))throw Error('Finite XZ endpoints required');a=a.slice();b=b.slice();
  const distance=Math.hypot(b[0]-a[0],b[1]-a[1]);if(distance>512)throw Error('Segment too long');
  const start=check(a,a);if(!start.pass)return {blockedBy:start.reason??'geometry',invalidOrigin:true,position:a,contact:a.slice(),clearDistance:0,distance,resolution:0};
  const whole=check(a,b);if(whole.pass)return {blockedBy:null,invalidOrigin:false,position:b,contact:null,clearDistance:distance,distance,resolution:0};
  let lo=0,hi=1;for(let i=0;i<HOOK_TRIAL.iterations;i++){const mid=(lo+hi)/2;if(check(a,mix(a,b,mid)).pass)lo=mid;else hi=mid;}
  const safe=Math.max(0,distance*lo-HOOK_TRIAL.wallGap),position=mix(a,b,distance?safe/distance:0);
  if(!check(a,position).pass)throw Error('Audit is not prefix-monotone');
  const contact=mix(a,b,hi),first=check(a,contact);
  return {blockedBy:first.reason??whole.reason??'geometry',invalidOrigin:false,position,contact,clearDistance:safe,distance,resolution:distance*(hi-lo)};
 }});
}
