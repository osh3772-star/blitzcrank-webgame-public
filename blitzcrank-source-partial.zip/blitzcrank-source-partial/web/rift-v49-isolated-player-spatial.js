import {createSpawnSearchTrial} from './rift-v49-spawn-search-trial.js';
import {classifyContainment} from './rift-v49-containment-audit.js';
import {auditUncertaintyCorridor} from './rift-v49-uncertainty-corridor.js';
// Conservative player-only alternative; hook/target colliders retain their supplied rules.
export function createIsolatedPlayerSpatialTrial(THREE,components,options){
 const inspect=p=>classifyContainment(THREE,components,[p[0],1.05,p[1]]);
 function spatial(a,b){
  const corridor=auditUncertaintyCorridor(components,{from:a,to:b});if(!corridor.pass)return {pass:false,reason:corridor.reason};
  for(const p of [a,b]){const c=inspect(p);if(c.insideCandidate||c.uncertain.length)return {pass:false,reason:'component-interior-or-uncertainty'};}
  return {pass:true};
 }
 function checked(fn,...points){const result=fn(...points.map(p=>p.slice())),pass=result?.pass;if(typeof pass!=='boolean')throw Error('Audit must return explicit boolean pass');return {...result,pass};}
 const combine=fn=>(a,b)=>{const original=checked(fn,a,b);return original.pass?spatial(a,b):original;};
 return Object.freeze({...createSpawnSearchTrial({...options,
  movementAudit:combine(options.movementAudit),pathAudit:combine(options.pathAudit),
  landingAudit:p=>{const r=checked(options.landingAudit,p);return r.pass?spatial(p,p):r;}
 }),inspectContainment:inspect});
}
