// Compact player assets: exact GPU Float32 attributes and exact Float64 poses.
// Index and pose dictionaries are shared read-only data. Copy before modifying.
const MAGIC = [82, 72, 80, 50]; // RHP2
const VERSION = 1, HEADER = 16, MAX_BYTES = 128 * 1024 * 1024;
const TYPES = {f32: Float32Array, f64: Float64Array, u16: Uint16Array};
const LITTLE_ENDIAN = new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;
const align8 = n => Math.ceil(n / 8) * 8;
const fail = message => {throw new Error('Player model: ' + message);};
const integer = n => Number.isSafeInteger(n) && n >= 0;
function exactJSON(value) {
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) fail('metadata contains a non-finite value');
    return Object.is(value, -0) ? '-0' : JSON.stringify(value);
  }
  if (Array.isArray(value)) return '[' + value.map(item => exactJSON(item) ?? 'null').join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.entries(value).filter(([, item]) => item !== undefined).map(([key, item]) => JSON.stringify(key) + ':' + exactJSON(item)).join(',') + '}';
  return JSON.stringify(value);
}
function finite(values, label) {
  if (!values || typeof values.length !== 'number') fail(label + ' is not an array');
  for (let i = 0, length = values.length; i < length; i++) if (!Number.isFinite(values[i])) fail(label + ' contains a non-finite value');
}
function checkParts(data) {
  if (!data || !Array.isArray(data.parts) || !data.parts.length || data.parts.length > 10000) fail('invalid parts');
  for (const part of data.parts) {
    if (typeof part.name !== 'string' || !part.name) fail('invalid part name');
    if (!part.vertices?.length || part.vertices.length % 3 || part.normals?.length !== part.vertices.length) fail('invalid geometry: ' + part.name);
    finite(part.vertices, 'vertices'); finite(part.normals, 'normals');
    if (part.uvs != null) {
      if (part.uvs.length !== part.vertices.length / 3 * 2) fail('invalid UV count: ' + part.name);
      finite(part.uvs, 'UVs');
    }
    if (!part.triangles?.length || part.triangles.length % 3) fail('invalid triangle count: ' + part.name);
    const vertexCount = part.vertices.length / 3;
    for (let i = 0; i < part.triangles.length; i++) {
      const index = part.triangles[i];
      if (!integer(index) || index > 65535 || index >= vertexCount) fail('invalid triangle index: ' + part.name);
    }
  }
  if (data.nodes != null) {
    if (!Array.isArray(data.nodes)) fail('invalid nodes');
    for (const node of data.nodes) {
      if (typeof node.name !== 'string' || !Array.isArray(node.position) || node.position.length !== 3) fail('invalid node');
      finite(node.position, 'node position');
    }
  }
}

/** Build-time encoder, also exported for format/round-trip tests. */
export function encodeModelData(data) {
  checkParts(data);
  const blocks = [], dictionary = new Map(); let size = 0;
  function add(values, type) {
    const ArrayType = TYPES[type], array = new ArrayType(values);
    finite(array, type);
    let bytes = new Uint8Array(array.buffer);
    if (!LITTLE_ENDIAN) {
      bytes = bytes.slice();
      for (let i = 0; i < bytes.length; i += ArrayType.BYTES_PER_ELEMENT) bytes.subarray(i, i + ArrayType.BYTES_PER_ELEMENT).reverse();
    }
    // Hash buckets are byte-compared, so collisions cannot change geometry.
    let hash = 2166136261;
    for (const byte of bytes) hash = Math.imul(hash ^ byte, 16777619) >>> 0;
    const key = type + ':' + bytes.length + ':' + hash;
    const matches = dictionary.get(key) || [];
    for (const match of matches) if (bytes.every((byte, i) => byte === match.bytes[i])) return match.ref;
    const offset = align8(size), ref = {type, offset, length: array.length};
    if (offset > size) blocks.push({offset: size, bytes: new Uint8Array(offset - size)});
    blocks.push({offset, bytes}); size = offset + bytes.length;
    matches.push({bytes, ref}); dictionary.set(key, matches);
    return ref;
  }
  const model = {...data, parts: data.parts.map(part => {
    const result = {...part};
    for (const key of ['vertices', 'normals', 'uvs', 'triangles']) if (part[key] != null) result[key] = add(part[key], key === 'triangles' ? 'u16' : 'f32');
    return result;
  })};
  const packed = {format: 'rocket-hand-model', version: VERSION, model};
  if (data.clips != null) {
    if (!Array.isArray(data.clips)) fail('invalid clips');
    const poses = [], poseKeys = new Map();
    model.clips = data.clips.map(clip => {
      if (!Array.isArray(clip.frames) || !clip.frames.length || !Number.isFinite(clip.fps) || clip.fps <= 0 || !Number.isFinite(clip.duration) || clip.duration <= 0) fail('invalid clip');
      return {...clip, frames: clip.frames.map(frame => {
        if (!Array.isArray(frame.poses) || frame.poses.length !== data.parts.length) fail('invalid frame pose count');
        const indices = frame.poses.map(pose => {
          if (Object.keys(pose).some(key => !['p', 'q', 's'].includes(key)) || pose.p?.length !== 3 || pose.q?.length !== 4 || pose.s?.length !== 3) fail('unsupported pose schema');
          const values = [...pose.p, ...pose.q, ...pose.s]; finite(values, 'pose');
          // Float64 bytes preserve signed zero as well as every source number.
          const key = Array.from(new Uint8Array(new Float64Array(values).buffer)).join(',');
          if (!poseKeys.has(key)) {
            if (poses.length >= 65536) fail('too many distinct poses');
            poseKeys.set(key, poses.length); poses.push(values);
          }
          return poseKeys.get(key);
        });
        return {...frame, poses: add(indices, 'u16')};
      })};
    });
    packed.poseTable = add(poses.flat(), 'f64');
  }
  const json = new TextEncoder().encode(exactJSON(packed)), base = align8(HEADER + json.length);
  if (json.length > 4 * 1024 * 1024 || base + size > MAX_BYTES) fail('asset exceeds size limit');
  const output = new Uint8Array(base + size), header = new DataView(output.buffer);
  output.set(MAGIC); header.setUint32(4, VERSION, true); header.setUint32(8, json.length, true); header.setUint32(12, size, true);
  output.set(json, HEADER);
  for (const block of blocks) output.set(block.bytes, base + block.offset);
  return output;
}

export function hasModelMagic(input) {
  const bytes = input instanceof ArrayBuffer ? new Uint8Array(input) : input;
  return bytes?.length >= 4 && MAGIC.every((byte, i) => bytes[i] === byte);
}

/** Return game-compatible data. Geometry and shared poses use zero-copy views. */
export function decodeModelBuffer(input) {
  let buffer;
  if (input instanceof ArrayBuffer) buffer = input;
  else if (ArrayBuffer.isView(input)) buffer = input.byteOffset === 0 && input.byteLength === input.buffer.byteLength ? input.buffer : input.buffer.slice(input.byteOffset, input.byteOffset + input.byteLength);
  else fail('expected an ArrayBuffer');
  if (buffer.byteLength < HEADER || buffer.byteLength > MAX_BYTES || !hasModelMagic(buffer)) fail('invalid binary header');
  const header = new DataView(buffer), jsonLength = header.getUint32(8, true), payloadLength = header.getUint32(12, true), base = align8(HEADER + jsonLength);
  if (header.getUint32(4, true) !== VERSION) fail('unsupported binary version');
  if (!jsonLength || jsonLength > 4 * 1024 * 1024 || base > buffer.byteLength || base + payloadLength !== buffer.byteLength) fail('invalid binary lengths');
  let packed;
  try {packed = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(new Uint8Array(buffer, HEADER, jsonLength)));}
  catch {fail('invalid metadata JSON');}
  if (packed?.format !== 'rocket-hand-model' || packed.version !== VERSION || !packed.model || !Array.isArray(packed.model.parts)) fail('invalid metadata schema');
  const arrays = new Map();
  function read(ref, expectedType) {
    if (!ref || ref.type !== expectedType || !integer(ref.offset) || !integer(ref.length)) fail('invalid array reference');
    const ArrayType = TYPES[expectedType], bytes = ref.length * ArrayType.BYTES_PER_ELEMENT;
    if (!integer(bytes) || ref.offset % 8 || ref.offset + bytes > payloadLength) fail('array reference outside payload');
    const key = expectedType + ':' + ref.offset + ':' + ref.length;
    if (arrays.has(key)) return arrays.get(key);
    let array;
    if (LITTLE_ENDIAN) array = new ArrayType(buffer, base + ref.offset, ref.length);
    else {
      array = new ArrayType(ref.length);
      const method = expectedType === 'f32' ? 'getFloat32' : expectedType === 'f64' ? 'getFloat64' : 'getUint16';
      for (let i = 0; i < array.length; i++) array[i] = header[method](base + ref.offset + i * ArrayType.BYTES_PER_ELEMENT, true);
    }
    arrays.set(key, array); return array;
  }
  const model = packed.model;
  if (!model.parts.length || model.parts.length > 10000) fail('invalid parts');
  for (const part of model.parts) {
    if (!part || typeof part !== 'object') fail('invalid part');
    for (const key of ['vertices', 'normals', 'triangles']) part[key] = read(part[key], key === 'triangles' ? 'u16' : 'f32');
    if (part.uvs != null) part.uvs = read(part.uvs, 'f32');
  }
  if (model.clips != null) {
    if (!Array.isArray(model.clips)) fail('invalid clips');
    const values = read(packed.poseTable, 'f64');
    if (!values.length || values.length % 10 || values.length / 10 > 65536) fail('invalid pose table');
    finite(values, 'pose table');
    const poses = Array.from({length: values.length / 10}, (_, i) => ({p: values.subarray(i * 10, i * 10 + 3), q: values.subarray(i * 10 + 3, i * 10 + 7), s: values.subarray(i * 10 + 7, i * 10 + 10)}));
    for (const clip of model.clips) {
      if (typeof clip.name !== 'string' || !Array.isArray(clip.frames) || !clip.frames.length || !Number.isFinite(clip.fps) || clip.fps <= 0 || !Number.isFinite(clip.duration) || clip.duration <= 0) fail('invalid clip');
      for (const frame of clip.frames) {
        const indices = read(frame.poses, 'u16');
        if (indices.length !== model.parts.length) fail('invalid frame pose count');
        frame.poses = Array.from(indices, index => {if (index >= poses.length) fail('invalid pose index'); return poses[index];});
      }
    }
  }
  checkParts(model);
  return model;
}

async function decompressGzip(bytes, decompressionStream) {
  const reader = new Blob([bytes]).stream().pipeThrough(decompressionStream).getReader();
  const chunks = []; let length = 0;
  try {
    while (true) {
      const {done, value} = await reader.read(); if (done) break;
      length += value.byteLength;
      if (length > MAX_BYTES) {await reader.cancel(); fail('decompressed asset exceeds size limit');}
      chunks.push(value);
    }
  } finally {reader.releaseLock();}
  const output = new Uint8Array(length); let offset = 0;
  for (const chunk of chunks) {output.set(chunk, offset); offset += chunk.length;}
  return output.buffer;
}

/** Hash-named assets are safe to reuse across sessions and deployments. */
export async function loadPlayerModel(entry, {
  fetchImpl = globalThis.fetch?.bind(globalThis),
  DecompressionStreamImpl = globalThis.DecompressionStream,
} = {}) {
  if (!entry || typeof entry.raw !== 'string' || typeof entry.gzip !== 'string' || typeof fetchImpl !== 'function') fail('invalid loader configuration');
  let decompressionStream;
  if (typeof DecompressionStreamImpl === 'function') {
    try {decompressionStream = new DecompressionStreamImpl('gzip');} catch {} // A platform can expose the API without supporting gzip.
  }
  const compressed = Boolean(decompressionStream), url = compressed ? entry.gzip : entry.raw;
  const response = await fetchImpl(url, {cache: 'force-cache'});
  if (!response.ok) fail('HTTP ' + response.status + ': ' + url);
  let bytes = await response.arrayBuffer();
  if (bytes.byteLength > MAX_BYTES) fail('download exceeds size limit');
  // A server may apply Content-Encoding: gzip to the .gz file. Fetch then
  // supplies decoded bytes, so never decompress valid model magic twice.
  if (!hasModelMagic(bytes)) {
    const signature = new Uint8Array(bytes);
    if (!compressed || signature[0] !== 0x1f || signature[1] !== 0x8b) fail('unexpected asset encoding: ' + url);
    try {bytes = await decompressGzip(bytes, decompressionStream);}
    catch (error) {fail('gzip decompression failed: ' + error.message);}
  }
  if (entry.bytes != null && bytes.byteLength !== entry.bytes) fail('manifest byte length mismatch');
  return decodeModelBuffer(bytes);
}
