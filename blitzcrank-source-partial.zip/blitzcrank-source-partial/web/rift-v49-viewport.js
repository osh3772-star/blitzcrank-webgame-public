export function readViewport({width,height,dpr=1}){
 if(!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1)return null;
 return {width:Math.floor(width),height:Math.floor(height),dpr:Number.isFinite(dpr)&&dpr>0?Math.min(dpr,1.5):1};
}
export function createViewportSync({renderer,camera}){
 let previous=null;
 return Object.freeze({sync(input){
  const next=readViewport(input);if(!next)return false;
  if(!previous||next.width!==previous.width||next.height!==previous.height||next.dpr!==previous.dpr){
   renderer.setDrawingBufferSize(next.width,next.height,next.dpr);
   camera.aspect=next.width/next.height;camera.updateProjectionMatrix();
   previous=next;
  }
  return true;
 }});
}
// Check before simulation so a hidden/collapsed canvas cannot move an unseen actor.
export function gateViewport({view,viewport,clearInput}){
 if(!view||readViewport(viewport))return true;
 clearInput();if(!view.trial.snapshot().paused)view.trial.pause();return false;
}
export function createViewportFrame({current,viewport,clearInput,driver,onError}){
 let previous=null,failed=false;
 return {failed:()=>failed&&current()===previous,tick(time){
  const view=current();if(view!==previous){previous=view;failed=false;}if(failed)return;
  try{if(gateViewport({view,viewport:viewport(),clearInput}))driver.tick(time);}
  catch(error){failed=true;clearInput();onError(error);}
 }};
}
