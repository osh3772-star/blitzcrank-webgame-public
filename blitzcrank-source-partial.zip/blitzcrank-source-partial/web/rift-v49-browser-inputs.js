import {createCollisionStudy} from './assets/map-study-v20/collision-study.mjs';
export const BROWSER_MAP_V49=Object.freeze({revision:'0.49',
 glb:'assets/map-study-v49/map.4b256204c876eba9.glb',glbSHA:'4b256204c876eba94eced55dd89f1780d5d05558d7f2fad3ea4c30c710541312',
 collision:'assets/map-study-v49/collision.5eb69477d5eeab2d.json',collisionSHA:'5eb69477d5eeab2dd4b3b00ab1cf242bfc07706da83f1fd21eb5458b46820356'});
export async function loadBrowserV49Inputs({fetchImpl=globalThis.fetch,cryptoImpl=globalThis.crypto,signal}={}){
 if(typeof fetchImpl!=='function'||typeof cryptoImpl?.subtle?.digest!=='function')throw Error('Fetch and Web Crypto SHA-256 required');
 const cancelled=()=>{if(signal?.aborted)throw new DOMException('Map input load cancelled','AbortError');};
 async function read(path,expected){
  cancelled();const response=await fetchImpl(new URL(path,import.meta.url),{signal});cancelled();
  if(!response?.ok)throw Error('Map input fetch failed: '+path);
  const bytes=await response.arrayBuffer();cancelled();if(!(bytes instanceof ArrayBuffer)||bytes.byteLength===0||bytes.byteLength>32*1024*1024)throw Error('Invalid map input size');
  const digest=await cryptoImpl.subtle.digest('SHA-256',bytes);cancelled();
  const hash=Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,'0')).join('');
  if(hash!==expected)throw Error('Exact official v49 hash required: '+path);return bytes;
 }
 const [glb,collision]=await Promise.all([read(BROWSER_MAP_V49.glb,BROWSER_MAP_V49.glbSHA),read(BROWSER_MAP_V49.collision,BROWSER_MAP_V49.collisionSHA)]);cancelled();
 const layout=JSON.parse(new TextDecoder().decode(collision));
 if(layout.assetVersion!=='sr-study-0.49'||layout.upAxis!=='Y'||layout.span!==160||layout.decorativeFoliageUsesCliffFootprint!==true)throw Error('Official v49 coordinate/foliage contract required');
 const view=new DataView(glb);if(view.getUint32(0,true)!==0x46546c67||view.getUint32(4,true)!==2||view.getUint32(8,true)!==glb.byteLength||view.getUint32(16,true)!==0x4e4f534a)throw Error('Verified GLB structure required');
 const json=JSON.parse(new TextDecoder().decode(new Uint8Array(glb,20,view.getUint32(12,true)))),name='Batched_Grass_And_Reeds',nodes=json.nodes.filter(n=>n.name===name),mesh=nodes.length===1?json.meshes[nodes[0].mesh]:null;
 if(!mesh||mesh.name!=='Batched_Forest_And_Reeds.001'||mesh.primitives.length!==1)throw Error('Verified foliage identity required');
 const foliagePolicy=Object.freeze({revision:'0.49',excludedMeshNames:Object.freeze([name]),blocksSurface:t=>t.mesh!==name,planarCliffAndBoundaryChecksRequired:true,otherFoliageExcluded:false,adopted:false});
 return Object.freeze({glb,layout:structuredClone(layout),foliagePolicy,revision:'0.49',byteCounts:Object.freeze({glb:glb.byteLength,collision:collision.byteLength}),
  createProbe({radius=Math.hypot(.7,.7)}={}){
   if(!Number.isFinite(radius)||radius<.1||radius>2)throw Error('Invalid probe radius');const kernel=createCollisionStudy(structuredClone(layout),{radius});
   return Object.freeze({revision:'0.49',radius,probe(from,to=from){if(![from,to].every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)))throw Error('Two finite XZ coordinates required');return {from:from.slice(),to:to.slice(),blockedBy:kernel.blockedSweep(from,to),radius};}});
  }
 });
}
