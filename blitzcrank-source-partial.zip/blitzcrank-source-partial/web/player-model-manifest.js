// Generated transport manifest; exact raw model bytes preserved.
export const PLAYER_MODELS = Object.freeze({
  "viewmodel": {
    "raw": "./assets/player-models/viewmodel.2aa38ae0da7d99b9.bin",
    "gzip": "./assets/player-models/viewmodel.2aa38ae0da7d99b9.bin.0c3ffb1b2ea37f5c.gz",
    "bytes": 3915560,
    "gzipBytes": 1391508,
    "sourceBytes": 11547941,
    "sha256": "2aa38ae0da7d99b9805e82977d82e6018cf758b6a416dde1a60a524c94ffeda4"
  },
  "fullbody": {
    "raw": "./assets/player-models/fullbody.8504b896c6aaa1ef.bin",
    "gzip": "./assets/player-models/fullbody.8504b896c6aaa1ef.bin.b22dea5dd0291683.gz",
    "bytes": 6529992,
    "gzipBytes": 2087776,
    "sourceBytes": 14470553,
    "sha256": "8504b896c6aaa1ef45020f7e75308acfd84235be864db3c1b75e36fa6ae9ad95"
  }
});
