export const FLASH_FRAMES=Object.freeze({
  "kind": "video-frame-cutout",
  "texture": "./assets/flash-video/departure.49e52e9d2856f9e3.png",
  "sha256": "49e52e9d2856f9e3fc7e2a843229fc1a3c9938074a13c5a3102d0c4b6dfe7147",
  "cellWidth": 64,
  "cellHeight": 80,
  "columns": 10,
  "rows": 1,
  "firstCell": 0,
  "frameCount": 6,
  "fps": 10,
  "anchor": [
    32,
    44
  ],
  "sourceFrames": [
    26,
    27,
    28,
    29,
    30,
    31
  ],
  "sourceRgbExact": true,
  "originalParticleAsset": false,
  "arrivalAvailable": false,
  "audioAvailable": false,
  "completeTail": false,
  "sourcePage": "https://tenor.com/view/lol-league-of-legends-flash-summoners-spell-gaming-gif-17514119",
  "sourceVideo": "https://media.tenor.com/hbTchozC6GkAAAPo/lol-league-of-legends.mp4",
  "sourceVideoSha256": "710477b54893fbe0cdaca12b208db075653019f766a67d007542c75740031e2c",
  "limits": [
    "Already composited ground color remains in source RGB.",
    "Only clean departure frames 26-31 are played; tail is cut at 0.6 s.",
    "Arrival and later tail cannot be recovered from champion/UI occlusion.",
    "No generated artwork, additional particles, fades, retouching or frame interpolation."
  ]
});
