import {staticComponentCandidates} from './rift-v49-static-component-index.js';
// Sweeps the fixed actor center through open-component envelopes, not a solid proof.
export function auditUncertaintyCorridor(components,{from,to,centerY=1.05}={}){
 const valid=p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite);
 if(!valid(from)||!valid(to)||!Number.isFinite(centerY))throw Error('Finite corridor required');
 const a=[from[0],centerY,from[1]],b=[to[0],centerY,to[1]],blocked=[];
 const candidates=staticComponentCandidates(components,from,to);
 for(let k=0;k<(candidates?candidates.length:components.length);k++){
  const i=candidates?candidates[k]:k;
  const c=components[i];if(c.topologicallyClosed)continue;
  const low=[c.bounds.min.x,c.bounds.min.y,c.bounds.min.z],high=[c.bounds.max.x,c.bounds.max.y,c.bounds.max.z];
  let enter=0,leave=1,hit=true;
  for(let j=0;j<3;j++){const d=b[j]-a[j];if(d===0){if(a[j]<low[j]||a[j]>high[j]){hit=false;break;}}else{const u=(low[j]-a[j])/d,v=(high[j]-a[j])/d;enter=Math.max(enter,Math.min(u,v));leave=Math.min(leave,Math.max(u,v));if(enter>leave){hit=false;break;}}}
  if(hit)blocked.push({component:i,mesh:c.mesh,enter,leave});
 }
 return {pass:blocked.length===0,reason:blocked.length?'uncertain-component-envelope':null,blocked,centerlineOnly:true,conservative:true,completeSolidSafetyVerified:false};
}
