// Offline static geometry evidence, not an adopted physics/support model.
export function collectStaticTriangles(THREE,scene){
 scene.updateMatrixWorld(true);const triangles=[];
 scene.traverse(o=>{
  if(!o.isMesh)return;
  if(o.isSkinnedMesh||o.isInstancedMesh||Object.keys(o.geometry.morphAttributes??{}).length)
   throw Error('Only static, non-instanced geometry is supported');
  const g=o.geometry,p=g.attributes.position,index=g.index;
  if(!p||((index?.count??p.count)%3))throw Error('Invalid triangle geometry');
  for(let i=0;i<(index?.count??p.count);i+=3){
   const vertices=[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(p,index?index.getX(i+j):i+j).applyMatrix4(o.matrixWorld));
   if(!vertices.every(v=>[v.x,v.y,v.z].every(Number.isFinite)))throw Error('Nonfinite geometry');
   const triangle=new THREE.Triangle(...vertices),normal=triangle.getNormal(new THREE.Vector3());
   if(normal.lengthSq()===0)continue;
   triangles.push({mesh:o.name,triangle,normal,bounds:new THREE.Box3().setFromPoints(vertices)});
  }
 });
 return triangles;
}

export function auditSupport(THREE,triangles,{position,halfExtent=.7,height=2.1,expectedY=0,
 supportNames=['Continuous_Terrain_Base_1'],samplesPerAxis=9,maxSlopeDegrees=35,
 maxHeightSpread=.18,maxElevationDifference=.5,skin=.01}={}){
 const finite=Number.isFinite;
 if(!Array.isArray(position)||position.length!==2||!position.every(finite)||
  ![halfExtent,height,expectedY,maxSlopeDegrees,maxHeightSpread,maxElevationDifference,skin].every(finite)||
  halfExtent<=0||halfExtent>2||height<=0||height>5||skin<=0||skin>=height||
  maxSlopeDegrees<0||maxSlopeDegrees>=90||maxHeightSpread<0||maxElevationDifference<0||
  !Number.isInteger(samplesPerAxis)||samplesPerAxis<2||samplesPerAxis>33||
  !Array.isArray(supportNames)||!supportNames.length||!supportNames.every(x=>typeof x==='string'&&x.length))
  throw Error('Invalid support audit options');
 const minX=position[0]-halfExtent,maxX=position[0]+halfExtent,minZ=position[1]-halfExtent,maxZ=position[1]+halfExtent;
 const local=triangles.filter(t=>t.bounds.max.x>=minX&&t.bounds.min.x<=maxX&&t.bounds.max.z>=minZ&&t.bounds.min.z<=maxZ);
 const minNormalY=Math.cos(maxSlopeDegrees*Math.PI/180);
 const eligible=local.filter(t=>supportNames.includes(t.mesh)&&t.normal.y>=minNormalY);
 const samples=[];
 // Ray intersection is double-sided analytically, but only upward support faces qualify.
 for(let ix=0;ix<samplesPerAxis;ix++)for(let iz=0;iz<samplesPerAxis;iz++){
  const x=minX+(maxX-minX)*ix/(samplesPerAxis-1),z=minZ+(maxZ-minZ)*iz/(samplesPerAxis-1);
  const ray=new THREE.Ray(new THREE.Vector3(x,expectedY+maxElevationDifference+1,z),new THREE.Vector3(0,-1,0));
  const hits=[];
  for(const t of eligible){const hit=ray.intersectTriangle(t.triangle.a,t.triangle.b,t.triangle.c,false,new THREE.Vector3());
   if(hit&&Math.abs(hit.y-expectedY)<=maxElevationDifference+1e-8)hits.push({y:hit.y,mesh:t.mesh,normalY:t.normal.y});}
  hits.sort((a,b)=>b.y-a.y||a.mesh.localeCompare(b.mesh));
  samples.push({x,z,support:hits[0]??null});
 }
 const supported=samples.filter(s=>s.support),ys=supported.map(s=>s.support.y),missingSamples=samples.length-supported.length;
 const minY=ys.length?Math.min(...ys):null,maxY=ys.length?Math.max(...ys):null;
 const spread=ys.length?maxY-minY:null,footY=maxY;
 const intersections=[];
 if(footY!==null){
  // Full-volume exact triangle test, not a few upward rays. Excludes a skin above floor.
  const body=new THREE.Box3(new THREE.Vector3(minX,footY+skin,minZ),new THREE.Vector3(maxX,footY+height,maxZ));
  for(const t of local)if(t.bounds.intersectsBox(body)&&body.intersectsTriangle(t.triangle))
   intersections.push({mesh:t.mesh,minY:t.bounds.min.y,maxY:t.bounds.max.y});
 }
 const bodySurfaceClear=footY!==null&&intersections.length===0;
 return {position:position.slice(),halfExtent,height,samplesPerAxis,sampleCount:samples.length,
  supportedSamples:supported.length,missingSamples,supportNames:[...supportNames],minY,maxY,heightSpread:spread,
  maxSlopeDegrees,maxHeightSpread,maxElevationDifference,skin,footY,
  headY:footY===null?null:footY+height,bodySurfaceClear,intersectionCount:intersections.length,
  intersectionMeshes:[...new Set(intersections.map(t=>t.mesh))].sort(),intersections,samples,
  sampleCheckPassed:missingSamples===0&&spread<=maxHeightSpread&&bodySurfaceClear,
  continuousFootprintCoverageVerified:false,closedSolidContainmentVerified:false,physicsSupportIntegrated:false,
  gameplayChanged:false,browserGpuVerified:false};
}
