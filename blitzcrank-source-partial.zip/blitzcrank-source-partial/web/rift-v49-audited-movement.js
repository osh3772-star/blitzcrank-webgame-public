// Independent fixed-plane controller, derived from the existing planar trial.
// Each proposed segment is audited before state commits. Not installed in gameplay.
import {PLANAR_TRIAL} from './rift-v39-planar.js';
export function createAuditedMovement({spawn,audit}={}){
 if(typeof audit!=='function')throw Error('Explicit movement audit required');
 const valid=p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite);
 function checked(from,to){const result=audit(from.slice(),to.slice());if(!result||typeof result.pass!=='boolean')throw Error('Audit must return explicit boolean pass');return result;}
 function start(p){if(!valid(p))throw Error('Finite XZ point required');const r=checked(p,p);if(!r.pass)throw Error('Spawn rejected: '+(r.reason??'audit'));return p.slice();}
 let position=start(spawn),origin=position.slice(),ticks=0,disposed=false;
 const snapshot=()=>({position:position.slice(),origin:origin.slice(),ticks,planeY:0,speed:PLANAR_TRIAL.speed,maxDt:PLANAR_TRIAL.maxDt,disposed,gameplayIntegrated:false});
 return Object.freeze({snapshot,dispose(){disposed=true;},reset(p=origin){
  if(disposed)throw Error('Controller disposed');const next=start(p);position=next;origin=next.slice();ticks=0;return snapshot();
 },advance(input,dt){
  if(disposed)throw Error('Controller disposed');
  if(!input||![input.x,input.z,dt].every(Number.isFinite)||dt<0)throw Error('Finite input and nonnegative dt required');
  const seconds=Math.min(dt,PLANAR_TRIAL.maxDt),length=Math.hypot(input.x,input.z),scale=length>1?1/length:1;
  const dx=input.x*scale*PLANAR_TRIAL.speed*seconds,dz=input.z*scale*PLANAR_TRIAL.speed*seconds;
  const from=position.slice(),segments=[],blocked=[];let next=position.slice(),remaining=PLANAR_TRIAL.speed*seconds;
  function attempt(to){
   const distance=Math.hypot(to[0]-next[0],to[1]-next[1]);if(distance>remaining&&distance>0)to=next.map((v,i)=>v+(to[i]-v)*remaining/distance);
   const result=checked(next,to);if(!result.pass){blocked.push(result.reason??'audit-rejected');return false;}
   if(next[0]!==to[0]||next[1]!==to[1]){segments.push({from:next.slice(),to:to.slice()});remaining=Math.max(0,remaining-Math.hypot(to[0]-next[0],to[1]-next[1]));next=to;}
   return true;
  }
  if(dx||dz){if(!attempt([next[0]+dx,next[1]+dz])){
   if(dx)attempt([next[0]+dx,next[1]]);if(dz)attempt([next[0],next[1]+dz]);
  }}
  // Throws from any audit leave all state untouched, including an earlier axis attempt.
  position=next;ticks++;
  return {...snapshot(),from,seconds,requestedDt:dt,segments,blockedBy:[...new Set(blocked)],distance:Math.hypot(position[0]-from[0],position[1]-from[1])};
 }});
}
