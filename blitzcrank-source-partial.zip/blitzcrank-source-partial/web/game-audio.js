import {AUDIO_CUES, AUDIO_EVENTS} from './audio-cues.js';
import {createNeutralAudio} from './neutral-audio.js';

/** Short, decoded one-shot sounds. Never queues a stale game event for later. */
export function createGameAudio({
  cues = AUDIO_CUES,
  events = AUDIO_EVENTS,
  createContext = () => new (globalThis.AudioContext || globalThis.webkitAudioContext)(),
  fetchImpl = globalThis.fetch?.bind(globalThis),
  onError = () => {},
  volume = 0.7,
  muted = false,
  maxVoices = 6,
  priorityEvents = null,
  backgroundConcurrency = 2,
} = {}) {
  let context, master, disposed = false, paused = false;
  const buffers = new Map(), pending = new Map(), active = new Set();
  const priorityIds = priorityEvents === null ? Object.keys(cues) : [...new Set(priorityEvents.map(event=>events[event]).filter(id=>cues[id]))];
  const deferredIds = Object.keys(cues).filter(id=>!priorityIds.includes(id));
  const concurrency = Math.max(1,Math.min(4,Math.floor(backgroundConcurrency)||2));
  let backgroundPromise;
  function loadBackground() {
    if (backgroundPromise || disposed || !deferredIds.length) return backgroundPromise;
    const queue=deferredIds.filter(id=>!buffers.has(id));
    backgroundPromise=Promise.all(Array.from({length:Math.min(concurrency,queue.length)},async()=>{
      while(queue.length&&!disposed) await load(queue.shift());
    })).finally(()=>{backgroundPromise=null;});
    return backgroundPromise;
  }
  const clamp = value => Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));
  volume = clamp(volume);
  const report = (error, id) => { try { onError(error, id); } catch {} };
  const tones = createNeutralAudio({maxVoices, onError: report});
  tones.setMuted(muted);
  function stopAll(group, emitter) {
    for (const record of [...active]) if ((!group || record.group === group) &&
        (emitter === undefined || record.emitter === emitter)) {
      active.delete(record);
      try { record.source.stop(); } catch {}
      try { record.source.disconnect(); record.gain.disconnect(); } catch {}
    }
  }
  function stateChanged() {
    // Audio time freezes during suspension; discard old samples before resume.
    if (context?.state !== 'running') stopAll();
  }
  function applyVolume() {
    if (!master || !context) return;
    const value = muted || paused ? 0 : volume;
    master.gain.cancelScheduledValues(context.currentTime);
    master.gain.setValueAtTime(value, context.currentTime);
  }
  async function load(id) {
    if (disposed || !context || !cues[id]) return false;
    if (buffers.has(id)) return true;
    if (pending.has(id)) return pending.get(id);
    const ctx = context, cue = cues[id];
    const job = (async () => {
      await Promise.resolve(); // Register pending before a synchronous fetch error.
      try {
        const response = await fetchImpl(cue.url);
        if (!response.ok) throw new Error(`Audio HTTP ${response.status}: ${id}`);
        const buffer = await ctx.decodeAudioData(await response.arrayBuffer());
        if (disposed) return false;
        if (!Number.isFinite(buffer.duration) || buffer.duration <= 0 || buffer.duration > cue.maxDuration + 0.05)
          throw new Error(`Unexpected audio duration: ${id}`);
        buffers.set(id, buffer);
        return true;
      } catch (error) { report(error, id); return false; }
      finally { pending.delete(id); }
    })();
    pending.set(id, job);
    return job;
  }
  function unlock() {
    if (disposed) return Promise.resolve(false);
    stateChanged();
    try {
      // Call directly from a trusted click/key/touch, before awaiting other work.
      if (!context) {
        context = createContext();
        master = context.createGain();
        master.connect(context.destination);
        tones.attachContext(context);
        context.addEventListener?.('statechange', stateChanged);
        applyVolume();
      }
      if (context.state !== 'running') tones.stopAll();
      const resumed = context.resume();
      // Resume every trusted gesture; load() deduplicates pending fetch/decode.
      return Promise.resolve(resumed).then(async () => {
        if (disposed) return false;
        await Promise.all(priorityIds.map(load));
        if(!disposed) void loadBackground();
        return !disposed && context.state === 'running';
      }).catch(error => {report(error, 'unlock'); return false;});
    } catch (error) {report(error, 'unlock'); return Promise.resolve(false);}
  }
  function playEvent(event, {emitter = null} = {}) {
    if (emitter !== null && (typeof emitter !== 'string' || !emitter.length || emitter.length > 64)) return false;
    stateChanged();
    const id = events[event], cue = cues[id], buffer = buffers.get(id);
    if (disposed || paused || muted || !cue || !buffer || context?.state !== 'running') return false;
    // One shot per semantic group and actor. Opponent Q must not cut off the
    // local Q. Both actors reuse the same decoded buffer; no queued events.
    stopAll(cue.group, emitter);
    if (active.size >= Math.max(1, maxVoices)) {
      const oldest = active.values().next().value;
      active.delete(oldest);
      try {oldest.source.stop(); oldest.source.disconnect(); oldest.gain.disconnect();} catch {}
    }
    let source, gain;
    try {
      source = context.createBufferSource(); gain = context.createGain();
      source.buffer = buffer; source.loop = false;
      gain.gain.setValueAtTime(clamp(cue.gain), context.currentTime);
      source.connect(gain); gain.connect(master);
      const record = {source, gain, group: cue.group, emitter};
      source.onended = () => {active.delete(record); try {source.disconnect(); gain.disconnect();} catch {}};
      active.add(record);
      source.start(context.currentTime, 0, Math.min(buffer.duration, cue.maxDuration));
      return true;
    } catch (error) {
      for (const record of [...active]) if (record.source === source) active.delete(record);
      try {source?.disconnect(); gain?.disconnect();} catch {}
      report(error, id); return false;
    }
  }
  return {
    unlock, playEvent, playTone: tones.play,
    isGroupPlaying: group => [...active].some(record => record.group === group),
    preload: () => context ? Promise.all(Object.keys(cues).map(load)) : Promise.resolve([]),
    setMuted(value) {muted = Boolean(value); if (muted) stopAll(); tones.setMuted(muted); applyVolume();},
    setVolume(value) {volume = clamp(value); applyVolume();},
    setPaused(value, {tonePaused = value, preserveTone = null} = {}) {paused = Boolean(value); if (paused) stopAll(); tones.setPaused(tonePaused, preserveTone); applyVolume();},
    stopAll() {stopAll(); tones.stopAll();},
    get status() {return {supported: Boolean(context), context: context?.state || 'locked', ready: [...buffers.keys()], active: active.size, activeTones: tones.status.active, tonesPaused: tones.status.paused, muted, paused, disposed, volume};},
    dispose() {
      if (disposed) return;
      disposed = true; stopAll(); tones.dispose(); buffers.clear();
      context?.removeEventListener?.('statechange', stateChanged);
      try {master?.disconnect();} catch {}
      try {Promise.resolve(context?.close()).catch(error => report(error, 'close'));} catch {}
    },
  };
}
