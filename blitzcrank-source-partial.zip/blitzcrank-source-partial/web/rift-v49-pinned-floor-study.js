import {createRedCampFloorPolicy} from './rift-v49-red-floor-policy.js';
import {createCollisionStudy} from './assets/map-study-v20/collision-study.mjs';
import {collectStaticTriangles} from './rift-v39-support-audit.js';
import {createTriangleIndex} from './rift-v39-route-search.js';
import {auditStraightCorridor} from './rift-v39-footprint-coverage.js';
import {buildClosedComponents,classifyContainment} from './rift-v49-containment-audit.js';
import {auditUncertaintyCorridor} from './rift-v49-uncertainty-corridor.js';
import {registerStaticComponents} from './rift-v49-static-component-index.js';
import {createCapBodyStudy} from './rift-v49-cap-body-study.js';
import {stationaryReason} from './rift-v49-spawn-diagnostics.js';
const pins=Object.freeze({glb:'79593e206740bf1d306e09e1ac6091a1a694ec97d6572071eaf9a63f3755c816',collision:'5eb69477d5eeab2dd4b3b00ab1cf242bfc07706da83f1fd21eb5458b46820356',cap:'b942711f80016c96da76c397aa0eaa3b6eba3069e7961475549c5273daff4b55',component:'ded7f11da133b8f2c83483dd6e7773a9c3a86d6a1ea5c86770dde42288e716de'});
export async function createPinnedFloorStudy(THREE,{scene,glb,collision,cap,cryptoImpl=globalThis.crypto}={}){
 if(typeof cryptoImpl?.subtle?.digest!=='function')throw Error('SHA-256 required');
 // Own every byte before the first await; never accept caller-supplied hashes or flags.
 const own=b=>{if(!(b instanceof ArrayBuffer)||!b.byteLength||b.byteLength>32*1024*1024)throw Error('Bounded ArrayBuffer required');return b.slice(0);};
 const bytes={glb:own(glb),collision:own(collision),cap:own(cap)},digest=async b=>Array.from(new Uint8Array(await cryptoImpl.subtle.digest('SHA-256',b)),v=>v.toString(16).padStart(2,'0')).join('');
 for(const name of ['glb','collision','cap'])if(await digest(bytes[name])!==pins[name])throw Error('Pinned '+name+' mismatch');
 const triangles=collectStaticTriangles(THREE,scene),components=buildClosedComponents(THREE,triangles),id=22170,c=components[id];
 if(!c||c.mesh!=='Continuous_Cliff_Walls_Layered_v11'||c.triangles.length!==396||c.badEdges!==44||c.topologicallyClosed)throw Error('Pinned component identity mismatch');
 const serialized=JSON.stringify({mesh:c.mesh,triangles:c.triangles.map(t=>[t.triangle.a.toArray(),t.triangle.b.toArray(),t.triangle.c.toArray()])});
 if(await digest(new TextEncoder().encode(serialized))!==pins.component)throw Error('Pinned component geometry mismatch');
 const mesh=JSON.parse(new TextDecoder().decode(bytes.cap)),solid=createCapBodyStudy(THREE,mesh),capTriangles=mesh.faces.map(f=>{const triangle=new THREE.Triangle(...f.map(i=>new THREE.Vector3(...mesh.positions[i])));return {mesh:c.mesh,triangle,normal:triangle.getNormal(new THREE.Vector3()),bounds:new THREE.Box3().setFromPoints([triangle.a,triangle.b,triangle.c])};}),derived=buildClosedComponents(THREE,capTriangles);if(derived.length!==1||!derived[0].topologicallyClosed)throw Error('Closed derived component required');
 const revised=components.slice();revised[id]=derived[0];registerStaticComponents(components);registerStaticComponents(revised);
 const index=createTriangleIndex(triangles),layout=JSON.parse(new TextDecoder().decode(bytes.collision)),kernel=createCollisionStudy(layout,{radius:Math.hypot(.7,.7)}),probe={probe:(from,to)=>({blockedBy:kernel.blockedSweep(from,to)})};
 const floorPolicy=await createRedCampFloorPolicy(THREE,triangles,layout,cryptoImpl);
 return Object.freeze({audit(from,to=from){
  if(![from,to].every(p=>Array.isArray(p)&&p.length===2&&p.every(v=>Number.isFinite(v)&&Math.abs(v)<=80)))throw Error('Bounded finite XZ required');
  const near=index.query(from,to),bodyOriginal=auditStraightCorridor(THREE,near,probe,{from,to}),body=auditStraightCorridor(THREE,near.filter(t=>floorPolicy.blocksBodySurface(t)),probe,{from,to}),baseCorridor=auditUncertaintyCorridor(components,{from,to}),baseContainment=classifyContainment(THREE,components,[from[0],1.05,from[1]]),corridor=auditUncertaintyCorridor(revised,{from,to}),containment=classifyContainment(THREE,revised,[from[0],1.05,from[1]]),capBody=solid.audit(from,to),reason=stationaryReason(body,corridor,containment)??capBody.reason;
  return {from:from.slice(),to:to.slice(),baselineReason:stationaryReason(bodyOriginal,baseCorridor,baseContainment),capOnlyReason:stationaryReason(bodyOriginal,corridor,containment)??capBody.reason,reason,studyClear:reason===null,body,corridor,containment,capBody,replacedComponent:id,originalSurfaceChecksRetainedExceptVerifiedRedFloor:true,excludedRedFloorTriangles:90,retainedOtherFloorTriangles:225,spawnPermission:false,runtimeAdopted:false,wholeGameSafetyVerified:false};
 }});
}
