// Application messages for one invited peer. No scores/positions come from inputs.
export const ONLINE_PROTOCOL='rocket-hand-duel/2';
export const ONLINE_ACTIONS=Object.freeze({Q:1,W:2,E:4,R:8,PUNCH:16,JUMP:32,FLASH:64});
export const ONLINE_INPUT_LIMIT=4096;
const record=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const exact=(x,keys)=>record(x)&&Object.keys(x).length===keys.length&&keys.every(k=>Object.hasOwn(x,k));
const id=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{16,80}$/.test(x);
export function isSessionId(x){return id(x);}
export function validateInput(x,{session,epoch}={}){
 if(!exact(x,['type','protocol','session','epoch','seq','x','z','yaw','pitch','actions']))return false;
 return x.type==='input'&&x.protocol===ONLINE_PROTOCOL&&x.session===session&&x.epoch===epoch&&id(x.session)&&Number.isSafeInteger(x.epoch)&&x.epoch>=0&&Number.isSafeInteger(x.seq)&&x.seq>=0&&x.seq<Number.MAX_SAFE_INTEGER&&[x.x,x.z,x.yaw,x.pitch].every(Number.isFinite)&&Math.abs(x.x)<=1&&Math.abs(x.z)<=1&&Math.abs(x.yaw)<=Math.PI&&Math.abs(x.pitch)<=1.25&&Number.isInteger(x.actions)&&x.actions>=0&&x.actions<=127;
}
export function makeInput({session,epoch,seq,x=0,z=0,yaw=0,pitch=0,actions=0}){
 const value={type:'input',protocol:ONLINE_PROTOCOL,session,epoch,seq,x,z,yaw,pitch,actions};
 if(!validateInput(value,{session,epoch}))throw new TypeError('Invalid duel input');
 return value;
}
export function parseInput(text,scope){
 if(typeof text!=='string'||text.length>ONLINE_INPUT_LIMIT)return null;
 try{const value=JSON.parse(text);return validateInput(value,scope)?value:null;}catch{return null;}
}
// Size/depth/string limits apply before snapshots reach renderers. This is
// structural validation, not proof that a player-host sent honest game state.
export function boundedJSON(text,maxBytes=65536){
 if(typeof text!=='string'||text.length>maxBytes)return null;
 try{
  const value=JSON.parse(text);let budget=12000;
  function visit(x,depth){if(--budget<0||depth>20)return false;if(x===null||typeof x==='boolean')return true;if(typeof x==='number')return Number.isFinite(x);if(typeof x==='string')return x.length<=512;if(Array.isArray(x))return x.length<=128&&x.every(v=>visit(v,depth+1));return record(x)&&Object.keys(x).length<=64&&Object.entries(x).every(([k,v])=>k.length<=80&&!['__proto__','constructor','prototype'].includes(k)&&visit(v,depth+1));}
  return visit(value,0)?value:null;
 }catch{return null;}
}
