/**
 * Pure, serializable first-to-three rules. No wall clock, callbacks, timers,
 * renderer, player controller, transport, or automatic network validation.
 * A trusted gameplay authority must validate an offensive hit BEFORE confirmHit.
 * confirmGrab remains a Q-only compatibility command.
 */
export const DUEL_RULES = Object.freeze({ winsRequired: 3, maxRounds: 5 });
export const DUEL_PHASES = Object.freeze([
  'preparing', 'countdown', 'active', 'roundReset', 'matchComplete', 'cancelled',
]);

const ID_LIMIT = 200;
const MAX = Number.MAX_SAFE_INTEGER;
const record = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const id = (value) => typeof value === 'string' && value.length > 0 && value.length <= ID_LIMIT && value.trim() === value && !/[\u0000-\u001f\u007f]/.test(value);
const integer = (value, min = 0, max = MAX) => Number.isSafeInteger(value) && value >= min && value <= max;
const duration = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= MAX;
const matchIdFor = (sessionId, matchNumber) => `${sessionId}/match/${matchNumber}`;
const roundIdFor = (matchId, roundNumber) => `${matchId}/round/${roundNumber}`;
const exactKeys = (value, keys) => record(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
const STATE_KEYS = ['schemaVersion', 'sessionId', 'matchNumber', 'matchId', 'winsRequired', 'maxRounds', 'playerIds', 'scores', 'timing', 'phase', 'phaseNumber', 'roundNumber', 'roundId', 'remainingMs', 'history', 'winnerId'];

function freeze(value) {
  if (value !== null && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}

function rawScope(state) {
  return {
    sessionId: state.sessionId,
    matchId: state.matchId,
    matchNumber: state.matchNumber,
    roundId: state.roundId,
    roundNumber: state.roundNumber,
    phaseNumber: state.phaseNumber,
  };
}

/** Validate data, not authority. Structurally valid input is not authenticated. */
export function isDuelState(state) {
  if (!exactKeys(state, STATE_KEYS) || state.schemaVersion !== 1 || !id(state.sessionId)) return false;
  if (!integer(state.matchNumber, 1) || state.matchId !== matchIdFor(state.sessionId, state.matchNumber)) return false;
  if (!integer(state.roundNumber, 1, 5) || state.roundId !== roundIdFor(state.matchId, state.roundNumber)) return false;
  if (!integer(state.phaseNumber, 1) || !DUEL_PHASES.includes(state.phase)) return false;
  if (state.winsRequired !== 3 || state.maxRounds !== 5) return false;
  if (!Array.isArray(state.playerIds) || state.playerIds.length !== 2 || !id(state.playerIds[0]) || !id(state.playerIds[1]) || state.playerIds[0] === state.playerIds[1]) return false;
  if (!Array.isArray(state.scores) || state.scores.length !== 2) return false;
  if (![0, 1].every((index) => exactKeys(state.scores[index], ['playerId', 'points']) && state.scores[index].playerId === state.playerIds[index] && integer(state.scores[index].points, 0, 3))) return false;
  if (!exactKeys(state.timing, ['countdownMs', 'roundResetMs']) || !duration(state.timing.countdownMs) || !duration(state.timing.roundResetMs)) return false;
  if (!duration(state.remainingMs)) return false;
  if (state.phase === 'countdown') {
    if (state.remainingMs <= 0 || state.remainingMs > state.timing.countdownMs) return false;
  } else if (state.phase === 'roundReset') {
    if (state.remainingMs > state.timing.roundResetMs) return false;
  } else if (state.remainingMs !== 0) return false;
  if (!Array.isArray(state.history) || state.history.length > 5) return false;
  const points = [0, 0];
  const eventIds = new Set();
  for (let index = 0; index < state.history.length; index += 1) {
    const round = state.history[index];
    if (!exactKeys(round, ['matchId', 'roundId', 'roundNumber', 'eventId', 'winnerId', 'loserId']) || round.matchId !== state.matchId || round.roundNumber !== index + 1 || round.roundId !== roundIdFor(state.matchId, index + 1)) return false;
    if (!id(round.eventId) || eventIds.has(round.eventId)) return false;
    eventIds.add(round.eventId);
    const winnerIndex = state.playerIds.indexOf(round.winnerId);
    if (winnerIndex < 0 || round.loserId !== state.playerIds[1 - winnerIndex]) return false;
    points[winnerIndex] += 1;
    if (points[winnerIndex] > 3 || (points[winnerIndex] === 3 && index !== state.history.length - 1)) return false;
  }
  if (!state.scores.every((score, index) => score.points === points[index])) return false;
  const winnerIndex = points.findIndex((score) => score === 3);
  const winnerId = winnerIndex < 0 ? null : state.playerIds[winnerIndex];
  if (state.winnerId !== winnerId) return false;
  if (state.phase === 'matchComplete') {
    if (winnerId === null || state.history.length !== state.roundNumber) return false;
  } else if (state.phase === 'roundReset') {
    if (winnerId !== null || state.history.length !== state.roundNumber || state.roundNumber >= 5) return false;
  } else if (state.phase === 'cancelled') {
    if (winnerId !== null || ![state.roundNumber - 1, state.roundNumber].includes(state.history.length)) return false;
  } else if (winnerId !== null || state.history.length !== state.roundNumber - 1) return false;
  return true;
}

/** Scope is a staleness guard, not a secret or authorization capability. */
export function getDuelScope(state) {
  return isDuelState(state) ? freeze(rawScope(state)) : null;
}

function success(state, effects = [], changed = true) {
  return freeze({ accepted: true, reason: null, changed, state, effects });
}

function reject(state, reason) {
  // Do not freeze malformed caller-owned data, and do not expose it as valid state.
  return Object.freeze({ accepted: false, reason, changed: false, state, effects: Object.freeze([]) });
}

function effect(type, state, extra = {}) {
  return { type, scope: rawScope(state), ...extra };
}

function initialState({ sessionId, playerIds, countdownMs, roundResetMs }, matchNumber = 1) {
  const matchId = matchIdFor(sessionId, matchNumber);
  return {
    schemaVersion: 1, sessionId, matchNumber, matchId,
    winsRequired: 3, maxRounds: 5,
    playerIds: [...playerIds],
    scores: playerIds.map((playerId) => ({ playerId, points: 0 })),
    timing: { countdownMs, roundResetMs },
    phase: 'preparing', phaseNumber: 1,
    roundNumber: 1, roundId: roundIdFor(matchId, 1),
    remainingMs: 0, history: [], winnerId: null,
  };
}

/**
 * sessionId must be unique per independently created session in the adapter's
 * event-routing domain. Use restartMatch on an existing session for rematches.
 */
export function createDuelMatch(options) {
  if (!record(options) || !id(options.sessionId)) return reject(null, 'invalid_options');
  if (!Array.isArray(options.playerIds) || options.playerIds.length !== 2 || !id(options.playerIds[0]) || !id(options.playerIds[1]) || options.playerIds[0] === options.playerIds[1]) return reject(null, 'invalid_players');
  const countdownMs = options.countdownMs === undefined ? 1000 : options.countdownMs;
  const roundResetMs = options.roundResetMs === undefined ? 1000 : options.roundResetMs;
  if (!duration(countdownMs) || !duration(roundResetMs)) return reject(null, 'invalid_timing');
  const state = initialState({ sessionId: options.sessionId, playerIds: options.playerIds, countdownMs, roundResetMs });
  return success(state, [effect('reset-round', state)]);
}

function scopeError(state, scope) {
  if (!record(scope) || !id(scope.sessionId) || typeof scope.matchId !== 'string' || !integer(scope.matchNumber, 1) || typeof scope.roundId !== 'string' || !integer(scope.roundNumber, 1, 5) || !integer(scope.phaseNumber, 1)) return 'invalid_scope';
  if (scope.sessionId !== state.sessionId || scope.matchId !== state.matchId || scope.matchNumber !== state.matchNumber) return 'stale_match';
  if (scope.roundId !== state.roundId || scope.roundNumber !== state.roundNumber) return 'stale_round';
  if (scope.phaseNumber !== state.phaseNumber) return 'stale_phase';
  return null;
}

function nextPhase(state, phase, remainingMs = 0, updates = {}) {
  return { ...state, ...updates, phase, remainingMs, phaseNumber: state.phaseNumber + 1 };
}

/**
 * Reduce one command, then store result.state BEFORE processing result.effects.
 * Every command requires the exact scope captured at the originating boundary.
 * A rejected command preserves the exact state reference and emits no effects.
 */
export function transitionDuel(state, command) {
  if (!isDuelState(state)) return reject(null, 'invalid_state');
  if (!record(command) || typeof command.type !== 'string') return reject(state, 'invalid_command');
  const error = scopeError(state, command.scope);
  if (error) return reject(state, error);
  if (state.phaseNumber >= MAX) return reject(state, 'counter_exhausted');

  if (command.type === 'restartMatch') {
    if (state.matchNumber >= MAX) return reject(state, 'counter_exhausted');
    const next = initialState({ sessionId: state.sessionId, playerIds: state.playerIds, ...state.timing }, state.matchNumber + 1);
    return success(next, [effect('cancel-pending-work', state), effect('reset-round', next)]);
  }
  if (command.type === 'cancelMatch') {
    if (['matchComplete', 'cancelled'].includes(state.phase)) return reject(state, 'terminal_phase');
    const next = nextPhase(state, 'cancelled');
    return success(next, [effect('cancel-pending-work', state), effect('match-cancelled', next)]);
  }
  if (['matchComplete', 'cancelled'].includes(state.phase)) return reject(state, 'terminal_phase');

  if (command.type === 'prepareRound') {
    if (state.phase !== 'preparing') return reject(state, 'wrong_phase');
    const startsNow = state.timing.countdownMs === 0;
    const next = nextPhase(state, startsNow ? 'active' : 'countdown', state.timing.countdownMs);
    return success(next, [effect(startsNow ? 'round-started' : 'countdown-started', next)]);
  }

  if (command.type === 'step') {
    if (!duration(command.deltaMs)) return reject(state, 'invalid_delta');
    if (command.deltaMs === 0 || !['countdown', 'roundReset'].includes(state.phase)) return success(state, [], false);
    const rest = state.remainingMs - command.deltaMs;
    const remainingMs = rest <= 1e-8 ? 0 : rest;
    if (remainingMs > 0) return success({ ...state, remainingMs });
    if (state.phase === 'countdown') {
      const next = nextPhase(state, 'active');
      return success(next, [effect('round-started', next)]);
    }
    const roundNumber = state.roundNumber + 1;
    const next = nextPhase(state, 'preparing', 0, { roundNumber, roundId: roundIdFor(state.matchId, roundNumber) });
    return success(next, [effect('reset-round', next)]);
  }

  // Local authority replays a simultaneous geometric tie without awarding a
  // point or consuming a numbered round. A fresh phase rejects all old hooks.
  if (command.type === 'replayRound') {
    if (state.phase !== 'active') return reject(state, 'wrong_phase');
    const next = nextPhase(state, 'preparing');
    return success(next, [effect('cancel-pending-work', state), effect('reset-round', next)]);
  }

  if (command.type === 'confirmGrab' || command.type === 'confirmHit') {
    const skill = command.type === 'confirmGrab' ? 'Q' : command.skill;
    if (!['Q', 'E', 'R'].includes(skill)) return reject(state, 'non_scoring_skill');
    if (!id(command.eventId)) return reject(state, 'invalid_event_id');
    if (state.history.some((round) => round.eventId === command.eventId)) return reject(state, 'duplicate_event');
    if (state.phase !== 'active') return reject(state, 'wrong_phase');
    if (command.result !== 'success') return reject(state, 'non_scoring_result');
    if (command.validated !== true) return reject(state, command.type === 'confirmGrab' ? 'unvalidated_grab' : 'unvalidated_hit');
    const winnerIndex = state.playerIds.indexOf(command.attackerId);
    if (winnerIndex < 0 || command.targetId !== state.playerIds[1 - winnerIndex]) return reject(state, 'invalid_opponents');
    const scores = state.scores.map((score, index) => ({ ...score, points: score.points + (index === winnerIndex ? 1 : 0) }));
    const round = {
      matchId: state.matchId, roundId: state.roundId, roundNumber: state.roundNumber,
      eventId: command.eventId, winnerId: command.attackerId, loserId: command.targetId,
    };
    const complete = scores[winnerIndex].points === 3;
    const next = nextPhase(state, complete ? 'matchComplete' : 'roundReset', complete ? 0 : state.timing.roundResetMs, {
      scores, history: [...state.history, round], winnerId: complete ? command.attackerId : null,
    });
    return success(next, [
      effect('cancel-pending-work', state),
      effect('round-scored', next, { round, skill }),
      effect(complete ? 'match-completed' : 'round-reset-started', next),
    ]);
  }

  return reject(state, 'unknown_command');
}
