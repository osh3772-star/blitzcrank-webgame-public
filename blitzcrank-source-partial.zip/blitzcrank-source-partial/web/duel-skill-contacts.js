import {SKILL_TUNING} from './skill-controller.js?v=0.24.70';
const axes=['x','y','z'];
const vector=v=>v&&axes.every(k=>Number.isFinite(v[k]));
const lerp=(a,b,t)=>Object.fromEntries(axes.map(k=>[k,a[k]+(b[k]-a[k])*t]));
// Inclusive point-ray / AABB contact. Cover wins equality, no hitbox expansion.
function rayBox(origin,direction,min,max,limit){
 let near=0,far=limit;
 for(const k of axes){if(Math.abs(direction[k])<1e-14){if(origin[k]<min[k]||origin[k]>max[k])return null;}else{let a=(min[k]-origin[k])/direction[k],b=(max[k]-origin[k])/direction[k];if(a>b)[a,b]=[b,a];near=Math.max(near,a);far=Math.min(far,b);if(near>far)return null;}}
 return near;
}
/** Pure E/R geometry at an authority-generated impact fraction. No casts,
 * callbacks, scores or remote hit flags. Actor origins are the same eye-space
 * points and torso AABBs used by Q; R retains the original eye-origin radius. */
export function evaluateDuelSkillContact({skill,attackerId,actors,obstacles,aim,fraction}){
 if(!['E','R'].includes(skill)||!Number.isFinite(fraction)||fraction<0||fraction>1)return null;
 const attacker=actors.find(a=>a.playerId===attackerId),opponent=actors.find(a=>a.playerId!==attackerId);
 if(!attacker||!opponent||actors.length!==2||!vector(attacker.motion?.from)||!vector(attacker.motion?.to)||!vector(opponent.motion?.from)||!vector(opponent.motion?.to))return null;
 const origin=lerp(attacker.motion.from,attacker.motion.to,fraction),target=lerp(opponent.motion.from,opponent.motion.to,fraction);
 let direction,limit,hitDistance;
 if(skill==='E'){
  if(!vector(aim))return null;
  const n=Math.hypot(aim.x,aim.y,aim.z);if(n<1e-12)return null;
  direction=Object.fromEntries(axes.map(k=>[k,aim[k]/n]));limit=SKILL_TUNING.eRange;
  if(opponent.shape?.type!=='aabb'||!vector(opponent.shape.min)||!vector(opponent.shape.max))return null;
  const min=Object.fromEntries(axes.map(k=>[k,target[k]+opponent.shape.min[k]])),max=Object.fromEntries(axes.map(k=>[k,target[k]+opponent.shape.max[k]]));
  hitDistance=rayBox(origin,direction,min,max,limit);if(hitDistance===null)return null;
 }else{
  const delta=Object.fromEntries(axes.map(k=>[k,target[k]-origin[k]]));hitDistance=Math.hypot(delta.x,delta.y,delta.z);limit=SKILL_TUNING.rRadius;
  if(hitDistance>limit)return null;
  direction=hitDistance?Object.fromEntries(axes.map(k=>[k,delta[k]/hitDistance])):{x:0,y:0,z:0};
 }
 for(const box of obstacles){if(!vector(box.min)||!vector(box.max))return null;if(rayBox(origin,direction,box.min,box.max,hitDistance)!==null)return null;}
 return {attackerId,targetId:opponent.playerId,skill,position:target,origin,distance:hitDistance};
}
