/** Plays masked pixels from the user-selected video. No procedural replacement.
 * Departure only: arrival pixels are inseparable from the recorded champion/UI.
 * Atlas frames are discrete 10 fps source samples, not interpolated particles.
 */
const finitePosition=p=>p&&[p.x,p.y,p.z].every(Number.isFinite);
export function validateFlashFrames(manifest){
 if(!manifest||manifest.kind!=='video-frame-cutout'||manifest.originalParticleAsset!==false||manifest.arrivalAvailable!==false||manifest.audioAvailable!==false||manifest.sourceRgbExact!==true)throw new TypeError('Unverified Flash video-frame provenance');
 const {cellWidth,cellHeight,columns,rows,firstCell,frameCount,fps,anchor}=manifest;
 if(![cellWidth,cellHeight,columns,rows,firstCell,frameCount].every(Number.isInteger)||Math.min(cellWidth,cellHeight,columns,rows,frameCount)<=0||firstCell<0||firstCell+frameCount>columns*rows||!Number.isFinite(fps)||fps<=0||fps>120||!Array.isArray(manifest.sourceFrames)||manifest.sourceFrames.length!==frameCount||!manifest.sourceFrames.every(Number.isInteger))throw new TypeError('Invalid Flash frame atlas');
 if(!Array.isArray(anchor)||anchor.length!==2||!anchor.every(Number.isFinite)||anchor[0]<0||anchor[0]>cellWidth||anchor[1]<0||anchor[1]>cellHeight||typeof manifest.texture!=='string'||!manifest.texture.startsWith('./assets/'))throw new TypeError('Invalid Flash frame coordinates');
 return manifest;
}
export async function loadFlashFrameTexture(THREE,manifest,{loader=new THREE.TextureLoader()}={}){
 validateFlashFrames(manifest);
 const texture=await loader.loadAsync(manifest.texture);
 texture.colorSpace=THREE.SRGBColorSpace;texture.magFilter=THREE.NearestFilter;texture.minFilter=THREE.NearestFilter;texture.generateMipmaps=false;texture.wrapS=texture.wrapT=THREE.ClampToEdgeWrapping;
 return texture;
}
export function createFlashFrameVfx(THREE,{scene,texture,manifest,worldHeight=1.6,groundLift=.12,viewScene=null}={}){
 validateFlashFrames(manifest);
 if(!scene?.add||!texture?.isTexture||!Number.isFinite(worldHeight)||worldHeight<=0||!Number.isFinite(groundLift)||groundLift<0)throw new TypeError('Flash frames require a loaded texture and scene');
 const material=new THREE.SpriteMaterial({map:texture,color:0xffffff,transparent:true,depthTest:true,depthWrite:false,opacity:1,toneMapped:false,fog:false,blending:THREE.NormalBlending});
 const sprite=new THREE.Sprite(material);sprite.name='Flash_selected_video_departure';sprite.visible=false;sprite.center.set(manifest.anchor[0]/manifest.cellWidth,1-manifest.anchor[1]/manifest.cellHeight);sprite.scale.set(worldHeight*manifest.cellWidth/manifest.cellHeight,worldHeight,1);scene.add(sprite);
 // FPS presentation replay, not an arrival effect: identical source texture,
 // frame cursor and material. World departure remains fixed at its true origin.
 let viewReplay=null;
 if(viewScene?.add){
  viewReplay=new THREE.Sprite(material);viewReplay.name='Flash_selected_departure_FPS_replay';
  viewReplay.visible=false;viewReplay.center.copy(sprite.center);
  viewReplay.scale.set(.75*manifest.cellWidth/manifest.cellHeight,.75,1);
  viewReplay.position.set(0,-.35,-2);viewScene.add(viewReplay);
 }
 texture.repeat.set(1/manifest.columns,1/manifest.rows);
 let age=Infinity,currentFrame=-1,disposed=false;
 function selectFrame(index){if(index===currentFrame)return;const cell=manifest.firstCell+index;texture.offset.set((cell%manifest.columns)/manifest.columns,1-(Math.floor(cell/manifest.columns)+1)/manifest.rows);currentFrame=index;}
 function reset(){sprite.visible=false;if(viewReplay)viewReplay.visible=false;age=Infinity;currentFrame=-1;}
 return {
  play(from,{firstPerson=false}={}){if(disposed||!finitePosition(from))return false;sprite.position.set(from.x,Math.max(0,from.y-1.7)+groundLift,from.z);age=0;selectFrame(0);sprite.visible=true;if(viewReplay)viewReplay.visible=firstPerson;return true;},
  update(dt,{firstPerson}={}){if(viewReplay&&typeof firstPerson==='boolean')viewReplay.visible=sprite.visible&&firstPerson;if(disposed||!sprite.visible||!Number.isFinite(dt)||dt<=0)return;age+=dt;const frame=Math.floor((age+1e-10)*manifest.fps);if(frame>=manifest.frameCount){reset();return;}selectFrame(frame);},
  reset,
  dispose(){if(disposed)return;reset();scene.remove(sprite);if(viewReplay)viewScene.remove(viewReplay);material.dispose();texture.dispose();disposed=true;},
  inspect(){return {active:sprite.visible,age:Number.isFinite(age)?age:null,frame:currentFrame,sourceFrame:currentFrame<0?null:manifest.sourceFrames[currentFrame],position:sprite.position.toArray(),source:'selected-video-frames',fpsReplay:viewReplay?.visible||false,presentation:'departure-source-replay',arrival:false,audio:false,disposed};},
 };
}
