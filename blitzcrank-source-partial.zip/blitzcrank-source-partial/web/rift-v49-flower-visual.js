import {createViewportSync,createViewportFrame} from './rift-v49-viewport.js';
import {resolvePointerAim} from './rift-v49-pointer-aim.js';
import {skillPresentation,createHookTether} from './rift-v49-skill-presentation.js';
import {createKeyboardInput} from './rift-v49-keyboard-input.js';
import {createFrameDriver} from './rift-v49-frame-driver.js';
import * as THREE from './vendor/three.module.js';import {GLTFLoader} from './vendor/GLTFLoader.js';
import {loadFlowerInputs} from './rift-v49-flower-inputs.js';import {createV49SceneAdapter} from './rift-v49-scene-adapter.js';import {createGuardedVisualSession} from './rift-v49-guarded-session.js';import {disposeMapScene} from './rift-v39-loader.js';
const $=id=>document.getElementById(id),keys=new Set();let aim=[2.5,3.5],last=0,raf=0;
const status=text=>{$('status').textContent=text;};
function install(gltf,inputs){let renderer,scene,trial;try{
 const adapter=createV49SceneAdapter(THREE,{scene:gltf.scene,inputs});trial=adapter.createTrial();trial.pause();
 scene=new THREE.Scene();scene.background=new THREE.Color(0x142b30);scene.add(gltf.scene);scene.add(new THREE.HemisphereLight(0xd2f3ff,0x343b20,2));const sun=new THREE.DirectionalLight(0xffe8c4,3);sun.position.set(-35,90,35);scene.add(sun);
 const marker=(geometry,color)=>{const m=new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color}));scene.add(m);return m;},player=marker(new THREE.BoxGeometry(1.4,2.1,1.4),0x45a8ff),target=marker(new THREE.BoxGeometry(1.4,2.1,1.4),0xffa341),hook=marker(new THREE.SphereGeometry(.12,12,8),0xfff1b0),aimMarker=marker(new THREE.RingGeometry(.2,.27,20),0x7affbb);aimMarker.rotation.x=-Math.PI/2;
 const tether=createHookTether(THREE);scene.add(tether.line);let lastTelemetry='';
 const camera=new THREE.PerspectiveCamera(58,1,.1,500);renderer=new THREE.WebGLRenderer({canvas:$('map'),antialias:true});renderer.outputColorSpace=THREE.SRGBColorSpace;const initial=trial.snapshot().position;camera.position.set(initial[0]+12,18,initial[1]+16);camera.lookAt(initial[0],0,initial[1]);camera.updateMatrixWorld();const viewportSync=createViewportSync({renderer,camera});
 return {trial,camera,renderer,scene,stats:adapter.stats,paint(){if(!viewportSync.sync({width:$('map').clientWidth,height:$('map').clientHeight,dpr:devicePixelRatio}))return;const s=trial.snapshot(),p=s.position,presentation=skillPresentation(s);tether.update(presentation);if(presentation.text!==lastTelemetry){lastTelemetry=presentation.text;$('telemetry').textContent=lastTelemetry;}player.position.set(p[0],1.05,p[1]);target.visible=!!s.pull.target;if(s.pull.target)target.position.set(s.pull.target.center[0],1.05,s.pull.target.center[1]);hook.visible=!!s.pull.position&&s.pull.phase!=='idle';if(s.pull.position)hook.position.set(s.pull.position[0],.8,s.pull.position[1]);aimMarker.position.set(aim[0],.03,aim[1]);camera.position.set(p[0]+12,18,p[1]+16);camera.lookAt(p[0],0,p[1]);renderer.render(scene,camera);},dispose(){trial.dispose();disposeMapScene(scene);renderer.dispose();$('telemetry').textContent='시험 상태 없음';}};
 }catch(error){trial?.dispose();if(scene){scene.remove(gltf.scene);disposeMapScene(scene);}renderer?.dispose();throw error;}}
const session=createGuardedVisualSession({load:signal=>loadFlowerInputs({signal}),parse:bytes=>new GLTFLoader().parseAsync(bytes,''),install,releaseParsed:gltf=>disposeMapScene(gltf.scene)});
function action(fn){if((driver.failed()||viewportFrame.failed())){status('프레임 오류 후에는 검증 파일을 다시 불러오세요.');return;}const v=session.current();if(!v){status('먼저 파일을 불러오세요.');return;}try{const r=fn(v.trial);status(r?.accepted===false?'거부: '+r.reason:'처리 완료 · '+(v.trial.snapshot().paused?'일시정지':'시험 진행'));}catch(e){keys.clear();v.trial.pause();status('검사 중지: '+e.message);}}
$('load').onclick=async()=>{keys.clear();status('해시 검증 및 3D 입력 준비 중…');try{const v=await session.start();if(v)status('공식 미반영 꽃 후보 준비됨 · '+v.stats.triangles+' 삼각형. 일시정지 상태입니다. 재개를 눌러 시험하세요.');}catch(e){if(e.superseded){console.warn('이전 로드의 자원 정리 실패',e);return;}status('로드 실패: '+e.message);}};
$('cancel').onclick=()=>{keys.clear();session.cancel();status('취소·자원 정리 완료');};
$('pause').onclick=()=>action(t=>{keys.clear();return t.snapshot().paused?t.resume():t.pause();});
$('hook').onclick=()=>action(t=>t.castPull({aim:aim.slice(),targets:[{id:'marker',center:aim.slice(),radius:.7}]}));$('flash').onclick=()=>action(t=>t.flash({aim:aim.slice()}));$('spawn').onclick=()=>action(t=>t.respawnNear({preferred:[0,-12],maxRadius:4,maxCandidates:1200}));
$('map').addEventListener('pointerdown',e=>{const v=session.current();if(!v||(driver.failed()||viewportFrame.failed()))return;const resolved=resolvePointerAim(THREE,{event:e,rect:$('map').getBoundingClientRect(),camera:v.camera});if(resolved){aim=resolved;e.preventDefault();}});
const interrupt=()=>{keys.clear();const v=session.current();if(v){v.trial.pause();status('초점 상실: 일시정지');}};
addEventListener('blur',interrupt);document.addEventListener('visibilitychange',()=>{if(document.hidden)interrupt();});
const keyboard=createKeyboardInput({keys,canMove:()=>!!session.current()&&!session.current().trial.snapshot().paused&&!(driver.failed()||viewportFrame.failed()),hook:()=>$('hook').click(),flash:()=>$('flash').click(),interrupt});
addEventListener('keydown',e=>keyboard.keydown(e));addEventListener('keyup',e=>keyboard.keyup(e));
const driver=createFrameDriver({current:()=>session.current(),input:()=>({x:Number(keys.has('KeyD'))-Number(keys.has('KeyA')),z:Number(keys.has('KeyS'))-Number(keys.has('KeyW'))}),onError:e=>{keys.clear();status('프레임 검사 중지: '+e.message+' · 검증 파일을 다시 불러오세요.');}});
const viewportFrame=createViewportFrame({current:()=>session.current(),viewport:()=>({width:$('map').clientWidth,height:$('map').clientHeight}),clearInput:()=>keys.clear(),driver,onError:e=>status('화면 검사 중지: '+e.message+' · 검증 파일을 다시 불러오세요.')});
function frame(time){viewportFrame.tick(time);raf=requestAnimationFrame(frame);}raf=requestAnimationFrame(frame);
addEventListener('pagehide',e=>{cancelAnimationFrame(raf);raf=0;last=0;keys.clear();if(e.persisted)session.cancel();else session.dispose();});
addEventListener('pageshow',e=>{if(e.persisted){status('페이지 복원됨. 검증 파일을 다시 불러오세요.');if(!raf)raf=requestAnimationFrame(frame);}});
$('map').addEventListener('webglcontextlost',e=>{e.preventDefault();keys.clear();session.cancel();status('그래픽 컨텍스트가 중단되었습니다. 복구 후 다시 불러오세요.');});
