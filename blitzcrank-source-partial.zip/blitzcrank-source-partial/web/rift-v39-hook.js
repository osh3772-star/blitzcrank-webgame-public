// Test-only planar hook; no import or mutation of the live game's authority.
import {createMapProbe} from './rift-v39-study.js';
import {CONFIG} from './core.js';
export const HOOK_TRIAL=Object.freeze({radius:.12,maxRange:CONFIG.maxRange,outSpeed:CONFIG.hookSpeed,returnSpeed:CONFIG.returnSpeed,maxDt:.05,iterations:40,wallGap:1e-5});
const point=p=>{if(!Array.isArray(p)||p.length!==2||!p.every(v=>Number.isFinite(v)&&Math.abs(v)<=1024))throw Error('유한한 XZ 좌표가 필요합니다.');return p.slice();};
const between=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*t);
export function createMapHookCollider(layout,options={}){
 const probe=createMapProbe(structuredClone(layout),{...options,radius:HOOK_TRIAL.radius});
 return Object.freeze({sweep(a,b){a=point(a);b=point(b);const distance=Math.hypot(b[0]-a[0],b[1]-a[1]);if(distance>512)throw Error('시험 선분 길이를 초과했습니다.');const invalid=probe.probe(a).blockedBy;if(invalid)return{blockedBy:invalid,invalidOrigin:true,position:a,contact:a,clearDistance:0,distance,resolution:0};const wall=probe.probe(a,b).blockedBy;if(!wall)return{blockedBy:null,invalidOrigin:false,position:b,contact:null,clearDistance:distance,distance,resolution:0};let lo=0,hi=1;for(let i=0;i<HOOK_TRIAL.iterations;i++){const mid=(lo+hi)/2;if(probe.probe(a,between(a,b,mid)).blockedBy)hi=mid;else lo=mid;}const safe=Math.max(0,distance*lo-HOOK_TRIAL.wallGap);return{blockedBy:probe.probe(a,between(a,b,hi)).blockedBy,invalidOrigin:false,position:between(a,b,distance?safe/distance:0),contact:between(a,b,hi),clearDistance:safe,distance,resolution:distance*(hi-lo)};}});
}
function targetsCopy(targets){if(!Array.isArray(targets)||targets.length>32)throw Error('시험 대상은 최대32개입니다.');const ids=new Set();return targets.map(t=>{if(!t||typeof t.id!=='string'||!t.id||ids.has(t.id)||!Number.isFinite(t.radius)||t.radius<=0||t.radius>2)throw Error('시험 대상 형식이 잘못됐습니다.');ids.add(t.id);return{id:t.id,center:point(t.center),radius:t.radius};});}
function targetContact(a,b,targets){const length=Math.hypot(b[0]-a[0],b[1]-a[1]);if(length===0)return null;const d=b.map((x,i)=>(x-a[i])/length);let best=null;for(const t of targets){const delta=a.map((x,i)=>x-t.center[i]),r=t.radius+HOOK_TRIAL.radius,c=delta[0]**2+delta[1]**2-r*r,projection=delta[0]*d[0]+delta[1]*d[1],disc=projection*projection-c;let at=c<=0?0:disc>=0?-projection-Math.sqrt(disc):Infinity;if(at>=0&&at<=length&&(!best||at<best.distance||at===best.distance&&t.id<best.id))best={id:t.id,distance:at,position:between(a,b,at/length)};}return best;}
export function createMapHookTrial(layout,options={}){
 const collider=createMapHookCollider(layout,options);let state={phase:'idle',position:null,origin:null,travel:0,hit:null,reason:null,contact:null},direction=null,targets=[];
 const snapshot=()=>structuredClone({...state,planarOnly:true,targetPull:false,heightCollision:false,gameplayChanged:false,networked:false});
 return Object.freeze({snapshot,cast({origin,aim,targets:input=[]}){origin=point(origin);aim=point(aim);const copied=targetsCopy(input),length=Math.hypot(aim[0]-origin[0],aim[1]-origin[1]);if(!length)return{accepted:false,reason:'zero-direction'};if(collider.sweep(origin,origin).blockedBy)return{accepted:false,reason:'blocked-origin'};if(['outbound','returning'].includes(state.phase))return{accepted:false,reason:'busy'};direction=aim.map((v,i)=>(v-origin[i])/length);targets=copied;state={phase:'outbound',position:origin.slice(),origin:origin.slice(),travel:0,hit:null,reason:null,contact:null};return{accepted:true,state:snapshot()};},cancel(){state={...state,phase:'idle',position:null,hit:null,reason:'cancelled',contact:null};return snapshot();},step(dt,{home=state.origin}={}){
  if(!Number.isFinite(dt)||dt<0)throw Error('유한한 음수가 아닌 시간이 필요합니다.');home=home===null?null:point(home);const seconds=Math.min(dt,HOOK_TRIAL.maxDt),segments=[];if(!seconds||!['outbound','returning'].includes(state.phase))return{...snapshot(),segments,seconds};
  const from=state.position.slice();
  if(state.phase==='outbound'){
   const distance=Math.min(HOOK_TRIAL.outSpeed*seconds,Math.max(0,HOOK_TRIAL.maxRange-state.travel)),to=from.map((v,i)=>v+direction[i]*distance),wall=collider.sweep(from,to),hit=targetContact(from,to,targets);
   if(hit&&(!wall.blockedBy||hit.distance<wall.clearDistance-wall.resolution)){state.position=hit.position;state.travel+=hit.distance;state.hit=hit.id;state.contact=hit.position.slice();state.reason='target';state.phase='returning';}
   else if(wall.blockedBy){state.position=wall.position;state.travel+=wall.clearDistance;state.contact=wall.contact;state.reason=wall.invalidOrigin?'invalid-origin':wall.blockedBy;state.phase=wall.invalidOrigin?'blocked':'returning';}
   else{state.position=to;state.travel+=distance;if(state.travel>=HOOK_TRIAL.maxRange){state.reason='range';state.phase='returning';}}
  }else{
   if(!home)throw Error('복귀 기준점이 필요합니다.');const d=Math.hypot(home[0]-from[0],home[1]-from[1]),amount=Math.min(d,HOOK_TRIAL.returnSpeed*seconds),to=d?between(from,home,amount/d):home.slice(),wall=collider.sweep(from,to);
   if(wall.blockedBy){state.position=wall.position;state.reason='return-blocked:'+wall.blockedBy;state.contact=wall.contact;state.phase='blocked';}else{state.position=to;if(amount===d)state.phase='idle';}
  }
  if(state.position.some((v,i)=>v!==from[i]))segments.push({from,to:state.position.slice()});return{...snapshot(),segments,seconds};
 }});
}
