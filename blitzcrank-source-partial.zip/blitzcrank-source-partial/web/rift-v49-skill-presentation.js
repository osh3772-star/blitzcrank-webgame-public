const phases={idle:'대기',outbound:'발사',pulling:'당김',returning:'복귀',blocked:'막힘'};
function xz(value){if(!Array.isArray(value)||value.length!==2||!value.every(Number.isFinite))throw Error('Finite presentation position required');return value.slice();}
// Read-only projection: no controller state, cooldown or collision rule is changed.
export function skillPresentation(snapshot){
 const player=xz(snapshot.position),pull=snapshot.pull,phase=pull.phase;
 if(!Object.hasOwn(phases,phase)||!Number.isFinite(snapshot.flash.remaining)||snapshot.flash.remaining<0)throw Error('Invalid presentation state');
 const active=['outbound','pulling','returning'].includes(phase),position=pull.position===null?null:xz(pull.position);
 if(active&&!position)throw Error('Active hook requires position');
 const tether=active?{from:[player[0],.8,player[1]],to:[position[0],.8,position[1]]}:null;
 const cooldown=snapshot.flash.ready?'준비':(Math.ceil(snapshot.flash.remaining*10)/10).toFixed(1)+'초';
 return {tether,phase,paused:snapshot.paused,text:(snapshot.paused?'일시정지':'시험 진행')+' · 그랩 '+phases[phase]+' · 점멸 '+cooldown+(pull.reason?' · 결과 '+String(pull.reason):'')+(pull.targetBlockedBy?' · 대상 장애물 '+String(pull.targetBlockedBy):'')};
}
// Real Three.js geometry construction can be tested without WebGL rendering.
export function createHookTether(THREE){
 const geometry=new THREE.BufferGeometry(),positions=new THREE.Float32BufferAttribute(new Float32Array(6),3);geometry.setAttribute('position',positions);
 const material=new THREE.LineBasicMaterial({color:0xffe08a}),line=new THREE.Line(geometry,material);line.visible=false;line.frustumCulled=false;let disposed=false;
 return {line,update(model){if(disposed)throw Error('Tether disposed');line.visible=!!model.tether;if(model.tether){positions.setXYZ(0,...model.tether.from);positions.setXYZ(1,...model.tether.to);positions.needsUpdate=true;}},dispose(){if(disposed)return;disposed=true;geometry.dispose();material.dispose();}};
}
