export function isolateSweepCollider(collider){
 if(!collider||typeof collider.sweep!=='function')throw Error('Sweep collider required');
 const point=p=>Array.isArray(p)&&p.length===2&&p.every(v=>Number.isFinite(v)&&Math.abs(v)<=1024);
 return Object.freeze({sweep(from,to){
  if(!point(from)||!point(to))throw Error('Finite bounded sweep endpoints required');
  const a=from.slice(),b=to.slice(),delta=b.map((v,i)=>v-a[i]),distance=Math.hypot(...delta),epsilon=1e-8*Math.max(1,distance);
  if(distance>512)throw Error('Sweep exceeds length limit');
  const raw=collider.sweep(a.slice(),b.slice());if(!raw||typeof raw!=='object')throw Error('Collider result required');
  const position=raw.position?.slice(),contact=raw.contact==null?null:raw.contact.slice(),clearDistance=raw.clearDistance,blockedBy=raw.blockedBy,invalidOrigin=raw.invalidOrigin??false,resolution=raw.resolution??0,reportedDistance=raw.distance??distance;
  if(!point(position)||(contact!==null&&!point(contact))||!(blockedBy===null||typeof blockedBy==='string'&&blockedBy.length>0)||typeof invalidOrigin!=='boolean'||![clearDistance,resolution,reportedDistance].every(Number.isFinite)||clearDistance<0||clearDistance>distance+epsilon||resolution<0||resolution>distance+epsilon||Math.abs(reportedDistance-distance)>epsilon)throw Error('Malformed sweep result');
  const along=p=>{const d=p.map((v,i)=>v-a[i]);if(!distance){if(Math.hypot(...d)>epsilon)throw Error('Stationary sweep displaced');return 0;}const t=(d[0]*delta[0]+d[1]*delta[1])/distance;const perpendicular=Math.abs(d[0]*delta[1]-d[1]*delta[0])/distance;if(t< -epsilon||t>distance+epsilon||perpendicular>epsilon)throw Error('Sweep result leaves requested segment');return t;};
  const progress=along(position);if(Math.abs(progress-clearDistance)>epsilon)throw Error('Sweep distance disagrees with position');
  if(contact!==null&&along(contact)+epsilon<progress)throw Error('Contact precedes safe endpoint');
  if(invalidOrigin&&(!blockedBy||clearDistance>epsilon))throw Error('Invalid-origin sweep advanced');
  if(blockedBy===null&&(invalidOrigin||Math.abs(clearDistance-distance)>epsilon))throw Error('Unblocked sweep did not reach endpoint');
  return {position:position.slice(),contact:contact?.slice()??null,clearDistance,blockedBy,invalidOrigin,resolution,distance};
 }});
}
