import {createColliderIsolatedTrial} from './rift-v49-collider-isolated-trial.js';
// Synchronous external-entry guard. Internal search-to-commit calls remain one operation.
export function createReentrancyGuardedTrial(THREE,components,options){
 const base=createColliderIsolatedTrial(THREE,components,options),readOnly=new Set(['snapshot','inspectContainment']);let active=null;
 const api={};
 for(const [name,method] of Object.entries(base)){
  if(typeof method!=='function')throw Error('Unexpected trial API value');
  api[name]=readOnly.has(name)?(...args)=>method(...args):(...args)=>{
   if(active!==null){const error=new Error('Reentrant trial operation blocked: '+name+' during '+active);error.code='TRIAL_REENTRANCY';throw error;}
   active=name;try{return method(...args);}finally{active=null;}
  };
 }
 return Object.freeze(api);
}
