import {createFullbodyWStationaryLayer} from './w-stationary-layer.js';
import {validateSkillAsset, bindSkillClips, createFullbodyPoseApplicator, createFullbodyELocomotionLayer, eRecoveryArmWeight, rRecoveryArmWeight, clearFullbodySkillPose} from './skill-animation.js?v=0.24.70';
// Presentation only. No opponent controller, simulation, scoring, inputs, VFX,
// resource creation, network code, or asset ownership lives in this adapter.
const PHASES = new Set(['windup', 'outbound', 'return', 'recover']);
const smooth = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
const finite = (value, name) => {
  if (!Number.isFinite(value)) throw new TypeError(`${name} must be finite`);
  return value;
};
function vector(value, size, name) {
  const values = Array.isArray(value) || ArrayBuffer.isView(value)
    ? Array.from(value) : value?.toArray?.();
  if (!values || values.length !== size || !values.every(Number.isFinite)) {
    throw new TypeError(`${name} must contain ${size} finite numbers`);
  }
  return values;
}
/** The live game changes only procedural pivots, Q launch and both knees.
 * Bake the other rig Groups, never surfaces, attached effects or the body root.
 * Call only for that immutable local-pose contract; world updates stay enabled. */
export function cacheStaticFullbodyNodeMatrices(nodes) {
  const cached=[];
  for(const [name,node] of nodes){
    if(!node.isGroup||name.startsWith('BC_Pivot_')||name.startsWith('BC_QLaunch')||name==='BC_Knee.L'||name==='BC_Knee.R')continue;
    node.updateMatrix();node.matrixAutoUpdate=false;cached.push(node);
  }
  return cached;
}
function cloneRig(source) {
  const body = source.body.clone(true), objects = new Map();
  function pair(a, b) {
    objects.set(a, b);
    for (let i = 0; i < a.children.length; i++) pair(a.children[i], b.children[i]);
  }
  pair(source.body, body);
  return {body, nodes: new Map([...source.nodes].map(([name, node]) => [name, objects.get(node)])),
    meshes: new Map([...source.meshes].map(([name, mesh]) => [name, objects.get(mesh)]))};
}
function validateTemplate({body, nodes, meshes}) {
  if (!body?.isObject3D || !(nodes instanceof Map) || !(meshes instanceof Map)) {
    throw new TypeError('An unposed fullbody and its node/mesh maps are required');
  }
  if (!nodes.has('BC_QLaunch.R') || !nodes.has('BC_Pivot_Shoulder.R') ||
      !meshes.has('BC_Palm.R') || !meshes.has('BC_Elbow.R')) throw new Error('Missing Q rig');
  const allowed = new Set([body, ...nodes.values(), ...meshes.values()]);
  if (allowed.size !== 1 + nodes.size + meshes.size) throw new Error('Rig maps must have unique objects');
  let count = 0;
  body.traverse(object => {
    count++;
    if (!allowed.has(object)) throw new Error('Capture the fullbody before attaching VFX or other children');
    if (object === body) return;
    if (!object.matrixAutoUpdate || !object.matrixWorldAutoUpdate || object.isSkinnedMesh || object.isInstancedMesh) {
      throw new Error('Expected the unposed rigid fullbody');
    }
    const base = object.isMesh ? [0, 0, 0] : object.userData.base;
    if (!base || object.position.toArray().some((v, i) => v !== base[i]) ||
        object.quaternion.x !== 0 || object.quaternion.y !== 0 || object.quaternion.z !== 0 ||
        Math.abs(object.quaternion.w) !== 1 || object.scale.toArray().some(v => v !== 1)) {
      throw new Error('Capture the fullbody before posing it');
    }
    if (object.isMesh && !object.geometry?.boundingBox) throw new Error('Expected calibrated mesh bounds');
  });
  if (count !== allowed.size) throw new Error('Rig maps contain objects outside the fullbody');
  if (!Number.isFinite(body.scale.x) || body.scale.x <= 0 || body.scale.x !== body.scale.y || body.scale.x !== body.scale.z) {
    throw new Error('Fullbody must have positive uniform scale');
  }
}

/** Capture once in buildFullbody, before animation/VFX. The returned factory owns
 * only cloned Object3Ds. Source geometry, materials, textures and bounds remain
 * shared and must be treated as immutable for the lifetime of all avatars.
 * Inject the existing createFullbodyLocomotion; no import paths need rewriting. */
export function createDuelAvatarFactory(THREE, {body, nodes, meshes, createLocomotion}) {
  if (typeof createLocomotion !== 'function') throw new TypeError('createLocomotion is required');
  validateTemplate({body, nodes, meshes});
  let template = cloneRig({body, nodes, meshes});
  template.body.position.set(0, 0, 0);
  template.body.quaternion.identity();
  template.body.visible = false;
  const scale = body.scale.x;
  body = nodes = meshes = null; // The factory must not retain the live player tree.
  return Object.freeze({
    create(options = {}) {
      if (!template) throw new Error('Avatar factory has been disposed');
      return createActor(THREE, cloneRig(template), createLocomotion, scale, options);
    },
    dispose() {
      if (!template) return;
      template.body.clear(); template.nodes.clear(); template.meshes.clear(); template = null;
    },
  });
}

// Opt-in assumes the current game's fixed rig/locomotion contract. Custom
// controllers that move other Groups must keep the default automatic matrices.
function createActor(THREE, initialRig, createLocomotion, scale, {parent = null, visible = false, staticRestMatrices = false, reuseSkillSurfaceRestPose = false, stationaryW = false} = {}) {
  let rig = initialRig, motion = createLocomotion(THREE, {nodes: rig.nodes, meshes: rig.meshes, scale});
  initialRig = null;
  // Calibrate while detached: the existing locomotion finds its model root by
  // walking ancestors, and must not accidentally calibrate against an arena Group.
  const object = rig.body;
  let q = rig.nodes.get('BC_QLaunch.R'), shoulder = rig.nodes.get('BC_Pivot_Shoulder.R');
  let palm = rig.meshes.get('BC_Palm.R'), elbow = rig.meshes.get('BC_Elbow.R');
  const rest = [];
  object.traverse(node => rest.push({node, position: node.position.clone(), quaternion: node.quaternion.clone(), scale: node.scale.clone()}));
  const qRest = q.position.clone(), qRestRotation = q.quaternion.clone();
  const homePalm = new THREE.Vector3(), homeOrientation = new THREE.Quaternion();
  const center = new THREE.Vector3(), current = new THREE.Vector3(), desired = new THREE.Vector3();
  const parentPosition = new THREE.Vector3(), parentScale = new THREE.Vector3(), parentOrientation = new THREE.Quaternion();
  const worldOrientation = new THREE.Quaternion(), handOrientation = new THREE.Quaternion();
  const worldMatrix = new THREE.Matrix4(), localMatrix = new THREE.Matrix4();
  const worldScale = new THREE.Vector3(scale, scale, scale), up = new THREE.Vector3(0, 1, 0);
  let disposed = false, phase = null, skillName = null, skillClips = null, eLayer = null, wLayer = null;
  let staticNodes=[], skillRestReusable=false;
  const surfaces = [...rig.meshes.values()], applySkill = createFullbodyPoseApplicator(THREE);
  function configureSkills(model) {
    assertLive();
    // Validate and bind before changing any actor state. Binding expands split
    // surfaces by source name and never touches the factory's pristine template.
    validateSkillAsset({version: 1, models: {viewmodel: model, fullbody: model}});
    configureBoundSkills(model);
  }
  /** Private startup contract: only the fresh, unmodified model from
   * loadSkillAsset, before it escapes to callers. Never use for caller-owned
   * or merely previously validated mutable data; use configureSkills instead. */
  function configureLoadedSkills(model) {
    assertLive();
    configureBoundSkills(model);
  }
  function configureBoundSkills(model) {
    const clips = new Map(bindSkillClips(model, surfaces).map(c => [c.name, c]));
    for (const mesh of surfaces) vector(mesh.userData.skillRestPoint, 3, 'skillRestPoint');
    // Anchor calibration requires rest transforms, so configure before posing.
    if (skillClips || skillName || phase || motion.poseBlend || motion.blend) throw new Error('Configure skills once before animation');
    const layer = createFullbodyELocomotionLayer(THREE, {body: object, nodes: rig.nodes, surfaces, locomotion: motion});
    const stationary = stationaryW ? createFullbodyWStationaryLayer(THREE, {body: object, nodes: rig.nodes, surfaces, locomotion: motion}) : null;
    skillClips = clips; eLayer = layer; wLayer = stationary;
  }
  const assertLive = () => { if (disposed) throw new Error('Avatar has been disposed'); };
  function checkParent() {
    if (!object.parent) return;
    object.parent.updateWorldMatrix(true, false);
    const m = object.parent.matrixWorld, e = m.elements;
    m.decompose(parentPosition, parentOrientation, parentScale);
    const s = parentScale.x, tolerance = 1e-8 * Math.max(1, s * s);
    const dot = (a, b) => e[a] * e[b] + e[a + 1] * e[b + 1] + e[a + 2] * e[b + 2];
    if (!e.every(Number.isFinite) || s <= 0 || m.determinant() <= 0 ||
        Math.abs(s - parentScale.y) > 1e-8 || Math.abs(s - parentScale.z) > 1e-8 ||
        Math.abs(dot(0, 4)) > tolerance || Math.abs(dot(0, 8)) > tolerance || Math.abs(dot(4, 8)) > tolerance) {
      throw new Error('Avatar parent must have a finite rigid or positive uniform-scale world transform');
    }
  }
  function place(position, yaw, offset = 0) {
    desired.fromArray(position); desired.y += offset;
    worldOrientation.setFromAxisAngle(up, yaw + Math.PI);
    worldMatrix.compose(desired, worldOrientation, worldScale);
    if (object.parent) localMatrix.copy(object.parent.matrixWorld).invert().multiply(worldMatrix);
    else localMatrix.copy(worldMatrix);
    localMatrix.decompose(object.position, object.quaternion, object.scale);
  }
  function readInput(dt, state) {
    finite(dt, 'dt');
    if (dt < 0 || dt > .1) throw new RangeError('dt must be within [0, 0.1] seconds');
    const position = vector(state?.position, 3, 'position'), yaw = finite(state.yaw, 'yaw');
    const pitch = finite(state.pitch ?? 0, 'pitch'), input = state.locomotion ?? {};
    const locomotion = {deltaX: finite(input.deltaX ?? 0, 'deltaX'), deltaZ: finite(input.deltaZ ?? 0, 'deltaZ'), yaw,
      grounded: input.grounded !== false};
    if (dt > 0 && !Number.isFinite(Math.hypot(locomotion.deltaX, locomotion.deltaZ) / dt)) {
      throw new RangeError('Locomotion travel/dt must produce a finite speed');
    }
    if (input.height !== undefined || input.velocityY !== undefined) {
      locomotion.height = finite(input.height, 'height');
      locomotion.velocityY = finite(input.velocityY, 'velocityY');
    }
    let hook = null;
    if (state.hook != null) {
      const h = state.hook;
      if (!PHASES.has(h.phase)) throw new TypeError('Unknown Q phase');
      hook = {phase: h.phase, phaseTime: finite(h.phaseTime, 'phaseTime')};
      if (hook.phaseTime < 0) throw new RangeError('phaseTime must be nonnegative');
      if (h.phase === 'outbound' || h.phase === 'return') {
        hook.position = vector(h.position, 3, 'hook.position');
        if (h.bodyOrientation != null) {
          hook.bodyOrientation = vector(h.bodyOrientation, 4, 'hook.bodyOrientation');
          const length = Math.hypot(...hook.bodyOrientation);
          if (length < 1e-12) throw new RangeError('bodyOrientation must be nonzero');
          hook.bodyOrientation = hook.bodyOrientation.map(v => v / length);
        }
      }
      if (h.phase === 'return') {
        hook.returnDuration = finite(h.returnDuration, 'returnDuration');
        if (hook.returnDuration <= 0) throw new RangeError('returnDuration must be positive');
      }
    }
    let skill = null;
    if (state.skill != null) {
      const readSkill = value => {
        if (!value || typeof value.name !== 'string' || !skillClips?.has(value.name)) throw new TypeError('Unknown or unconfigured skill clip');
        const time = finite(value.time, 'skill.time');
        if (time < 0) throw new RangeError('skill.time must be nonnegative');
        return {name: value.name, time};
      };
      skill = readSkill(state.skill);
      if (state.skill.presentation != null) skill = readSkill(state.skill.presentation);
    }
    return {position, yaw, pitch, locomotion, hook, skill};
  }
  function update(dt, state, {deferWorldMatrices = false, rLocomotion = false, eArmRecovery = false, rArmRecovery = false} = {}) {
    assertLive();
    // Reject malformed snapshots before advancing motion or changing local poses.
    const input = readInput(dt, state);
    checkParent();
    motion.advance(dt, input.locomotion);
    motion.restorePose(); q.position.copy(qRest); q.quaternion.copy(qRestRotation);
    const nextSkillName = !input.hook ? input.skill?.name ?? null : null;
    // Game-only opt-in: standard locomotion/VFX never modify surface local TRS,
    // and validated clips/rest metadata remain immutable. Keep the first clear
    // of each consecutive skill sequence to preserve its canonical Euler state.
    // Other consumers retain the original unconditional reset by default.
    if (skillName && !(reuseSkillSurfaceRestPose && nextSkillName && skillRestReusable)) clearFullbodySkillPose(surfaces);
    skillRestReusable = !!(skillName && nextSkillName);
    skillName = nextSkillName;
    let offset = 0;
    if (skillName) {
      applySkill(skillClips.get(skillName), input.skill.time, surfaces);
      // Evaluate the existing lower-body layer in canonical model coordinates;
      // placement below converts its root offset to world space even under a parent.
      object.position.set(0, 0, 0); object.quaternion.identity(); object.scale.setScalar(scale);
      // Game presentation opt-in; standalone R keeps its authored lower pose.
      if (skillName.startsWith('E_') || (rLocomotion && skillName === 'R_Cast')) offset = eLayer({armRecoveryWeight:eArmRecovery&&skillName==='E_Strike'?eRecoveryArmWeight(input.skill.time,skillClips.get(skillName).duration):rArmRecovery&&skillName==='R_Cast'?rRecoveryArmWeight(input.skill.time,skillClips.get(skillName).duration):0});
      else if (wLayer && skillName.startsWith('W_')) wLayer();
    } else offset = motion.applyPose({preserveUpper: !!input.hook});
    place(input.position, input.yaw, offset);
    phase = input.hook?.phase ?? null;
    if (input.hook) {
      const h = input.hook;
      const lift = phase === 'windup' ? smooth(h.phaseTime / .25) : phase === 'recover' ? 1 - smooth(h.phaseTime / .26) : 1;
      shoulder.rotation.x = -(Math.PI / 2 + input.pitch) * lift; shoulder.rotation.z = 0;
    }
    // Capture the attached palm BEFORE translating the actual Q subtree. No
    // duplicate fist is created; every forearm/hand surface follows that subtree.
    palm.geometry.boundingBox.getCenter(center); palm.localToWorld(center); homePalm.copy(center);
    q.getWorldQuaternion(homeOrientation);
    if (phase === 'outbound' || phase === 'return') {
      const h = input.hook;
      if (h.bodyOrientation) handOrientation.fromArray(h.bodyOrientation);
      else handOrientation.copy(homeOrientation);
      if (phase === 'return') handOrientation.slerp(homeOrientation, smooth(h.phaseTime / h.returnDuration));
      q.quaternion.copy(q.parent.getWorldQuaternion(parentOrientation).invert()).multiply(handOrientation);
      palm.geometry.boundingBox.getCenter(center); palm.localToWorld(center);
      current.copy(center); q.parent.worldToLocal(current);
      desired.fromArray(h.position); q.parent.worldToLocal(desired);
      q.position.add(desired.sub(current));
    }
    // The game can let its normal render pass refresh the full descendant tree.
    // Socket getters remain immediate; standalone callers and resets stay eager.
    if (!deferWorldMatrices) object.updateWorldMatrix(true, true);
  }
  function reset({position = [0, 0, 0], yaw = 0, pitch = 0, visible = false} = {}) {
    assertLive(); readInput(0, {position, yaw, pitch}); checkParent();
    motion.reset();
    for (const r of rest) {
      r.node.position.copy(r.position); r.node.quaternion.copy(r.quaternion); r.node.scale.copy(r.scale);
    }
    for(const node of staticNodes)node.updateMatrix();
    update(0, {position, yaw, pitch}); object.visible = !!visible;
  }
  function getSockets() {
    assertLive();
    // Each world-space getter refreshes its own ancestor chain. Avoid a second
    // full avatar/VFX descendant traversal just to read these socket transforms.
    const palmPoint = palm.localToWorld(palm.geometry.boundingBox.getCenter(center)).toArray();
    const cablePoint = elbow.localToWorld(elbow.geometry.boundingBox.getCenter(center)).toArray();
    return {palm: palmPoint, homePalm: homePalm.toArray(), cable: cablePoint,
      chain: q.getWorldPosition(center).toArray(), homeOrientation: homeOrientation.toArray(),
      handOrientation: q.getWorldQuaternion(handOrientation).toArray()};
  }
  function dispose() {
    if (disposed) return;
    motion.reset(); clearFullbodySkillPose(surfaces);
    for (const r of rest) {
      r.node.position.copy(r.position); r.node.quaternion.copy(r.quaternion); r.node.scale.copy(r.scale); r.node.updateMatrix();
    }
    skillClips = eLayer = wLayer = null; skillName = null; surfaces.length = 0;
    object.visible = false; object.removeFromParent(); object.clear();
    rig.nodes.clear(); rig.meshes.clear(); rest.length = 0; staticNodes.length = 0;
    rig = motion = q = shoulder = palm = elbow = null; disposed = true; phase = null;
    // NEVER dispose geometry/material/texture: the player and other avatars own
    // and still render the same immutable assets.
  }
  try {
    if (parent) {
      if (!parent.isObject3D) throw new TypeError('parent must be a Three.js Object3D');
      parent.add(object); parent = null;
    }
    reset({visible});
    if(staticRestMatrices)staticNodes=cacheStaticFullbodyNodeMatrices(rig.nodes);
  } catch (error) { dispose(); throw error; }
  return Object.freeze({object, update, reset, getSockets, dispose, configureSkills, configureLoadedSkills,
    getSkillHands() { assertLive(); return ['L', 'R'].map(side => rig.meshes.get('BC_Palm.' + side)); },
    hide() { assertLive(); object.visible = false; },
    show() { assertLive(); object.visible = true; },
    inspect() { return {disposed, visible: object.visible, phase, skill: skillName, nodes: rig?.nodes.size ?? 0,
      surfaces: rig?.meshes.size ?? 0, locomotion: motion?.inspect() ?? null}; },
  });
}
