// Isolated candidate, not wired into the game. No THREE, rendering, clock,
// contact, score, hook, reset, or actor mutation belongs in this module.
const DEFAULT_BOUNDS = {min: {x: -23.4, z: -42.5}, max: {x: 23.4, z: 15.5}};
const HARD_OBSTACLE_LIMIT = 64;
const HARD_NODE_LIMIT = 258; // endpoints plus four corners per obstacle
const finite = Number.isFinite;
const point = p => p && ['x', 'y', 'z'].every(k => finite(p[k]));
const copy = p => ({x: p.x, y: p.y, z: p.z});
const lerp = (a, b, u) => a + (b - a) * u;
const fail = (code, details = {}) => ({ok: false, code, ...details});

// Exact open-interior slab test, not a finite set of point samples. Touching a
// face/edge without entering the interior is legal, like existing movement.
// A segment can be arbitrarily short or skip completely over a thin obstacle.
export function segmentCrossesOpenBox(a, b, box, axes = ['x', 'y', 'z']) {
  let lo = 0, hi = 1;
  for (const axis of axes) {
    const delta = b[axis] - a[axis];
    if (delta === 0) {
      if (a[axis] <= box.min[axis] || a[axis] >= box.max[axis]) return false;
    } else {
      const t0 = (box.min[axis] - a[axis]) / delta;
      const t1 = (box.max[axis] - a[axis]) / delta;
      lo = Math.max(lo, Math.min(t0, t1));
      hi = Math.min(hi, Math.max(t0, t1));
      if (lo >= hi) return false;
    }
  }
  return lo < hi;
}

function insideXZ(p, box) {
  return p.x > box.min.x && p.x < box.max.x && p.z > box.min.z && p.z < box.max.z;
}
function withinXZ(p, bounds) {
  return p.x >= bounds.min.x && p.x <= bounds.max.x && p.z >= bounds.min.z && p.z <= bounds.max.z;
}
function convexHull(points) {
  const sorted = points.slice().sort((a, b) => a.x - b.x || a.z - b.z);
  const cross = (a, b, c) => (b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x);
  const half = items => {
    const result = [];
    for (const p of items) {
      while (result.length > 1 && cross(result.at(-2), result.at(-1), p) <= 0) result.pop();
      result.push(p);
    }
    return result;
  };
  const lower = half(sorted), upper = half(sorted.slice().reverse());
  return lower.slice(0, -1).concat(upper.slice(0, -1));
}
function hullCrossesOpenBox(points, box) {
  const hull = convexHull(points);
  if (hull.length <= 2) return segmentCrossesOpenBox(hull[0] ?? points[0], hull.at(-1) ?? points[0], box, ['x', 'z']);
  const corners = [{x: box.min.x, z: box.min.z}, {x: box.min.x, z: box.max.z},
    {x: box.max.x, z: box.min.z}, {x: box.max.x, z: box.max.z}];
  const axes = [{x: 1, z: 0}, {x: 0, z: 1}];
  for (let i = 0; i < hull.length; i++) {
    const a = hull[i], b = hull[(i + 1) % hull.length];
    axes.push({x: -(b.z - a.z), z: b.x - a.x});
  }
  for (const axis of axes) {
    if (axis.x === 0 && axis.z === 0) continue;
    const a = hull.map(p => p.x * axis.x + p.z * axis.z), b = corners.map(p => p.x * axis.x + p.z * axis.z);
    if (Math.max(...a) <= Math.min(...b) || Math.max(...b) <= Math.min(...a)) return false;
  }
  return true;
}

function certifyChords(plan, boxes, maxProgressStep) {
  if (plan.kind === 'direct') return {ok: true, maxProgressStep: 1, checkedEnvelopes: 0};
  const maxTravel = plan.length * maxProgressStep;
  const lowY = Math.min(plan.from.y, plan.to.y), highY = Math.max(plan.from.y, plan.to.y);
  const active = boxes.filter(b => lowY < b.max.y && highY > b.min.y);
  let checkedEnvelopes = 0;
  for (let i = 0; i < plan.points.length - 1; i++) {
    for (let j = i + 1; j < plan.points.length - 1; j++) {
      const gap = plan.cumulative[j] - plan.cumulative[i + 1];
      if (gap > maxTravel) break;
      const reach = maxTravel - gap;
      const a0 = plan.points[i], a1 = plan.points[i + 1], b0 = plan.points[j], b1 = plan.points[j + 1];
      const lenA = plan.cumulative[i + 1] - plan.cumulative[i], lenB = plan.cumulative[j + 1] - plan.cumulative[j];
      // Split the first endpoint interval into 16 CLOSED ranges. Within each,
      // use the largest possible second interval. This covers the triangular
      // constraint a+b+gap<=maxTravel without the much broader full rectangle.
      const aReach = Math.min(reach, lenA), slices = aReach > 0 ? 16 : 1;
      for (let slice = 0; slice < slices; slice++) {
        const aLow = aReach * slice / slices, aHigh = aReach * (slice + 1) / slices;
        const ua0 = lenA ? 1 - aHigh / lenA : 0, ua1 = lenA ? 1 - aLow / lenA : 0;
        const ub = lenB ? Math.min(1, (reach - aLow) / lenB) : 0;
        const envelope = [{x: lerp(a0.x, a1.x, ua0), z: lerp(a0.z, a1.z, ua0)},
          {x: lerp(a0.x, a1.x, ua1), z: lerp(a0.z, a1.z, ua1)}, b0,
          {x: lerp(b0.x, b1.x, ub), z: lerp(b0.z, b1.z, ub)}];
        checkedEnvelopes++;
        const blocking = active.find(box => hullCrossesOpenBox(envelope, box));
        if (blocking) return fail('FRAME_CHORD_UNSAFE', {maxProgressStep, legA: i, legB: j, obstacleIndex: blocking.obstacleIndex});
      }
    }
  }
  return {ok: true, maxProgressStep, checkedEnvelopes};
}

/** Sufficient analytic certificate for EVERY pair with |du| <= the bound.
 * Endpoint sets on each leg are enclosed in a convex polygon. SAT proves
 * that entire polygon misses every inflated obstacle; all chords lie in it.
 * Conservative failure means unproved, not necessarily an observed collision.
 */
export function certifyDuelPullFrameChords(plan, options) {
  if (!plan?.ok || !finite(options?.maxProgressStep) || options.maxProgressStep < 0 || options.maxProgressStep > 1) return fail('INVALID_INPUT');
  const input = normalize({...options, from: plan.from, to: plan.to});
  if (!input.ok) return input;
  return certifyChords(plan, input.boxes, options.maxProgressStep);
}
function normalize(options) {
  const {from, to, obstacles = [], bounds = DEFAULT_BOUNDS, radius = .42,
    eyeToFeet = 1.7, eyeToTop = 0, floorY = 0, cornerPadding = .00001,
    maxNodes = HARD_NODE_LIMIT} = options ?? {};
  if (!point(from) || !point(to) || !Array.isArray(obstacles) ||
      !bounds?.min || !bounds?.max || !['x', 'z'].every(k =>
        finite(bounds.min[k]) && finite(bounds.max[k]) && bounds.min[k] < bounds.max[k]) ||
      ![radius, eyeToFeet, eyeToTop, cornerPadding].every(v => finite(v) && v >= 0) ||
      !finite(floorY) || !Number.isInteger(maxNodes) || maxNodes < 2 || maxNodes > HARD_NODE_LIMIT) {
    return fail('INVALID_INPUT');
  }
  if (obstacles.length > HARD_OBSTACLE_LIMIT) return fail('OBSTACLE_BUDGET_EXCEEDED', {limit: HARD_OBSTACLE_LIMIT});
  const boxes = [];
  for (let index = 0; index < obstacles.length; index++) {
    const o = obstacles[index];
    if (!point(o?.min) || !point(o?.max) || !['x', 'y', 'z'].every(k => o.min[k] <= o.max[k])) {
      return fail('INVALID_OBSTACLE', {obstacleIndex: index});
    }
    // Minkowski expansion: the eye is a point and the actor occupies a box
    // [x-radius,x+radius] × [eye-eyeToFeet,eye+eyeToTop] × [z-radius,z+radius].
    const b = {obstacleIndex: index,
      min: {x: o.min.x - radius, y: o.min.y - eyeToTop, z: o.min.z - radius},
      max: {x: o.max.x + radius, y: o.max.y + eyeToFeet, z: o.max.z + radius}};
    if (!point(b.min) || !point(b.max)) return fail('INVALID_OBSTACLE', {obstacleIndex: index});
    boxes.push(b);
  }
  if (!finite(floorY + eyeToFeet)) return fail('INVALID_INPUT');
  return {ok: true, from: copy(from), to: copy(to), originalEnd: copy(to), boxes,
    bounds: {min: {...bounds.min}, max: {...bounds.max}}, minEyeY: floorY + eyeToFeet,
    cornerPadding, maxNodes};
}

function endpointMetadata(input) {
  const x = input.to.x - input.originalEnd.x, z = input.to.z - input.originalEnd.z;
  return {originalEnd: copy(input.originalEnd), end: copy(input.to),
    endpointAdjusted: x !== 0 || z !== 0, adjustment: {x, y: 0, z, distance: Math.hypot(x, z)}};
}

function projectEnd(input) {
  const {to, boxes, bounds, minEyeY} = input;
  if (!withinXZ(to, bounds)) return fail('ENDPOINT_OUT_OF_BOUNDS', {endpoint: 'to'});
  if (to.y < minEyeY) return fail('ENDPOINT_BELOW_FLOOR', {endpoint: 'to', minEyeY});
  const active = boxes.filter(b => to.y > b.min.y && to.y < b.max.y);
  if (!active.some(b => insideXZ(to, b))) return {ok: true, end: copy(to), candidateCount: 0};

  // Global closest point in a bounded rectangle minus a union of open AABBs.
  // A minimum is either the original point, an orthogonal projection onto a
  // free boundary segment, or an endpoint of such a segment. Every such point
  // uses x/z coordinates from {original, arena edges, obstacle edges}.
  // Enumerate their Cartesian product and check against ALL active boxes.
  // Boundary contact is legal under the exact existing .42 movement rule.
  const xs = new Set([to.x, bounds.min.x, bounds.max.x]);
  const zs = new Set([to.z, bounds.min.z, bounds.max.z]);
  for (const b of active) {
    for (const x of [b.min.x, b.max.x]) if (x >= bounds.min.x && x <= bounds.max.x) xs.add(x);
    for (const z of [b.min.z, b.max.z]) if (z >= bounds.min.z && z <= bounds.max.z) zs.add(z);
  }
  let best = null, bestDistance = Infinity, candidateCount = 0;
  for (const x of [...xs].sort((a, b) => a - b)) {
    for (const z of [...zs].sort((a, b) => a - b)) {
      candidateCount++;
      const p = {x, y: to.y, z};
      if (active.some(b => insideXZ(p, b))) continue;
      const distance = Math.hypot(x - to.x, z - to.z);
      // Deterministic equal-distance tie: lower x, then lower z.
      if (distance < bestDistance) { best = p; bestDistance = distance; }
    }
  }
  if (!best || !finite(bestDistance)) return fail('ENDPOINT_PROJECTION_FAILED', {candidateCount});
  return {ok: true, end: best, candidateCount, nearestDistance: bestDistance};
}

/** Explicit stage; never moves a legal endpoint or changes its height. */
export function projectBlockedDuelPullEnd(options) {
  const input = normalize({...options, from: options?.end, to: options?.end});
  if (!input.ok) return input;
  const result = projectEnd(input);
  if (!result.ok) return result;
  input.to = result.end;
  return {...result, ...endpointMetadata(input)};
}

function makePlan(input, nodes, kind, padding, diagnostics) {
  const {from, to, boxes, bounds, minEyeY} = input;
  const cumulative = [0];
  for (let i = 1; i < nodes.length; i++) {
    cumulative.push(cumulative[i - 1] + Math.hypot(nodes[i].x - nodes[i - 1].x, nodes[i].z - nodes[i - 1].z));
  }
  const length = cumulative.at(-1);
  if (!finite(length)) return fail('NUMERICAL_VALIDATION_FAILED');
  const points = nodes.map((p, i) => ({x: p.x, y: lerp(from.y, to.y, length ? cumulative[i] / length : i), z: p.z}));
  points[0] = copy(from);
  points[points.length - 1] = copy(to);
  // A second full 3-D continuous certification, including the actual y law.
  // This must pass before any sampleable success can leave the module.
  for (let i = 0; i < points.length; i++) {
    if (!withinXZ(points[i], bounds) || points[i].y < minEyeY) return fail('NUMERICAL_VALIDATION_FAILED');
    if (i && boxes.some(b => segmentCrossesOpenBox(points[i - 1], points[i], b))) {
      return fail('NUMERICAL_VALIDATION_FAILED');
    }
  }
  const straightLength = Math.hypot(to.x - from.x, to.z - from.z);
  return {ok: true, kind, from, to, points, cumulative, length, straightLength,
    ...endpointMetadata(input),
    extraLength: length - straightLength, cornerPadding: padding, diagnostics};
}

function routeGraph(input, projected, padding) {
  const {from, to, bounds, maxNodes} = input;
  const candidates = [];
  for (const box of projected) {
    for (const x of [box.min.x - padding, box.max.x + padding]) {
      for (const z of [box.min.z - padding, box.max.z + padding]) {
        const p = {x, z};
        if (withinXZ(p, bounds) && !projected.some(b => insideXZ(p, b))) candidates.push(p);
      }
    }
  }
  candidates.sort((a, b) => a.x - b.x || a.z - b.z);
  const nodes = [{x: from.x, z: from.z}, {x: to.x, z: to.z}];
  const seen = new Set(nodes.map(p => `${p.x},${p.z}`));
  for (const p of candidates) {
    const key = `${p.x},${p.z}`;
    if (!seen.has(key)) { seen.add(key); nodes.push(p); }
  }
  if (nodes.length > maxNodes) return fail('NODE_BUDGET_EXCEEDED', {needed: nodes.length, limit: maxNodes});
  const links = Array.from({length: nodes.length}, () => []);
  let checkedEdges = 0;
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      checkedEdges++;
      if (projected.some(b => segmentCrossesOpenBox(nodes[i], nodes[j], b, ['x', 'z']))) continue;
      const length = Math.hypot(nodes[i].x - nodes[j].x, nodes[i].z - nodes[j].z);
      if (!finite(length)) return fail('NUMERICAL_VALIDATION_FAILED');
      links[i].push({node: j, length}); links[j].push({node: i, length});
    }
  }
  const distances = Array(nodes.length).fill(Infinity), hops = Array(nodes.length).fill(Infinity);
  const previous = Array(nodes.length).fill(-1), visited = Array(nodes.length).fill(false);
  distances[0] = 0; hops[0] = 0;
  for (let iteration = 0; iteration < nodes.length; iteration++) {
    let current = -1;
    for (let i = 0; i < nodes.length; i++) {
      if (!visited[i] && finite(distances[i]) && (current < 0 || distances[i] < distances[current] ||
          (distances[i] === distances[current] && hops[i] < hops[current]))) current = i;
    }
    if (current < 0 || current === 1) break;
    visited[current] = true;
    for (const edge of links[current]) {
      const next = edge.node, d = distances[current] + edge.length, h = hops[current] + 1;
      if (!visited[next] && (d < distances[next] ||
          (d === distances[next] && (h < hops[next] || (h === hops[next] && current < previous[next]))))) {
        distances[next] = d; hops[next] = h; previous[next] = current;
      }
    }
  }
  if (!finite(distances[1])) return fail('NO_SAFE_PATH_FOUND', {nodes: nodes.length, checkedEdges});
  const path = [];
  for (let at = 1; at >= 0; at = previous[at]) path.push(nodes[at]);
  path.reverse();
  return makePlan(input, path, 'polyline', padding, {nodes: nodes.length, checkedEdges});
}

/**
 * Plan one frozen-start/frozen-destination static-obstacle pull.
 * The caller supplies the existing destination; it is never recomputed here.
 * Success is direct (bit-identical lerp formula) or a certified X/Z polyline.
 * Endpoint preservation is the default. Explicit projectBlockedDestination:
 * true permits only the globally nearest legal X/Z projection of an endpoint
 * inside cover, and exposes originalEnd/end/adjustment. It never moves an
 * already legal endpoint, an out-of-bounds endpoint, or an invalid start.
 * Failure NEVER supplies a fallback path. The caller must handle it explicitly.
 * Runtime is bounded by 64 obstacles and 258 nodes. Continuous-only planning
 * tries at most two graphs; frame-chord certification tries at most 12 graphs
 * (8 with the default padding limit). No frame time or clock is advanced.
 */
export function planDuelPullPath(options) {
  const input = normalize(options);
  if (!input.ok) return input;
  if (options.projectBlockedDestination !== undefined && typeof options.projectBlockedDestination !== 'boolean') return fail('INVALID_INPUT');
  const maxProgressStep = options.maxProgressStep ?? 0;
  const maxCornerPadding = options.maxCornerPadding ?? .75;
  if (!finite(maxProgressStep) || maxProgressStep < 0 || maxProgressStep > 1 ||
      !finite(maxCornerPadding) || maxCornerPadding < 0 || maxCornerPadding > 2) return fail('INVALID_INPUT');
  const {from, boxes, bounds, minEyeY, cornerPadding} = input;
  let {to} = input;
  for (const [endpoint, p] of [['from', from], ['to', to]]) {
    if (!withinXZ(p, bounds)) return fail('ENDPOINT_OUT_OF_BOUNDS', {endpoint});
    if (p.y < minEyeY) return fail('ENDPOINT_BELOW_FLOOR', {endpoint, minEyeY});
    const blocking = boxes.find(b => segmentCrossesOpenBox(p, p, b));
    if (blocking) {
      if (endpoint !== 'to' || !options.projectBlockedDestination) return fail('ENDPOINT_BLOCKED', {endpoint, obstacleIndex: blocking.obstacleIndex});
      const projection = projectEnd(input);
      if (!projection.ok) return projection;
      input.to = to = projection.end;
      input.projection = {candidateCount: projection.candidateCount, nearestDistance: projection.nearestDistance};
    }
  }
  if (!boxes.some(b => segmentCrossesOpenBox(from, to, b))) {
    const result = makePlan(input, [from, to], 'direct', 0, {nodes: 2, checkedEdges: 1});
    return result.ok ? {...result, frameChords: {ok: true, maxProgressStep: 1, checkedEnvelopes: 0}} : result;
  }
  // Conservatively reserve every footprint touched by the complete vertical
  // envelope. This prevents an unsafe timing-dependent route. A safe 3-D
  // route can exist even if this conservative projection cannot find it.
  const lowY = Math.min(from.y, to.y), highY = Math.max(from.y, to.y);
  const projected = boxes.filter(b => lowY < b.max.y && highY > b.min.y &&
    b.min.x < bounds.max.x && b.max.x > bounds.min.x && b.min.z < bounds.max.z && b.max.z > bounds.min.z);
  for (const [endpoint, p] of [['from', from], ['to', to]]) {
    if (projected.some(b => insideXZ(p, b))) return fail('HEIGHT_PROJECTION_BLOCKED', {endpoint, ...endpointMetadata(input)});
  }
  // Prefer a slight outward offset to an exact geometric tangent. If it loses
  // a narrow corridor, retry original inflated corners, still fully certified.
  const paddings = maxProgressStep > 0
    ? [...new Set([cornerPadding, .025, .05, .1, .2, .35, .5, .75, 1, 1.5, 2, maxCornerPadding])]
      .filter(p => p <= maxCornerPadding).sort((a, b) => a - b)
    : cornerPadding > 0 ? [cornerPadding, 0] : [0];
  let result;
  for (let attempt = 0; attempt < paddings.length; attempt++) {
    result = routeGraph(input, projected, paddings[attempt]);
    if (result.ok) {
      const frameChords = maxProgressStep > 0 ? certifyChords(result, boxes, maxProgressStep) : {ok: false, code: 'NOT_REQUESTED'};
      if (maxProgressStep === 0 || frameChords.ok) return {...result, frameChords, diagnostics: {...result.diagnostics, attempts: attempt + 1}};
      result = frameChords;
    }
    if (result.code === 'NODE_BUDGET_EXCEEDED') return {...result, ...endpointMetadata(input)};
  }
  return {...result, ...endpointMetadata(input)};
}

/** Input is already-eased hook return progress; no clock or easing is added. */
export function sampleDuelPullPath(plan, progress) {
  if (!plan?.ok) throw new TypeError('Cannot sample an unsuccessful pull plan');
  if (!finite(progress)) throw new TypeError('Pull progress must be finite');
  const u = Math.max(0, Math.min(1, progress));
  if (u === 0) return copy(plan.from);
  if (u === 1) return copy(plan.to);
  if (plan.kind === 'direct' || plan.length === 0) {
    return {x: lerp(plan.from.x, plan.to.x, u), y: lerp(plan.from.y, plan.to.y, u), z: lerp(plan.from.z, plan.to.z, u)};
  }
  const distance = plan.length * u;
  let i = 1;
  while (i < plan.cumulative.length - 1 && plan.cumulative[i] < distance) i++;
  const a = plan.points[i - 1], b = plan.points[i];
  const legLength = plan.cumulative[i] - plan.cumulative[i - 1];
  const v = legLength > 0 ? (distance - plan.cumulative[i - 1]) / legLength : 1;
  return {x: lerp(a.x, b.x, v), y: lerp(plan.from.y, plan.to.y, u), z: lerp(a.z, b.z, v)};
}
