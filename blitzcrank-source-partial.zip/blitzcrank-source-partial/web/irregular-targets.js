// Seeded horizontal dodges remain inside the target's original practice lane.
// This controller never moves targets: the main lifecycle owns their positions.
export function createIrregularTargets({seed=0x51f15e}={}){
 let states=new WeakMap();
 function reset(){states=new WeakMap();}
 function resetTarget(target){states.delete(target);}
 function initialize(target,index,obstacles){
  const a=target.anchor,b=target.bounds??{min:{x:-.9,y:-.9,z:-.9},max:{x:.9,y:.9,z:.9}};
  const gap=.06;
  let min=Math.max(a.x-target.amplitude,-25.5-b.min.x+gap),max=Math.min(a.x+target.amplitude,25.5-b.max.x-gap);
  // Inflate by the full model and its existing .23-unit hover envelope.
  for(const o of obstacles){
   if(a.z+b.max.z<=o.min.z-gap||a.z+b.min.z>=o.max.z+gap||a.y+b.max.y+.23<=o.min.y-gap||a.y+b.min.y-.23>=o.max.y+gap)continue;
   const left=o.min.x-b.max.x-gap,right=o.max.x-b.min.x+gap;
   if(a.x<=left)max=Math.min(max,left);else if(a.x>=right)min=Math.max(min,right);else min=max=a.x;
  }
  if(min>max)min=max=a.x;
  let rng=(seed^Math.imul(index+1,0x9e3779b9))>>>0;
  const random=()=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng/4294967296;};
  const s={x:a.x,min,max,velocity:0,remaining:0,random};states.set(target,s);return s;
 }
 function step(target,index,dt,obstacles=[]){
  const s=states.get(target)??initialize(target,index,obstacles);
  if(!Number.isFinite(dt)||dt<=0||!target.active||target.captured||target.knockup||target.comboHold)return s.x;
  // Main frame deltas are capped. A cap also keeps this helper bounded for callers.
  let time=Math.min(dt,.1);
  while(time>1e-9){
   if(s.remaining<=1e-9){s.velocity=(s.random()<.5?-1:1)*(.65+s.random()*1.9);s.remaining=.35+s.random()*1.05;}
   const slice=Math.min(time,s.remaining);time-=slice;s.remaining-=slice;
   if(s.max-s.min<1e-8)continue;
   // Reflect any overshoot, preserving continuous position and the speed cap.
   let x=s.x+s.velocity*slice;
   if(x<s.min||x>s.max){const width=s.max-s.min,fold=((x-s.min)%(2*width)+2*width)%(2*width);x=s.min+(fold<=width?fold:2*width-fold);if(fold>width)s.velocity=-s.velocity;}
   s.x=x;
  }
  return s.x;
 }
 return{reset,resetTarget,step};
}
