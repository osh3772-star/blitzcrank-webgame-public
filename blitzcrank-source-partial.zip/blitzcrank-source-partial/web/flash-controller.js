// Mechanics-only preparation. This is not Riot source or a League simulation.
// No image, particle, shader, animation, or sound is synthesized by this module.
export const FLASH_TUNING=Object.freeze({range:4,cooldown:15,minDistance:.05,searchStep:.05});
export const FLASH_BOUNDS=Object.freeze({minX:-23.4,maxX:23.4,minZ:-42.5,maxZ:15.5});
const finitePoint=p=>p&&[p.x,p.y,p.z].every(Number.isFinite);
const inBounds=(p,b)=>p.x>=b.minX&&p.x<=b.maxX&&p.z>=b.minZ&&p.z<=b.maxZ;

/** Horizontal aim blink with a safe endpoint, preserving vertical jump state.
 * A thin interior obstacle may be crossed if its far-side landing is free.
 * The outer arena is never crossed. This intentionally does not reproduce
 * League's undocumented wall snap rules or its coordinate scale.
 */
export function resolveFlashDestination({position,yaw,range=FLASH_TUNING.range,minDistance=FLASH_TUNING.minDistance,searchStep=FLASH_TUNING.searchStep,isBlocked=()=>false,bounds=FLASH_BOUNDS}={}){
 if(!finitePoint(position)||!Number.isFinite(yaw)||!Number.isFinite(range)||range<=0||!Number.isFinite(minDistance)||minDistance<=0||!Number.isFinite(searchStep)||searchStep<=0||typeof isBlocked!=='function')return null;
 if(!bounds||![bounds.minX,bounds.maxX,bounds.minZ,bounds.maxZ].every(Number.isFinite)||bounds.minX>=bounds.maxX||bounds.minZ>=bounds.maxZ||!inBounds(position,bounds)||isBlocked(position.x,position.z))return null;
 const dx=-Math.sin(yaw),dz=-Math.cos(yaw);
 let distance=range;
 if(dx>1e-12)distance=Math.min(distance,(bounds.maxX-position.x)/dx);else if(dx< -1e-12)distance=Math.min(distance,(bounds.minX-position.x)/dx);
 if(dz>1e-12)distance=Math.min(distance,(bounds.maxZ-position.z)/dz);else if(dz< -1e-12)distance=Math.min(distance,(bounds.minZ-position.z)/dz);
 // Remove roundoff outside the arena without changing the aimed direction.
 distance=Math.max(0,distance-1e-9);
 const point=d=>({x:position.x+dx*d,y:position.y,z:position.z+dz*d});
 const valid=d=>{const p=point(d);return inBounds(p,bounds)&&!isBlocked(p.x,p.z);};
 if(distance<minDistance)return null;
 if(valid(distance))return {position:point(distance),distance};
 // Search back toward the caster only when the requested landing is occupied.
 // The callback checks the full player radius using the game's collision rules.
 const step=Math.max(searchStep,distance/1000);let upper=distance;
 for(let probe=Math.max(0,distance-step);;probe=Math.max(0,probe-step)){
  if(probe>=minDistance&&valid(probe)){
   let lower=probe;
   for(let i=0;i<18;i++){const mid=(lower+upper)/2;if(valid(mid))lower=mid;else upper=mid;}
   return {position:point(lower),distance:lower};
  }
  if(probe<minDistance)break;
  upper=probe;
 }
 return null;
}

export function createFlashController(tuning={}){
 const config={...FLASH_TUNING,...tuning};
 for(const key of ['range','cooldown','minDistance','searchStep'])if(!Number.isFinite(config[key])||config[key]<=0)throw new TypeError('Invalid flash tuning: '+key);
 let remaining=0,casts=0;
 return {
  cast({playing=false,...args}={}){
   if(!playing)return {accepted:false,reason:'inactive'};
   if(remaining>0)return {accepted:false,reason:'cooldown'};
   const destination=resolveFlashDestination({...args,range:config.range,minDistance:config.minDistance,searchStep:config.searchStep});
   if(!destination)return {accepted:false,reason:'blocked'};
   remaining=config.cooldown;casts++;
   return {accepted:true,...destination};
  },
  step(dt){if(Number.isFinite(dt)&&dt>0){remaining=Math.max(0,remaining-dt);if(remaining<1e-12)remaining=0;}},
  reset(){remaining=0;casts=0;},
  get status(){return {remaining,casts,ready:remaining===0,range:config.range,cooldown:config.cooldown,visuals:'unavailable',audio:'unavailable'};},
 };
}
