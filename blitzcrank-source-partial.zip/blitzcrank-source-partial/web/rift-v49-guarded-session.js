import {createResilientVisualSession} from './rift-v49-resilient-session.js';
// Only synchronous ownership transitions are guarded; async load/parse can cancel.
export function createGuardedVisualSession(options){
 const base=createResilientVisualSession(options);let busy=false;
 function guard(action){if(busy){const e=new Error('Reentrant visual session mutation');e.code='SESSION_REENTRANCY';throw e;}busy=true;try{return action();}finally{busy=false;}}
 return Object.freeze({current:base.current,cancel:()=>guard(()=>base.cancel()),dispose:()=>guard(()=>base.dispose()),start(){try{return guard(()=>base.start());}catch(e){return Promise.reject(e);}}});
}
