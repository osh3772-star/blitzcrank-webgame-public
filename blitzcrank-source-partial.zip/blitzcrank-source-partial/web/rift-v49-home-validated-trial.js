// Shared-state diagnostic coordinator. These interaction policies are not live rules.
import {createAuditedMovement} from './rift-v49-audited-movement.js';
import {createAuditedFlash} from './rift-v49-audited-flash.js';
import {createWallTimedPullTrial} from './rift-v49-wall-timed-pull.js';
import {auditActorEnvelopes} from './rift-v49-actor-envelope.js';
import {auditTimedActors,timeActorPath} from './rift-v49-timed-actor.js';
import {FLASH_TUNING} from './flash-controller.js';
export function createHomeValidatedTrial({spawn,movementAudit,landingAudit,pathAudit,boundaryAudit,bounds,bodyCollider,hookCollider}={}){
 let position=createAuditedMovement({spawn,audit:movementAudit}).snapshot().position;
 let pull=createWallTimedPullTrial({body:bodyCollider,hook:hookCollider});
 let remaining=0,casts=0,ticks=0,paused=false,disposed=false;
 const snapshot=()=>({position:position.slice(),flash:{remaining,casts,ready:remaining===0},pull:pull.snapshot(),ticks,paused,disposed,gameplayIntegrated:false});
 const guard=()=>{if(disposed)throw Error('Trial disposed');};
 return Object.freeze({snapshot,pause(){guard();paused=true;pull.cancel();return snapshot();},resume(){guard();paused=false;return snapshot();},dispose(){pull.cancel();disposed=true;paused=true;},
  castPull({aim,targets=[]}={}){guard();if(paused)return {accepted:false,reason:'paused'};if(targets.some(t=>!auditActorEnvelopes([position],[t.center]).pass))return {accepted:false,reason:'actor-overlap'};return pull.cast({origin:position.slice(),aim,targets});},
  cancelPull(){guard();pull.cancel();return snapshot();},
  flash({aim,policy='clear-path'}={}){
   guard();if(paused)return {accepted:false,reason:'paused'};if(remaining>0)return {accepted:false,reason:'cooldown'};
   // Ephemeral calculation avoids a second stale position or hidden cooldown owner.
   const trial=createAuditedFlash({spawn:position,bounds,landingAudit,pathAudit,boundaryAudit}),result=trial.cast({aim,policy});
   if(!result.accepted)return result;
   const bodyLanding=bodyCollider.sweep(result.position,result.position);
   if(bodyLanding.blockedBy)return {accepted:false,reason:"body-landing-rejected",blockedBy:bodyLanding.blockedBy};
   const target=pull.snapshot().target;if(target&&!auditActorEnvelopes([result.position],[target.center]).pass)return {accepted:false,reason:'actor-overlap'};
   pull.cancel();position=result.position.slice();remaining=FLASH_TUNING.cooldown;casts++;
   return {...result,state:snapshot(),interactionPolicy:'accepted-flash-cancels-active-hook'};
  },
  step(input={x:0,z:0},dt){
   guard();if(!Number.isFinite(dt)||dt<0)throw Error('Finite nonnegative dt required');
   if(paused)return {...snapshot(),seconds:0,movementSegments:[],skillSegments:[]};
   const movement=createAuditedMovement({spawn:position,audit:movementAudit}).advance(input,dt),seconds=movement.seconds;
   // Pull's home is the candidate player position from this same simulation step.
   const before=pull.snapshot(),candidatePull=pull.fork(),skill=candidatePull.step(seconds,{home:movement.position});
   if(skill.homeRejected)return {...snapshot(),seconds:0,movementSegments:[],skillSegments:[],homeRejected:true,reason:"body-home-rejected"};
   if(before.target&&skill.target){
    const playerPath=[position,...movement.segments.flatMap(s=>[s.from,s.to]),movement.position];
    const targetPath=[before.target.center,...skill.segments.filter(s=>s.kind!=='hook').flatMap(s=>[s.from,s.to]),skill.target.center];
    const pair=auditTimedActors(timeActorPath(playerPath),skill.targetTimeline??timeActorPath(targetPath));
    if(!pair.pass)return {...snapshot(),seconds:0,movementSegments:[],skillSegments:[],actorRejected:true,actorAudit:pair};
   }
   pull=candidatePull;
   position=movement.position.slice();remaining=Math.max(0,remaining-seconds);if(remaining<1e-12)remaining=0;ticks++;
   return {...snapshot(),seconds,movementSegments:movement.segments,skillSegments:skill.segments,movementBlockedBy:movement.blockedBy,targetTimeline:skill.targetTimeline??null};
  }
 });
}
