// Node-only, exact official-v49 inputs. Does not register a runtime map or relabel data.
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
import {createCollisionStudy} from './assets/map-study-v20/collision-study.mjs';
export const MAP_V49=Object.freeze({revision:'0.49',
 glb:'assets/map-study-v49/map.4b256204c876eba9.glb',
 glbSHA:'4b256204c876eba94eced55dd89f1780d5d05558d7f2fad3ea4c30c710541312',
 collision:'assets/map-study-v49/collision.5eb69477d5eeab2d.json',
 collisionSHA:'5eb69477d5eeab2dd4b3b00ab1cf242bfc07706da83f1fd21eb5458b46820356'});
export function loadV49Inputs(root){
 const hash=b=>createHash('sha256').update(b).digest('hex');
 const glb=fs.readFileSync(path.join(root,MAP_V49.glb)),bytes=fs.readFileSync(path.join(root,MAP_V49.collision));
 if(hash(glb)!==MAP_V49.glbSHA||hash(bytes)!==MAP_V49.collisionSHA)throw Error('Exact official v49 hashes required');
 const layout=JSON.parse(bytes);
 if(layout.assetVersion!=='sr-study-0.49'||layout.upAxis!=='Y'||layout.span!==160)throw Error('Official v49 coordinate contract required');
 return {glb,layout:structuredClone(layout),createProbe({radius=Math.hypot(.7,.7)}={}){
  if(!Number.isFinite(radius)||radius<.1||radius>2)throw Error('Invalid offline probe radius');
  const kernel=createCollisionStudy(structuredClone(layout),{radius});
  return Object.freeze({revision:'0.49',radius,probe(from,to=from){
   if(![from,to].every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite)))throw Error('Two finite XZ coordinates required');
   return {from:from.slice(),to:to.slice(),blockedBy:kernel.blockedSweep(from,to),radius};
  }});
 }};
}
