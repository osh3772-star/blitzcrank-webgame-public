// Async load/parse ownership; stale parse results never replace the current view.
export function createVisualSession({load,parse,install,releaseParsed}){
 let generation=0,controller=null,current=null,disposed=false;
 function cancel(){generation++;controller?.abort();controller=null;const old=current;current=null;old?.dispose();}
 return Object.freeze({current:()=>current,cancel,dispose(){cancel();disposed=true;},async start(){
  if(disposed)throw Error('Visual session disposed');cancel();const token=generation,abort=new AbortController();controller=abort;let parsed=null,installed=false;
  try{
   const inputs=await load(abort.signal);if(token!==generation)return null;
   parsed=await parse(inputs.glb);if(token!==generation){releaseParsed(parsed);parsed=null;return null;}
   const view=install(parsed,inputs);
   if(!view||typeof view.dispose!=='function')throw Error('Disposable view required');installed=true;
   if(token!==generation){view.dispose();return null;}current=view;return view;
  }catch(error){if(parsed&&!installed)releaseParsed(parsed);if(token!==generation)return null;throw error;}
  finally{if(token===generation)controller=null;}
 }});
}
