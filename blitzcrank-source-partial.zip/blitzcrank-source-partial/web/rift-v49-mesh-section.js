// Diagnostic horizontal slice only; never supplies collision/spawn permission.
const cross=(a,b,p)=>(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);
const on=(a,b,p)=>Math.abs(cross(a,b,p))<=1e-9&&p[0]>=Math.min(a[0],b[0])-1e-9&&p[0]<=Math.max(a[0],b[0])+1e-9&&p[1]>=Math.min(a[1],b[1])-1e-9&&p[1]<=Math.max(a[1],b[1])+1e-9;
export function sectionMesh({positions,faces},height){
 if(!Number.isFinite(height)||!Array.isArray(positions)||!positions.every(p=>Array.isArray(p)&&p.length===3&&p.every(Number.isFinite))||!Array.isArray(faces)||!faces.every(f=>f.length===3&&f.every(i=>Number.isInteger(i)&&i>=0&&i<positions.length)))throw Error('Finite indexed triangle mesh required');
 const points=[],cache=new Map(),segments=[],adj=new Map();let degeneracies=0;
 function intersection(a,b){const lo=Math.min(a,b),hi=Math.max(a,b),key=lo+':'+hi;if(cache.has(key))return cache.get(key);const p=positions[lo],q=positions[hi],t=(height-p[1])/(q[1]-p[1]),point=[p[0]+(q[0]-p[0])*t,p[2]+(q[2]-p[2])*t];const id=points.length;points.push(point);cache.set(key,id);return id;}
 for(const f of faces){const ds=f.map(i=>positions[i][1]-height);if(ds.some(d=>d===0)){degeneracies++;continue;}const cut=[];for(let k=0;k<3;k++)if(ds[k]*ds[(k+1)%3]<0)cut.push(intersection(f[k],f[(k+1)%3]));if(cut.length===2){segments.push(cut);for(const [a,b]of [cut,cut.slice().reverse()]){if(!adj.has(a))adj.set(a,[]);adj.get(a).push(b);}}}
 const badDegrees=[...adj].filter(([id,n])=>n.length!==2).map(([id,n])=>({id,degree:n.length})),loops=[],seen=new Set();
 if(!degeneracies&&!badDegrees.length)for(const start of adj.keys()){if(seen.has(start))continue;let prev=-1,current=start;const loop=[];do{if(seen.has(current))throw Error('Unexpected slice graph');seen.add(current);loop.push(points[current]);const next=adj.get(current).find(i=>i!==prev);prev=current;current=next;}while(current!==start);loops.push(loop);}
 let selfContacts=0;
 for(let i=0;i<segments.length;i++)for(let j=i+1;j<segments.length;j++){const a=segments[i],b=segments[j];if(a.some(id=>b.includes(id)))continue;const [p,q]=a.map(id=>points[id]),[r,s]=b.map(id=>points[id]),c1=cross(p,q,r),c2=cross(p,q,s),c3=cross(r,s,p),c4=cross(r,s,q);if(c1*c2<0&&c3*c4<0||on(p,q,r)||on(p,q,s)||on(r,s,p)||on(r,s,q))selfContacts++;}
 return {height,closed:!degeneracies&&!badDegrees.length&&!selfContacts,degeneracies,badDegrees,selfContacts,loops,segmentCount:segments.length,spawnPermission:false,solidProof:false};
}
export function classifySectionPoint(section,point){
 if(!Array.isArray(point)||point.length!==2||!point.every(Number.isFinite))throw Error('Finite XZ point required');
 if(!section.closed)return {classification:'uncertain',reason:'slice-not-simple-closed',spawnPermission:false};
 let inside=false;for(const loop of section.loops)for(let i=0;i<loop.length;i++){const a=loop[i],b=loop[(i+1)%loop.length];if(on(a,b,point))return {classification:'uncertain',reason:'slice-boundary',spawnPermission:false};if((a[1]>point[1])!==(b[1]>point[1])&&point[0]<(b[0]-a[0])*(point[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside;}
 return {classification:inside?'inside-slice':'outside-slice',spawnPermission:false,solidProof:false};
}
