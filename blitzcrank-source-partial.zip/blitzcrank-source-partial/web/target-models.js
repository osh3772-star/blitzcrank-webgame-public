import * as THREE from './vendor/three.module.js';
import {GLTFLoader} from './vendor/GLTFLoader.js';
export const TARGET_TYPES=Object.freeze([{id:'mage',label:'수정 마법사'},{id:'guardian',label:'중갑 수호자'},{id:'cannon',label:'대포 전차'}]);
// Changed geometry uses immutable filenames so old browser asset caches cannot mask an update.
export const TARGET_MODEL_FILES=Object.freeze({"mage":"mage.794da90add458ea8.glb","guardian":"guardian.2988b19a54afe0fc.glb","cannon":"cannon.2c6ba2c87cd3e711.glb"});
export async function loadCharacterTargets(fetchAsset=fetch){
 const loader=new GLTFLoader();
 return Promise.all(TARGET_TYPES.map(async type=>{const response=await fetchAsset(`./assets/targets/${TARGET_MODEL_FILES[type.id]}`);if(!response.ok)throw new Error(type.id+' target HTTP '+response.status);const gltf=await loader.parseAsync(await response.arrayBuffer(),'');return{...type,scene:gltf.scene};}));
}
export function attachCharacterTarget(target,asset){
 const model=asset.scene.clone(true),bounds=new THREE.Box3().setFromObject(model),size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3());
 if(!Number.isFinite(size.y)||size.y<=0)throw new Error(asset.id+' has invalid dimensions');
 const scale=2.2/size.y;model.scale.multiplyScalar(scale);model.position.set(-center.x*scale,-center.y*scale,-center.z*scale);
 model.traverse(node=>{if(node.isMesh){node.castShadow=true;node.receiveShadow=true;}});
 for(const child of [...target.group.children])if(child!==target.ring)target.group.remove(child);
 target.group.add(model);target.character=model;target.type=asset.id;target.label=asset.label;
 model.updateWorldMatrix(true,true);const box=new THREE.Box3().setFromObject(model);target.bounds={min:box.min.sub(target.group.position),max:box.max.sub(target.group.position)};
 target.ring.position.set(0,-1.08,0);target.ring.rotation.set(Math.PI/2,0,0);target.ring.scale.setScalar(.9);
 return target;
}
