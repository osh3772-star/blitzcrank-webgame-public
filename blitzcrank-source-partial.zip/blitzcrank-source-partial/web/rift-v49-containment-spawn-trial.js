import {createSpawnSearchTrial} from './rift-v49-spawn-search-trial.js';
import {classifyContainment} from './rift-v49-containment-audit.js';
// Additional rejection guard, never an approval that all open/self-crossing meshes are safe.
export function createContainmentSpawnTrial(THREE,components,options){
 const inspect=p=>classifyContainment(THREE,components,[p[0],1.05,p[1]]);
 const audit=(a,b)=>{
  const original=options.movementAudit(a,b);if(!original?.pass)return original;
  if(a[0]===b[0]&&a[1]===b[1]){const c=inspect(a);if(c.insideCandidate||c.uncertain.some(v=>v.reason==='ray-boundary-or-disagreement'))return {pass:false,reason:'closed-component-containment-candidate'};}
  return original;
 };
 return Object.freeze({...createSpawnSearchTrial({...options,movementAudit:audit}),inspectContainment:inspect});
}
