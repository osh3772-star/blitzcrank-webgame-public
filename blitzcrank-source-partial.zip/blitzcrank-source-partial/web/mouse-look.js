// Mouse look is intentionally independent of WebGL so actual DOM input can be tested.
// Desktop play starts only after real pointer capture; Escape always restores the cursor.
export function createMouseLook({canvas,doc=document,isRunning,onLook,onPunch,onLockLost=()=>{},onMode=()=>{},onFallback=()=>{},onMouseActivity=()=>{}}){
 let locked=doc.pointerLockElement===canvas,pending=false,releasing=false,lastFree=null,mode=locked?'locked':'free',lastFailure='';
 const updateMode=next=>{mode=next;if(canvas.style)canvas.style.cursor=isRunning()&&doc.pointerLockElement===canvas?'none':'';onMode(next);};
 const look=(dx,dy)=>{if(!Number.isFinite(dx)||!Number.isFinite(dy))return;onLook(Math.max(-250,Math.min(250,dx)),Math.max(-250,Math.min(250,dy)));};
 const fallback=reason=>{pending=false;if(doc.pointerLockElement!==canvas){locked=false;updateMode('free');if(isRunning()&&reason!==lastFailure){lastFailure=reason;onFallback(reason);}}};
 function release(){
  // Pointer unlock completes asynchronously. Remember intentional releases across
  // a quick resume/restart so the old completion cannot pause the new session.
  if(doc.pointerLockElement!==canvas||releasing||typeof doc.exitPointerLock!=='function')return;
  releasing=true;
  try{doc.exitPointerLock();}catch{releasing=false;}
 }
 function request(){
  if(!isRunning()||doc.pointerLockElement===canvas||pending||releasing)return;
  lastFree=null;
  if(typeof canvas.requestPointerLock!=='function'){fallback('unsupported');return;}
  pending=true;
  try{const result=canvas.requestPointerLock();if(result&&typeof result.then==='function')result.then(()=>{pending=false;},()=>fallback('denied'));}
  catch{fallback('denied');}
 }
 function mousemove(e){
  if(!isRunning()){lastFree=null;return;}
  if(e.sourceCapabilities?.firesTouchEvents)return;
  if(doc.pointerLockElement===canvas){lastFree=null;look(Number(e.movementX)||0,Number(e.movementY)||0);return;}
  // Uncaptured pointer movement belongs to the browser/UI, never to FPS aiming.
  if(e.target===canvas)onMouseActivity();
 }
 function pointerdown(e){
  if(!isRunning()||e.pointerType==='touch'||e.sourceCapabilities?.firesTouchEvents||(e.button!==0&&e.button!==2))return;
  onMouseActivity();
  // Either mouse button can request capture, but that gesture never attacks.
  if(doc.pointerLockElement!==canvas){request();return;}
  if(e.button===0)onPunch();
 }
 function change(){
  const wasLocked=locked,intentionalRelease=releasing;locked=doc.pointerLockElement===canvas;pending=false;lastFree=null;
  if(!locked)releasing=false;
  updateMode(locked?'locked':'free');
  if(locked&&!isRunning()){release();return;}
  // A settings range/input must not keep swallowing game keys after capture.
  if(locked&&!wasLocked)try{canvas.focus?.({preventScroll:true});}catch{}
  if(wasLocked&&!locked&&isRunning()&&!intentionalRelease)onLockLost();
 }
 const error=()=>fallback('denied');
 doc.addEventListener('mousemove',mousemove);doc.addEventListener('pointerlockchange',change);doc.addEventListener('pointerlockerror',error);canvas.addEventListener('pointerdown',pointerdown);
 updateMode(mode);
 return{request,release,refresh(){updateMode(doc.pointerLockElement===canvas?'locked':'free');},reset(){lastFree=null;},get mode(){return mode;},get pending(){return pending;},dispose(){doc.removeEventListener('mousemove',mousemove);doc.removeEventListener('pointerlockchange',change);doc.removeEventListener('pointerlockerror',error);canvas.removeEventListener('pointerdown',pointerdown);}};
}
