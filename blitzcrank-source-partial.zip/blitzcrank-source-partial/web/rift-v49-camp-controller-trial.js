import {createPinnedFloorStudy} from './rift-v49-pinned-floor-study.js';
import {createStationaryFallbackTrial} from './rift-v49-stationary-fallback-trial.js';
import {collectStaticTriangles} from './rift-v39-support-audit.js';
import {createTriangleIndex} from './rift-v39-route-search.js';
import {sweptFootprint,triangleIntersectsPrism} from './rift-v39-footprint-coverage.js';
import {createCollisionStudy} from './assets/map-study-v20/collision-study.mjs';
import {createAuditedHookCollider} from './rift-v49-hook-collider.js';
// Independent controller adapter. Main game and visual entrypoints do not import this module.
export async function createCampControllerTrial(THREE,args){
 if(!args||!(args.collision instanceof ArrayBuffer))throw Error('Pinned collision bytes required');
 const collision=args.collision.slice(0),study=await createPinnedFloorStudy(THREE,{...args,collision}),layout=JSON.parse(new TextDecoder().decode(collision));
 const triangles=collectStaticTriangles(THREE,args.scene),index=createTriangleIndex(triangles),hookKernel=createCollisionStudy(layout,{radius:.12}),boundary=createCollisionStudy({...layout,walls:[],baseWalls:[],rearBackdropWalls:[],propColliders:[]},{radius:Math.hypot(.7,.7)}),xs=layout.mapBoundaryXZ.map(p=>p[0]),zs=layout.mapBoundaryXZ.map(p=>p[1]),bounds={minX:Math.min(...xs),maxX:Math.max(...xs),minZ:Math.min(...zs),maxZ:Math.max(...zs)};
 const bodyAudit=(a,b)=>{const r=study.audit(a,b);return {pass:r.studyClear,reason:r.reason};};
 // Unchanged hook-height prism and exact grass/reed exclusion from the pinned flower asset.
 const hookAudit=(a,b)=>{const blockedBy=hookKernel.blockedSweep(a,b);if(blockedBy)return {pass:false,reason:blockedBy};const footprint=sweptFootprint(a,b,.12),xx=footprint.map(p=>p[0]),zz=footprint.map(p=>p[1]),box=new THREE.Box3(new THREE.Vector3(Math.min(...xx),.68,Math.min(...zz)),new THREE.Vector3(Math.max(...xx),.92,Math.max(...zz)));for(const t of index.query(a,b,.12))if(t.mesh!=='Batched_Grass_And_Reeds'&&t.bounds.intersectsBox(box)&&triangleIntersectsPrism(t.triangle,footprint,.68,.92))return {pass:false,reason:'mesh:'+t.mesh};return {pass:true};};
 return Object.freeze({auditBody:bodyAudit,auditHook:hookAudit,inspect:p=>study.audit(p),createTrial({spawn=[-3,-37]}={}){
  if(!study.audit(spawn).studyClear||boundary.blockedSweep(spawn,spawn))throw Error('Validated initial spawn required');
  // All component containment/corridor checks already execute inside the pinned body audit.
  // Do not append the old open-cliff envelope a second time in the generic coordinator.
  const trial=createStationaryFallbackTrial(THREE,[],{spawn,movementAudit:bodyAudit,landingAudit:p=>bodyAudit(p,p),pathAudit:bodyAudit,boundaryAudit:(a,b)=>({pass:!boundary.blockedSweep(a,b)}),bounds,bodyCollider:createAuditedHookCollider({auditSegment:bodyAudit}),hookCollider:createAuditedHookCollider({auditSegment:hookAudit})});
  return Object.freeze({...trial,inspectContainment:p=>study.audit(p).containment});
 },runtimeAdopted:false});
}
