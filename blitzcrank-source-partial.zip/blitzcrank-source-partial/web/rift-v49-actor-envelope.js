// Conservative continuous safety: overlapping swept envelopes reject the whole tick.
// This can reject noncolliding paths at different times; it never certifies those paths.
export function auditActorEnvelopes(a,b,{halfExtent=.7}={}){
 if(!Number.isFinite(halfExtent)||halfExtent<=0)throw Error('Positive half extent required');
 const envelope=path=>{
  if(!Array.isArray(path)||!path.length||path.some(p=>!Array.isArray(p)||p.length!==2||!p.every(Number.isFinite)))throw Error('Finite XZ paths required');
  return [0,1].map(i=>[Math.min(...path.map(p=>p[i]))-halfExtent,Math.max(...path.map(p=>p[i]))+halfExtent]);
 };
 const aa=envelope(a),bb=envelope(b),separated=aa.some((r,i)=>r[1]<=bb[i][0]||bb[i][1]<=r[0]);
 return {pass:separated,reason:separated?null:'actor-swept-envelope-overlap',player:aa,target:bb,conservative:true,temporalResolution:false};
}
