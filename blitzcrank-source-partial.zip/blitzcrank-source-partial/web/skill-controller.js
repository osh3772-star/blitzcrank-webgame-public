import {createSkillTimeline} from './skill-timeline.js?v=0.24.70';

// Original Rocket Hand training balance, not current League of Legends values.
export const SKILL_TUNING = Object.freeze({wCooldown:12,wDuration:4,wSlowDuration:2,wMoveMultiplier:1.55,wAttackMultiplier:1.5,wSlowMultiplier:.65,eCooldown:5,eArmedDuration:5,eRange:3.4,eKnockupDuration:1.1,eKnockupHeight:2.2,ePoints:80,rCooldown:12,rRadius:7,rPoints:60});
export const SKILL_CLIP_NAMES = Object.freeze(['W_Start','W_Loop','W_End','E_Charge','E_Hold','E_Strike','R_Cast']);

/** One simulation clock owns poses and impact events. Pause means no step(). */
export function createSkillController(clips,{onEvent=()=>{}}={}) {
 const byName = new Map(clips.map(c=>[c.name,c]));
 for(const name of SKILL_CLIP_NAMES)if(!byName.has(name))throw new Error('Missing skill clip: '+name);
 const slowClip=byName.get('W_Loop_Slow');
 if(slowClip&&(!Number.isFinite(slowClip.duration)||slowClip.duration<=0||slowClip.loop!==true||(slowClip.events?.length??0)!==0))throw new Error('Invalid slow W presentation clip');
 for(const [name,type,time] of [['E_Strike','power_fist_hit',.4],['R_Cast','static_field_discharge',.3]]){const events=byName.get(name).events?.filter(e=>e.type===type)||[];if(events.length!==1||Math.abs(events[0].time-time)>1e-6)throw new Error('Missing or incorrect skill impact event: '+type);}
 let cooldown={W:0,E:0,R:0},boost=0,slow=0,armed=0,phase=null,wExit=null,slowSequence=0;
 const w=createSkillTimeline({onComplete:({name})=>{if(name==='W_Start'&&boost>0)w.play(byName.get('W_Loop'));}});
 const action=createSkillTimeline({onEvent,onComplete:({name})=>{
  if(name==='E_Charge'){phase='E_Hold';armed=SKILL_TUNING.eArmedDuration;action.play(byName.get('E_Hold'));}
  else if(name==='R_Cast'&&armed>0){phase='E_Hold';action.play(byName.get('E_Hold'));}
  else {phase=null;}
 }});
 // Complete the outgoing authored run cycle before entering its matching
 // W_End frame zero. Rescale only presentation time to retain the original end
 // deadline. Whole authored poses keep rigid joints joined; per-mesh TRS
 // crossfading would separate joints whose rotations use different origins.
 // The optional cadence variant changes presentation only. Existing callers
 // with the seven original clips keep the old controller behavior.
 function slowPresentation(){
  const clip=slowClip;
  if(!clip||slow<=0)return null;
  const end=byName.get('W_End'),elapsed=SKILL_TUNING.wSlowDuration-slow;
  const start=wExit?wExit.time/wExit.duration*clip.duration:0;
  const exitDuration=Math.min(end.duration,SKILL_TUNING.wSlowDuration);
  const exitAt=SKILL_TUNING.wSlowDuration-exitDuration;
  const at=t=>{const x=t%clip.duration;return Math.min(x,clip.duration-x)<1e-12?0:x;};
  if(elapsed<exitAt)return {name:clip.name,time:at(start+elapsed),duration:clip.duration,sequence:slowSequence};
  // Follow the complete authored path to frame zero before W_End. Blending
  // independent mesh TRS would split the rigid joints. Finish at slow expiry.
  const from=at(start+exitAt),remaining=from>1e-12?clip.duration-from:0;
  const carry=Math.min(remaining,.24,exitDuration*.5),local=elapsed-exitAt;
  const presentation=local<carry
   ?{name:clip.name,time:from+remaining*local/carry}
   :{name:end.name,time:Math.min(end.duration,(local-carry)*end.duration/(exitDuration-carry))};
  return {name:end.name,time:local,duration:exitDuration,sequence:slowSequence,presentation};
 }
 function animationState(){
  const slowState=!action.state&&slowPresentation();
  if(slowState)return slowState;
  const state=action.state||w.state;
  if(state?.name!=='W_End'||!wExit)return state;
  const remaining=wExit.duration-wExit.time;
  if(remaining<1e-8||wExit.time<1e-8)return state;
  const carry=Math.min(remaining,.24,state.duration*.5);
  const presentation=state.time<carry
   ?{name:wExit.name,time:wExit.time+remaining*state.time/carry}
   :{name:state.name,time:(state.time-carry)*state.duration/(state.duration-carry)};
  return {...state,presentation};
 }
 function cancelAction(){action.stop();phase=null;armed=0;}
 // Shared by casts and the HUD. Querying never mutates timelines or cooldowns.
 function blockReason(key,{busy=false}={}){
  if(!['W','E','R'].includes(key))return 'unknown';
  if(key!=='W'&&busy)return 'busy';
  if(cooldown[key]>0)return 'cooldown';
  if(key==='E'&&phase)return 'casting';
  if(key==='R'&&['E_Charge','E_Strike','R_Cast'].includes(phase))return 'casting';
  return null;
 }
 return {
  blockReason,
  castW(){if(blockReason('W'))return false;cooldown.W=SKILL_TUNING.wCooldown;boost=SKILL_TUNING.wDuration;slow=0;wExit=null;w.play(byName.get('W_Start'));return true;},
  castE({busy=false}={}){if(blockReason('E',{busy}))return false;cooldown.E=SKILL_TUNING.eCooldown;phase='E_Charge';action.play(byName.get(phase));return true;},
  strikeE({busy=false}={}){if(busy||phase!=='E_Hold')return false;armed=0;phase='E_Strike';action.play(byName.get(phase));return true;},
  castR({busy=false}={}){if(blockReason('R',{busy}))return false;action.stop();cooldown.R=SKILL_TUNING.rCooldown;phase='R_Cast';action.play(byName.get(phase));return true;},
  step(dt){if(!Number.isFinite(dt)||dt<=0)return;
   // Match armed expiry: clear only sub-picosecond frame-subtraction residue.
   for(const key of Object.keys(cooldown)){cooldown[key]=Math.max(0,cooldown[key]-dt);if(cooldown[key]<1e-12)cooldown[key]=0;}
   if(boost>0){boost=Math.max(0,boost-dt);if(boost<1e-12)boost=0;if(boost===0){slow=SKILL_TUNING.wSlowDuration;const outgoing=w.state;wExit=outgoing?.name==='W_Loop'?outgoing:null;slowSequence=w.play(byName.get('W_End'));}else w.step(dt);}else{slow=Math.max(0,slow-dt);if(slow<1e-12)slow=0;w.step(dt);}
   if(armed>0){
    armed=Math.max(0,armed-dt);
    // Repeated frame subtraction can leave a sub-picosecond residue at expiry.
    // Clear it before R completion can restore an already expired E_Hold.
    if(armed<1e-12)armed=0;
    if(armed===0&&phase==='E_Hold')cancelAction();
   }
   action.step(dt);
  },
  reset(){w.stop();cancelAction();cooldown={W:0,E:0,R:0};boost=slow=0;wExit=null;},
  get animation(){return animationState();},
  get moveMultiplier(){return boost>0?SKILL_TUNING.wMoveMultiplier:slow>0?SKILL_TUNING.wSlowMultiplier:1;},
  get attackMultiplier(){return boost>0?SKILL_TUNING.wAttackMultiplier:1;},
  get blocksAttack(){return ['E_Charge','E_Strike','R_Cast'].includes(phase);},
  get status(){return {cooldown:{...cooldown},boost,slow,armed,phase,animation:animationState()};}
 };
}
