// Coordinate conversion only. No DOM, target placement or collision permission.
export function resolvePointerAim(THREE,{event,rect,camera,bound=80}){
 if(!Number.isFinite(bound)||bound<=0)throw Error('Positive aim bound required');
 if(event.button!==0||event.isPrimary===false||event.ctrlKey||event.metaKey||event.altKey)return null;
 const values=[rect.left,rect.top,rect.width,rect.height,event.clientX,event.clientY];
 if(!values.every(Number.isFinite)||rect.width<=0||rect.height<=0)return null;
 const x=(event.clientX-rect.left)/rect.width,y=(event.clientY-rect.top)/rect.height;
 if(x<0||x>1||y<0||y>1)return null;
 const projected=camera.clone();if(projected.isPerspectiveCamera){projected.aspect=rect.width/rect.height;projected.updateProjectionMatrix();}projected.updateMatrixWorld();
 const ray=new THREE.Raycaster();ray.setFromCamera(new THREE.Vector2(x*2-1,1-y*2),projected);
 const point=ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,1,0),0),new THREE.Vector3());
 if(!point||!Number.isFinite(point.x)||!Number.isFinite(point.z)||Math.abs(point.x)>bound||Math.abs(point.z)>bound)return null;
 return [point.x,point.z];
}
