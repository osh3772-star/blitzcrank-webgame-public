// Diagnostic only: never installed into online-duel-world or a live match.
import {createCollisionStudy} from './assets/map-study-v20/collision-study.mjs';
import {MAP_STUDY,assertMapStudy} from './rift-map-revisions.js';
export {MAP_STUDY} from './rift-map-revisions.js';
export function createMapProbe(layout,{radius=.42,study=MAP_STUDY}={}){
 assertMapStudy(study);
 if(!layout||layout.assetVersion!=='sr-study-'+study.revision||layout.upAxis!=='Y'||layout.span!==160)throw Error('Pinned v'+study.revision+' coordinate contract required');
 if(study!==MAP_STUDY)validateStudyCoordinates(layout);
 if(!Number.isFinite(radius)||radius<.1||radius>2)throw Error('Diagnostic radius out of range');
 const collision=createCollisionStudy(layout,{radius});
 return Object.freeze({identityMapping:true,radius,probe(a,b=a){if(!Array.isArray(a)||!Array.isArray(b)||a.length!==2||b.length!==2||![...a,...b].every(Number.isFinite))throw Error('Two finite XZ coordinates required');return {from:a.slice(),to:b.slice(),radius,blockedBy:collision.blockedSweep(a,b)};},counts:{polygons:collision.polygons,circles:collision.circles},limitations:{floorHeightIntegrated:false,overheadCollisionIntegrated:false,hookRulesIntegrated:false,flashRulesIntegrated:false}});
}
export function inspectMapScene(THREE,scene){
 scene.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(scene);let meshes=0,triangles=0,logicalAttributeBytes=0;const materials=new Set(),textures=new Set(),views=new Map(),buffers=new Set();
 scene.traverse(o=>{if(!o.isMesh)return;meshes++;const g=o.geometry;triangles+=(g.index?.count??g.attributes.position.count)/3;for(const attr of [...Object.values(g.attributes),...(g.index?[g.index]:[])]){const a=attr.array;logicalAttributeBytes+=a.byteLength;buffers.add(a.buffer);let intervals=views.get(a.buffer);if(!intervals)views.set(a.buffer,intervals=[]);intervals.push([a.byteOffset,a.byteOffset+a.byteLength]);}for(const m of Array.isArray(o.material)?o.material:[o.material]){materials.add(m);for(const v of Object.values(m))if(v?.isTexture)textures.add(v);}});
 let uniqueReferencedBytes=0;for(const xs of views.values()){xs.sort((a,b)=>a[0]-b[0]);let end=-1;for(const[a,b]of xs){uniqueReferencedBytes+=Math.max(0,b-Math.max(a,end));end=Math.max(end,b);}}
 const textureImages=[...new Set([...textures].map(t=>t.image))].map(im=>({width:im?.width??0,height:im?.height??0}));
 return {meshes,triangles,materials:materials.size,textures:textures.size,textureImages,baseLevelRGBABytes:textureImages.reduce((n,x)=>n+x.width*x.height*4,0),logicalAttributeBytes,uniqueReferencedBytes,uniqueBackingBufferBytes:[...buffers].reduce((n,b)=>n+b.byteLength,0),bounds:{min:bounds.min.toArray(),max:bounds.max.toArray()},GPUBytesMeasured:false,FPSMeasured:false};
}

// Validate all collision coordinates before the shared kernel sees a v36 layout.
function validateStudyCoordinates(layout){
 const point=p=>Array.isArray(p)&&p.length===2&&p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024);
 const polygon=p=>Array.isArray(p)&&p.length>=3&&p.every(point);
 if(!polygon(layout.mapBoundaryXZ))throw Error('Invalid study boundary coordinates');
 for(const key of ['walls','baseWalls','rearBackdropWalls']){
  if(!Array.isArray(layout[key]))throw Error('Missing study polygons');
  for(const p of layout[key])if(!p||typeof p.id!=='string'||!p.id||!polygon(p.pointsXZ)||!Number.isFinite(p.minY)||!Number.isFinite(p.maxY)||p.minY>p.maxY||(p.visualBevelMargin!==undefined&&(!Number.isFinite(p.visualBevelMargin)||p.visualBevelMargin<0)))throw Error('Invalid study polygon coordinates');
 }
 if(!Array.isArray(layout.propColliders))throw Error('Missing study circles');
 for(const p of layout.propColliders)if(!p||typeof p.id!=='string'||!p.id||!point(p.centerXZ)||!Number.isFinite(p.radius)||p.radius<=0||!Number.isFinite(p.minY)||!Number.isFinite(p.maxY)||p.minY>p.maxY)throw Error('Invalid study circle coordinates');
}
