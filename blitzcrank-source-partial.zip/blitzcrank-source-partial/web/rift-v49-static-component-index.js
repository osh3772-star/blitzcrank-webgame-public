// Only privately owned, immutable scene components opt in. Generic arrays stay eager.
const indexes=new WeakMap(),CELL=4,LIMIT=4096;
export function registerStaticComponents(components){
 if(indexes.has(components))throw Error('Static components already registered');
 const cells=new Map(),overflow=[];
 for(let i=0;i<components.length;i++){
  const b=components[i].bounds,values=[b.min.x,b.min.y,b.min.z,b.max.x,b.max.y,b.max.z];
  if(!values.every(Number.isFinite)||b.min.x>b.max.x||b.min.y>b.max.y||b.min.z>b.max.z)throw Error('Invalid static component bounds');
  const x0=Math.floor(b.min.x/CELL),x1=Math.floor(b.max.x/CELL),z0=Math.floor(b.min.z/CELL),z1=Math.floor(b.max.z/CELL);
  if(![x0,x1,z0,z1].every(Number.isSafeInteger)||(x1-x0+1)*(z1-z0+1)>LIMIT){overflow.push(i);continue;}
  for(let x=x0;x<=x1;x++)for(let z=z0;z<=z1;z++){const key=x+','+z;if(!cells.has(key))cells.set(key,[]);cells.get(key).push(i);}
 }
 // The adapter does not expose these objects. Freeze bounds so index membership cannot stale.
 for(const c of components){Object.freeze(c.bounds.min);Object.freeze(c.bounds.max);Object.freeze(c.bounds);Object.freeze(c.triangles);Object.freeze(c);}
 Object.freeze(components);indexes.set(components,{cells,overflow});
}
export function staticComponentCandidates(components,from,to=from){
 const index=indexes.get(components);if(!index)return null;
 // Slab intersection arithmetic can conservatively report contact just outside endpoint bounds.
 // Expand only the broadphase; the original exact narrowphase still decides every result.
 if([...from,...to].some(v=>!Number.isFinite(v)||Math.abs(v)>1e6))return null;
 const pad=CELL; // One full cell exceeds coordinate-rounding error in the bounded fast path.
 const x0=Math.floor((Math.min(from[0],to[0])-pad)/CELL),x1=Math.floor((Math.max(from[0],to[0])+pad)/CELL),z0=Math.floor((Math.min(from[1],to[1])-pad)/CELL),z1=Math.floor((Math.max(from[1],to[1])+pad)/CELL);
 if(![x0,x1,z0,z1].every(Number.isSafeInteger)||(x1-x0+1)*(z1-z0+1)>LIMIT)return null;
 const ids=new Set(index.overflow);
 for(let x=x0;x<=x1;x++)for(let z=z0;z<=z1;z++)for(const i of index.cells.get(x+','+z)??[])ids.add(i);
 return [...ids].sort((a,b)=>a-b);
}
