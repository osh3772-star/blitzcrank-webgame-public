import {createReentrancyGuardedTrial} from './rift-v49-reentrancy-guarded-trial.js';
// Alternate control policy: one stationary retry only after a wholly rejected movement tick.
export function createStationaryFallbackTrial(THREE,components,options){
 const base=createReentrancyGuardedTrial(THREE,components,options);
 return Object.freeze({...base,step(input={x:0,z:0},dt){
  const request=input&&{x:input.x,z:input.z},result=base.step(request,dt);
  if(!(request.x||request.z)||!(result.actorRejected||result.homeRejected))return result;
  if(result.seconds!==0||result.movementSegments.length||result.skillSegments.length)throw Error('Rejected tick violated no-commit contract');
  const retry=base.step({x:0,z:0},dt);
  return {...retry,movementFallback:{reason:result.actorRejected?'actor-overlap':'body-home-rejected',stationaryTickAccepted:!retry.actorRejected&&!retry.homeRejected,requestedInput:request}};
 }});
}
