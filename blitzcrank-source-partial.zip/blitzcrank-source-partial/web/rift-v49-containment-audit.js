import {staticComponentCandidates} from './rift-v49-static-component-index.js';
// Additional diagnostic only: topological closure does not prove no self intersections.
export function buildClosedComponents(THREE,triangles){
 const groups=new Map();for(const t of triangles){if(!groups.has(t.mesh))groups.set(t.mesh,[]);groups.get(t.mesh).push(t);}
 const components=[];
 for(const [mesh,ts] of groups){
  const parent=ts.map((_,i)=>i),find=i=>{while(parent[i]!==i){parent[i]=parent[parent[i]];i=parent[i];}return i;},join=(a,b)=>{a=find(a);b=find(b);if(a!==b)parent[b]=a;};
  const vertices=new Map(),edges=new Map();
  const vertex=v=>{if(![v.x,v.y,v.z].every(Number.isFinite))throw Error('Finite triangle vertices required');const key=[v.x,v.y,v.z].join(',');if(!vertices.has(key))vertices.set(key,vertices.size);return vertices.get(key);};
  ts.forEach((t,i)=>{const ids=[t.triangle.a,t.triangle.b,t.triangle.c].map(vertex);for(let j=0;j<3;j++){const a=ids[j],b=ids[(j+1)%3],key=a<b?a+':'+b:b+':'+a;if(!edges.has(key))edges.set(key,[]);const entries=edges.get(key);if(entries.length)join(i,entries[0].i);entries.push({i,sign:a<b?1:-1});}});
  const sets=new Map();ts.forEach((t,i)=>{const key=find(i);if(!sets.has(key))sets.set(key,{mesh,triangles:[],badEdges:0,bounds:new THREE.Box3(),topologicallyClosed:false});const c=sets.get(key);c.triangles.push(t);c.bounds.union(t.bounds);});
  for(const entries of edges.values())if(entries.length!==2||entries[0].sign===entries[1].sign)sets.get(find(entries[0].i)).badEdges++;
  for(const c of sets.values()){c.topologicallyClosed=c.badEdges===0&&c.triangles.length>=4;components.push(c);}
 }
 return components;
}
export function classifyContainment(THREE,components,position,{epsilon=1e-8}={}){
 if(!Array.isArray(position)||position.length!==3||!position.every(Number.isFinite)||!Number.isFinite(epsilon)||epsilon<=0)throw Error('Finite XYZ point and positive tolerance required');
 const p=new THREE.Vector3(...position),inside=[],uncertain=[],directions=[[1,.371,.217],[.193,1,.419],[.283,.173,1]].map(v=>new THREE.Vector3(...v).normalize());
 const candidates=staticComponentCandidates(components,[position[0],position[2]]);
 for(let k=0;k<(candidates?candidates.length:components.length);k++){
  const i=candidates?candidates[k]:k;
  const c=components[i];if(!c.bounds.containsPoint(p))continue;
  if(!c.topologicallyClosed){uncertain.push({component:i,mesh:c.mesh,reason:'open-or-inconsistent-topology'});continue;}
  const votes=[];let ambiguous=false;
  for(const direction of directions){const ray=new THREE.Ray(p,direction);let count=0;
   for(const {triangle:t} of c.triangles){const hit=ray.intersectTriangle(t.a,t.b,t.c,false,new THREE.Vector3());if(!hit)continue;
    const bary=t.getBarycoord(hit,new THREE.Vector3());if(hit.distanceTo(p)<=epsilon||Math.min(bary.x,bary.y,bary.z)<=epsilon){ambiguous=true;break;}count++;
   }
   if(ambiguous)break;votes.push(count%2===1);
  }
  if(ambiguous||votes.some(v=>v!==votes[0]))uncertain.push({component:i,mesh:c.mesh,reason:'ray-boundary-or-disagreement'});
  else if(votes[0])inside.push({component:i,mesh:c.mesh});
 }
 return {insideCandidate:inside.length>0,inside,uncertain,topologicalOnly:true,selfIntersectionsVerified:false,completeSolidSafetyVerified:false};
}
