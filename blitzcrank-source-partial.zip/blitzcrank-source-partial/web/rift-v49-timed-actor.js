// Explicit diagnostic interpolation: constant path speed within normalized tick time.
export function timeActorPath(points){
 if(!Array.isArray(points)||!points.length||points.some(p=>!Array.isArray(p)||p.length!==2||!p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024)))throw Error('Finite XZ path required');
 const path=points.filter((p,i)=>!i||p.some((x,j)=>x!==points[i-1][j]));
 const lengths=path.slice(1).map((p,i)=>Math.hypot(p[0]-path[i][0],p[1]-path[i][1])),total=lengths.reduce((a,b)=>a+b,0);
 if(!total)return [{t:0,p:path[0].slice()},{t:1,p:path[0].slice()}];
 let sum=0;return path.map((p,i)=>({t:i===path.length-1?1:i?(sum+=lengths[i-1])/total:0,p:p.slice()}));
}
export function auditTimedActors(a,b,{halfExtent=.7}={}){
 if(!Number.isFinite(halfExtent)||halfExtent<=0||halfExtent>1024)throw Error('Positive half extent required');
 for(const path of [a,b])if(!Array.isArray(path)||path.length<2||path[0].t!==0||path.at(-1).t!==1||path.some((v,i)=>!Number.isFinite(v.t)||!Array.isArray(v.p)||v.p.length!==2||!v.p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024)||(i&&v.t<=path[i-1].t)))throw Error('Strict timed paths from 0 to 1 required');
 const at=(path,t)=>{let i=1;while(i<path.length-1&&path[i].t<t)i++;const l=path[i-1],r=path[i],f=(t-l.t)/(r.t-l.t);return l.p.map((x,j)=>x+(r.p[j]-x)*f);};
 const times=[...new Set([...a,...b].map(v=>v.t))].sort((x,y)=>x-y),extent=2*halfExtent;
 for(let k=1;k<times.length;k++){
  const start=times[k-1],end=times[k],a0=at(a,start),a1=at(a,end),b0=at(b,start),b1=at(b,end);let lo=0,hi=1,possible=true;
  for(let j=0;j<2;j++){
   const x=a0[j]-b0[j],v=a1[j]-b1[j]-x;
   if(v===0){if(Math.abs(x)>=extent){possible=false;break;}}
   else{const u=(-extent-x)/v,w=(extent-x)/v;lo=Math.max(lo,Math.min(u,w));hi=Math.min(hi,Math.max(u,w));}
  }
  if(possible&&lo<hi)return {pass:false,reason:'simultaneous-actor-overlap',contactTime:start+(end-start)*lo,intervalEnd:start+(end-start)*hi,temporalResolution:true};
 }
 return {pass:true,reason:null,temporalResolution:true};
}
