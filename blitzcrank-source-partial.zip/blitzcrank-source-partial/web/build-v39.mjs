import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

// Reviewed runtime closure: game, manual online duel, and isolated map study.
// Packed assets are already checked in. Build never repacks or rewrites sources.
export const RUNTIME_FILES = Object.freeze(["rift-v39-flash.js", "rift-v39-hook.js", "rift-v39-loader.js", "rift-v39-planar-ui.js", "rift-v39-planar.js", "rift-v39-pull.js", "rift-v39-revisions.js", "rift-v39-study.js", "rift-v39-test.js", "rift-map-v39-test.html", "assets/map-study-v39/collision.8e88cb3b81d9274a.json", "assets/map-study-v39/game-probes.json", "assets/map-study-v39/map.f847a3493df20b26.glb",'rift-map-revisions.js','rift-map-loader.js','rift-map-v36-test.html','assets/map-study-v36/map.16e20ecd1269fd4a.glb','assets/map-study-v36/collision.93fad933f339c794.json','assets/map-study-v36/game-probes.json','assets/audio/basic-attack.wav','assets/audio/flash/flash-cast.wav','assets/audio/flash/source-manifest.json','assets/audio/hook-cast.wav','assets/audio/manifest.json','assets/audio/skills/e-empower.wav','assets/audio/skills/e-hit.wav','assets/audio/skills/provenance.json','assets/audio/skills/r-cast.wav','assets/audio/skills/w-activate.wav','assets/audio/skills/w-end.wav','assets/audio/turrets/source-manifest.json','assets/audio/turrets/turret-hit.wav','assets/audio/turrets/turret-shot.wav','assets/audio/turrets/turret-target-extended.wav','assets/audio/turrets/turret-target-single-044.wav','assets/audio/turrets/turret-target.wav','assets/audio/voice/age-of-man.wav','assets/audio/voice/death.wav','assets/audio/voice/exterminate.wav','assets/audio/voice/focus.wav','assets/audio/voice/golem-joke.wav','assets/audio/voice/however-long.wav','assets/audio/voice/leaking-oil.wav','assets/audio/voice/losing-steam.wav','assets/audio/voice/magic-calls.wav','assets/audio/voice/manifest.json','assets/audio/voice/metal-stronger.wav','assets/audio/voice/poor-bones.wav','assets/audio/voice/precisely.wav','assets/audio/voice/rolling-golem.wav','assets/audio/voice/tremble-flesh.wav','assets/blitz-materials/aged-yellow-basecolor.46f000102005e744.png','assets/blitz-materials/aged-yellow-basecolor.934272f6b63ea94b.png','assets/blitz-materials/aged-yellow-roughness.5ab56dca175fc5e2.png','assets/blitz-materials/aged-yellow-roughness.de1e87c13e16d312.png','assets/flash-video/departure.49e52e9d2856f9e3.png','assets/flash-video/pixel-correspondence-tests.json','assets/flash-video/source-manifest.json','assets/map-study-v20/collision-study.mjs','assets/map-study-v20/collision.e06f65aba28614a7.json','assets/map-study-v20/game-probes.json','assets/map-study-v20/map.978dba74ce1cace5.glb','assets/player-models/fullbody.8504b896c6aaa1ef.bin','assets/player-models/fullbody.8504b896c6aaa1ef.bin.b22dea5dd0291683.gz','assets/player-models/fullbody.8504b896c6aaa1ef.bin.gz','assets/player-models/manifest.json','assets/player-models/viewmodel.2aa38ae0da7d99b9.bin','assets/player-models/viewmodel.2aa38ae0da7d99b9.bin.0c3ffb1b2ea37f5c.gz','assets/player-models/viewmodel.2aa38ae0da7d99b9.bin.gz','assets/skill-animations/skills.403e90667511be4b.json','assets/skill-animations/skills.403e90667511be4b.json.gz','assets/skill-animations/skills.9b293d06ddb21614.json','assets/skill-animations/skills.9b293d06ddb21614.json.gz','assets/targets/cannon.1720a299e7573d6f.glb','assets/targets/cannon.2c6ba2c87cd3e711.glb','assets/targets/cannon.ea1159ec02004cd1.glb','assets/targets/guardian.2988b19a54afe0fc.glb','assets/targets/guardian.638195a23537033b.glb','assets/targets/guardian.eca6d8f038e90aa4.glb','assets/targets/mage.794da90add458ea8.glb','assets/targets/mage.976c71bc6d1e06e4.glb','assets/targets/mage.adda0e7dff7aac77.glb','assets/targets/mage.b3e2d52dc5b40951.glb','assets/targets/source-manifest.json','assets/turret/turret-manifest.json','assets/turret/turret.5a9fd4b0b1c143e9.glb','assets/turret/turret.782104e94ef3eff8.glb','assets/ui/grab.svg','assets/ui/jump.svg','assets/ui/punch.svg','assets/ui/skills/Overdrive.png','assets/ui/skills/PowerFist.png','assets/ui/skills/RocketGrab.png','assets/ui/skills/StaticField.png','assets/ui/skills/SummonerFlash.png','assets/ui/skills/flash-source-manifest.json','assets/ui/skills/source-manifest.json','audio-cues.js','blitz-materials.js','combo-practice.css','combo-practice.js','core.js','duel-avatar.js','duel-bot-inputs.js','duel-hook-contacts.js','duel-pull-path.js','duel-round-rules.js','duel-simulation.js','duel-skill-contacts.js','flash-audio.js','flash-controller.js','flash-controls.css','flash-frame-manifest.js','flash-frame-vfx.js','fullbody-locomotion.js','game-audio.js','hook-chain.js','index.html','irregular-targets.css','irregular-targets.js','main.js','mobile-interface.css','mode-records.js','model-codec.js','mouse-look.js','neutral-audio.js','online-duel-app.js','online-duel-peer.js','online-duel-protocol.js','online-duel-session.js','online-duel-view.js','online-duel-world.js','online-duel.css','online-remote-smoothing.js','online.html','player-model-manifest.js','rift-map-flash.js','rift-map-hook.js','rift-map-planar-ui.js','rift-map-planar.js','rift-map-pull.js','rift-map-study.js','rift-map-test.html','rift-map-test.js','skill-animation-manifest.js','skill-animation.js','skill-audio.js','skill-controller.js','skill-timeline.js','skill-vfx.js','style.css','target-models.js','touch-layout.css','training-mirror.js','turret-core.js','turret-direction.js','turret-view.js','vendor/BufferGeometryUtils.js','vendor/GLTFLoader.js','vendor/Reflector.js','vendor/THREE-LICENSE.txt','vendor/three.module.js','voice-cues.js','voice-schedule.js','w-stationary-layer.js']);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');

export function buildRuntime(root = path.dirname(fileURLToPath(import.meta.url))) {
  root = path.resolve(root);
  const destination = path.join(root, 'dist-v39');
  let outputStat = null;
  try { outputStat = fs.lstatSync(destination); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  if (outputStat && (outputStat.isSymbolicLink() || !outputStat.isDirectory())) {
    throw new Error('Refusing non-directory or symlink dist');
  }
  // Validate every source before touching an earlier build.
  for (const name of RUNTIME_FILES) {
    let current = root;
    for (const part of name.split('/')) {
      current = path.join(current, part);
      if (fs.lstatSync(current).isSymbolicLink()) throw new Error('Runtime symlink rejected: ' + name);
    }
    if (!fs.statSync(current).isFile()) throw new Error('Runtime file missing: ' + name);
  }
  const stage = fs.mkdtempSync(path.join(root, '.dist-v39-stage-'));
  const manifest = {};
  let backup = null;
  try {
    for (const name of RUNTIME_FILES) {
      const source = fs.readFileSync(path.join(root, name));
      const target = path.join(stage, name);
      fs.mkdirSync(path.dirname(target), {recursive: true});
      fs.writeFileSync(target, source, {flag: 'wx'});
      manifest[name] = hash(source);
      if (hash(fs.readFileSync(target)) !== manifest[name]) throw new Error('Build copy mismatch: ' + name);
    }
    if (fs.existsSync(destination)) {
      backup = fs.mkdtempSync(path.join(root, '.dist-v39-backup-'));
      fs.renameSync(destination, path.join(backup, 'dist-v39'));
    }
    try { fs.renameSync(stage, destination); }
    catch (error) {
      if (backup && !fs.existsSync(destination)) fs.renameSync(path.join(backup, 'dist-v39'), destination);
      throw error;
    }
    return {files: RUNTIME_FILES.length, destination, previousBuild: backup ? path.join(backup, 'dist-v39') : null, manifest};
  } catch (error) {
    // Only our new incomplete staging directory is removed. Earlier output is retained.
    fs.rmSync(stage, {recursive: true, force: true});
    throw error;
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const result = buildRuntime();
  console.log(JSON.stringify({files: result.files, destination: result.destination, previousBuild: result.previousBuild, entrypoints: ['index.html', 'online.html', 'rift-map-test.html', 'rift-map-v36-test.html', 'rift-map-v39-test.html'], published: false}, null, 2));
}
