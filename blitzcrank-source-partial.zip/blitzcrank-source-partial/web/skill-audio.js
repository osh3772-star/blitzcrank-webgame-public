// Short excerpts of the official demonstration soundtrack, not isolated banks.
// For this existing owner-private prototype only; no game-use license asserted.
export const SKILL_AUDIO_CUES=Object.freeze({
 overdriveStart:Object.freeze({url:'./assets/audio/skills/w-activate.wav',channel:'sfx',group:'overdrive',gain:.8,maxDuration:1.37}),
 overdriveEnd:Object.freeze({url:'./assets/audio/skills/w-end.wav',channel:'sfx',group:'overdrive',gain:.8,maxDuration:1.79}),
 powerCharge:Object.freeze({url:'./assets/audio/skills/e-empower.wav',channel:'sfx',group:'power-fist',gain:.8,maxDuration:1.23}),
 powerImpact:Object.freeze({url:'./assets/audio/skills/e-hit.wav',channel:'sfx',group:'power-fist',gain:.65,maxDuration:1.35}),
 staticCast:Object.freeze({url:'./assets/audio/skills/r-cast.wav',channel:'sfx',group:'static-field',gain:.5,maxDuration:1.63}),
});
export const SKILL_AUDIO_EVENTS=Object.freeze({overdriveStart:'overdriveStart',overdriveEnd:'overdriveEnd',powerCharge:'powerCharge',powerImpact:'powerImpact',staticCast:'staticCast'});

/** Simulation events only. No delayed timers, stale replay, or separate R pulse sample. */
export function createSkillAudio({playEvent,playTone}){
 let boosted=false,rSampleStarted=false;
 return {
  castW(){boosted=true;return playEvent('overdriveStart')||playTone(220,700,.2);},
  castE(){return playEvent('powerCharge')||playTone(160,520,.25);},
  castR(){rSampleStarted=playEvent('staticCast');if(!rSampleStarted)playTone(130,430,.3);},
  hitE(){return playEvent('powerImpact')||playTone(650,1200,.2);},
  dischargeR(){if(!rSampleStarted)playTone(1200,80,.35);rSampleStarted=false;},
  update(status){if(boosted&&status.boost<=0){boosted=false;if(status.slow>0)playEvent('overdriveEnd');}},
  reset(){boosted=false;rSampleStarted=false;},
 };
}
