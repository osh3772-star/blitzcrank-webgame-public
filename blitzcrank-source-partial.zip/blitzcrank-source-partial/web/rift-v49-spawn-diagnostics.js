import {collectStaticTriangles} from './rift-v39-support-audit.js';
import {createTriangleIndex} from './rift-v39-route-search.js';
import {auditStraightCorridor} from './rift-v39-footprint-coverage.js';
import {buildClosedComponents,classifyContainment} from './rift-v49-containment-audit.js';
import {auditUncertaintyCorridor} from './rift-v49-uncertainty-corridor.js';
import {registerStaticComponents} from './rift-v49-static-component-index.js';
export function stationaryReason(body,corridor,containment){
 if(body.blockedBy)return 'planar:'+body.blockedBy;
 if(!body.coverage.covered)return 'support-gap';
 if(body.intersectionCount)return 'body-surface';
 if(!corridor.pass)return 'uncertain-component-envelope';
 if(containment.insideCandidate||containment.uncertain.length)return 'component-interior-or-uncertainty';
 return null;
}
// Read-only explanation of the existing fixed-height stationary terrain contract.
// This does not grant spawn permission: boundary and actor checks remain separate.
export function createSpawnDiagnostics(THREE,{scene,inputs}){
 const triangles=collectStaticTriangles(THREE,scene),index=createTriangleIndex(triangles),components=buildClosedComponents(THREE,triangles),probe=inputs.createProbe();registerStaticComponents(components);
 const floorName='Irregular_Camp_Exposed_Stone_Floors',floor=triangles.filter(t=>t.mesh===floorName);
 const verifiedFloor=inputs.layout?.campFloorDetailsAreTraversable===true&&floor.length>0&&floor.every(t=>t.bounds.min.y>=.017999&&t.bounds.max.y<=.022001);
 function inspect(point,excludeFloor=false){
  if(!Array.isArray(point)||point.length!==2||!point.every(v=>Number.isFinite(v)&&Math.abs(v)<=1024))throw Error('Finite bounded diagnostic XZ required');
  const p=point.slice(),near=index.query(p,p),body=auditStraightCorridor(THREE,excludeFloor?near.filter(t=>t.mesh!==floorName):near,probe,{from:p,to:p}),corridor=auditUncertaintyCorridor(components,{from:p,to:p}),containment=classifyContainment(THREE,components,[p[0],1.05,p[1]]),hits=[],ray=new THREE.Ray(new THREE.Vector3(p[0],20,p[1]),new THREE.Vector3(0,-1,0));
  for(const t of near){const hit=ray.intersectTriangle(t.triangle.a,t.triangle.b,t.triangle.c,false,new THREE.Vector3());if(hit&&hit.y>=-10)hits.push({mesh:t.mesh,height:hit.y,normalY:t.normal.y});}
  const surfaces=[...new Map(hits.map(h=>[h.mesh+':'+h.height.toFixed(6),h])).values()].sort((a,b)=>b.height-a.height);
  const ids=[...new Set([...(corridor.blocked??[]).map(x=>x.component),...containment.uncertain.map(x=>x.component),...containment.inside.map(x=>x.component)])];const componentEvidence=ids.map(id=>{const c=components[id];return {id,mesh:c.mesh,triangles:c.triangles.length,badEdges:c.badEdges,topologicallyClosed:c.topologicallyClosed,bounds:{min:c.bounds.min.toArray(),max:c.bounds.max.toArray()}};});
  return {componentEvidence,point:p,reason:stationaryReason(body,corridor,containment),body,corridor,containment,centerRaySurfaces:surfaces,planeY:0,bodyHeight:2.1,halfExtent:.7,spawnPermission:false,browserGpuVerified:false,excludedFloorForAnalysis:excludeFloor?floorName:null};
 }
 return Object.freeze({inspect:p=>inspect(p),inspectTraversableFloor(p){if(!verifiedFloor)throw Error('Verified thin traversable camp floor required');return inspect(p,true);},floorEvidence:Object.freeze({mesh:floorName,triangles:floor.length,verified:verifiedFloor,metadataFlag:inputs.layout?.campFloorDetailsAreTraversable===true,minY:floor.length?Math.min(...floor.map(t=>t.bounds.min.y)):null,maxY:floor.length?Math.max(...floor.map(t=>t.bounds.max.y)):null})});
}
