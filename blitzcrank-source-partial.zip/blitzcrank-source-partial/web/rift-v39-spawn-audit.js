// Offline spawn suggestions only. Never changes a match or certifies height support.
import {createMapProbe} from './rift-v39-study.js';
import {MAP_STUDY_V39} from './rift-v39-revisions.js';

export function auditSpawn(layout, {origin, radius=.7, step=.25, maxDistance=8,
  occupied=[], corridorTo=null, limit=8, study=MAP_STUDY_V39}={}) {
  const point=p=>Array.isArray(p)&&p.length===2&&p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024);
  if(!point(origin)||!Number.isFinite(step)||step<.05||step>2||
     !Number.isFinite(maxDistance)||maxDistance<0||maxDistance>32||
     !Number.isInteger(limit)||limit<1||limit>32||
     (corridorTo!==null&&!point(corridorTo))||!Array.isArray(occupied)||occupied.length>64)
    throw Error('Invalid or unbounded spawn audit options');
  for(const body of occupied) if(!body||!point(body.position)||!Number.isFinite(body.radius)||body.radius<.1||body.radius>2)
    throw Error('Invalid occupied body');
  const n=Math.floor(maxDistance/step);
  if((2*n+1)**2>100000) throw Error('Spawn audit sample budget exceeded');
  const probe=createMapProbe(structuredClone(layout),{radius,study});
  const originalBlockedBy=probe.probe(origin).blockedBy;
  const rejects={collision:0,occupied:0,corridor:0};
  const offsets=[];
  for(let x=-n;x<=n;x++)for(let z=-n;z<=n;z++){
    const distanceSq=(x*step)**2+(z*step)**2;
    if(distanceSq<=maxDistance**2) offsets.push({x,z,distanceSq});
  }
  offsets.sort((a,b)=>a.distanceSq-b.distanceSq||a.x-b.x||a.z-b.z);
  const candidates=[];
  let examined=0;
  for(const {x,z,distanceSq} of offsets){
    examined++;
    const position=[origin[0]+x*step,origin[1]+z*step];
    if(probe.probe(position).blockedBy){rejects.collision++;continue;}
    if(occupied.some(b=>Math.hypot(position[0]-b.position[0],position[1]-b.position[1])<=radius+b.radius+1e-9)){
      rejects.occupied++;continue;
    }
    if(corridorTo&&probe.probe(position,corridorTo).blockedBy){rejects.corridor++;continue;}
    candidates.push({position,distance:Math.sqrt(distanceSq),planarClear:true,
      straightCorridorClear:corridorTo?true:null});
    if(candidates.length===limit)break;
  }
  return {revision:study.revision,origin:origin.slice(),originalBlockedBy,radius,step,maxDistance,
    examined,searchGridSamples:offsets.length,rejected:rejects,candidates,
    selected:candidates[0]??null,searchStatus:candidates.length?'suggestions':'no-candidate-in-grid',
    adopted:false,verticalSupportVerified:false,gameplayChanged:false,browserGpuVerified:false};
}
