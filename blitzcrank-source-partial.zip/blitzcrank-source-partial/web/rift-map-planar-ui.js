// UI-only test controls. No gameplay, signaling, hook, damage or score mutations.
export function createPlanarControls({trial,onFrame,onState,requestFrame,cancelFrame}){
 let running=false,frame=null,last=null,generation=0;const keys=new Set(),buttons=new Set();const accepted=new Map([['KeyW','up'],['ArrowUp','up'],['KeyS','down'],['ArrowDown','down'],['KeyA','left'],['ArrowLeft','left'],['KeyD','right'],['ArrowRight','right']]);
 function clear(){keys.clear();buttons.clear();last=null;}
 function held(name){return buttons.has(name)||[...keys].some(k=>accepted.get(k)===name);}
 function tick(now,token){if(!running||token!==generation)return;frame=null;if(last!==null&&Number.isFinite(now)&&now>=last){const result=trial.advance({x:Number(held('right'))-Number(held('left')),z:Number(held('down'))-Number(held('up'))},(now-last)/1000);onFrame(result);}last=Number.isFinite(now)?now:null;frame=requestFrame(now=>tick(now,token));}
 function stop(){generation++;running=false;if(frame!==null)cancelFrame(frame);frame=null;clear();onState(false);}
 return Object.freeze({start(){if(running)return;running=true;clear();onState(true);const token=++generation;frame=requestFrame(now=>tick(now,token));},stop,reset(p){clear();onFrame(trial.reset(p));},key(code,down){const name=accepted.get(code);if(!name||!running)return false;down?keys.add(code):keys.delete(code);return true;},button(name,down){if(!['up','down','left','right'].includes(name)||!running)return false;down?buttons.add(name):buttons.delete(name);return true;},clear,dispose:stop,get running(){return running;}});
}
