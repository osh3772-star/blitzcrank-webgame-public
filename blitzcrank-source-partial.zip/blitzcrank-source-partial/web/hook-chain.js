// Visual only: one instanced draw, fixed-size oval links, no physics or collisions.
export function createHookChain(THREE) {
  const capacity=256, pitch=.17, samples=128;
  // An elliptical centreline swept with a circular wire section, not a scaled torus:
  // scaling a torus would also stretch the metal wire at its ends.
  const segments=32, sides=6, wire=.018, rx=.052, ry=.107;
  const vertices=[], normals=[], indices=[];
  for(let i=0;i<=segments;i++) {
    const a=i/segments*Math.PI*2, ca=Math.cos(a), sa=Math.sin(a);
    let nx=ry*ca, ny=rx*sa; const norm=Math.hypot(nx,ny); nx/=norm; ny/=norm;
    for(let j=0;j<=sides;j++) {
      const b=j/sides*Math.PI*2, cb=Math.cos(b), sb=Math.sin(b);
      vertices.push(rx*ca+wire*cb*nx,ry*sa+wire*cb*ny,wire*sb);
      normals.push(cb*nx,cb*ny,sb);
      if(i<segments&&j<sides) {const k=i*(sides+1)+j;indices.push(k,k+sides+1,k+1,k+1,k+sides+1,k+sides+2);}
    }
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
  geometry.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));
  geometry.setIndex(indices); geometry.computeBoundingSphere();
  const material=new THREE.MeshStandardMaterial({color:0x776b58,metalness:.84,roughness:.29});
  const links=new THREE.InstancedMesh(geometry,material,capacity);
  links.name='Linked steel chain';links.count=0;
  links.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  // World-space matrices move every frame; a stale instanced bound would cull it.
  links.frustumCulled=false;links.castShadow=false;links.receiveShadow=true;
  const group=new THREE.Group();group.name='Hook chain';group.add(links);group.links=links;
  const info=group.userData;
  Object.assign(info,{start:new THREE.Vector3(),end:new THREE.Vector3(),linkCount:0,length:0,arcLength:0,pitch,capacity,linkWidth:.14,linkLength:.25,sag:0});
  const points=Array.from({length:samples+1},()=>new THREE.Vector3());
  const distances=new Float64Array(samples+1);
  const delta=new THREE.Vector3(),side=new THREE.Vector3(),reference=new THREE.Vector3();
  const position=new THREE.Vector3(),tangent=new THREE.Vector3(),x=new THREE.Vector3(),z=new THREE.Vector3(),swap=new THREE.Vector3();
  const matrix=new THREE.Matrix4();
  let lastPhase=null,lastWave=0,returnWave=0;
  group.update=function(start,end,{phase='outbound',phaseTime=0,time=0}={}) {
    info.start.copy(start); info.end.copy(end); delta.subVectors(end,start);
    const length=delta.length();info.length=length;
    if(!Number.isFinite(length)||length<1e-7) {links.count=info.linkCount=0;info.arcLength=info.sag=0;return group;}
    phaseTime=Number.isFinite(phaseTime)?Math.max(0,phaseTime):0;
    time=Number.isFinite(time)?time:0;
    const returning=phase==='return'||phase==='recover';
    const settle=returning?Math.exp(-phaseTime*22):1;
    const floorClearance=Math.max(0,Math.min(start.y,end.y)-.08);
    const sag=Math.min(floorClearance,Math.min(.75,length*.025)*settle+Math.min(.10,length*.004)*(1-settle));
    if(returning&&lastPhase!=='return'&&lastPhase!=='recover')returnWave=lastPhase==='outbound'?lastWave:Math.min(.035,length*.008);
    const wave=returning?Math.min(returnWave,length*.008)*Math.exp(-phaseTime*22):Math.min(.035,length*.008)*Math.exp(-phaseTime*5);
    lastPhase=phase;lastWave=wave;
    info.sag=sag;
    // Fixed reference, with a well-conditioned fallback for vertical shots.
    side.set(-delta.z,0,delta.x);
    if(side.lengthSq()<1e-10)side.set(1,0,0);else side.normalize();
    for(let i=0;i<=samples;i++) {
      const t=i/samples, envelope=Math.sin(Math.PI*t);
      points[i].copy(start).addScaledVector(delta,t);
      points[i].y-=4*t*(1-t)*sag;
      points[i].addScaledVector(side,envelope*Math.sin(t*Math.PI*3-time*12)*wave);
      if(i)distances[i]=distances[i-1]+points[i].distanceTo(points[i-1]);
    }
    // Explicit copies avoid even the tiny sin(pi)/interpolation residue at the anchors.
    points[0].copy(start);points[samples].copy(end);
    const arcLength=distances[samples];info.arcLength=arcLength;
    const count=Math.min(capacity,Math.ceil(arcLength/pitch)+1);
    links.count=info.linkCount=count;
    const step=count===capacity&&arcLength>(capacity-1)*pitch?arcLength/(capacity-1):pitch;
    let cursor=1;
    for(let i=0;i<count;i++) {
      // Feed new links from the sleeve. All other links retain their pitch and
      // orientation parity relative to the flying hand, even when count changes.
      const distance=i===0?0:Math.max(0,arcLength-(count-1-i)*step);
      while(cursor<samples&&distances[cursor]<distance)cursor++;
      const previous=cursor-1,span=distances[cursor]-distances[previous];
      position.lerpVectors(points[previous],points[cursor],span>1e-12?(distance-distances[previous])/span:0);
      if(i===0)position.copy(start);else if(i===count-1)position.copy(end);
      tangent.subVectors(points[Math.min(samples,cursor+1)],points[Math.max(0,previous-1)]).normalize();
      if(tangent.lengthSq()<.5)tangent.copy(delta).normalize();
      reference.copy(side);x.copy(reference).addScaledVector(tangent,-reference.dot(tangent)).normalize();
      z.crossVectors(x,tangent).normalize();
      if((count-1-i)%2){swap.copy(x);x.copy(z);z.copy(swap).negate();}
      matrix.makeBasis(x,tangent,z);matrix.setPosition(position);links.setMatrixAt(i,matrix);
    }
    links.instanceMatrix.needsUpdate=true;
    return group;
  };
  return group;
}
