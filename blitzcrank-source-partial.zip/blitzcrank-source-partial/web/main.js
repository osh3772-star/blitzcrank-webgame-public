import {createFullbodyWStationaryLayer} from './w-stationary-layer.js';
import {planDuelPullPath,sampleDuelPullPath} from './duel-pull-path.js?v=0.24.87';
import {turretDirectionWarnings,turretDirectionText} from './turret-direction.js?v=0.24.87';
import * as THREE from './vendor/three.module.js';
import {loadPlayerModel} from './model-codec.js';
import {PLAYER_MODELS} from './player-model-manifest.js?v=0.24.87';
import {createIrregularTargets} from './irregular-targets.js?v=0.24.87';
import {createComboPractice} from './combo-practice.js?v=0.24.87';
import {createModeRecords} from './mode-records.js?v=0.24.87';
import {createFlashController} from './flash-controller.js?v=0.24.87';
import {FLASH_AUDIO_CUES,FLASH_AUDIO_EVENTS} from './flash-audio.js';
import {FLASH_FRAMES} from './flash-frame-manifest.js?v=0.24.87';
import {loadFlashFrameTexture,createFlashFrameVfx} from './flash-frame-vfx.js?v=0.24.87';
import {CONFIG,Session,raySphere,rayBox,formatTime,thirdPersonCameraPosition} from './core.js';
import {validateSkillSourceParts,bindSkillClips,createFullbodyPoseApplicator,createFullbodyELocomotionLayer,eRecoveryArmWeight,rRecoveryArmWeight,clearFullbodySkillPose,loadSkillAsset} from './skill-animation.js?v=0.24.87';
import {createSkillController,SKILL_TUNING} from './skill-controller.js?v=0.24.87';
import {createFullbodyLocomotion} from './fullbody-locomotion.js?v=0.24.87';
import {createSkillVfx} from './skill-vfx.js?v=0.24.87';
import {createSkillAudio,SKILL_AUDIO_CUES,SKILL_AUDIO_EVENTS} from './skill-audio.js';
import {SKILL_ASSET} from './skill-animation-manifest.js';
import {createMouseLook} from './mouse-look.js?v=0.24.87';
import {createDuelAvatarFactory,cacheStaticFullbodyNodeMatrices} from './duel-avatar.js?v=0.24.87';
import {createDuelSimulation,DUEL_PLAYERS,DUEL_SHAPE} from './duel-simulation.js?v=0.24.87';
import {createDuelBotInputs} from './duel-bot-inputs.js?v=0.24.87';
import {createHookChain} from './hook-chain.js';
import {createTrainingMirror} from './training-mirror.js';
import {createGameAudio} from './game-audio.js?v=0.24.87';
import {AUDIO_CUES,AUDIO_EVENTS,TURRET_AUDIO_CUES,TURRET_AUDIO_EVENTS} from './audio-cues.js?v=0.24.87';
import {VOICE_CUES,VOICE_EVENTS,RANDOM_VOICE_EVENTS,START_VOICE_EVENT,DEATH_VOICE_EVENT} from './voice-cues.js';
import {createVoiceSchedule} from './voice-schedule.js';
import {createBlitzMaterial,blitzMaterialKey,loadBlitzTextures,attachBlitzUV} from './blitz-materials.js';
const playerTextures=new Map();
import {loadCharacterTargets,attachCharacterTarget} from './target-models.js?v=0.24.87';
import {loadTurretModel,createTurretArena} from './turret-view.js?v=0.24.87';
const $=id=>document.getElementById(id),canvas=$('game'),session=new Session(),gameAudio=createGameAudio({cues:{...AUDIO_CUES,...VOICE_CUES,...SKILL_AUDIO_CUES,...TURRET_AUDIO_CUES,...FLASH_AUDIO_CUES},events:{...AUDIO_EVENTS,...VOICE_EVENTS,...SKILL_AUDIO_EVENTS,...TURRET_AUDIO_EVENTS,...FLASH_AUDIO_EVENTS},priorityEvents:[START_VOICE_EVENT,'hookWindup','punchHit','turretAcquired','turretShot','turretImpact','flashCast',DEATH_VOICE_EVENT,...Object.keys(SKILL_AUDIO_EVENTS)],backgroundConcurrency:2});
const voiceSchedule=createVoiceSchedule({playEvent:event=>gameAudio.playEvent(event),isBusy:()=>gameAudio.isGroupPlaying('voice'),randomPool:RANDOM_VOICE_EVENTS,startEvent:START_VOICE_EVENT,deathEvent:DEATH_VOICE_EVENT});
let isTouch=matchMedia('(any-pointer: coarse)').matches;
let renderer,scene,camera,viewScene,viewCamera,viewmodel,clips={},parts=[],clipName='Idle',clipTime=0,oneShot=0,loaded=false;
let startupPhase='graphics',startupReloadPending=false;
let menuReady=false,menuBodyData=null,gameplayPending=null,pendingStart=null,startIntent=0;
const startupRetry=$('startupretry');
startupRetry.hidden=true;startupRetry.disabled=true;
function retryStartup(){
 if(state!=='error'||startupReloadPending)return;
 startupReloadPending=true;startupRetry.disabled=true;
 startupRetry.textContent='다시 불러오는 중…';
 $('startupretrystatus').textContent='페이지를 다시 불러오도록 요청했어요. 화면이 그대로면 브라우저의 새로고침을 이용해 주세요.';
 try{
  // Native reload dispatch is synchronous. It does not report network recovery.
  window.location.reload();
 }catch{
  startupReloadPending=false;startupRetry.disabled=false;
  startupRetry.textContent='다시 불러오기';
  $('startupretrystatus').textContent='다시 불러오기를 요청하지 못했어요. 버튼을 다시 누르거나 브라우저의 새로고침을 이용해 주세요.';
 }
}
startupRetry.onclick=retryStartup;
let state='loading',yaw=0,pitch=0,velocityY=0,grounded=true,shotCooldown=0,punchCooldown=0,shake=0,flash=0,noticeTime=0,muted=false,sensitivity=1;
const player=new THREE.Vector3(0,1.7,7),keys=new Set(),targets=[],obstacles=[],cameraOnlyObstacles=[],sparks=[],worldMaterials=[];
let mouseLook=null,lastInputType='mouse',turretArena=null,health=100,damageFlash=0,graphicsLost=false,deathVoiceActive=false,resultTurretImpactActive=false,resultTone=null;
let thirdPerson=false,fullbody=null,fullbodyParts=0,targetTypes=[],fullbodyNodes=new Map(),fullbodyMeshes=new Map(),walkBlend=0,showcase=null,showcaseScene=null,showcaseCamera=null;
let trainingMirror=null,locomotion=null,applyEWalkLayer=null;
let duelMode=false,duel=null,duelFactory=null,duelAvatar=null,duelRope=null,duelBrain=null,duelSerial=0,duelFinalTime=0,duelPull=null,duelHumanKnockup=null,duelBotSkills=null,duelBotVfx=null;
const duelBot={position:new THREE.Vector3(0,1.7,-12),yaw:Math.PI,pitch:0,velocity:new THREE.Vector3(),knockup:null};
const duelTarget={duel:true,label:'BLITZ · BOT',group:{position:duelBot.position},bounds:{min:new THREE.Vector3().copy(DUEL_SHAPE.min),max:new THREE.Vector3().copy(DUEL_SHAPE.max)}};
const ordinaryControlHint=$('controlhint').textContent,ordinarySessionTag=$('sessiontag').innerHTML;
const duelVector=p=>({x:p.x,y:p.y,z:p.z});
function arenaObstacles(){return duelMode?obstacles.filter(o=>!o.turretId):obstacles;}
function duelGameplay(){return !duelMode||!!duel?.active;}

let skills=null,soloSkills=null,duelSkillClips=null,skillVfx=null,skillClips={viewmodel:{},fullbody:{}},fullbodySurfaces=[],bodySkillActive=false;
const skillAudio=createSkillAudio({playEvent:event=>gameAudio.playEvent(event),playTone:(...args)=>audio(...args)});
const duelBotAudio=createSkillAudio({playEvent:event=>gameAudio.playEvent(event,{emitter:'duel-bot'}),playTone:(...args)=>audio(...args)});
let applyWStationaryLayer;
const applyBodySkill=createFullbodyPoseApplicator(THREE),skillMetrics={powerHits:0,discharges:0,pulseHits:0};
let punchPlaybackRate=1;
const comboPractice=createComboPractice();
const irregularTargets=createIrregularTargets();
let irregularPractice=false;
const flashAbility=createFlashController(),flashButton=$('flashbutton'),flashStatus=$('flashstatus');
const flashHudLast={};
let flashFrameVfx=null;
let challengeFlashAssisted=false;
let fist,rope,hook=null,projectileParts=[],fullbodySocket=new THREE.Vector3(),clock=new THREE.Clock(),dragPointer=null,lastPointer=null,joystick={x:0,y:0},joystickPointer=null;
let inputViewportWidth=innerWidth,inputViewportHeight=innerHeight;
const modeRecords=createModeRecords(),recordUI=Object.fromEntries(['best','combobest','comboerbest','recordstatus'].map(id=>[id,$(id)])),recordLast={};
const comboTime=value=>value===null?'—':value.toFixed(2)+'초';
const scoreRecord=(record,format)=>format(record.best)+(record.best!==null&&!record.saved?' (임시)':'');
const flashRecord=(record,format)=>record.best===null?'':' · 점멸 '+scoreRecord(record,format);
function updateRecordMenu(){
 const records=modeRecords.snapshot(),challenge=records.challenge,combo=records.combo,er=records.comboER;
 const text={best:'90초 최고 '+scoreRecord(challenge,value=>value===null?'—':value+'점')+flashRecord(records.challengeFlash,value=>value+'점'),combobest:'그랩 연계 '+scoreRecord(combo,comboTime)+flashRecord(records.comboFlash,comboTime),comboerbest:'주먹 연계 '+scoreRecord(er,comboTime)+flashRecord(records.comboERFlash,comboTime),recordstatus:Object.values(records).some(record=>record.issue==='invalid')?'읽을 수 없는 기존 기록은 그대로 보존해요. (임시)는 이번 접속만 유지돼요.':Object.values(records).some(record=>record.issue)?'일부 기록을 저장할 수 없어요. (임시)는 새로고침하면 사라질 수 있어요.':'이 브라우저에만 저장 · 점멸 기록은 분리 · 이전 통합 기록은 변경하지 않아요'};
 for(const id of Object.keys(text))if(recordLast[id]!==text[id]){recordUI[id].textContent=text[id];recordLast[id]=text[id];}
}
updateRecordMenu();
syncTouchUI();
function material(color,metalness=.5,roughness=.5,emissive=0){const m=new THREE.MeshStandardMaterial({color,metalness,roughness,emissive});worldMaterials.push(m);return m;}
function box(w,h,d,mat,x,y,z){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;scene.add(o);return o;}
function glowLine(points,color=0x5b9d9b){const g=new THREE.BufferGeometry().setFromPoints(points.map(p=>new THREE.Vector3(...p)));const l=new THREE.Line(g,new THREE.LineBasicMaterial({color,transparent:true,opacity:.65}));scene.add(l);return l;}
function initWorld(){
 renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);renderer.autoClear=false;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.35;renderer.shadowMap.enabled=!isTouch;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
 startupPhase='scene';
 scene=new THREE.Scene();scene.background=new THREE.Color(0x10242e);scene.fog=new THREE.Fog(0x10242e,30,85);camera=new THREE.PerspectiveCamera(64,innerWidth/innerHeight,.08,110);camera.rotation.order='YXZ';
 scene.add(new THREE.HemisphereLight(0xc7edec,0x17202a,2.0));const sun=new THREE.DirectionalLight(0xffe0a0,3.2);sun.position.set(-8,18,10);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-27,right:27,top:28,bottom:-25,far:85});scene.add(sun);
 const rim=new THREE.DirectionalLight(0x52bace,2.5);rim.position.set(7,8,-20);scene.add(rim);
 const floor=material(0x172e37,.45,.7),wall=material(0x203a44,.65,.6),metal=material(0x35454a,.75,.4),dark=material(0x0d202a,.5,.5),gold=material(0xc8a052,.7,.3),cyan=material(0x6bddd0,.2,.3,0x2c837d);
 box(52,.3,70,floor,0,-.18,-13);const grid=new THREE.GridHelper(52,26,0x486463,0x29454d);grid.position.set(0,.005,-13);scene.add(grid);
 box(1,9,65,wall,-26,4.3,-13);box(1,9,65,wall,26,4.3,-13);box(52,13,1,wall,0,6,-46);
 // Visible arena surfaces also stop hooks and turret projectiles.
 for(const [x,y,z,w,h,d] of [[0,-.18,-13,52,.3,70],[-26,4.3,-13,1,9,65],[26,4.3,-13,1,9,65],[0,6,-46,52,13,1]])obstacles.push({min:new THREE.Vector3(x-w/2,y-h/2,z-d/2),max:new THREE.Vector3(x+w/2,y+h/2,z+d/2),arenaSurface:true});
 // Wall supports are visual scenery, not movement or attack blockers. Keep
 // their exact mesh bounds in a camera-only set so the shoulder lens cannot
 // enter a column without changing movement, Flash, Q/E/R, or bot planning.
 for(let z=11;z>-46;z-=11){for(const x of [-24,24]){const column=box(.6,11,.8,metal,x,5.3,z);cameraOnlyObstacles.push(new THREE.Box3().setFromObject(column));}box(49,.5,.8,metal,0,10.5,z);box(11,.09,.16,cyan,-10,10.15,z);box(11,.09,.16,cyan,10,10.15,z);}
 for(const x of [-17,-6,6,17])glowLine([[x,.018,16],[x,.018,-43]],0x406365);
 for(let z=5;z>-40;z-=8){box(.12,.025,2,gold,-2,.02,z);box(.12,.025,2,gold,2,.02,z);}
 for(const [x,z,w,h,d] of [[-9,-8,3,2.8,3],[9,-14,4,3.2,3],[-6,-25,3,3.4,3],[16,-29,4,4,4],[-18,-34,5,3,4]]){
  box(w,h,d,dark,x,h/2,z);box(w+.05,.13,d+.05,gold,x,h-.2,z);obstacles.push({min:new THREE.Vector3(x-w/2,0,z-d/2),max:new THREE.Vector3(x+w/2,h,z+d/2)});
  for(let i=0;i<3;i++)box(.15,h*.7,.04,metal,x-w/3+i*w/3,h/2,z+d/2+.03);
 }
 // Replace the photographed back-wall sign with a full-height real mirror.
 box(10,7.6,.2,dark,0,3.75,-45.3);
 for(const x of [-4.72,4.72])box(.22,7.3,.2,gold,x,3.75,-44.99);
 for(const y of [.12,7.38])box(9.65,.22,.2,gold,0,y,-44.99);
 for(const x of [-4.55,4.55])box(.035,6.8,.04,cyan,x,3.75,-44.86);
 trainingMirror=createTrainingMirror(THREE,{isTouch,beforeReflection:prepareMirrorBody,afterReflection:restoreMirrorBody});scene.add(trainingMirror);
 obstacles.push({min:new THREE.Vector3(-4.5,.25,-45.17),max:new THREE.Vector3(4.5,7.25,-45.05),mirrorSurface:true});
 const locations=[[0,1.8,-9,1.1,.65],[-4,2.1,-16,3,.8],[5,2.4,-22,3,.9],[-12,2.7,-22,2,.6],[12,2,-9,2,1.1],[0,3.2,-31,4,1.0],[-17,2,-12,2,1.0],[17,3,-37,3,.7]];
 locations.forEach((p,i)=>{const group=new THREE.Group();scene.add(group);const shell=new THREE.Mesh(new THREE.IcosahedronGeometry(.64,1),material(i%3===0?0xc29a52:0x748e91,.75,.3));group.add(shell);const core=new THREE.Mesh(new THREE.SphereGeometry(.31,14,10),material(0x8af3d4,.25,.2,0x29856c));core.position.z=.5;group.add(core);const ring=new THREE.Mesh(new THREE.TorusGeometry(.86,.035,5,32),material(0x78d9c7,.4,.3,0x2d685d));group.add(ring);const finmat=material(0x304953,.7,.4);for(let k=0;k<3;k++){const fin=new THREE.Mesh(new THREE.BoxGeometry(.5,.08,.34),finmat);fin.rotation.z=k*Math.PI*2/3;fin.position.set(Math.cos(k*Math.PI*2/3)*.65,Math.sin(k*Math.PI*2/3)*.65,0);group.add(fin);}const t={group,ring,anchor:new THREE.Vector3(p[0],p[1],p[2]),amplitude:p[3],speed:p[4],phase:i*1.8,respawn:0,captured:false,active:true};group.position.copy(t.anchor);targets.push(t);});
 viewScene=new THREE.Scene();viewCamera=new THREE.PerspectiveCamera(54,innerWidth/innerHeight,.03,20);viewScene.add(new THREE.HemisphereLight(0xf1efe4,0x334452,2));const vl=new THREE.DirectionalLight(0xffdfa3,4);vl.position.set(-3,5,2);viewScene.add(vl);const vr=new THREE.DirectionalLight(0x86bfd6,2);vr.position.set(3,1,-1);viewScene.add(vr);
 rope=createHookChain(THREE);rope.visible=false;scene.add(rope);
 resize();
}
function buildModel(data){
 viewmodel=new THREE.Group();viewScene.add(viewmodel);const materials=new Map();
 for(const p of data.parts){const verts=new Float32Array(p.vertices),normals=new Float32Array(p.normals),indices=p.triangles.slice();for(let i=2;i<verts.length;i+=3){verts[i]*=-1;normals[i]*=-1;}for(let i=0;i<indices.length;i+=3)[indices[i],indices[i+2]]=[indices[i+2],indices[i]];const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(verts,3));geometry.setAttribute('normal',new THREE.BufferAttribute(normals,3));geometry.setIndex(new THREE.BufferAttribute(ArrayBuffer.isView(indices)?indices:new Uint16Array(indices),1));attachBlitzUV(THREE,geometry,p);geometry.computeBoundingBox();geometry.computeBoundingSphere();const key=blitzMaterialKey(p,{metalness:.76,roughness:.34});let mat=materials.get(key);if(!mat){mat=createBlitzMaterial(THREE,p,{metalness:.76,roughness:.34},playerTextures);materials.set(key,mat);}const mesh=new THREE.Mesh(geometry,mat);mesh.name=p.name;mesh.userData.sourcePart=p.sourcePart||p.name;mesh.frustumCulled=false;viewmodel.add(mesh);parts.push(mesh);}
 for(const c of data.clips)clips[c.name]=c;
 fist=new THREE.Group();projectileParts=parts.filter(m=>m.name.endsWith('.R')&&/ElbowForearmLink|Forearm|Wrist|Palm|KnucklePlate|Finger|Thumb/.test(m.name));for(const m of projectileParts){const clone=new THREE.Mesh(m.geometry,m.material);clone.matrixAutoUpdate=false;fist.add(clone);}fist.visible=false;scene.add(fist);viewmodel.position.set(0,-.13,.18);applyAnimation(0);
}
function buildFullbody(data){
 const group=new THREE.Group();const materials=new Map();fullbodyParts=data.parts.length;
 for(const node of data.nodes){const object=new THREE.Group();object.name=node.name;object.userData.base=node.position.slice();fullbodyNodes.set(node.name,object);}
 const records=new Map(data.nodes.map(n=>[n.name,n]));
 for(const node of data.nodes){const object=fullbodyNodes.get(node.name),parent=fullbodyNodes.get(node.parent),parentRecord=records.get(node.parent);object.position.fromArray(node.position);if(parent){object.position.sub(new THREE.Vector3().fromArray(parentRecord.position));parent.add(object);}else group.add(object);object.userData.base=object.position.toArray();}
 for(const p of data.parts){const node=fullbodyNodes.get(p.name),record=records.get(p.name),g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p.vertices,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(p.normals,3));g.setIndex(new THREE.BufferAttribute(ArrayBuffer.isView(p.triangles)?p.triangles:new Uint16Array(p.triangles),1));attachBlitzUV(THREE,g,p);g.translate(-record.position[0],-record.position[1],-record.position[2]);g.computeBoundingBox();g.computeBoundingSphere();const key=blitzMaterialKey(p);let mat=materials.get(key);if(!mat){mat=createBlitzMaterial(THREE,p,undefined,playerTextures);materials.set(key,mat);}const mesh=new THREE.Mesh(g,mat);mesh.name=p.name+'_surface';mesh.userData.sourcePart=p.sourcePart||p.name;mesh.userData.skillRestPoint=record.position.slice();fullbodySurfaces.push(mesh);mesh.castShadow=true;mesh.receiveShadow=true;node.add(mesh);fullbodyMeshes.set(p.name,mesh);}
 fullbody=group;fullbody.scale.setScalar(.78);fullbody.visible=false;scene.add(fullbody);
 duelFactory=createDuelAvatarFactory(THREE,{body:fullbody,nodes:fullbodyNodes,meshes:fullbodyMeshes,createLocomotion:createFullbodyLocomotion});
 duelAvatar=duelFactory.create({parent:scene,staticRestMatrices:true,reuseSkillSurfaceRestPose:true,stationaryW:true});duelRope=createHookChain(THREE);duelRope.visible=false;scene.add(duelRope);
 locomotion=createFullbodyLocomotion(THREE,{nodes:fullbodyNodes,meshes:fullbodyMeshes,scale:.78});
 applyWStationaryLayer=createFullbodyWStationaryLayer(THREE,{body:fullbody,nodes:fullbodyNodes,surfaces:fullbodySurfaces,locomotion});
 applyEWalkLayer=createFullbodyELocomotionLayer(THREE,{body:fullbody,nodes:fullbodyNodes,surfaces:fullbodySurfaces,locomotion});
 cacheStaticFullbodyNodeMatrices(fullbodyNodes);
 showcaseScene=new THREE.Scene();showcaseScene.background=new THREE.Color(0x0e2029);showcaseScene.add(new THREE.HemisphereLight(0xb3e9e9,0x202530,2.3));const keyLight=new THREE.DirectionalLight(0xffdda1,4.5);keyLight.position.set(-4,6,5);showcaseScene.add(keyLight);const rim=new THREE.DirectionalLight(0x62bfd4,3);rim.position.set(4,3,-4);showcaseScene.add(rim);showcase=group.clone();showcase.visible=true;showcase.scale.setScalar(1);showcaseScene.add(showcase);
 const base=new THREE.Mesh(new THREE.CylinderGeometry(1.9,2.1,.18,64),material(0x273c42,.8,.45));base.position.set(0,-.1,0);showcase.add(base);const halo=new THREE.Mesh(new THREE.TorusGeometry(1.92,.018,4,80),new THREE.MeshBasicMaterial({color:0xd6b568}));halo.rotation.x=Math.PI/2;halo.position.y=.01;showcase.add(halo);
 // The menu display rotates/resizes only at its root. Bake the unchanged
 // descendant local transforms once; world matrices still follow the root.
 showcase.traverse(object=>{if(object!==showcase){object.updateMatrix();object.matrixAutoUpdate=false;}});
 showcaseCamera=new THREE.PerspectiveCamera(40,innerWidth/innerHeight,.1,40);resize();
}
// Game presentation layer, not an authored combined E/W clip. Reuse each W
// elbow's rigid motion for its entire held-fist arm, retaining E finger/hand
// articulation and every within-arm joint connection. Real travel owns phase.
const heldRunP=new THREE.Vector3(),heldRunQ=new THREE.Quaternion(),heldRunRestQ=new THREE.Quaternion(),heldRunRestP=new THREE.Vector3(),heldRunNextQ=new THREE.Quaternion(),heldRunIdentity=new THREE.Quaternion();
let heldRunSequence=null,heldRunElapsed=0;
function applyHeldFistWalkPresentation(dt){
 const animation=visibleSkillAnimation();
 if(animation?.name!=='E_Hold'){heldRunSequence=null;heldRunElapsed=0;return;}
 if(heldRunSequence!==animation.sequence){heldRunSequence=animation.sequence;heldRunElapsed=0;}
 else if(Number.isFinite(dt)&&dt>0)heldRunElapsed+=dt;
 const boost=skills?.status.boost||0;
 if(!locomotion?.blend||!boost)return;
 const run=skillClips.viewmodel.W_Loop,frame=locomotion.phase*run.duration*run.fps;
 const a=Math.min(Math.floor(frame),run.frames.length-1),b=Math.min(a+1,run.frames.length-1),u=frame-a;
 const weight=locomotion.blend*smooth(Math.min(1,heldRunElapsed/.18,boost/.18,(SKILL_TUNING.wDuration-boost)/.18));
 for(const side of ['L','R']){
  const i=parts.findIndex(part=>part.name==='VM_Elbow.'+side),p=run.frames[a].poses[i],q=run.frames[b].poses[i],rest=run.frames[0].poses[i];
  heldRunP.set(p.p[0]+(q.p[0]-p.p[0])*u,p.p[1]+(q.p[1]-p.p[1])*u,-p.p[2]-(q.p[2]-p.p[2])*u);
  heldRunQ.set(-p.q[0],-p.q[1],p.q[2],p.q[3]).normalize();heldRunNextQ.set(-q.q[0],-q.q[1],q.q[2],q.q[3]).normalize();heldRunQ.slerp(heldRunNextQ,u);
  heldRunRestQ.set(-rest.q[0],-rest.q[1],rest.q[2],rest.q[3]).normalize().invert();heldRunQ.multiply(heldRunRestQ);
  heldRunRestP.set(rest.p[0],rest.p[1],-rest.p[2]).applyQuaternion(heldRunQ);heldRunP.sub(heldRunRestP).multiplyScalar(weight);
  heldRunQ.slerp(heldRunIdentity,1-weight);
  for(const part of parts)if(part.name.endsWith('.'+side)){part.position.applyQuaternion(heldRunQ).add(heldRunP);part.quaternion.premultiply(heldRunQ);}
 }
}
function visibleSkillAnimation(){if(hook||oneShot>0)return null;const skill=skills?.animation;return skill?.presentation?{...skill,...skill.presentation}:skill;}
function animateFullbody(dt,walking){
 if(!fullbody)return;
 // Movement advances the gait exactly once. Zero-dt hook refreshes only reapply it.
 locomotion?.restorePose();fullbody.position.y=player.y-1.7;
 for(const [name,node] of fullbodyNodes){if(name.startsWith('BC_Pivot_')||name.startsWith('BC_QLaunch')){node.rotation.set(0,0,0);node.position.fromArray(node.userData.base);}}
 const skill=visibleSkillAnimation();if(skill){applyBodySkill(skillClips.fullbody[skill.name],skill.time,fullbodySurfaces);if(skill.name.startsWith('E_')){const st=skills.status;applyEWalkLayer({armRecoveryWeight:skill.name==='E_Strike'&&!st.boost&&!st.slow?eRecoveryArmWeight(skill.time,skill.duration):0});}if(skill.name==='R_Cast'){const st=skills.status;applyEWalkLayer({armRecoveryWeight:st.armed||st.boost||st.slow?0:rRecoveryArmWeight(skill.time,skill.duration)});}if(skill.name.startsWith('W_'))applyWStationaryLayer();bodySkillActive=true;updateFullbodyHand();return;}
 if(bodySkillActive){clearFullbodySkillPose(fullbodySurfaces);bodySkillActive=false;}
 // Q launches from the actual upper-body socket: keep its original root path.
 fullbody.position.y=player.y-1.7+(locomotion?.applyPose({preserveUpper:!!hook})||0);
 const shoulder=fullbodyNodes.get('BC_Pivot_Shoulder.R');
 if(oneShot>0&&clipName==='Basic_Punch'&&shoulder){const t=Math.min(1,clipTime/.65),reach=Math.sin(t*Math.PI);shoulder.rotation.x=-reach*1.3;shoulder.rotation.z=0;}
 if(hook&&shoulder){const lift=hook.phase==='windup'?smooth(Math.min(1,hook.phaseTime/.25)):hook.phase==='recover'?1-smooth(Math.min(1,hook.phaseTime/.26)):1;shoulder.rotation.x=-(Math.PI/2+pitch)*lift;shoulder.rotation.z=0;}
 updateFullbodyHand();
}
function updateFullbodyHand(){
 const q=fullbodyNodes.get('BC_QLaunch.R'),palm=fullbodyMeshes.get('BC_Palm.R');if(!q||!palm)return;
 const detached=hook&&['outbound','return'].includes(hook.phase);
 // World-space queries refresh their ancestor paths. A flying hand only needs
 // the whole body tree updated once, after its final orientation and position.
 q.position.fromArray(q.userData.base);q.quaternion.identity();const center=palm.geometry.boundingBox.getCenter(new THREE.Vector3());palm.localToWorld(center);fullbodySocket.copy(center);
 if(detached){
  const home=q.getWorldQuaternion(new THREE.Quaternion()),orientation=hook.bodyOrientation?.clone()||home.clone();
  if(hook.phase==='return')orientation.slerp(home,smooth(Math.min(1,hook.phaseTime/hook.returnDuration)));
  q.quaternion.copy(q.parent.getWorldQuaternion(new THREE.Quaternion()).invert()).multiply(orientation);
  palm.geometry.boundingBox.getCenter(center);palm.localToWorld(center);const current=q.parent.worldToLocal(center.clone()),desired=q.parent.worldToLocal(hook.position.clone());q.position.add(desired.sub(current));fullbody.updateMatrixWorld(true);
 }
}

function syncCamera(){
 camera.rotation.set(pitch,yaw,0);camera.position.copy(player);
 if(thirdPerson)camera.position.copy(thirdPersonCameraPosition(player,yaw,pitch,[...arenaObstacles(),...cameraOnlyObstacles]));
 if(fullbody){fullbody.visible=thirdPerson;fullbody.position.set(player.x,player.y-1.7,player.z);fullbody.rotation.y=yaw+Math.PI;}
}
// Keep the shoulder/body and arena readable on tall screens without moving the
// camera or changing its center aim ray. Use a 60° horizontal minimum, capped
// at 120° vertically for unusually narrow windows. Other views stay at 64°.
function syncCameraProjection(){
 if(!camera)return;
 const portraitFov=THREE.MathUtils.radToDeg(2*Math.atan(Math.tan(THREE.MathUtils.degToRad(60/2))/camera.aspect));
 camera.fov=thirdPerson&&camera.aspect<1?Math.max(64,Math.min(120,portraitFov)):64;
 camera.updateProjectionMatrix();
}
function clampViewPitch(value){return THREE.MathUtils.clamp(value,thirdPerson?-1.15:-1.3,thirdPerson?.5:1.3);}
function toggleView(){thirdPerson=!thirdPerson;pitch=clampViewPitch(pitch);syncCameraProjection();updateViewLabel();skillVfx?.setView(thirdPerson);flashFrameVfx?.update(0,{firstPerson:!thirdPerson});if(state==='running'||state==='paused'||state==='results'){syncCamera();animateFullbody(0,false);if(hook&&['outbound','return'].includes(hook.phase))syncHookVisuals();}}
function playClip(name,oneshot=false){if(!clips[name])return;if(!oneshot&&oneShot>0)return;if(name===clipName&&!oneshot)return;clipName=name;clipTime=0;if(oneshot)oneShot=clips[name].duration;}
const qa=new THREE.Quaternion(),qb=new THREE.Quaternion();
function smooth(t){return t*t*(3-2*t);}
function applyAnimation(dt,walking=false){if(!viewmodel)return;
 if(hook){clipName='Q_Launch';oneShot=.1;clipTime=hook.phase==='windup'?.28*smooth(Math.min(1,hook.phaseTime/.25)):hook.phase==='recover'?.28*(1-smooth(Math.min(1,hook.phaseTime/.26))):.28;}else{oneShot=Math.max(0,oneShot-dt);if(dt>0&&clipName==='Basic_Punch'&&oneShot<1e-12)oneShot=0;if(!oneShot&&state==='running')playClip(walking?'Walk_Arm_Sway':'Idle');clipTime+=dt*(clipName==='Basic_Punch'?punchPlaybackRate:1);}
 const skill=visibleSkillAnimation(),c=skill?skillClips.viewmodel[skill.name]:clips[clipName],animationTime=skill?skill.time:clipTime,t=c.loop?animationTime%c.duration:Math.min(animationTime,c.duration),f=t*c.fps,a=Math.min(Math.floor(f),c.frames.length-1),b=Math.min(a+1,c.frames.length-1),u=f-a;
 let previousX,previousY,reuseQuaternion=false;
 for(let i=0;i<parts.length;i++){
  const x=c.frames[a].poses[i],y=c.frames[b].poses[i];
  // Split surfaces share endpoints. Reuse only this call's computed transform.
  if(i>0&&x===previousX&&y===previousY){
   const previous=parts[i-1];parts[i].position.copy(previous.position);parts[i].scale.copy(previous.scale);
   // Three's dot>=1 early return can leave a distinct Euler value. Preserve
   // that exact callback path instead of resynchronizing it via a plain copy.
   if(reuseQuaternion)parts[i].quaternion.copy(previous.quaternion);else parts[i].quaternion.copy(qa).slerp(qb,u);
   continue;
  }
  previousX=x;previousY=y;
  parts[i].position.set(THREE.MathUtils.lerp(x.p[0],y.p[0],u),THREE.MathUtils.lerp(x.p[1],y.p[1],u),-THREE.MathUtils.lerp(x.p[2],y.p[2],u));qa.set(-x.q[0],-x.q[1],x.q[2],x.q[3]);qb.set(-y.q[0],-y.q[1],y.q[2],y.q[3]);reuseQuaternion=u===0||u===1||(qa.w*qb.w+qa.x*qb.x+qa.y*qb.y+qa.z*qb.z)<1;parts[i].quaternion.copy(qa).slerp(qb,u);parts[i].scale.set(THREE.MathUtils.lerp(x.s[0],y.s[0],u),THREE.MathUtils.lerp(x.s[1],y.s[1],u),THREE.MathUtils.lerp(x.s[2],y.s[2],u));}
 const detached=hook&&['outbound','return'].includes(hook.phase);for(const p of projectileParts)p.visible=!detached;
}

function audio(freq,end,duration=.16){return gameAudio.playTone(freq,end,duration);}
function toast(text){$('toast').textContent=text;$('toast').style.opacity=1;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').style.opacity=0,3500);}
function viewToWorldMatrix(){camera.updateMatrixWorld(true);viewmodel.updateMatrixWorld(true);const ratio=Math.tan(THREE.MathUtils.degToRad(camera.fov/2))/Math.tan(THREE.MathUtils.degToRad(viewCamera.fov/2));return camera.matrixWorld.clone().multiply(new THREE.Matrix4().makeScale(ratio,ratio,1));}
function fpsHandPoint(conversion=viewToWorldMatrix()){const palm=parts.find(p=>p.name==='VM_Palm.R');const point=palm.geometry.boundingBox.getCenter(new THREE.Vector3());return point.applyMatrix4(palm.matrixWorld).applyMatrix4(conversion);}
// World-space socket getters refresh their ancestors without rewalking the
// complete player/VFX subtree. Pose updates retain their final full-body pass.
function cableSocket(){if(thirdPerson){const elbow=fullbodyMeshes.get('BC_Elbow.R');return elbow.localToWorld(elbow.geometry.boundingBox.getCenter(new THREE.Vector3()));}const conversion=viewToWorldMatrix(),elbow=parts.find(p=>p.name==='VM_Elbow.R');return elbow.geometry.boundingBox.getCenter(new THREE.Vector3()).applyMatrix4(elbow.matrixWorld).applyMatrix4(conversion);}
function handPoint(){return thirdPerson?fullbodySocket.clone():fpsHandPoint();}
function fullbodyCableSocket(){const elbow=fullbodyMeshes.get('BC_Elbow.R');return elbow.localToWorld(elbow.geometry.boundingBox.getCenter(new THREE.Vector3()));}
function fullbodyChainSocket(){return fullbodyNodes.get('BC_QLaunch.R').getWorldPosition(new THREE.Vector3());}
// The first-person arms belong to a separate overlay scene. Reflections instead
// show the original complete body, and only one copy of the detached hand.
function prepareMirrorBody(){
 if(!fullbody)return null;
 const token={body:fullbody,bodyVisible:fullbody.visible,fist,fistVisible:fist?.visible,chain:null};
 fullbody.visible=true;if(fist)fist.visible=false;
 if(!thirdPerson&&hook&&rope?.visible&&['outbound','return'].includes(hook.phase)){
  token.chain={start:rope.userData.start.clone(),end:rope.userData.end.clone(),state:{phase:hook.phase,phaseTime:hook.phaseTime,time:session.elapsed}};
  rope.update(fullbodyCableSocket(),fullbodyChainSocket(),token.chain.state);
 }
 return token;
}
function restoreMirrorBody(token){
 if(!token)return;
 token.body.visible=token.bodyVisible;if(token.fist)token.fist.visible=token.fistVisible;
 if(token.chain)rope.update(token.chain.start,token.chain.end,token.chain.state);
}

// The chain enters the detached forearm at its original elbow connector,
// rather than running through the flying hand to its palm center.
function chainHandSocket(){
 if(thirdPerson){return fullbodyNodes.get('BC_QLaunch.R').getWorldPosition(new THREE.Vector3());}
 fist.updateMatrixWorld(true);const index=projectileParts.findIndex(p=>p.name==='VM_ElbowForearmLink.R'),mesh=fist.children[index];
 return mesh.geometry.boundingBox.getCenter(new THREE.Vector3()).applyMatrix4(mesh.matrixWorld);
}
function prepareProjectile(place=true){
 // Reuse this call's already-refreshed conversion; no transform changes occur
 // before reading the palm. Standalone hand queries still refresh normally.
 const conversion=viewToWorldMatrix(),center=fpsHandPoint(conversion),inverse=new THREE.Matrix4().compose(center,camera.quaternion,new THREE.Vector3(1,1,1)).invert();
 for(let i=0;i<projectileParts.length;i++)fist.children[i].matrix.copy(inverse).multiply(conversion).multiply(projectileParts[i].matrixWorld);if(place){fist.position.copy(center);fist.quaternion.copy(camera.quaternion);}
}

// Private, synchronous queries use internal ordinary Vector3 bounds. Rebuild after every move.
const rayTargetMin=new THREE.Vector3(),rayTargetMax=new THREE.Vector3();
function nearestRay(origin,dir,range){let nearest=range,target=null,blocked=false;for(const t of duelMode?[duelTarget]:targets){if(!t.duel&&(!t.active||t.captured))continue;const d=t.bounds?rayBox(origin,dir,rayTargetMin.copy(t.bounds.min).add(t.group.position),rayTargetMax.copy(t.bounds.max).add(t.group.position),nearest):raySphere(origin,dir,t.group.position,CONFIG.targetRadius,nearest);if(d!==null){nearest=d;target=t;blocked=false;}}for(const o of arenaObstacles()){const d=rayBox(origin,dir,o.min,o.max,nearest);if(d!==null){nearest=d;target=null;blocked=true;}}return{distance:nearest,target,blocked};}
// One availability decision drives both input and the visible ready state.
function hookBlockReason(){
 if(state!=='running'||graphicsLost)return state==='paused'||graphicsLost?'paused':'inactive';
 if(!playing())return 'capture';
 if(!duelGameplay())return 'round';
 if(hook)return 'hook';
 if(shotCooldown>0)return 'cooldown';
 if(skills?.blocksAttack)return 'casting';
 if(oneShot>0)return clipName==='Basic_Punch'?'punch':'recover';
 if(comboPractice.enabled&&!comboPractice.canStart)return 'combo';
 return null;
}
function fireHook(){const blocked=hookBlockReason();if(blocked){const text={casting:'Q · 스킬 시전 중',punch:'Q · 펀치 동작 중',recover:'Q · 손 복구 중',combo:comboPractice.active?'Q · 연계 진행 중':'Q · 다음 시도 준비'}[blocked];if(text)notice(isTouch?text.replace('Q · ',''):text);updateHookHud();return;}if(duelMode){if(duel.cast('human')){gameAudio.playEvent('hookWindup');playClip('Q_Launch',true);syncDuelHook();updateHud();}return;}if(comboPractice.enabled&&!comboPractice.start(session.elapsed))return;session.shot();shotCooldown=CONFIG.cooldown;playClip('Q_Launch',true);syncCamera();hook={samplePlayed:gameAudio.playEvent('hookWindup'),phase:'windup',phaseTime:0,position:handPoint(),direction:new THREE.Vector3(),travel:0,returning:false,target:null,hit:false};fist.visible=rope.visible=false;updateHud();}
function launchHook(){const h=hook;syncCamera();applyAnimation(0);animateFullbody(0,false);prepareProjectile();const dir=camera.getWorldDirection(new THREE.Vector3()),aimed=nearestRay(camera.position,dir,CONFIG.maxRange),aim=camera.position.clone().addScaledVector(dir,aimed.distance),origin=handPoint(),toward=aim.sub(origin),blockedAim=thirdPerson&&toward.dot(dir)<=.05;h.position.copy(origin);h.direction.copy(blockedAim?dir:toward.normalize());h.bodyOrientation=fullbodyNodes.get('BC_QLaunch.R').getWorldQuaternion(new THREE.Quaternion());h.phase='outbound';h.phaseTime=0;h.orientation=new THREE.Quaternion().setFromUnitVectors(dir,h.direction).multiply(camera.quaternion);for(const p of projectileParts)p.visible=false;fist.position.copy(origin);fist.visible=!thirdPerson;rope.visible=true;if(blockedAim){startReturn(h);session.miss();comboPractice.fail(session.elapsed,'Q가 장애물에 막혔어요');notice('BLOCKED');audio(150,65,.12);}else if(!h.samplePlayed)audio(650,95,.24);syncHookVisuals();}

function punch(){
 if(!playing()||!duelGameplay()||punchCooldown>0||hook||skills?.blocksAttack)return;
 if(skills?.status.phase==='E_Hold'){if(skills.strikeE()){punchCooldown=44/30;oneShot=0;shake=.05;updateHookHud();updateSkillHud();}return;}
 if(comboPractice.enabled){comboPractice.fail(session.elapsed,'E 충전 후 펀치');notice(isTouch?'강철 주먹 충전 뒤 펀치':'E 충전 후 좌클릭 · 터치는 펀치');updateHookHud();return;}
 punchPlaybackRate=skills?.attackMultiplier||1;punchCooldown=.65/punchPlaybackRate;playClip('Basic_Punch',true);oneShot=clips.Basic_Punch.duration/punchPlaybackRate;shake=.08;
 const hit=meleeHit(3);if(hit?.target){const t=hit.target;particles(t.group.position,0xdfbd6b);if(duelMode){notice(isTouch?'펀치 명중':'PUNCH · 명중');if(!gameAudio.playEvent('punchHit'))audio(700,1100,.12);updateHookHud();updateSkillHud();return;}t.active=false;t.respawn=session.elapsed+2;t.group.visible=false;const points=session.punch();notice('+'+points+'  PUNCH');if(!gameAudio.playEvent('punchHit'))audio(700,1100,.12);}else audio(125,40,.15);updateHookHud();updateSkillHud();
}
function meleeHit(range){syncCamera();const direction=camera.getWorldDirection(new THREE.Vector3());if(thirdPerson){const aimed=nearestRay(camera.position,direction,CONFIG.maxRange),toward=camera.position.clone().addScaledVector(direction,aimed.distance).sub(player);if(toward.lengthSq()<1e-8||toward.dot(direction)<=0)return null;direction.copy(toward).normalize();}return nearestRay(player,direction,range);}
function castFlash(){
 const departure={x:player.x,y:player.y,z:player.z};
 const result=flashAbility.cast({playing:playing()&&duelGameplay(),position:player,yaw,isBlocked:collides});
 if(!result.accepted){if(playing()&&result.reason==='blocked')notice('점멸 · 이동할 공간이 없어요');return false;}
 player.set(result.position.x,result.position.y,result.position.z);
 if(comboPractice.enabled)comboPractice.markFlash();else if(!duelMode&&!session.practice)challengeFlashAssisted=true;
 // Existing poses, flying hook, jump velocity and charge survive the move.
 // Replay proven departure pixels and the user-selected Flash recording.
 // Failed or pending audio is dropped, never synthesized or queued.
 gameAudio.playEvent('flashCast');
 flashFrameVfx?.play(departure,{firstPerson:!thirdPerson});
 syncCamera();animateFullbody(0,false);
 if(hook&&['outbound','return'].includes(hook.phase))syncHookVisuals();
 notice('점멸 · 출발 영상 프레임');updateHud();return true;
}
function updateFlashHud(){
 const status=flashAbility.status,available=playing()&&duelGameplay(),disabled=!status.ready||!available;
 const text=!status.ready?Math.ceil(status.remaining)+'초':available?'준비':graphicsLost||state==='paused'?'정지':state==='running'?'대기':state==='results'?'종료':'대기';
 if(flashHudLast.text!==text){flashStatus.textContent=text;flashHudLast.text=text;}
 if(flashHudLast.disabled!==disabled){flashButton.setAttribute('aria-disabled',String(disabled));flashHudLast.disabled=disabled;}
}
function skillBlockReason(key){
 if(state!=='running'||graphicsLost)return state==='paused'||graphicsLost?'paused':'inactive';
 if(!playing())return 'capture';
 if(!duelGameplay())return 'round';
 if(!skills)return 'inactive';
 if(comboPractice.enabled&&!comboPractice.active){
  if(key==='E'&&!comboPractice.canStart)return 'comboRetry';
  if(key==='R')return comboPractice.canStart?'comboStart':'comboRetry';
 }
 const reason=skills.blockReason(key,{busy:!!hook||oneShot>0});
 return reason==='busy'?(hook?'hook':'punch'):reason;
}
function castW(){if(!skillBlockReason('W')&&skills.castW()){notice(isTouch?'폭주':'SHIFT  OVERDRIVE');skillAudio.castW();updateHud();}}
function castE(){if(!skillBlockReason('E')&&skills.castE({busy:!!hook||oneShot>0})){if(comboPractice.canStart)comboPractice.start(session.elapsed,'er');notice(isTouch?'강철 주먹 충전 뒤 펀치':'E  충전 후 좌클릭');skillAudio.castE();updateHud();}}
function castR(){if(playing()&&comboPractice.enabled&&!comboPractice.active){notice(isTouch?'강철 주먹으로 띄운 뒤 전기장':'E + 펀치 → R · Q는 선택이에요');return;}if(!skillBlockReason('R')&&skills.castR({busy:!!hook||oneShot>0})){notice(isTouch?'전기장':'R  STATIC FIELD');skillAudio.castR();updateHud();}}
let soloSkillFrame=null;
function stepSoloSkills(dt){
 if(!skills)return;
 // Scope event timing to this exact controller step. A later cast/reset must
 // never inherit an earlier animation clock. Duel owns its separate context.
 soloSkillFrame={dt,animation:skills.animation};
 try{skills.step(dt);}finally{soloSkillFrame=null;}
}
function soloEffectOffset(event){
 const step=soloSkillFrame,before=step?.animation;
 if(!before||event.clip!==before.name||event.sequence!==before.sequence||!Number.isFinite(step.dt)||step.dt<=0)return 0;
 const offset=event.time-before.time,epsilon=16*Number.EPSILON*Math.max(1,before.duration);
 if(!Number.isFinite(offset)||offset < -epsilon||offset > step.dt+epsilon)return 0;
 if(Math.abs(offset-step.dt)<=epsilon)return step.dt;
 return Math.max(0,Math.min(step.dt,offset));
}
function skillEvent(event){
 if(!playing()||!duelGameplay())return;
 if(duelMode)return; // Duel authority owns both controllers and all impacts.
 const frameOffset=soloEffectOffset(event);
 if(event.type==='power_fist_hit'){
  const hit=meleeHit(SKILL_TUNING.eRange);shake=.15;
  if(hit?.target){const t=hit.target;const drill=comboPractice.enabled,valid=drill&&comboPractice.powerHit(targets.indexOf(t),session.elapsed);if(valid&&!t.comboHold)t.comboHold=t.group.position.clone();t.active=valid;t.knockup={time:0,origin:t.group.position.clone()};t.respawn=session.elapsed+SKILL_TUNING.eKnockupDuration+1.7;session.score+=SKILL_TUNING.ePoints;session.punches++;skillMetrics.powerHits++;skillVfx?.event('power_fist_hit',{position:t.group.position,frameOffset});notice('+'+SKILL_TUNING.ePoints+'  POWER FIST ↑');skillAudio.hitE();}else{comboPractice.fail(session.elapsed,'E 펀치가 빗나갔어요');notice('POWER FIST · MISS');audio(220,65,.15);}
 }
 if(event.type==='static_field_discharge'){
  skillMetrics.discharges++;let hits=0;const comboHits=[];shake=.2;
  skillVfx?.event('static_field_discharge',{position:player,frameOffset});
  for(const t of targets){if(!t.active||t.captured)continue;const delta=t.group.position.clone().sub(player),distance=delta.length();if(distance>SKILL_TUNING.rRadius)continue;const direction=delta.normalize();if(obstacles.some(o=>rayBox(player,direction,o.min,o.max,distance-.01)!==null))continue;comboHits.push(targets.indexOf(t));t.active=false;t.knockup=null;t.comboHold=null;t.group.visible=false;t.respawn=session.elapsed+2.2;skillVfx?.event('static_field_target',{position:t.group.position,frameOffset});hits++;}
  if(comboPractice.discharge(comboHits,session.elapsed)){
   const result=comboPractice.snapshot(session.elapsed);
   if(result.phase==='success'&&result.last?.success){modeRecords.recordCombo(result.last);updateRecordMenu();}
  }
  session.score+=hits*SKILL_TUNING.rPoints;skillMetrics.pulseHits+=hits;notice(hits?'+'+(hits*SKILL_TUNING.rPoints)+'  STATIC FIELD ×'+hits:'STATIC FIELD');skillAudio.dischargeR();
 }
 updateHud();
}
function resetSkills(){locomotion?.reset();walkBlend=0;if(fullbody)fullbody.position.y=player.y-1.7;skills?.reset();skillVfx?.reset();skillAudio.reset();clearFullbodySkillPose(fullbodySurfaces);bodySkillActive=false;punchPlaybackRate=1;for(const key of Object.keys(skillMetrics))skillMetrics[key]=0;}
function notice(text){setHitNoticeUI(text,true);noticeTime=1.0;}
// Same sixteen meshes and trajectories; immutable resources are shared only
// inside one burst. Reference-counted cleanup covers expiry and restart.
function releaseSpark(s){scene.remove(s.mesh);if(--s.batch.remaining===0){s.mesh.geometry.dispose();s.mesh.material.dispose();}}
function particles(pos,color){const geometry=new THREE.BoxGeometry(.055,.055,.055),material=new THREE.MeshBasicMaterial({color}),batch={remaining:16};for(let i=0;i<16;i++){const m=new THREE.Mesh(geometry,material);m.position.copy(pos);scene.add(m);sparks.push({mesh:m,batch,life:.65,velocity:new THREE.Vector3((Math.random()-.5)*7,Math.random()*4,(Math.random()-.5)*7)});}}
function comboDeliveryPoint(){const direction=camera.getWorldDirection(new THREE.Vector3()),distance=player.clone().sub(camera.position).dot(direction)+2.2;const point=camera.position.clone().addScaledVector(direction,distance);point.y=Math.max(1.15,point.y);return point;}
function startReturn(h){h.returning=true;h.phase='return';h.phaseTime=0;h.returnStart=h.position.clone();h.returnDuration=.22+h.position.distanceTo(handPoint())/CONFIG.returnSpeed;}
function advanceHook(dt){if(!hook)return;const h=hook;h.phaseTime+=dt;
 if(h.phase==='windup'){h.position.copy(handPoint());if(h.phaseTime>=.25)launchHook();return;}
 // The frame posed the still-active hook before this phase advance. Restore
 // the body with the FPS rig now, without advancing any gait or skill clock.
 if(h.phase==='recover'){if(h.phaseTime>=.26){hook=null;oneShot=0;clipName='Idle';clipTime=0;applyAnimation(0);animateFullbody(0,false);updateHud();}return;}
 if(h.phase==='outbound'){const step=Math.min(CONFIG.hookSpeed*dt,CONFIG.maxRange-h.travel),result=nearestRay(h.position,h.direction,step);h.position.addScaledVector(h.direction,result.distance);h.travel+=result.distance;fist.quaternion.slerp(h.orientation,Math.min(1,dt*18));
 // Character groups only translate. Keep their collision contact instead of a sphere-sized fixed offset.
 if(result.target){h.target=result.target;h.target.captured=true;if(h.target.character)h.targetContactOffset=h.target.group.position.clone().sub(h.position);if(comboPractice.enabled)h.targetReturnStart=h.target.group.position.clone();startReturn(h);h.hit=true;comboPractice.hooked(targets.indexOf(h.target));session.hit();particles(h.position,0x9affdc);audio(500,850,.1);}else if(result.blocked||h.travel>=CONFIG.maxRange-.001){startReturn(h);session.miss();comboPractice.fail(session.elapsed,result.blocked?'Q가 장애물에 막혔어요':'Q가 빗나갔어요');notice(result.blocked?'BLOCKED':'MISSED');audio(150,65,.12);}}
 else{const end=handPoint(),dist=h.position.distanceTo(end),u=Math.min(1,h.phaseTime/h.returnDuration);h.position.lerpVectors(h.returnStart,end,smooth(u));fist.quaternion.slerp(camera.quaternion,Math.min(1,dt*(dist<2?20:5)));
 if(u>=1){h.position.copy(end);prepareProjectile(false);fist.position.copy(end);fist.quaternion.copy(camera.quaternion);if(h.target){const t=h.target;t.captured=false;t.active=false;t.respawn=session.elapsed+1.7;t.group.visible=false;if(comboPractice.delivered(targets.indexOf(t))){t.comboHold=comboDeliveryPoint();t.group.position.copy(t.comboHold);t.active=t.group.visible=true;t.respawn=0;}const points=session.capture();notice('+'+points+'  CAPTURE');particles(end,0xf3ca65);audio(600,1350,.19);shake=.10;}h.phase='recover';h.phaseTime=0;fist.visible=rope.visible=false;for(const p of projectileParts)p.visible=true;updateFullbodyHand();updateHud();return;}if(h.target){if(comboPractice.enabled)h.target.group.position.lerpVectors(h.targetReturnStart,comboDeliveryPoint(),smooth(u));else if(h.targetContactOffset)h.target.group.position.copy(h.position).add(h.targetContactOffset);else h.target.group.position.copy(h.position).addScaledVector(h.direction,.6);}}
 syncHookVisuals();}
function syncHookVisuals(){if(!hook)return;prepareProjectile(false);fist.position.copy(hook.position);fist.visible=!thirdPerson;updateFullbodyHand();rope.update(cableSocket(),chainHandSocket(),{phase:hook.phase,phaseTime:hook.phaseTime,time:session.elapsed});}
function cancelHook(){
 if(!hook)return;
 // A stopped round must release an unfinished capture without scoring it.
 // Restore both rigs now: result screens no longer advance their animations.
 if(hook.target?.captured)hook.target.captured=false;
 hook=null;fist.visible=rope.visible=false;oneShot=0;clipName='Idle';clipTime=0;
 applyAnimation(0);animateFullbody(0,false);
}

function resetTargets(){irregularTargets.reset();targets.forEach(t=>{t.captured=false;t.active=true;t.knockup=null;t.comboHold=null;t.respawn=0;t.group.visible=true;t.group.position.copy(t.anchor);});}
function hasLookContact(){return dragPointer!==null&&canvas.hasPointerCapture(dragPointer);}
function resetLook(){dragPointer=null;lastPointer=null;}
function hasStickContact(){return joystickPointer!==null&&stick.hasPointerCapture(joystickPointer);}
function resetStick(){joystickPointer=null;joystick.x=joystick.y=0;stick.firstElementChild.style.transform='';}
function resetTouchPointers(preserveMovement=false){resetLook();if(!preserveMovement||!hasStickContact())resetStick();}
function isMovementKey(code){return ['KeyW','KeyA','KeyS','KeyD'].includes(code);}
function resetPointers(preserveMovement=false){
 // Round boundaries discard actions/look drag, not live held movement.
 // Safety resets keep the default: require a fresh press after interruption.
 for(const code of keys)if(!preserveMovement||!isMovementKey(code))keys.delete(code);
 mouseLook?.reset();resetTouchPointers(preserveMovement);
}
function updateViewLabel(){$('viewtoggle').textContent=(thirdPerson?'3인칭':'1인칭')+(isTouch?'':' · V');}
function syncTouchUI(){
 document.querySelector('body').classList.toggle('touch-ui',isTouch);updateViewLabel();
 if(!isTouch)return;
 $('flashbutton').setAttribute('aria-label','점멸, 출발 영상 프레임과 선택 녹음 사용, 도착 효과 미연결');
 for(const [key,name,label] of [['W','폭주','폭주'],['E','강철 주먹','강철 주먹 충전, 충전 뒤 펀치'],['R','전기장','전기장']]){const button=$('skill'+key);button.querySelector('span').textContent=name;button.setAttribute('aria-label',label);}
 $('combopractice').innerHTML='연계 연습';if(loaded&&state==='menu')$('loadstatus').textContent='준비 완료 · 90초 · 자유 연습 · 연계 연습 · 봇 1대1';
 $('skillbar').setAttribute('aria-label','스킬');$('sensitivity').setAttribute('aria-label','조준 감도');
}
function enableTouch(){if(isTouch)return;isTouch=true;syncTouchUI();$('mobile').classList.toggle('hidden',state!=='running');updateHud();}
function playing(){return !graphicsLost&&state==='running'&&(lastInputType==='touch'||document.pointerLockElement===canvas);}
function updateCaptureUI(){if(!playing()||duelMode||comboPractice.enabled)setThreatUI(false);gameAudio.setPaused(!playing()&&!(state==='results'&&(deathVoiceActive||resultTurretImpactActive)),{tonePaused:!playing(),preserveTone:state==='results'?resultTone:null});if(playing()&&!muted)voiceSchedule.resume();else voiceSchedule.pause();const locked=document.pointerLockElement===canvas,waiting=state==='running'&&lastInputType!=='touch'&&!locked;canvas.style.cursor=state==='running'&&locked?'none':'';$('captureprompt').classList.toggle('hidden',!waiting);$('crosshair').classList.toggle('hidden',state!=='running'||waiting);$('mousecapture').classList.toggle('hidden',state!=='running'||lastInputType==='touch'||locked);$('mousecapture').setAttribute('aria-pressed',String(locked));updateHookHud();updateSkillHud();updateFlashHud();}
function setState(next){if(next!=='results'){deathVoiceActive=false;resultTurretImpactActive=false;resultTone=null;}resetPointers();state=next;$('mainmenu').classList.toggle('hidden',next!=='paused'&&next!=='results');$('mousecapture').classList.toggle('hidden',next!=='running'||lastInputType==='touch');$('overlay').classList.toggle('hidden',next==='running');$('hud').classList.toggle('hidden',next==='loading'||next==='menu');$('mobile').classList.toggle('hidden',next!=='running'||!isTouch);$('pause').textContent=next==='running'?'Ⅱ':'▷';$('pause').setAttribute('aria-label',next==='running'?'일시정지':next==='paused'?'계속하기':next==='results'?'다시 도전':'훈련 시작');if(next!=='running'){keys.clear();joystick.x=joystick.y=0;$('joystick').firstElementChild.style.transform='';mouseLook?.release();}else{clock.getDelta();}mouseLook?.refresh();updateCaptureUI();}
// Mode selection is latest-wins. Assets continue loading after cancellation,
// but only a still-current foreground gesture may enter the completed game.
function cancelPendingStart(){
 startIntent++;const hadIntent=!!pendingStart;pendingStart=null;
 if(hadIntent){mouseLook?.release();$('mainmenu').classList.add('hidden');if(state!=='error')$('loadstatus').textContent=loaded?'준비 완료 · v0.24.87 · 모드를 선택해 주세요.':'훈련 파일 준비는 계속됩니다. 시작하려면 모드를 다시 선택해 주세요.';}
}
function begin(practice=false,combo=false,duelRequested=false){
 if(graphicsLost||state==='error'||!menuReady)return;
 if(loaded){cancelPendingStart();beginReady(practice,combo,duelRequested);return;}
 const intent=++startIntent;pendingStart={practice,combo,duelRequested,intent};
 // Audio unlock stays in the original gesture; desktop capture requires a
 // fresh click on the existing capture prompt after asynchronous readiness.
 gameAudio.unlock();
 $('mainmenu').classList.remove('hidden');$('loadstatus').textContent=lastInputType==='touch'?'첫 훈련 파일 준비 중 · 준비가 끝나면 시작합니다. 메뉴로 취소할 수 있어요.':'첫 훈련 파일 준비 중 · 완료 후 화면을 클릭해 마우스를 고정해 주세요. Esc 또는 메뉴로 취소할 수 있어요.';
 ensureGameplayAssets().then(()=>{
  if(!pendingStart||pendingStart.intent!==intent||graphicsLost||document.hidden||state==='error')return;
  const choice=pendingStart;pendingStart=null;
  beginReady(choice.practice,choice.combo,choice.duelRequested,false);
 },()=>{}); // ensureGameplayAssets owns the visible fatal error and reload path.
}
function beginReady(practice=false,combo=false,duelRequested=false,gesture=true){if(!loaded||graphicsLost)return;closeDuel();duelMode=duelRequested;setDuelWorld(duelMode);flashAbility.reset();flashFrameVfx?.reset();challengeFlashAssisted=false;modeRecords.refresh();updateRecordMenu();gameAudio.stopAll();if(gesture)gameAudio.unlock();session.reset(practice||combo||duelMode);comboPractice.reset(combo);irregularPractice=!!(practice&&!combo&&!duelMode&&$('irregularpractice').checked);resetSkills();health=100;damageFlash=0;turretArena?.reset();setDamageFlashUI(0);setThreatUI(false);player.set(0,1.7,7);yaw=0;pitch=0;velocityY=0;grounded=true;shotCooldown=0;punchCooldown=0;hook=null;for(const p of projectileParts)p.visible=true;fist.visible=rope.visible=false;oneShot=0;clipName='Idle';clipTime=0;resetTargets();for(const s of sparks){releaseSpark(s);}sparks.length=0;$('results').classList.add('hidden');setHitNoticeUI('');noticeTime=0;if(duelMode)setupDuel();setState('running');syncCamera();if(gesture)requestLock();audio(200,480,.1);updateHud();voiceSchedule.begin();if(muted)voiceSchedule.pause();}
function pause(){cancelPendingStart();if(state!=='running')return;setState('paused');$('overlay').querySelector('h1').innerHTML='TAKE A<br><span>BREATHER.</span>';$('intro').innerHTML='잠깐 쉬어도 괜찮아요.<br>시간과 표적은 그대로 기다립니다.';$('start').innerHTML='계속하기 <span>▶</span>';$('practice').textContent='새로 시작';}
function resume(){if(state!=='paused'||graphicsLost)return;if(duelPull&& !duelPull.plan.ok){begin(session.practice,comboPractice.enabled,duelMode);return;}gameAudio.unlock();setState('running');requestLock();}
function startOrResume(){if(state==='paused')resume();else if(state==='results')begin(session.practice,comboPractice.enabled,duelMode);else begin(false);}
function finish(defeated=false){if(duelMode){finishDuel();return;}flashAbility.reset();flashFrameVfx?.reset();if(!defeated){resultTone=null;resultTurretImpactActive=false;}resetSkills();cancelHook();deathVoiceActive=Boolean(defeated&&DEATH_VOICE_EVENT);setState('results');if(defeated&&DEATH_VOICE_EVENT){gameAudio.setPaused(false,{tonePaused:true,preserveTone:resultTone});voiceSchedule.defeat();}else voiceSchedule.stop();turretArena?.reset();setThreatUI(false);if(!comboPractice.enabled)modeRecords.recordChallenge({...session,flashAssisted:challengeFlashAssisted});updateRecordMenu();$('overlay').querySelector('h1').innerHTML='NICE<br><span>CONNECTION.</span>';$('intro').textContent=defeated?'포탑 공격으로 기체가 정지했습니다. 붉은 경고선이 보이면 이동하거나 엄폐하세요.':'훈련 완료. 다음 한 발은 더 정확하게.';if(!comboPractice.enabled&&challengeFlashAssisted)$('intro').textContent+=' 점멸 사용 기록은 별도로 구분합니다.';if(defeated)$('overlay').querySelector('h1').innerHTML='SYSTEM<br><span>OFFLINE.</span>';$('results').innerHTML=`<div><b>${session.score}</b><small>SCORE</small></div><div><b>${session.catches}</b><small>CAPTURES</small></div><div><b>${session.accuracy}%</b><small>ACCURACY</small></div><div><b>${session.bestCombo}×</b><small>BEST COMBO</small></div>`;$('results').classList.remove('hidden');$('start').innerHTML='다시 도전 <span>▶</span>';$('practice').textContent='자유 연습';}
function returnToMenu(){
 cancelPendingStart();
 closeDuel();duelMode=false;irregularPractice=false;irregularTargets.reset();setDuelWorld(false);
 flashAbility.reset();flashFrameVfx?.reset();challengeFlashAssisted=false;
 modeRecords.refresh();updateRecordMenu();comboPractice.reset();resetSkills(); voiceSchedule.stop(); turretArena?.reset();setThreatUI(false);hook=null;if(fist)fist.visible=false;if(rope)rope.visible=false;if(fullbody)fullbody.visible=false;oneShot=0;clipName='Idle';clipTime=0;resetTargets();setState('menu');$('results').classList.add('hidden');$('overlay').querySelector('h1').innerHTML='LOCK ON.<br><span>PULL IN.</span>';$('intro').innerHTML='수정 마법사 · 중갑 수호자 · 대포 전차를 끌어오세요.<br>포탑의 경고선을 피하면서 90초 동안 포획하세요.';$('start').innerHTML='훈련 시작 <span>▶</span>';$('practice').textContent='자유 연습';
}
function requestLock(){if(lastInputType!=='touch')mouseLook?.request();}
function damagePlayer(amount,turretImpact=false){if(!playing()||duelMode||health<=0)return;health=Math.max(0,health-amount);damageFlash=.28;shake=.16;const samplePlayed=turretImpact&&gameAudio.playEvent('turretImpact'),impact=turretImpact?null:audio(95,40,.16);updateHud();if(health<=0){resultTurretImpactActive=Boolean(samplePlayed);resultTone=impact;session.done=true;finish(true);}}
// These elements remain mounted for the page lifetime. Every writer, including
// restart/results/menu paths, goes through the same cache to avoid stale values.
const statusUI=Object.fromEntries(['crosshair','targetname','threatwarning','hitnotice','damageflash'].map(id=>[id,$(id)]));
const statusLast={};
function setAimUI(target){const aimed=!!target,name=target?.label||'';if(statusLast.aimed!==aimed){statusUI.crosshair.classList.toggle('aimed',aimed);statusLast.aimed=aimed;}if(statusLast.targetName!==name){statusUI.targetname.textContent=name;statusLast.targetName=name;}}
function setThreatUI(warning,text='포탑 조준 중 · 이동하거나 엄폐하세요'){if(statusLast.warningText!==text){statusUI.threatwarning.textContent=text;statusLast.warningText=text;}if(statusLast.warning!==warning){statusUI.threatwarning.classList.toggle('hidden',!warning);statusLast.warning=warning;}}
function setHitNoticeUI(text,force=false){if(force||statusLast.notice!==text){statusUI.hitnotice.textContent=text;statusLast.notice=text;}}
function setDamageFlashUI(opacity){if(statusLast.damageFlash!==opacity){statusUI.damageflash.style.opacity=opacity;statusLast.damageFlash=opacity;}}
// HUD elements are stable for the lifetime of the page. Keep the last displayed
// values so unchanged frames do not recreate text nodes or repeat DOM mutations.
const hud=Object.fromEntries(['hud','scorelabel','timerlabel','caughtlabel','comborecord','health','healthbar','healthblock','score','caught','combo','timer','hookstate','touchhookstate','hookability','touchhook','cooldown',...['W','E','R'].flatMap(key=>['skill'+key,'skillstate'+key])].map(id=>[id,$(id)]));
const hudLast={skills:{W:{},E:{},R:{}}};
function updateHud(){
 if(duelMode&&duel){updateDuelHud();return;}
 if(hudLast.health!==health){hud.health.textContent=String(health);hud.healthbar.style.width=health+'%';hud.healthblock.classList.toggle('critical',health<=36);hudLast.health=health;}
 const mode=comboPractice.enabled,drill=mode?comboPractice.snapshot(session.elapsed):null;
 if(hudLast.drill!==mode){hud.hud.classList.toggle('combo-practice',mode);hud.comborecord.classList.toggle('hidden',!mode);hud.caughtlabel.textContent=mode?'시도':'CAPTURED';hudLast.drill=mode;}
 const scoreLabel=mode?'연계 성공':challengeFlashAssisted?'점멸 사용 점수':'SCORE';if(hudLast.scoreLabel!==scoreLabel){hud.scorelabel.textContent=scoreLabel;hudLast.scoreLabel=scoreLabel;}
 const assisted=mode&&(drill.route?drill.flashAssisted:drill.last?.flashAssisted);
 const timerLabel=mode?(assisted?'점멸 연계':drill.route==='er'?'주먹 연계':drill.route==='qer'?'그랩 연계':'연계 시간'):irregularPractice?'불규칙 자유 연습':'TIME REMAINING';if(hudLast.timerLabel!==timerLabel){hud.timerlabel.textContent=timerLabel;hudLast.timerLabel=timerLabel;}
 const score=mode?drill.successes:session.score,catches=mode?drill.attempts:session.catches;
 if(hudLast.score!==score){hud.score.textContent=String(score).padStart(mode?2:5,'0');hudLast.score=score;}else if(hudLast.scoreMode!==mode)hud.score.textContent=String(score).padStart(mode?2:5,'0');hudLast.scoreMode=mode;
 if(hudLast.catches!==catches){hud.caught.textContent=String(catches).padStart(2,'0');hudLast.catches=catches;}
 const combo=mode?({ready:'Q 또는 E로 시작 · E + 펀치 → R',hook:'Q · 명중 대기',pull:'Q · 회수 중',e:'E 충전 → 펀치',r:'R · 같은 표적에 마무리',success:(drill.route==='er'?'E → R':'Q → E → R')+(assisted?' · 점멸':'')+' 연계 성공! · 다음 시도 준비',failed:'다시 도전 · 다음 시도 준비'}[drill.phase]):session.combo>1?`COMBO ×${Math.min(session.combo,5)} / ${session.combo} IN A ROW`:'READY TO CONNECT';
 const routeName=mode?((drill.route??drill.last?.route)==='er'?'주먹':'그랩')+(assisted?'·점멸':'')+' 연계':'';
 const comboText=mode&&isTouch?({ready:'그랩 또는 강철 주먹으로 시작',hook:'그랩 · 명중 대기',pull:'그랩 · 회수 중',e:'강철 주먹 충전 → 펀치',r:'전기장으로 마무리',success:routeName+' 성공!',failed:drill.last?.reason?.replaceAll('Q','그랩').replaceAll('E','강철 주먹').replaceAll('R','전기장')||'다시 도전'}[drill.phase]):combo;
 if(hudLast.combo!==comboText){hud.combo.textContent=comboText;hudLast.combo=comboText;}
 const remaining=CONFIG.duration-session.elapsed,timer=mode?drill.elapsed.toFixed(2)+'초':session.practice?'∞':formatTime(remaining),urgent=!session.practice&&remaining<15;
 if(hudLast.timer!==timer){hud.timer.textContent=timer;hudLast.timer=timer;}
 if(hudLast.urgent!==urgent){hud.timer.parentElement.classList.toggle('urgent',urgent);hudLast.urgent=urgent;}
 if(mode){
  const selectedRoute=drill.route??drill.last?.route??'qer',personal=modeRecords.snapshot()[(selectedRoute==='er'?'comboER':'combo')+(assisted?'Flash':'')],temporary=personal.best!==null&&!personal.saved;
  const recipe=drill.route?(selectedRoute==='er'?'E + 펀치 → R':'Q → E + 펀치 → R'):'Q → E + 펀치 → R / E + 펀치 → R';
  const result=!drill.active&&drill.last?(drill.last.success?routeName+' 성공 '+drill.last.elapsed.toFixed(2)+'초':'실패 · '+drill.last.reason):recipe;
  const record=isTouch?routeName.replace(' 연계','').replace('·점멸','')+(temporary?' 임시':'')+' '+comboTime(personal.best)+'\n이번 '+comboTime(drill.best):result+'\n'+(temporary?'임시 최단':assisted?'점멸 최단':'개인 최단')+' '+comboTime(personal.best)+' · 이번 연습 '+comboTime(drill.best);
  if(hudLast.record!==record){hud.comborecord.textContent=record;hudLast.record=record;}
 }
 updateHookHud();updateSkillHud();updateFlashHud();
}
function updateHookHud(){
 const blocked=hookBlockReason(),labels={round:['ROUND WAIT','라운드 대기'],inactive:state==='results'?['FINISHED','종료']:['WAITING','대기'],paused:['PAUSED','일시정지'],capture:['CAPTURE MOUSE','화면 고정'],casting:['CASTING','시전 중'],punch:['PUNCHING','펀치 중'],recover:['RECOVERING','손 복구'],combo:comboPractice.active?['COMBO ACTIVE','연계 진행']:['RETRY WAIT','재시도 대기']};
 const text=blocked==='hook'?(hook.phase==='windup'?['WINDUP','발사']:hook.phase==='recover'?['REATTACH','회수']:hook.returning?['RETURNING','복귀']:['IN FLIGHT','비행']):blocked==='cooldown'?[`${shotCooldown.toFixed(1)}s RECHARGING`,shotCooldown.toFixed(1)+'s']:labels[blocked]||['READY','준비'];
 if(hudLast.hookState!==text[0]){hud.hookstate.textContent=text[0];hud.touchhookstate.textContent=text[1];hudLast.hookState=text[0];}
 const ready=blocked===null;if(hudLast.hookReady!==ready){hud.hookability.setAttribute('data-ready',String(ready));hud.touchhook.setAttribute('aria-disabled',String(!ready));hudLast.hookReady=ready;}
 if(hudLast.cooldown!==shotCooldown){hud.cooldown.style.width=`${(1-shotCooldown/CONFIG.cooldown)*100}%`;hudLast.cooldown=shotCooldown;}
}

function updateSkillHud(){if(!skills)return;const st=skills.status;for(const key of ['W','E','R']){
 const label=key==='W'?(st.boost>0?'BOOST '+st.boost.toFixed(1)+'s':st.slow>0?'SLOW '+st.slow.toFixed(1)+'s':''):key==='E'?(st.phase==='E_Hold'?'ARMED '+st.armed.toFixed(1)+'s':st.phase?.startsWith('E_')?'CASTING':''):st.phase==='R_Cast'?'CASTING':'';
 const reason=skillBlockReason(key),blockedLabels={round:['ROUND WAIT','라운드 대기'],inactive:['WAITING','대기'],paused:['PAUSED','일시정지'],capture:['CAPTURE MOUSE','화면 고정'],hook:['HOOK ACTIVE','그랩 중'],punch:['PUNCHING','펀치 중'],casting:['CASTING','시전 중'],comboStart:['E FIRST','주먹 먼저'],comboRetry:['RETRY WAIT','재시도 대기']};
 const unavailable=blockedLabels[reason],readyText=unavailable?unavailable[isTouch?1:0]:st.cooldown[key]>0?st.cooldown[key].toFixed(1)+'s':isTouch?'준비':'READY';
 const last=hudLast.skills[key],button=hud['skill'+key],text=label?(isTouch?label.replace('BOOST ','가속 ').replace('SLOW ','감속 ').replace('ARMED ','강화 ').replace('CASTING','시전'):label):readyText,active=!!label,cooling=!label&&st.cooldown[key]>0,disabled=reason!==null;
 if(last.text!==text){hud['skillstate'+key].textContent=text;last.text=text;}
 if(last.active!==active){button.classList.toggle('active',active);last.active=active;}
 if(last.cooling!==cooling){button.classList.toggle('cooling',cooling);last.cooling=cooling;}
 if(last.disabled!==disabled){button.setAttribute('aria-disabled',String(disabled));last.disabled=disabled;}
}}
// Local duel adapter: command source, physical actor movement, match rules and
// model presentation are separate. Replacing the bot is not networking.
function setDuelWorld(enabled){
 document.querySelector('body').classList.toggle('duel-mode',enabled);
 $('sessiontag').innerHTML=enabled?'<i></i> BOT DUEL <span>FIRST TO 3</span>':ordinarySessionTag;
 hud.healthblock.classList.toggle('hidden',enabled);
 $('controlhint').textContent=enabled?'Q / E 펀치 / R 명중 +1 · 5판 3선승 · WASD 이동 · Shift 폭주 · E / 좌클릭 / R · F 점멸':ordinaryControlHint;
 for(const v of turretArena?.visuals.values()||[]){v.root.visible=v.ring.visible=!enabled;v.line.visible=v.flare.visible=false;}
 if(enabled)for(const t of targets){t.active=false;t.captured=false;t.group.visible=false;}
 // Force only changed mode writers to refresh, leaving ordinary frame caching.
 for(const key of Object.keys(hudLast))if(key!=='skills')delete hudLast[key];
}
function closeDuel(){
 if(duel){duel.cancel();duel=null;}skills=soloSkills;duelBotSkills=null;duelBotVfx?.reset();duelBotAudio.reset();duelBrain=null;duelPull=null;duelHumanKnockup=null;duelFinalTime=0;
 duelAvatar?.reset({visible:false});if(duelRope){duelRope.visible=false;duelRope.update(new THREE.Vector3(),new THREE.Vector3(),{phase:'outbound',phaseTime:0,time:0});}
 if(duelMode){cancelHook();for(const s of sparks)releaseSpark(s);sparks.length=0;}
}
function setupDuel(){
 if(!duelBotVfx)duelBotVfx=createSkillVfx(THREE,{scene,viewScene,fullbody:duelAvatar.object,worldHands:duelAvatar.getSkillHands(),rRadius:SKILL_TUNING.rRadius,wDuration:SKILL_TUNING.wDuration,wSlowDuration:SKILL_TUNING.wSlowDuration});
 duel=createDuelSimulation({sessionId:'local-duel-'+(++duelSerial),config:CONFIG,skillClips:duelSkillClips});
 skills=duel.getSkills('human');duelBotSkills=duel.getSkills('bot');
 duelBrain=createDuelBotInputs({seed:0x5b17+duelSerial,tuning:{playerSpeed:CONFIG.playerSpeed,hookSpeed:CONFIG.hookSpeed,maxRange:CONFIG.maxRange,cooldown:CONFIG.cooldown,windup:.25},arena:{min:{x:-23.4,z:-42.5},max:{x:23.4,z:15.5}},obstacles:arenaObstacles().filter(o=>!o.arenaSurface).map(o=>({min:duelVector(o.min),max:duelVector(o.max)}))});
 setDuelWorld(true);resetDuelRound();
}
function resetDuelRound(){
 resetPointers(true);cancelHook();resetSkills();flashAbility.reset();flashFrameVfx?.reset();
 for(const s of sparks)releaseSpark(s);sparks.length=0;
 player.set(0,1.7,7);yaw=0;pitch=0;velocityY=0;grounded=true;shotCooldown=punchCooldown=0;
 duelBot.position.set(0,1.7,-12);duelBot.yaw=Math.PI;duelBot.pitch=0;duelBot.velocity.set(0,0,0);duelBot.knockup=null;
 duelPull=null;duelHumanKnockup=null;duelFinalTime=0;duelBotVfx?.reset();duelBotAudio.reset();duelBrain.reset({seed:`${duel.state.roundId}/${duel.state.phaseNumber}`});duelAvatar.reset({position:[0,0,-12],yaw:Math.PI,visible:true});
 duelRope.visible=false;duelRope.update(new THREE.Vector3(),new THREE.Vector3(),{phase:'outbound',phaseTime:0,time:0});
 duel.prepare();syncCamera();applyAnimation(0);animateFullbody(0,false);setAimUI(null);
}
function syncDuelHook(){
 const previous=hook,h=duel.getHook('human');
 hook=h?{...h,position:new THREE.Vector3().copy(h.position),direction:new THREE.Vector3().copy(h.direction),returning:['return','recover'].includes(h.phase),bodyOrientation:h.bodyOrientation?new THREE.Quaternion().fromArray(h.bodyOrientation):null,orientation:h.orientation?new THREE.Quaternion().fromArray(h.orientation):camera.quaternion.clone()}:null;
 shotCooldown=duel.cooldown('human');
 const detached=hook&&['outbound','return'].includes(hook.phase);
 rope.visible=!!detached;fist.visible=!!detached&&!thirdPerson;
 if(detached){prepareProjectile(false);fist.quaternion.copy(hook.orientation);}
 if(previous&&!hook){oneShot=0;clipName='Idle';clipTime=0;applyAnimation(0);animateFullbody(0,false);}
 for(const p of projectileParts)p.visible=!detached;
}
function updateDuelAvatar(dt,deltaX=0,deltaZ=0){
 const h=duel.getHook('bot'),height=duelBot.position.y-1.7;
 duelAvatar.update(dt,{position:[duelBot.position.x,height,duelBot.position.z],yaw:duelBot.yaw,pitch:duelBot.pitch,skill:duelBotSkills?.animation,locomotion:{deltaX,deltaZ,grounded:height<=0,height,velocityY:duelBot.velocity.y},hook:h?{...h,position:[h.position.x,h.position.y,h.position.z]}:null},{deferWorldMatrices:true,rLocomotion:true,eArmRecovery:!(duelBotSkills?.status.boost||duelBotSkills?.status.slow),rArmRecovery:!(duelBotSkills?.status.armed||duelBotSkills?.status.boost||duelBotSkills?.status.slow)});
 const detached=h&&['outbound','return'].includes(h.phase);duelRope.visible=!!detached;
 if(detached){const sockets=duelAvatar.getSockets();duelRope.update(new THREE.Vector3().fromArray(sockets.cable),new THREE.Vector3().fromArray(sockets.chain),{phase:h.phase,phaseTime:h.phaseTime,time:session.elapsed});}
}
function duelSockets(){
 const dir=camera.getWorldDirection(new THREE.Vector3()),aimed=nearestRay(camera.position,dir,CONFIG.maxRange),origin=handPoint(),toward=camera.position.clone().addScaledVector(dir,aimed.distance).sub(origin);
 const blockedAim=thirdPerson&&toward.dot(dir)<=.05;if(blockedAim)toward.copy(dir);toward.normalize();
 const bot=duelAvatar.getSockets(),botRay=new THREE.Vector3(-Math.sin(duelBot.yaw)*Math.cos(duelBot.pitch),Math.sin(duelBot.pitch),-Math.cos(duelBot.yaw)*Math.cos(duelBot.pitch));
 let botRange=rayBox(duelBot.position,botRay,new THREE.Vector3().copy(DUEL_SHAPE.min).add(player),new THREE.Vector3().copy(DUEL_SHAPE.max).add(player),CONFIG.maxRange)??CONFIG.maxRange;
 for(const o of arenaObstacles()){const d=rayBox(duelBot.position,botRay,o.min,o.max,botRange);if(d!==null)botRange=d;}
 const direction=duelBot.position.clone().addScaledVector(botRay,botRange).sub(new THREE.Vector3().fromArray(bot.homePalm)),botBlockedAim=direction.dot(botRay)<=.05;if(botBlockedAim)direction.copy(botRay);direction.normalize();
 const humanAim=thirdPerson?camera.position.clone().addScaledVector(dir,aimed.distance).sub(player):dir.clone();if(humanAim.dot(dir)<=0)humanAim.set(0,0,0);else humanAim.normalize();
 return {human:{aimDirection:duelVector(humanAim),blockedAim,origin:duelVector(origin),home:duelVector(origin),direction:duelVector(toward),bodyOrientation:fullbodyNodes.get('BC_QLaunch.R').getWorldQuaternion(new THREE.Quaternion()).toArray(),orientation:new THREE.Quaternion().setFromUnitVectors(dir,toward).multiply(camera.quaternion).toArray()},bot:{aimDirection:duelVector(botRay),blockedAim:botBlockedAim,origin:{x:bot.homePalm[0],y:bot.homePalm[1],z:bot.homePalm[2]},home:{x:bot.homePalm[0],y:bot.homePalm[1],z:bot.homePalm[2]},direction,bodyOrientation:bot.homeOrientation}};
}
function duelBotBlocked(x,z){return Math.abs(x)>23.4||z>15.5||z<-42.5||arenaObstacles().some(o=>x>o.min.x-.42&&x<o.max.x+.42&&z>o.min.z-.42&&z<o.max.z+.42&&duelBot.position.y-1.7<o.max.y);}
function startDuelPull(target){
 const winner=target==='bot'?'human':'bot',from=(target==='bot'?duelBot.position:player).clone(),end=(winner==='human'?player:duelBot.position).clone(),away=from.clone().sub(end);away.y=0;
 const stopDistance=Math.min(2.3,away.length());if(stopDistance>0)away.normalize();end.addScaledVector(away,stopDistance);end.y=1.7;
 const h=duel.getHook(winner),plan=planDuelPullPath({from,to:end,obstacles:arenaObstacles(),projectBlockedDestination:true,maxProgressStep:Math.min(1,1.5*.05/h.returnDuration)});
 return {target,from,plan};
}
function applyDuelPull(){
 if(duelPull?.plan.ok){
  const winner=duelPull.target==='bot'?'human':'bot',h=duel.getHook(winner),u=h?.phase==='return'?smooth(Math.min(1,h.phaseTime/h.returnDuration)):1;
  (duelPull.target==='bot'?duelBot.position:player).copy(sampleDuelPullPath(duelPull.plan,u));
 }
}

function advanceDuel(dt){
 // A clock can report the same timestamp twice. Keep a zero-time refresh from
 // dividing displacement by zero and poisoning the opponent's pose velocity.
 if(!Number.isFinite(dt)||dt<=0)return !!locomotion?.moving;
 flashFrameVfx?.update(dt,{firstPerson:!thirdPerson});
 session.elapsed+=dt;const beforeHuman=player.clone(),beforeBot=duelBot.position.clone();let walking=false,humanMotionAdvanced=false;
 if(duel.active){
  flashAbility.step(dt);
  walking=move(dt);humanMotionAdvanced=true;punchCooldown=Math.max(0,punchCooldown-dt);if(dt>0&&punchCooldown<1e-12)punchCooldown=0;
  const ray=player.clone().sub(duelBot.position),range=ray.length();ray.normalize();
  const canSeeOpponent=!arenaObstacles().some(o=>rayBox(duelBot.position,ray,o.min,o.max,range)!==null);
  const command=duelBrain.step({dt,active:true,self:{position:duelVector(duelBot.position),velocity:duelVector(duelBot.velocity),yaw:duelBot.yaw,pitch:duelBot.pitch,cooldown:duel.cooldown('bot'),hookActive:!!duel.getHook('bot'),canCastQ:!duelBot.knockup&&!duelBotSkills.blocksAttack,skills:duelBotSkills.status,canCastE:!duelBotSkills.blockReason('E'),canStrikeE:!duelBot.knockup,canCastR:!duelBotSkills.blockReason('R')},opponent:{position:duelVector(player),velocity:{x:(player.x-beforeHuman.x)/dt,y:velocityY,z:(player.z-beforeHuman.z)/dt}},canSeeOpponent});
  duelBot.yaw=command.yaw;duelBot.pitch=command.pitch;
  if(!duelBot.knockup){const length=Math.max(1,Math.hypot(command.move.x,command.move.z)),x=command.move.x/length*CONFIG.playerSpeed*duelBotSkills.moveMultiplier*dt,z=command.move.z/length*CONFIG.playerSpeed*duelBotSkills.moveMultiplier*dt;if(!duelBotBlocked(duelBot.position.x+x,duelBot.position.z))duelBot.position.x+=x;if(!duelBotBlocked(duelBot.position.x,duelBot.position.z+z))duelBot.position.z+=z;
   if(command.castE&&duelBotSkills.castE())duelBotAudio.castE();
   if(command.strikeE)duelBotSkills.strikeE();
   if(command.castR&&duelBotSkills.castR())duelBotAudio.castR();
   if(command.castQ&&duel.cast('bot'))gameAudio.playEvent('hookWindup',{emitter:'duel-bot'});
  }
  duelBot.velocity.copy(duelBot.position).sub(beforeBot).divideScalar(dt);
 }else if((['roundReset','matchComplete'].includes(duel.state.phase)||duel.tieRemaining>0)&&!duelHumanKnockup&&duelPull?.target!=='human'){
  // Scoring locks new commands and horizontal travel, not an existing jump.
  // E reactions and pulled victims keep their own vertical presentation.
  advancePlayerVertical(dt);humanMotionAdvanced=true;
  locomotion?.advance(dt,{deltaX:0,deltaZ:0,yaw,grounded,height:player.y-1.7,velocityY});
  walkBlend=locomotion?.blend||0;
 }
 syncCamera();applyAnimation(0,walking);animateFullbody(0,walking);updateDuelAvatar(dt,duelBot.position.x-beforeBot.x,duelBot.position.z-beforeBot.z);
 const actor=(playerId,from,to)=>({playerId,shape:DUEL_SHAPE,motion:{type:'linear',from:duelVector(from),to:duelVector(to)}});
 duel.step(dt,{actors:[actor('human',beforeHuman,player),actor('bot',beforeBot,duelBot.position)],obstacles:arenaObstacles().map((o,i)=>({obstacleId:'cover-'+i,min:duelVector(o.min),max:duelVector(o.max)})),sockets:duelSockets()});
 for(const event of duel.drainEvents()){
  if(event.type==='round-started')resetPointers(true);
  if(event.type==='skill-impact')duelSkillEvent(event);
  if(event.type==='grab-started'){duelPull=startDuelPull(event.targetId);if(!duelPull.plan.ok){pause();$('overlay').querySelector('h1').innerHTML='SAFE<br><span>RESTART.</span>';$('intro').textContent='엄폐물 주변 경로를 안전하게 계산하지 못해 대전을 멈췄어요. 이번 그랩 점수는 추가하지 않았어요. 새로 시작하거나 메인 화면으로 돌아갈 수 있어요.';$('start').innerHTML='대전 새로 시작 <span>▶</span>';$('practice').textContent='대전 새로 시작';$('pause').setAttribute('aria-label','대전 새로 시작');}else notice('그랩 · 끌어오는 중');resetPointers(true);}
  if(event.type==='round-scored'){if(event.skill==='Q')applyDuelPull();const won=event.round.winnerId==='human',label=event.skill==='Q'?'그랩':event.skill==='E'?'강철 주먹':'전기장';notice((won?'+1 · ':'BOT +1 · ')+label+' 명중');particles(new THREE.Vector3().copy(event.skill==='Q'?(won?duelBot.position:player):duel.contact.position),won?0x9affdc:0xf3ca65);audio(won?500:180,won?850:100,.15);resetPointers(true);}
  if(event.type==='simultaneous-replay'){notice(isTouch?'동시 명중 · 재시도':'동시 명중 · 득점 없이 같은 라운드 재시도');resetPointers(true);}
  if(event.type==='hook-blocked'&&event.playerId==='human'&&duel.active)notice(isTouch?'막힘 · 득점 없음':'BLOCKED · 득점 없음');
 }
 if(duel.state.phase==='preparing')resetDuelRound();
 syncDuelHook();
 applyDuelPull();
 const humanReaction=!!duelHumanKnockup||duelPull?.target==='human';
 advanceDuelReactions(dt);
 if(humanReaction){
  // Pulls and knockups own position. Observe their vertical motion for the
  // existing leg response, rather than integrating a second jump trajectory.
  grounded=player.y<=1.7;velocityY=grounded?0:(player.y-beforeHuman.y)/dt;
  if(!humanMotionAdvanced){
   locomotion?.advance(dt,{deltaX:0,deltaZ:0,yaw,grounded,height:player.y-1.7,velocityY});
   walkBlend=locomotion?.blend||0;
  }
 }
 skillAudio.update(skills.status);duelBotAudio.update(duelBotSkills.status);
 syncCamera();
 // Live frames receive their final human pose in advanceFrame, before hook
 // visuals, VFX and rendering. Keep it here when pause/results skip that pass.
 if(!playing()||duel.resultReady)animateFullbody(0,walking);
 updateDuelAvatar(0);
 duelBotVfx?.update(dt,{status:duelBotSkills.status,position:duelBot.position,yaw:duelBot.yaw,moving:duelBot.velocity.lengthSq()>0,thirdPerson:true});
 const aimResult=nearestRay(camera.position,camera.getWorldDirection(new THREE.Vector3()),CONFIG.maxRange);setAimUI(duel.active?aimResult.target:null);
 if(duel.resultReady)finishDuel();
 return walking;
}
// Presentation consumes only validated authority results. It never awards points.
function duelSkillEvent(event){
 const human=event.playerId==='human',vfx=human?skillVfx:duelBotVfx,sound=human?skillAudio:duelBotAudio;
 const target=human?duelBot.position:player,position=event.position?new THREE.Vector3().copy(event.position):target;
 if(event.skill==='E'){
  if(human)shake=.15;
  vfx?.event('power_fist_hit',event.hit?{position,frameOffset:event.offset}:{});
  if(event.hit){
   if(human)skillMetrics.powerHits++;
   const reaction={time:-event.offset,originY:target.y};
   if(human)duelBot.knockup=reaction;else duelHumanKnockup=reaction;
   sound.hitE();
  }else if(human){notice(isTouch?'강철 주먹 · 빗나감':'POWER FIST · MISS');audio(220,65,.15);}
 }
 if(event.skill==='R'){
  if(human){skillMetrics.discharges++;shake=.2;}
  vfx?.event('static_field_discharge',{position:event.origin|| (human?player:duelBot.position),frameOffset:event.offset});
  if(event.hit){if(human)skillMetrics.pulseHits++;vfx?.event('static_field_target',{position,frameOffset:event.offset});}
  sound.dischargeR();
 }
}
function advanceDuelReactions(dt){
 for(const id of DUEL_PLAYERS){const k=id==='human'?duelHumanKnockup:duelBot.knockup;if(!k)continue;k.time+=dt;const u=Math.min(1,Math.max(0,k.time)/SKILL_TUNING.eKnockupDuration),position=id==='human'?player:duelBot.position;position.y=k.originY+(1.7-k.originY)*smooth(u)+Math.sin(u*Math.PI)*SKILL_TUNING.eKnockupHeight;
  if(u>=1){position.y=1.7;if(id==='human'){duelHumanKnockup=null;velocityY=0;grounded=true;}else duelBot.knockup=null;}
 }
}
function updateDuelHud(){
 const m=duel.state,human=m.scores[0].points,bot=m.scores[1].points;
 const phase=duel.pendingGrab?'그랩 · 끌어오는 중':duel.tieRemaining>0?'동시 명중 · 같은 라운드 재시도':m.phase==='countdown'?'준비 '+Math.ceil(m.remainingMs/1000):m.phase==='roundReset'?'다음 라운드까지 '+Math.ceil(m.remainingMs/1000)+'초':m.phase==='matchComplete'?(m.winnerId==='human'?'승리!':'봇 승리'): 'Q / E 펀치 / R 명중 +1 · 먼저 3점';
 const touchPhase=duel.pendingGrab?'그랩 · 끌어오는 중':duel.tieRemaining>0?'동시 명중\n같은 판 재시도':m.phase==='countdown'?'준비 '+Math.ceil(m.remainingMs/1000)+'\n스킬 명중 +1':m.phase==='roundReset'?'다음 판까지 '+Math.ceil(m.remainingMs/1000)+'초\n스킬 명중 +1':m.phase==='matchComplete'?(m.winnerId==='human'?'승리!':'봇 승리')+'\n'+human+' : '+bot:'스킬 명중 +1\n먼저 3점';
 const values={scorelabel:'나 : BOT',score:human+' : '+bot,timerlabel:isTouch?'3선승':'5판 3선승',timer:isTouch?m.roundNumber+'/5':'ROUND '+m.roundNumber,caughtlabel:'승리까지',caught:String(3-human),combo:phase,comborecord:isTouch?touchPhase:'Q / E 펀치 / R 명중 +1 · 기본 펀치 / 폭주 / 점멸은 득점 없음'};
 for(const [key,value]of Object.entries(values))if(hudLast[key]!==value){hud[key].textContent=value;hudLast[key]=value;}
 if(!hudLast.duel){hud.healthblock.classList.add('hidden');hud.comborecord.classList.remove('hidden');hud.hud.classList.remove('combo-practice');hud.timer.parentElement.classList.remove('urgent');hudLast.duel=true;}
 updateHookHud();updateSkillHud();updateFlashHud();
}
function finishDuel(){
 if(!duelMode||!duel||state==='results')return;
 const m=duel.state,won=m.winnerId==='human';resetSkills();duelBotVfx?.reset();duelBotAudio.reset();flashAbility.reset();flashFrameVfx?.reset();duel.cancel();cancelHook();duelRope.visible=false;duelAvatar.update(0,{position:[duelBot.position.x,duelBot.position.y-1.7,duelBot.position.z],yaw:duelBot.yaw,hook:null});
 voiceSchedule.stop();setState('results');$('overlay').querySelector('h1').innerHTML=won?'DUEL<br><span>VICTORY.</span>':'NEXT<br><span>ROUND?</span>';
 $('intro').textContent='봇 1대1 · '+m.scores[0].points+' : '+m.scores[1].points+' · '+(isTouch?'그랩 · 강철 주먹 · 전기장 명중 득점':'Q / E 펀치 / R 명중 득점')+' · 개인 훈련 기록에는 저장하지 않아요.';
 $('results').innerHTML=`<div><b>${m.scores[0].points}</b><small>나</small></div><div><b>${m.scores[1].points}</b><small>BOT</small></div><div><b>${m.history.length}</b><small>ROUNDS</small></div>`;
 $('results').classList.remove('hidden');$('start').innerHTML='다시 대전 <span>▶</span>';$('practice').textContent='자유 연습';updateHud();
}

function collides(x,z){if(Math.abs(x)>23.4||z>15.5||z<-42.5)return true;return arenaObstacles().some(o=>x>o.min.x-.42&&x<o.max.x+.42&&z>o.min.z-.42&&z<o.max.z+.42&&player.y-1.7<o.max.y);}
function advancePlayerVertical(dt){velocityY-=20*dt;player.y+=velocityY*dt;if(player.y<=1.7){player.y=1.7;velocityY=0;grounded=true;}}
function move(dt){if(joystickPointer!==null&&!hasStickContact())resetStick();const beforeX=player.x,beforeZ=player.z;let dx=(keys.has('KeyD')?1:0)-(keys.has('KeyA')?1:0)+joystick.x,dz=(keys.has('KeyS')?1:0)-(keys.has('KeyW')?1:0)+joystick.y;const len=Math.hypot(dx,dz);if(len>1){dx/=len;dz/=len;}const speed=CONFIG.playerSpeed*(skills?.moveMultiplier||1);const x=(dx*Math.cos(yaw)+dz*Math.sin(yaw))*dt*speed,z=(-dx*Math.sin(yaw)+dz*Math.cos(yaw))*dt*speed;if(!collides(player.x+x,player.z))player.x+=x;if(!collides(player.x,player.z+z))player.z+=z;advancePlayerVertical(dt);locomotion?.advance(dt,{deltaX:player.x-beforeX,deltaZ:player.z-beforeZ,yaw,grounded,height:player.y-1.7,velocityY});walkBlend=locomotion?.blend||0;return !!locomotion?.moving;}
function jump(){if(playing()&&duelGameplay()&&grounded){velocityY=7;grounded=false;}}
function tick(){
 requestAnimationFrame(tick);if(!renderer)return;const elapsed=clock.getDelta();if(state==='loading'||state==='error')return;
 // Only an already-scored hold catches up to real running time. Live combat,
 // pending pulls, countdowns and solo physics retain their original 50ms cap.
 // Run presentation with every authority step so E finishes before the reset.
 // Cap foreground stalls at 500ms (ten steps); discard excess, never bank debt
 // across pause/capture loss. Stop at the boundary, before next-round gameplay.
 const holdPhase=playing()&&duelMode&&['roundReset','matchComplete'].includes(duel.state.phase)?duel.state.phase:null;
 const dt=Math.min(elapsed,holdPhase ? .5 : .05),steps=holdPhase&&dt>0?Math.ceil(dt/.05):1;
 for(let i=0;i<steps;i++){
  advanceFrame(dt/steps);
  if(holdPhase&&(!playing()||duel.state.phase!==holdPhase))break;
 }
 renderer.clear();if(state==='menu'&&showcase){showcase.rotation.y+=dt*.35;renderer.render(showcaseScene,showcaseCamera);}else{renderer.render(scene,camera);renderer.clearDepth();if(viewmodel&&!thirdPerson)renderer.render(viewScene,viewCamera);}
}
function advanceFrame(dt){let walking=false,turretPlayerStart;
 if(playing()&&duelMode){walking=advanceDuel(dt);}
 if(playing()&&!duelMode){session.tick(dt);if(session.done){finish();}else{if(comboPractice.enabled&&comboPractice.step(session.elapsed)){cancelHook();resetSkills();resetTargets();shotCooldown=punchCooldown=0;comboPractice.ready();}stepSoloSkills(dt);flashAbility.step(dt);flashFrameVfx?.update(dt,{firstPerson:!thirdPerson});if(skills)skillAudio.update(skills.status);if(!comboPractice.enabled)turretPlayerStart=player.clone();walking=move(dt);syncCamera();shotCooldown=Math.max(0,shotCooldown-dt);if(shotCooldown<1e-12)shotCooldown=0;punchCooldown=Math.max(0,punchCooldown-dt);if(dt>0&&punchCooldown<1e-12)punchCooldown=0;for(const t of targets){if(t.captured)continue;if(t.knockup){t.knockup.time+=dt;const u=Math.min(1,t.knockup.time/SKILL_TUNING.eKnockupDuration);t.group.position.copy(t.knockup.origin);t.group.position.y+=Math.sin(u*Math.PI)*SKILL_TUNING.eKnockupHeight;if(u>=1){t.knockup=null;t.group.visible=!!t.comboHold;}continue;}if(!t.active){if(session.elapsed>=t.respawn){t.active=true;t.group.visible=true;irregularTargets.resetTarget(t);}else continue;}if(t.comboHold){t.group.position.copy(t.comboHold);t.ring.rotation.z+=dt*.8;continue;}t.group.position.copy(t.anchor);if(irregularPractice)t.group.position.x=irregularTargets.step(t,targets.indexOf(t),dt,obstacles);else t.group.position.x+=Math.sin(session.elapsed*t.speed+t.phase)*t.amplitude;t.group.position.y+=Math.sin(session.elapsed*1.3+t.phase)*.23;if(t.character){t.ring.rotation.z+=dt*.8;}else{t.ring.rotation.z+=dt*.8;t.ring.rotation.y=Math.sin(session.elapsed*.5+t.phase)*.35;}}
 const aim=nearestRay(camera.position,camera.getWorldDirection(new THREE.Vector3()),CONFIG.maxRange);setAimUI(aim.target);}}
 if(state==='menu'||state==='loading'){camera.position.set(0,1.7,7);camera.rotation.set(-.015,Math.sin(performance.now()*.00012)*.055,0);for(const t of targets)t.ring.rotation.z+=dt*.3;}
 // Freeze the first-person impact offset with gameplay, including zero-time refreshes.
 if(viewmodel&&playing()&&dt>0){viewmodel.position.x=shake?Math.sin(performance.now()*.07)*shake*.1:0;viewmodel.position.y=-.13;viewmodel.position.z=.18;}
 // Preserve the hidden idle phase while its viewmodel asset is deferred.
 if(state==='menu'&&!viewmodel)clipTime+=dt;
 if(playing()||state==='menu'){applyAnimation(dt,walking);applyHeldFistWalkPresentation(dt);}if(playing()){animateFullbody(dt,walking);if(duelMode){if(hook&&['outbound','return'].includes(hook.phase))syncHookVisuals();}else advanceHook(dt);skillVfx?.update(dt,{status:skills.status,position:player,yaw,moving:walking,thirdPerson});if(!duelMode&&!comboPractice.enabled)turretArena?.step(dt,player,health>0,turretPlayerStart);voiceSchedule.step(dt);updateHud();}const threatActive=playing()&&health>0&&!duelMode&&!comboPractice.enabled,threatText=turretDirectionText(turretDirectionWarnings(turretArena?.sim,camera,player,{active:threatActive}));setThreatUI(threatActive&&(!!turretArena?.warning||!!threatText),threatText||undefined);for(let i=sparks.length-1;i>=0;i--){const s=sparks[i];if(playing()){s.life-=dt;s.velocity.y-=9*dt;s.mesh.position.addScaledVector(s.velocity,dt);s.mesh.scale.setScalar(Math.max(.01,s.life/.65));}if(s.life<=0){releaseSpark(s);sparks.splice(i,1);}}
 if(playing()){noticeTime=Math.max(0,noticeTime-dt);if(noticeTime===0)setHitNoticeUI('');shake=Math.max(0,shake-dt);}damageFlash=Math.max(0,damageFlash-dt);setDamageFlashUI(damageFlash);
 if(deathVoiceActive&&!gameAudio.isGroupPlaying('voice')){deathVoiceActive=false;updateCaptureUI();}
 if(resultTurretImpactActive&&!gameAudio.isGroupPlaying('turret-impact')){resultTurretImpactActive=false;updateCaptureUI();}
}
function resize(){if(!renderer||!Number.isFinite(innerWidth)||!Number.isFinite(innerHeight)||innerWidth<=0||innerHeight<=0)return;if(innerWidth!==inputViewportWidth||innerHeight!==inputViewportHeight){resetTouchPointers();inputViewportWidth=innerWidth;inputViewportHeight=innerHeight;}renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;syncCameraProjection();viewCamera.aspect=camera.aspect;viewCamera.fov=camera.aspect<1?72:54;viewCamera.updateProjectionMatrix();if(showcaseCamera){showcaseCamera.aspect=camera.aspect;showcaseCamera.fov=camera.aspect<1?44:40;showcaseCamera.position.set(0,1.6,camera.aspect<1?8.5:7.2);showcaseCamera.lookAt(0,1.35,0);showcaseCamera.updateProjectionMatrix();showcase.position.set(camera.aspect<1?0:2.0,camera.aspect<1?1.6:0,0);showcase.scale.setScalar(camera.aspect<1?.9:1);}}
function aim(dx,dy){yaw-=dx*.0021*sensitivity;pitch=clampViewPitch(pitch-dy*.0021*sensitivity);if(camera)syncCamera();}
// Native Enter autorepeat must not bypass edge-triggered gameplay controls.
const actionBindings=new Map([['touchhook',fireHook],['touchpunch',punch],['touchjump',jump],['skillW',castW],['skillE',castE],['skillR',castR],['flashbutton',castFlash]]);
// Native Enter activates a focused button on keydown. Treat holding it as one
// discrete command for camera/pause/sound toggles, without replacing
// the first native activation, Space keyup, pointer or assistive clicks.
const singleActivationButtons=new Set([...actionBindings.keys(),'pause','viewtoggle','sound','startupretry']);
$('start').onclick=startOrResume;$('practice').onclick=()=>begin(state==='paused'?session.practice:true,state==='paused'&&comboPractice.enabled,state==='paused'&&duelMode);$('duelmode').onclick=()=>begin(true,false,true);$('combopractice').onclick=()=>begin(true,true);$('pause').onclick=()=>state==='running'?pause():startOrResume();
$('capturestart').onclick=$('mousecapture').onclick=()=>{gameAudio.unlock();lastInputType='mouse';updateCaptureUI();mouseLook.request();};$('mainmenu').onclick=returnToMenu;$('viewtoggle').onclick=toggleView;document.querySelector('.brand').onclick=e=>{e.preventDefault();pause();};$('sensitivity').oninput=e=>sensitivity=Number(e.target.value);$('sound').onclick=()=>{muted=!muted;gameAudio.setMuted(muted);if(muted)voiceSchedule.pause();else{gameAudio.unlock();if(playing())voiceSchedule.resume();}$('sound').textContent=muted?'SOUND OFF':'SOUND ON';$('sound').setAttribute('aria-pressed',String(muted));};
addEventListener('resize',resize);addEventListener('keydown',e=>{const tag=(e.target?.tagName||'').toLowerCase();if(['input','select','textarea'].includes(tag)||e.target?.isContentEditable)return;if((tag==='button'||tag==='a')&&['Enter','Space'].includes(e.code)){if(e.code==='Enter'&&e.repeat&&singleActivationButtons.has(e.target?.id))e.preventDefault();return;}if(e.repeat)return;if(e.code==='Escape'){if(pendingStart){e.preventDefault();cancelPendingStart();}if(state==='running'){e.preventDefault();pause();}return;}if(e.code==='Enter'){e.preventDefault();if(state==='paused'||state==='menu'||state==='results')startOrResume();return;}if(e.code==='KeyR'&&state==='results'){e.preventDefault();begin(session.practice,comboPractice.enabled,duelMode);return;}if(!playing())return;if(e.code==='KeyV'){toggleView();return;}if(e.code==='KeyM'){$('sound').click();return;}if(isMovementKey(e.code)){keys.add(e.code);return;}if(!duelGameplay())return;if(e.code==='Space')e.preventDefault();keys.add(e.code);if(e.code==='KeyQ')fireHook();if(e.code==='KeyF')castFlash();if(e.code==='Space')jump();if(e.code==='ShiftLeft'||e.code==='ShiftRight')castW();if(e.code==='KeyE')castE();if(e.code==='KeyR')castR();});addEventListener('keyup',e=>keys.delete(e.code));
// A graphics interruption also stops the result-screen voice/impact tail.
// Restore enables explicit resume, never replays a discarded sound.
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();if(state==='error')return;graphicsLost=true;interruptPlayback();$('duelmode').disabled=$('start').disabled=$('practice').disabled=$('combopractice').disabled=true;$('loadstatus').textContent='그래픽 연결 복구 대기 중 · 게임을 일시정지했어요.';if(state==='paused'&&!(duelPull&&!duelPull.plan.ok))$('intro').textContent='그래픽 연결이 끊겨 게임을 멈췄습니다. 복구 후 계속할 수 있어요.';});
canvas.addEventListener('webglcontextrestored',()=>{if(state==='error')return;graphicsLost=false;if(menuReady){$('duelmode').disabled=$('start').disabled=$('practice').disabled=$('combopractice').disabled=false;const restartDuel=!!(duelPull&&!duelPull.plan.ok);$('loadstatus').textContent=restartDuel?'그래픽 연결 복구 완료 · 대전 새로 시작을 눌러 주세요.':'그래픽 연결 복구 완료 · 계속하기를 눌러 주세요.';if(state==='paused'&&!restartDuel)$('intro').textContent='화면이 복구됐어요. 계속하기를 누르면 훈련을 재개합니다.';}});
// A result-screen voice may survive pointer-lock release, never a real app interruption.
function interruptPlayback(){resultTone=null;deathVoiceActive=false;resultTurretImpactActive=false;pause();gameAudio.setPaused(true);voiceSchedule.pause();}
document.querySelector('a[href="online.html"]')?.addEventListener?.('click',cancelPendingStart);
addEventListener('pagehide',cancelPendingStart);
addEventListener('blur',interruptPlayback);document.addEventListener('visibilitychange',()=>{if(document.hidden)interruptPlayback();});
document.addEventListener('pointerdown',e=>{if(e.pointerType){lastInputType=e.pointerType;if(e.pointerType==='touch')enableTouch();updateCaptureUI();}},true);
mouseLook=createMouseLook({canvas,doc:document,isRunning:()=>state==='running',onLook:aim,onPunch:punch,onLockLost:pause,onMouseActivity:()=>{lastInputType='mouse';updateCaptureUI();},onMode:updateCaptureUI,onFallback:reason=>{$('capturemessage').textContent=reason==='unsupported'?'이 브라우저는 마우스 고정을 지원하지 않아요. 데스크톱 Chrome 또는 Edge에서 열어 주세요.':'마우스 고정이 허용되지 않았어요. 브라우저에서 사이트를 직접 연 뒤 다시 클릭해 주세요.';updateCaptureUI();}});
canvas.addEventListener('pointerdown',e=>{if(state!=='running'||e.pointerType!=='touch')return;lastInputType='touch';enableTouch();updateCaptureUI();$('mousecapture').classList.add('hidden');if(e.clientX<=innerWidth*.35)return;if(dragPointer!==null){if(hasLookContact())return;resetLook();}try{canvas.setPointerCapture(e.pointerId);}catch{return;}if(!canvas.hasPointerCapture(e.pointerId))return;dragPointer=e.pointerId;lastPointer={x:e.clientX,y:e.clientY};});
canvas.addEventListener('pointermove',e=>{if(e.pointerType==='touch'&&state==='running'&&e.pointerId===dragPointer&&lastPointer){if(!playing()||!hasLookContact()){resetLook();return;}aim(e.clientX-lastPointer.x,e.clientY-lastPointer.y);lastPointer={x:e.clientX,y:e.clientY};}});
function stopDrag(e){if(e.pointerId!==dragPointer)return;resetLook();}
canvas.addEventListener('pointerup',stopDrag);canvas.addEventListener('pointercancel',stopDrag);canvas.addEventListener('lostpointercapture',stopDrag);canvas.addEventListener('contextmenu',e=>e.preventDefault());
const stick=$('joystick');stick.onpointerdown=e=>{if(!playing()||(e.button!==undefined&&e.button!==0))return;if(joystickPointer!==null){if(hasStickContact())return;resetStick();}if(e.pointerType==='touch')enableTouch();try{stick.setPointerCapture(e.pointerId);}catch{return;}if(!stick.hasPointerCapture(e.pointerId))return;joystickPointer=e.pointerId;updateStick(e);};stick.onpointermove=e=>{if(e.pointerId!==joystickPointer)return;if(!playing()||!hasStickContact()){resetStick();return;}updateStick(e);};
function updateStick(e){const r=stick.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,len=Math.hypot(dx,dy),scale=len>38?38/len:1;joystick.x=dx*scale/38;joystick.y=dy*scale/38;const thumbRadius=Math.min(38,Math.max(0,(Math.min(r.width,r.height)-42)/2-2));stick.firstElementChild.style.transform=`translate(${joystick.x*thumbRadius}px,${joystick.y*thumbRadius}px)`;}
const releaseStick=e=>{if(e.pointerId===joystickPointer)resetStick();};stick.onpointerup=releaseStick;stick.onpointercancel=releaseStick;stick.onlostpointercapture=releaseStick;
for(const [id,action] of actionBindings){const button=$(id);button.onpointerdown=e=>{if(e.button!==undefined&&e.button!==0)return;e.preventDefault();if(e.pointerType==='touch')enableTouch();action();};button.onclick=e=>{if(e.detail===0)action();};}
// Observable state for QA; no network, remote analytics, or privileged browser access.
window.__HOOK_ARENA__={get irregularPractice(){return irregularPractice;},get duel(){return duelMode&&duel?{match:duel.state,active:duel.active,pendingGrab:duel.pendingGrab,resultReady:duel.resultReady,tieRemaining:duel.tieRemaining,humanKnockup:duelHumanKnockup?.time??null,bot:{skills:duelBotSkills?.status,vfx:duelBotVfx?.inspect(),position:duelBot.position.toArray(),yaw:duelBot.yaw,pitch:duelBot.pitch,knockup:duelBot.knockup?.time??null,hook:duel.getHook('bot'),cooldown:duel.cooldown('bot')},avatar:duelAvatar.inspect(),ropeVisible:duelRope.visible}:null},get flashFrames(){return flashFrameVfx?.inspect()||null},get flashAbility(){return {...flashAbility.status,audio:gameAudio.status.ready.includes('flashCast')?'recorded-ready':'recorded-not-ready'}},get records(){return modeRecords.snapshot()},get comboPractice(){return comboPractice.snapshot(session.elapsed)},get skills(){return skills?{...skills.status,moveMultiplier:skills.moveMultiplier,attackMultiplier:skills.attackMultiplier,metrics:{...skillMetrics},effects:skillVfx?.inspect().fieldVisible?1:0,vfx:skillVfx?.inspect()}:null},get targets(){return targets.map(t=>({active:t.active,captured:t.captured,knockup:t.knockup?.time??null,comboHold:!!t.comboHold,visible:t.group.visible,position:t.group.position.toArray()}));},get voice(){return voiceSchedule.status},get audio(){return gameAudio.status},get state(){return state},get session(){return{...session,accuracy:session.accuracy}},get health(){return health},get turrets(){return turretArena?{count:turretArena.sim.turrets.length,warning:turretArena.warning,bullets:turretArena.sim.bullets.length}:null},get assets(){return{targetTypes:targetTypes.slice(),targetCount:targets.filter(t=>t.character).length,parts:parts.length,clips:Object.keys(clips),fullbodyParts,fullbodyJoints:fullbodyNodes.size}},get view(){return thirdPerson?'third':'first'},get mouseMode(){return mouseLook?.mode},get playing(){return playing()},get menuRotation(){return showcase?showcase.rotation.y:0},get motion(){return{walkBlend,locomotion:locomotion?.inspect()||null,shoulderR:fullbodyNodes.get('BC_Pivot_Shoulder.R')?.rotation.x,hipL:fullbodyNodes.get('BC_Pivot_Hip.L')?.rotation.x,qExtension:fullbodyNodes.has('BC_QLaunch.R')?fullbodyNodes.get('BC_QLaunch.R').position.distanceTo(new THREE.Vector3().fromArray(fullbodyNodes.get('BC_QLaunch.R').userData.base)):0}},get hook(){return hook?{phase:hook.phase,returning:hook.returning,hit:hook.hit,travel:hook.travel}:null},get player(){return{x:player.x,y:player.y,z:player.z,yaw,pitch}}};
function failStartup(error){cancelPendingStart();console.error(error);state='error';startupRetry.hidden=false;startupRetry.disabled=false;$('start').textContent='불러오기 실패';$('duelmode').disabled=$('start').disabled=$('practice').disabled=$('combopractice').disabled=true;$('loadstatus').textContent=startupPhase==='graphics'?'3D 화면을 시작하지 못했어요. WebGL 2 지원과 브라우저 그래픽 설정을 확인해 주세요.':startupPhase==='assets'?'게임 파일을 불러오지 못했어요. 연결 상태를 확인한 뒤 새로고침해 주세요.':'모델을 준비하는 중 오류가 발생했어요. 새로고침해도 같으면 알려 주세요.';$('intro').textContent=error.message;}
const withPlayerTextures=entry=>loadPlayerModel(entry).then(async data=>{await loadBlitzTextures(THREE,data,playerTextures);return data;});
function ensureGameplayAssets(){
 if(gameplayPending)return gameplayPending;
 startupPhase='assets';
 gameplayPending=(async()=>{
 const [viewData,characterAssets,turretData,skillData,flashTexture]=await Promise.all([withPlayerTextures(PLAYER_MODELS.viewmodel),loadCharacterTargets(),loadTurretModel(),loadSkillAsset(SKILL_ASSET),loadFlashFrameTexture(THREE,FLASH_FRAMES)]);
 const bodyData=menuBodyData;
 startupPhase='scene';$('loadstatus').textContent='모델과 훈련장을 배치하고 있어요.';
 buildModel(viewData);
 // The showcase rig was constructed first; retain the original scene child
 // order once its first-person projectile is available, without rebuilding it.
 scene.children.splice(scene.children.indexOf(fist),1);scene.children.splice(scene.children.indexOf(fullbody),0,fist);
 flashFrameVfx=createFlashFrameVfx(THREE,{scene,viewScene,texture:flashTexture,manifest:FLASH_FRAMES});
 // loadSkillAsset fully validated this private parsed data. Only geometry names are new here.
 validateSkillSourceParts(skillData,{viewmodel:[...new Set(viewData.parts.map(p=>p.sourcePart||p.name))],fullbody:[...new Set(bodyData.parts.map(p=>p.sourcePart||p.name))]});
 skillClips.viewmodel=Object.fromEntries(bindSkillClips(skillData.models.viewmodel,parts).map(c=>[c.name,c]));skillClips.fullbody=Object.fromEntries(bindSkillClips(skillData.models.fullbody,fullbodySurfaces).map(c=>[c.name,c]));
 duelSkillClips=skillData.models.fullbody.clips;skills=soloSkills=createSkillController(duelSkillClips,{onEvent:skillEvent});
 duelAvatar.configureSkills(skillData.models.fullbody);
 skillVfx=createSkillVfx(THREE,{scene,viewScene,fullbody,worldHands:['L','R'].map(side=>fullbodyMeshes.get('BC_Palm.'+side)),viewHands:[...['L','R'].map(side=>parts.find(p=>p.name==='VM_Palm.'+side)),fist.children[projectileParts.findIndex(p=>p.name==='VM_Palm.R')]],rRadius:SKILL_TUNING.rRadius,wDuration:SKILL_TUNING.wDuration,wSlowDuration:SKILL_TUNING.wSlowDuration});updateSkillHud();
 targetTypes=characterAssets.map(a=>a.id);targets.forEach((t,i)=>{const menuRotation=t.ring.rotation.z;attachCharacterTarget(t,characterAssets[i%characterAssets.length]);t.ring.rotation.z=menuRotation;});
 turretArena=createTurretArena(scene,turretData,obstacles,{onDamage:amount=>damagePlayer(amount,true),onAcquired:()=>gameAudio.playEvent('turretAcquired'),onShot:()=>gameAudio.playEvent('turretShot')});

 loaded=true;menuBodyData=null;
 if(!pendingStart)$('loadstatus').textContent=graphicsLost?'그래픽 연결 복구 대기 중':'준비 완료 · v0.24.87 · 모드를 선택해 주세요.';
 })();
 gameplayPending.catch(failStartup); // Observe all late failures, including canceled starts.
 return gameplayPending;
}
try{
 // Only the unchanged showcase model/artwork are needed before a mode choice.
 const pendingMenu=withPlayerTextures(PLAYER_MODELS.fullbody);
 pendingMenu.catch(()=>{}); // Renderer failure must not hide a late asset rejection.
 initWorld();tick();startupPhase='assets';
 menuBodyData=await pendingMenu;startupPhase='scene';buildFullbody(menuBodyData);
 // Asset attachment used to reset these before the first menu frame.
 for(const target of targets)target.ring.rotation.z=0;
 menuReady=true;state='menu';$('duelmode').disabled=$('start').disabled=$('practice').disabled=$('combopractice').disabled=graphicsLost;
 $('start').innerHTML='훈련 시작 <span>▶</span>';
 $('loadstatus').textContent=graphicsLost?'그래픽 연결 복구 대기 중':'전시 준비 완료 · v0.24.87 · 첫 훈련 선택 시 게임 파일을 불러옵니다.';
}catch(error){failStartup(error);}
