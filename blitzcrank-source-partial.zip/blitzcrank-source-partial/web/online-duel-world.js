// Independent authoritative simulation for two humans. Existing solo/bot code
// remains untouched. The first player is a trusted host, NOT an anti-cheat server.
import {CONFIG,rayBox,thirdPersonCameraPosition} from './core.js';
import {createDuelSimulation,DUEL_SHAPE,DUEL_PLAYERS} from './duel-simulation.js';
import {createFlashController} from './flash-controller.js';
import {SKILL_TUNING} from './skill-controller.js';
import {planDuelPullPath,sampleDuelPullPath} from './duel-pull-path.js';
import {ONLINE_PROTOCOL,ONLINE_ACTIONS as A,validateInput,isSessionId} from './online-duel-protocol.js';
export const ONLINE_DT=1/60;
export const ONLINE_INPUT_STALE_TICKS=18;
const v=(x=0,y=0,z=0)=>({x,y,z}),copy=p=>({...p}),smooth=x=>x*x*(3-2*x);
const normalize=d=>{const n=Math.hypot(d.x,d.y,d.z);return n?{x:d.x/n,y:d.y/n,z:d.z/n}:v();};
const aim=a=>v(-Math.sin(a.yaw)*Math.cos(a.pitch),Math.sin(a.pitch),-Math.cos(a.yaw)*Math.cos(a.pitch));
const subtract=(a,b)=>v(a.x-b.x,a.y-b.y,a.z-b.z);
export function onlineArenaObstacles(){
 const specs=[[0,-.18,-13,52,.3,70],[-26,4.3,-13,1,9,65],[26,4.3,-13,1,9,65],[0,6,-46,52,13,1],[-9,1.4,-8,3,2.8,3],[9,1.6,-14,4,3.2,3],[-6,1.7,-25,3,3.4,3],[16,2,-29,4,4,4],[-18,1.5,-34,5,3,4],[0,3.75,-45.11,9,7,.12]];
 return specs.map(([x,y,z,w,h,d],i)=>({obstacleId:'online-cover-'+i,min:v(x-w/2,y-h/2,z-d/2),max:v(x+w/2,y+h/2,z+d/2),arenaSurface:i<4}));
}
export function createOnlineDuelWorld({session,skillClips,obstacles=onlineArenaObstacles(),socketProvider=null,aimMode='first',countdownMs=1600}={}){
 if(!isSessionId(session))throw new TypeError('Invalid session identity');
 const sim=createDuelSimulation({sessionId:session,config:CONFIG,skillClips,countdownMs,roundResetMs:3000});
 const actors={},pending={},lastSeq={},inputTick={},flash={},ready={human:false,bot:false};
 let tick=0,epoch=0,closed=false,pull=null,fault=null,events=[],serial=0;
 for(const id of DUEL_PLAYERS){actors[id]={position:v(),yaw:0,pitch:0,velocity:v(),grounded:true,knockup:null,punchCooldown:0,punchTime:0,punchDuration:1};flash[id]=createFlashController();lastSeq[id]=-1;}
 const blocked=(a,x,z)=>Math.abs(x)>23.4||z>15.5||z< -42.5||obstacles.some(o=>x>o.min.x-.42&&x<o.max.x+.42&&z>o.min.z-.42&&z<o.max.z+.42&&a.position.y-1.7<o.max.y);
 const active=()=>!closed&&!fault&&ready.human&&ready.bot;
 function emit(type,data={}){events.push({serial:++serial,type,...data});if(events.length>64)events.shift();}
 function resetRound(){
  epoch++;pull=null;
  for(const [i,id] of DUEL_PLAYERS.entries()){
   Object.assign(actors[id],{position:v(0,1.7,i?-12:7),yaw:i?Math.PI:0,pitch:0,velocity:v(),grounded:true,knockup:null,punchCooldown:0,punchTime:0,punchDuration:1});
   pending[id]=null;inputTick[id]=-Infinity;flash[id].reset();
  }
  sim.prepare();emit('round-reset');
 }
 resetRound();sim.drainEvents();
 function sockets(){
  const out={};
  for(const id of DUEL_PLAYERS){
   const a=actors[id],d=aim(a),other=actors[id==='human'?'bot':'human'],eye=aimMode==='third'?thirdPersonCameraPosition(a.position,a.yaw,a.pitch,obstacles):a.position;
   const supplied=socketProvider?.(id,actorSnapshot(id));
   const origin=supplied?.origin??copy(a.position);
   if(!origin||!Object.values(origin).every(Number.isFinite)||Math.hypot(...Object.values(subtract(origin,a.position)))>4)throw new Error('Invalid authority socket');
   let range=rayBox(eye,d,v(other.position.x+DUEL_SHAPE.min.x,other.position.y+DUEL_SHAPE.min.y,other.position.z+DUEL_SHAPE.min.z),v(other.position.x+DUEL_SHAPE.max.x,other.position.y+DUEL_SHAPE.max.y,other.position.z+DUEL_SHAPE.max.z),CONFIG.maxRange)??CONFIG.maxRange;
   for(const o of obstacles){const hit=rayBox(eye,d,o.min,o.max,range);if(hit!==null)range=hit;}
   const target=v(eye.x+d.x*range,eye.y+d.y*range,eye.z+d.z*range),toward=subtract(target,origin);
   const blockedAim=toward.x*d.x+toward.y*d.y+toward.z*d.z<=.05;
   out[id]={origin:copy(origin),home:copy(origin),direction:normalize(blockedAim?d:toward),aimDirection:normalize(subtract(target,a.position)),blockedAim,...(supplied?.bodyOrientation?{bodyOrientation:supplied.bodyOrientation}: {})};
  }
  return out;
 }
 function actorSnapshot(id){const a=actors[id],skills=sim.getSkills(id);return {...structuredClone(a),skills:skills.status,hook:sim.getHook(id),qCooldown:sim.cooldown(id),flash:flash[id].status};}
 function applyActions(id,command){
  const a=actors[id],s=sim.getSkills(id),mask=command.actions,hook=sim.getHook(id),busy=!!hook||a.punchTime>0;
  if(mask&A.W&&s.castW())emit('cast',{id,skill:'W'});
  if(mask&A.E&&s.castE({busy}))emit('cast',{id,skill:'E'});
  if(mask&A.R&&s.castR({busy}))emit('cast',{id,skill:'R'});
  if(mask&A.Q&&!busy&&sim.cast(id))emit('cast',{id,skill:'Q'});
  if(mask&A.PUNCH&&a.punchCooldown===0&&!sim.getHook(id)&&!s.blocksAttack){
   if(s.status.phase==='E_Hold'){if(s.strikeE()){a.punchCooldown=44/30;a.punchTime=0;emit('cast',{id,skill:'E_Strike'});}}
   else {a.punchDuration=1/s.attackMultiplier;a.punchTime=a.punchDuration;a.punchCooldown=.65/s.attackMultiplier;emit('cast',{id,skill:'PUNCH'});}
  }
  if(mask&A.JUMP&&a.grounded){a.velocity.y=7;a.grounded=false;}
  if(mask&A.FLASH){const result=flash[id].cast({playing:true,position:a.position,yaw:a.yaw,isBlocked:(x,z)=>blocked(a,x,z)});if(result.accepted){const departure=copy(a.position);a.position=result.position;emit('cast',{id,skill:'FLASH',departure});}}
 }
 function vertical(a){a.velocity.y-=20*ONLINE_DT;a.position.y+=a.velocity.y*ONLINE_DT;if(a.position.y<=1.7){a.position.y=1.7;a.velocity.y=0;a.grounded=true;}}
 function applyPull(){if(!pull)return;const h=sim.getHook(pull.winner),u=h?.phase==='return'?smooth(Math.min(1,h.phaseTime/h.returnDuration)):1;actors[pull.target].position=sampleDuelPullPath(pull.plan,u);}
 const api={
  get scope(){return {session,epoch};},
  get status(){return {closed,fault,paused:!active(),ready:{...ready},tick,epoch};},
  submit(id,command){
   if(!DUEL_PLAYERS.includes(id)||!active()||!sim.active||!validateInput(command,{session,epoch})||command.seq<=lastSeq[id])return false;
   // A bounded command accumulator: held directions are latest-wins, actions
   // are edge requests consumed once. Floods cannot advance clock or cooldown.
   lastSeq[id]=command.seq;inputTick[id]=tick;
   pending[id]={...command,actions:(pending[id]?.actions??0)|command.actions};return true;
  },
  setReady(id,value){if(!DUEL_PLAYERS.includes(id)||typeof value!=='boolean'||closed)return false;
   // Repeated consent in the same epoch must not cancel already accepted input
   // or refresh its stale-input clock. A real transition still clears it.
   if(ready[id]===value)return true;
   ready[id]=value;pending[id]=null;inputTick[id]=-Infinity;return true;},
  pause(){const changed=ready.human||ready.bot;if(changed)epoch++;ready.human=ready.bot=false;pending.human=pending.bot=null;if(changed)emit('paused');},
  disconnect(){if(closed)return;closed=true;ready.human=ready.bot=false;pending.human=pending.bot=null;emit('disconnected');},
  restart(){if(closed||sim.state.phase!=='matchComplete'||!sim.resultReady||!active())return false;sim.restart();resetRound();return true;},
  step(){
   if(!active())return false;
   tick++;for(const id of DUEL_PLAYERS){actors[id].punchTime=Math.max(0,actors[id].punchTime-ONLINE_DT);if(actors[id].punchTime<1e-12)actors[id].punchTime=0;}const before=Object.fromEntries(DUEL_PLAYERS.map(id=>[id,copy(actors[id].position)]));
   if(sim.active)for(const id of DUEL_PLAYERS){
    const a=actors[id],s=sim.getSkills(id),command=pending[id];
    for(const field of ['punchCooldown']){a[field]=Math.max(0,a[field]-ONLINE_DT);if(a[field]<1e-12)a[field]=0;}
    flash[id].step(ONLINE_DT);
    if(command&&tick-inputTick[id]<=ONLINE_INPUT_STALE_TICKS){a.yaw=command.yaw;a.pitch=command.pitch;applyActions(id,command);command.actions=0;
     // Flash is instantaneous, not a hittable sweep through all intervening cover.
     before[id]=copy(a.position);
     const n=Math.max(1,Math.hypot(command.x,command.z)),speed=CONFIG.playerSpeed*s.moveMultiplier*ONLINE_DT;
     const dx=(command.x*Math.cos(a.yaw)+command.z*Math.sin(a.yaw))/n*speed,dz=(-command.x*Math.sin(a.yaw)+command.z*Math.cos(a.yaw))/n*speed;
     if(!blocked(a,a.position.x+dx,a.position.z))a.position.x+=dx;if(!blocked(a,a.position.x,a.position.z+dz))a.position.z+=dz;
    }
    vertical(a);
   }else for(const id of DUEL_PLAYERS)if(!actors[id].knockup&&pull?.target!==id)vertical(actors[id]);
   for(const id of DUEL_PLAYERS){actors[id].velocity.x=(actors[id].position.x-before[id].x)/ONLINE_DT;actors[id].velocity.z=(actors[id].position.z-before[id].z)/ONLINE_DT;}
   sim.step(ONLINE_DT,{actors:DUEL_PLAYERS.map(playerId=>({playerId,shape:DUEL_SHAPE,motion:{type:'linear',from:before[playerId],to:copy(actors[playerId].position)}})),obstacles:obstacles.map(({obstacleId,min,max})=>({obstacleId,min,max})),sockets:sockets()});
   for(const event of sim.drainEvents()){
    emit('authority',{event});
    if(event.type==='round-started'){epoch++;pending.human=pending.bot=null;}
    if(event.type==='skill-impact'&&event.skill==='E'&&event.hit){const target=event.playerId==='human'?'bot':'human';actors[target].knockup={time:-event.offset,originY:actors[target].position.y};}
    if(event.type==='grab-started'){
     const from=actors[event.targetId].position,home=actors[event.attackerId].position,d=subtract(from,home);d.y=0;const length=Math.hypot(d.x,d.z),stop=Math.min(2.3,length),n=normalize(d),to=v(home.x+n.x*stop,1.7,home.z+n.z*stop),h=sim.getHook(event.attackerId);
     const plan=planDuelPullPath({from,to,obstacles,projectBlockedDestination:true,maxProgressStep:Math.min(1,1.5*.05/h.returnDuration)});
     if(!plan.ok){fault='pull-path';api.pause();return false;}pull={winner:event.attackerId,target:event.targetId,plan};
    }
    if(event.type==='round-scored'){applyPull();epoch++;pending.human=pending.bot=null;}
   }
   applyPull();
   for(const id of DUEL_PLAYERS){const a=actors[id],k=a.knockup;if(!k)continue;k.time+=ONLINE_DT;const u=Math.min(1,Math.max(0,k.time)/SKILL_TUNING.eKnockupDuration);a.position.y=k.originY+(1.7-k.originY)*smooth(u)+Math.sin(u*Math.PI)*SKILL_TUNING.eKnockupHeight;a.grounded=a.position.y<=1.7;a.velocity.y=a.grounded?0:(a.position.y-before[id].y)/ONLINE_DT;if(u>=1){a.position.y=1.7;a.knockup=null;a.velocity.y=0;a.grounded=true;}}
   if(sim.state.phase==='preparing')resetRound();
   // Cap unsent historical events. State remains authoritative after drops.
   if(events.length>64)events=events.slice(-64);
   return true;
  },
  snapshot(){return {type:'state',protocol:ONLINE_PROTOCOL,session,epoch,tick,paused:!active(),closed,fault,match:sim.state,active:sim.active,resultReady:sim.resultReady,tieRemaining:sim.tieRemaining,pendingGrab:sim.pendingGrab,actors:Object.fromEntries(DUEL_PLAYERS.map(id=>[id,actorSnapshot(id)])),events:structuredClone(events)};},
  drainEvents(){const value=events;events=[];return value;}
 };
 return api;
}
