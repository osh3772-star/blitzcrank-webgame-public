// Independent slow W candidate; original assets are preserved.
export const SKILL_ASSET = Object.freeze({
  "raw": "./assets/skill-animations/skills.403e90667511be4b.json",
  "gzip": "./assets/skill-animations/skills.403e90667511be4b.json.gz",
  "bytes": 4620728,
  "gzipBytes": 299801,
  "sha256": "403e90667511be4b3ed7aa7d09423223059c9b0d200b8104d652f4e06e7498ce"
});
