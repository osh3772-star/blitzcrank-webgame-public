// Conservative alternative: reject every reported component-envelope uncertainty.
import {createSpawnSearchTrial} from './rift-v49-spawn-search-trial.js';
import {classifyContainment} from './rift-v49-containment-audit.js';
// Additional rejection guard, never an approval that all open/self-crossing meshes are safe.
export function createStrictContainmentSpawnTrial(THREE,components,options){
 const inspect=p=>classifyContainment(THREE,components,[p[0],1.05,p[1]]);
 const audit=(a,b)=>{
  const original=options.movementAudit(a,b);if(!original?.pass)return original;
  if(a[0]===b[0]&&a[1]===b[1]){const c=inspect(a);if(c.insideCandidate||c.uncertain.length>0)return {pass:false,reason:c.insideCandidate?'closed-component-containment-candidate':'uncertain-component-envelope'};}
  return original;
 };
 return Object.freeze({...createSpawnSearchTrial({...options,movementAudit:audit}),inspectContainment:inspect});
}
