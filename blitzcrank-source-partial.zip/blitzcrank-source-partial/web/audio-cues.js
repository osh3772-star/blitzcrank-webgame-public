// For the existing private prototype only. Audio ownership remains with Riot.
// Q contact/capture and dialogue are deliberately NOT inferred from this bank.
export const AUDIO_CUES = Object.freeze({
  hookCast: Object.freeze({url: './assets/audio/hook-cast.wav', channel: 'sfx', group: 'hook', gain: 0.65, maxDuration: 1.05}),
  basicAttack: Object.freeze({url: './assets/audio/basic-attack.wav', channel: 'sfx', group: 'punch', gain: 0.65, maxDuration: 0.60}),
});
export const AUDIO_EVENTS = Object.freeze({hookWindup: 'hookCast', punchHit: 'basicAttack'});
// No source is assigned to hookHit, hookMiss, capture, punchMiss, damage,
// start, victory, defeat, or any voice event. Keep existing neutral cues there.

// Historical YouTube gameplay excerpts, not verified isolated/current original SFX.
// Existing owner-private prototype only; see assets/audio/turrets/source-manifest.json.
export const TURRET_AUDIO_CUES=Object.freeze({
 turretTarget:Object.freeze({url:'./assets/audio/turrets/turret-target-single-044.wav',channel:'sfx',group:'turret-target',gain:.8,maxDuration:.44}),
 turretShot:Object.freeze({url:'./assets/audio/turrets/turret-shot.wav',channel:'sfx',group:'turret-shot',gain:.8,maxDuration:.53}),
 turretImpact:Object.freeze({url:'./assets/audio/turrets/turret-hit.wav',channel:'sfx',group:'turret-impact',gain:.8,maxDuration:.56}),
});
export const TURRET_AUDIO_EVENTS=Object.freeze({turretAcquired:'turretTarget',turretShot:'turretShot',turretImpact:'turretImpact'});
