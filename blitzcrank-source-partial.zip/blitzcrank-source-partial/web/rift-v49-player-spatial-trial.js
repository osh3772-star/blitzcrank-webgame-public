import {createSpawnSearchTrial} from './rift-v49-spawn-search-trial.js';
import {classifyContainment} from './rift-v49-containment-audit.js';
import {auditUncertaintyCorridor} from './rift-v49-uncertainty-corridor.js';
// Conservative player-only alternative; hook/target colliders retain their supplied rules.
export function createPlayerSpatialTrial(THREE,components,options){
 const inspect=p=>classifyContainment(THREE,components,[p[0],1.05,p[1]]);
 function spatial(a,b){
  const corridor=auditUncertaintyCorridor(components,{from:a,to:b});if(!corridor.pass)return {pass:false,reason:corridor.reason};
  for(const p of [a,b]){const c=inspect(p);if(c.insideCandidate||c.uncertain.length)return {pass:false,reason:'component-interior-or-uncertainty'};}
  return {pass:true};
 }
 const combine=fn=>(a,b)=>{const original=fn(a,b);return original?.pass?spatial(a,b):original;};
 return Object.freeze({...createSpawnSearchTrial({...options,
  movementAudit:combine(options.movementAudit),pathAudit:combine(options.pathAudit),
  landingAudit:p=>{const r=options.landingAudit(p);return r?.pass?spatial(p,p):r;}
 }),inspectContainment:inspect});
}
