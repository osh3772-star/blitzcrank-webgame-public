// Shared-state diagnostic coordinator. These interaction policies are not live rules.
import {createAuditedMovement} from './rift-v49-audited-movement.js';
import {createAuditedFlash} from './rift-v49-audited-flash.js';
import {createAuditedPullTrial} from './rift-v49-audited-pull.js';
import {FLASH_TUNING} from './flash-controller.js';
export function createIntegratedTrial({spawn,movementAudit,landingAudit,pathAudit,boundaryAudit,bounds,bodyCollider,hookCollider}={}){
 let position=createAuditedMovement({spawn,audit:movementAudit}).snapshot().position;
 const pull=createAuditedPullTrial({body:bodyCollider,hook:hookCollider});
 let remaining=0,casts=0,ticks=0,paused=false,disposed=false;
 const snapshot=()=>({position:position.slice(),flash:{remaining,casts,ready:remaining===0},pull:pull.snapshot(),ticks,paused,disposed,gameplayIntegrated:false});
 const guard=()=>{if(disposed)throw Error('Trial disposed');};
 return Object.freeze({snapshot,pause(){guard();paused=true;pull.cancel();return snapshot();},resume(){guard();paused=false;return snapshot();},dispose(){pull.cancel();disposed=true;paused=true;},
  castPull({aim,targets=[]}={}){guard();if(paused)return {accepted:false,reason:'paused'};return pull.cast({origin:position.slice(),aim,targets});},
  cancelPull(){guard();pull.cancel();return snapshot();},
  flash({aim,policy='clear-path'}={}){
   guard();if(paused)return {accepted:false,reason:'paused'};if(remaining>0)return {accepted:false,reason:'cooldown'};
   // Ephemeral calculation avoids a second stale position or hidden cooldown owner.
   const trial=createAuditedFlash({spawn:position,bounds,landingAudit,pathAudit,boundaryAudit}),result=trial.cast({aim,policy});
   if(!result.accepted)return result;
   pull.cancel();position=result.position.slice();remaining=FLASH_TUNING.cooldown;casts++;
   return {...result,state:snapshot(),interactionPolicy:'accepted-flash-cancels-active-hook'};
  },
  step(input={x:0,z:0},dt){
   guard();if(!Number.isFinite(dt)||dt<0)throw Error('Finite nonnegative dt required');
   if(paused)return {...snapshot(),seconds:0,movementSegments:[],skillSegments:[]};
   const movement=createAuditedMovement({spawn:position,audit:movementAudit}).advance(input,dt),seconds=movement.seconds;
   // Pull's home is the candidate player position from this same simulation step.
   const skill=pull.step(seconds,{home:movement.position});
   position=movement.position.slice();remaining=Math.max(0,remaining-seconds);if(remaining<1e-12)remaining=0;ticks++;
   return {...snapshot(),seconds,movementSegments:movement.segments,skillSegments:skill.segments,movementBlockedBy:movement.blockedBy};
  }
 });
}
