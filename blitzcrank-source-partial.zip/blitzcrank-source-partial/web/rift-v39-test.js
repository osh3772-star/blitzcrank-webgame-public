import {selectMapStudy} from './rift-v39-revisions.js';
import {createStudyLoader,disposeMapScene} from './rift-v39-loader.js';
import {createMapFlashAdapter,FLASH_TRIAL} from './rift-v39-flash.js';
import {createMapPullTrial} from './rift-v39-pull.js';
import {HOOK_TRIAL,createMapHookTrial,createMapHookCollider} from './rift-v39-hook.js';
import {PLANAR_TRIAL,createPlanarTrial} from './rift-v39-planar.js';
import {createPlanarControls} from './rift-v39-planar-ui.js';
import * as THREE from './vendor/three.module.js';import {GLTFLoader} from './vendor/GLTFLoader.js';
import {createMapProbe,inspectMapScene} from './rift-v39-study.js';import {onlineArenaObstacles} from './online-duel-world.js';import {DUEL_SHAPE} from './duel-simulation.js';
const $=id=>document.getElementById(id);let renderer,scene,camera,map,outline,arena,probe,start,trace;let busy=false,loadGeneration=0;
const study=selectMapStudy(document.documentElement?.dataset?.studyRevision??'0.20');
const studyLoader=createStudyLoader({parse:bin=>new GLTFLoader().parseAsync(bin,''),fetchImpl:fetch,cryptoImpl:crypto});
const status=x=>$('status').textContent=x;
function line(points,color,closed=false){const g=new THREE.BufferGeometry().setFromPoints(closed?[...points,points[0]]:points);return new THREE.Line(g,new THREE.LineBasicMaterial({color,depthTest:false,transparent:true,opacity:.7}));}
function render(){if(renderer)renderer.render(scene,camera);}
function release(){clearFlashPreview();flashAdapter=null;for(const id of flashIDs)$(id).disabled=true;cancelHook();hookTrial=null;for(const id of hookIDs)$(id).disabled=true;planarControls?.dispose();planarControls=null;planarTrial=null;for(const id of trialIDs)$(id).disabled=true;disposeMapScene(scene??map);renderer?.dispose();renderer=scene=camera=map=outline=arena=probe=start=trace=null;hookPaint=flashPaint=null;for(const id of ['view','outlines','arena'])$(id).disabled=true;}
function viewpoint(){const name=$('view').value,at=planarTrial?.snapshot().position??[0,0],p=name==='trial'?[at[0]+12,14,at[1]+15]:name==='overview'?[115,135,130]:name==='river'?[19,14,13]:[13,15,25],target=name==='trial'?[at[0],0,at[1]]:name==='overview'?[0,0,0]:name==='river'?[0,-.22,0]:[0,0,-2.5];camera.position.fromArray(p);camera.lookAt(...target);render();}
function cancelLoad(message='진단 로드/표시 취소. 다시 불러올 수 있습니다.'){
 loadGeneration++;studyLoader.cancel();busy=false;release();$('load').disabled=false;$('cancel-load').disabled=true;status(message);
}
$('cancel-load').onclick=()=>cancelLoad();
$('load').onclick=async()=>{if(busy||renderer)return;const token=++loadGeneration;busy=true;$('load').disabled=true;$('cancel-load').disabled=false;status('v'+study.revision+' 원본과 좌표를 불러오는 중…');try{
 const loaded=await studyLoader.load(study);if(token!==loadGeneration||!loaded){if(loaded)disposeMapScene(loaded.gltf.scene);return;}
 const {layout,record,gltf,byteCounts}=loaded;probe=createMapProbe(layout,{study});map=gltf.scene;
 scene=new THREE.Scene();scene.background=new THREE.Color(0x142b30);scene.add(map);camera=new THREE.PerspectiveCamera(58,1,.1,500);renderer=new THREE.WebGLRenderer({canvas:$('map'),antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
 scene.add(new THREE.HemisphereLight(0xd2f3ff,0x343b20,2));const sun=new THREE.DirectionalLight(0xffe8c4,3);sun.position.set(-35,90,35);scene.add(sun);outline=new THREE.Group();scene.add(outline);
 for(const p of [...layout.walls,...layout.baseWalls,...layout.rearBackdropWalls])outline.add(line(p.pointsXZ.map(([x,z])=>new THREE.Vector3(x,p.maxY+.06,z)),0xffdd55,true));
 for(const p of layout.propColliders)outline.add(line(Array.from({length:32},(_,i)=>new THREE.Vector3(p.centerXZ[0]+Math.cos(i/32*Math.PI*2)*p.radius,p.maxY+.06,p.centerXZ[1]+Math.sin(i/32*Math.PI*2)*p.radius)),0xffdd55,true));
 outline.add(line(layout.mapBoundaryXZ.map(([x,z])=>new THREE.Vector3(x,.12,z)),0xffaa66,true));arena=new THREE.Group();scene.add(arena);
 for(const o of onlineArenaObstacles()){const b=new THREE.Box3(new THREE.Vector3(o.min.x,o.min.y,o.min.z),new THREE.Vector3(o.max.x,o.max.y,o.max.z));arena.add(new THREE.Box3Helper(b,0xffffff));}
 for(const [i,z] of [7,-12].entries()){const box=new THREE.Mesh(new THREE.BoxGeometry(DUEL_SHAPE.max.x-DUEL_SHAPE.min.x,DUEL_SHAPE.max.y-DUEL_SHAPE.min.y,DUEL_SHAPE.max.z-DUEL_SHAPE.min.z),new THREE.MeshStandardMaterial({color:i?0xff725e:0x54b7ff,transparent:true,opacity:.8}));box.position.set(0,1.7+(DUEL_SHAPE.min.y+DUEL_SHAPE.max.y)/2,z);scene.add(box);}
 for(const route of record.routes)scene.add(line(route.points.map(p=>new THREE.Vector3(p.x,p.y-1.7+.16,p.z)),0x68ff9a));
 $('stats').textContent=JSON.stringify({map:inspectMapScene(THREE,map),verifiedMapAndCollisionBytes:byteCounts.glb+byteCounts.collision,verifiedProbeRecordBytes:byteCounts.record,revision:study.revision,probe:probe.counts,recordedGameProbe:record.summary,limitations:probe.limitations},null,2);
 $('view').disabled=$('outlines').disabled=$('arena').disabled=false;setupPlanar(layout);setupHook(layout);setupFlash(layout);resize();viewpoint();status('시험 전용 로드 완료 · v'+study.revision+'. 실제 경기 스폰 B (0, −12)는 wall_poly_13에 막힙니다. 높이 미통합·실기 미검증·경기 규칙 채택 아님.');
 }catch(e){if(token===loadGeneration){release();status('시험 로드 실패: '+e.message);$('load').disabled=false;$('cancel-load').disabled=true;}}finally{if(token===loadGeneration)busy=false;}};
function resize(){if(!renderer)return;const r=$('map').getBoundingClientRect();renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.updateProjectionMatrix();render();}
$('view').onchange=viewpoint;$('outlines').onchange=()=>{outline.visible=$('outlines').checked;render();};$('arena').onchange=()=>{arena.visible=$('arena').checked;render();};addEventListener('resize',resize);
$('map').addEventListener('click',e=>{if(!map)return;const r=$('map').getBoundingClientRect(),ray=new THREE.Raycaster();ray.setFromCamera(new THREE.Vector2((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1),camera);const hit=ray.intersectObject(map,true)[0];if(!hit)return;const p=[hit.point.x,hit.point.z];if(!start){start=p;status('첫 점 '+p.map(x=>x.toFixed(2)).join(', ')+' · 도착점을 선택하세요.');return;}const result=probe.probe(start,p);if(trace){scene.remove(trace);trace.geometry.dispose();trace.material.dispose();}trace=line([new THREE.Vector3(start[0],.25,start[1]),new THREE.Vector3(p[0],.25,p[1])],result.blockedBy?0xff5555:0x44ff99);scene.add(trace);status('연구 XZ sweep: '+(result.blockedBy?'차단 '+result.blockedBy:'통과')+' · 높이/그랩/점멸 판정 아님');start=null;render();});

let planarTrial=null,planarControls=null;const trialIDs=['trial-spawn','trial-start','trial-reset','trial-up','trial-left','trial-down','trial-right'];
function setupPlanar(layout){
 planarTrial=createPlanarTrial(layout,{study,spawn:$('trial-spawn').value==='B'?PLANAR_TRIAL.spawnB:PLANAR_TRIAL.spawnA});const marker=new THREE.Mesh(new THREE.SphereGeometry(PLANAR_TRIAL.radius,16,10),new THREE.MeshStandardMaterial({color:0xffd438}));scene.add(marker);
 function update(state){marker.position.set(state.position[0],PLANAR_TRIAL.radius,state.position[1]);$('trial-position').textContent='시험 X '+state.position[0].toFixed(2)+' · Z '+state.position[1].toFixed(2)+' · 평면 Y=0'+(state.blockedBy?.length?' · 연구 충돌 차단: '+state.blockedBy.join(', '):'');if($('view').value==='trial')viewpoint();else render();}
 planarControls=createPlanarControls({trial:planarTrial,onFrame:update,onState:running=>{$('trial-start').textContent=running?'평면 이동 정지':'평면 이동 시작';},requestFrame:cb=>requestAnimationFrame(cb),cancelFrame:id=>cancelAnimationFrame(id)});
 for(const id of trialIDs)$(id).disabled=false;update(planarTrial.snapshot());
 $('trial-start').onclick=()=>{if(planarControls.running){planarControls.stop();return;}$('view').value='trial';viewpoint();planarControls.start();$('map').focus?.();};
 const reset=()=>{clearFlashPreview();cancelHook();planarControls.stop();planarControls.reset($('trial-spawn').value==='B'?PLANAR_TRIAL.spawnB:PLANAR_TRIAL.spawnA);};$('trial-reset').onclick=reset;$('trial-spawn').onchange=reset;
 for(const name of ['up','left','down','right']){const button=$('trial-'+name);button.onpointerdown=e=>{if(!planarControls?.running)return;e.preventDefault();button.setPointerCapture?.(e.pointerId);planarControls.button(name,true);};for(const event of ['pointerup','pointercancel','lostpointercapture'])button['on'+event]=()=>planarControls?.button(name,false);}
}
addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName))return;if(planarControls?.key(e.code,true))e.preventDefault();});
addEventListener('keyup',e=>{if(planarControls?.key(e.code,false))e.preventDefault();});
addEventListener('blur',()=>{planarControls?.stop();cancelHook();});
addEventListener('pagehide',()=>cancelLoad('화면을 떠나 진단 자원을 해제했습니다. 돌아오면 명시적으로 다시 불러오세요.'));
addEventListener('pageshow',e=>{if(e.persisted&&!renderer&&!busy)status('돌아온 화면입니다. 진단 자원은 해제되어 있으며 다시 불러오기를 기다립니다.');});
document.addEventListener('visibilitychange',()=>{if(document.hidden){planarControls?.stop();cancelHook();}});

let hookTrial=null,hookFrame=null,hookLast=null,hookGeneration=0,hookPaint=null;const hookIDs=['hook-enable','hook-target','hook-cast','hook-cancel','pull-enable','pull-moving'];
function cancelHook(){hookGeneration++;if(hookFrame!==null)cancelAnimationFrame(hookFrame);hookFrame=null;hookLast=null;if(hookTrial){hookPaint?.(hookTrial.cancel());$('hook-status').textContent='시험 그랩 취소 · 경기 상태는 변경하지 않았습니다.';}}
function setupHook(layout){
 hookTrial=createMapHookTrial(layout,{study});const cableCollider=createMapHookCollider(layout,{study});const target=new THREE.Mesh(new THREE.SphereGeometry(.7,16,10),new THREE.MeshStandardMaterial({color:0xff74b8,wireframe:true})),tip=new THREE.Mesh(new THREE.SphereGeometry(HOOK_TRIAL.radius,12,8),new THREE.MeshStandardMaterial({color:0xffe3f0})),cable=line([new THREE.Vector3(),new THREE.Vector3()],0xff74b8);cable.name='map-hook-diagnostic-cable';tip.name='map-hook-diagnostic-tip';scene.add(target,tip,cable);target.visible=tip.visible=cable.visible=false;
 hookPaint=state=>{if(state.target){target.visible=true;target.position.set(state.target.center[0],.7,state.target.center[1]);}tip.visible=cable.visible=!!state.position;if(state.position){const home=planarTrial.snapshot().position;tip.position.set(state.position[0],.8,state.position[1]);const a=cable.geometry.attributes.position;a.setXYZ(0,home[0],.8,home[1]);const clipped=cableCollider.sweep(home,state.position).position;a.setXYZ(1,clipped[0],.8,clipped[1]);a.needsUpdate=true;cable.geometry.computeBoundingSphere();}render();};
 function drive(now,token){if(token!==hookGeneration)return;hookFrame=null;if(hookLast!==null){const state=hookTrial.step(Math.max(0,(now-hookLast)/1000),{home:planarTrial.snapshot().position});hookPaint(state);if(['idle','blocked'].includes(state.phase)){$('hook-status').textContent=(state.phase==='blocked'?'복귀 차단: ':'시험 복귀 완료: ')+(state.hit?'진단 대상 접촉 '+state.hit+' · ':'')+(state.reason??'')+(state.targetPull?' · 시험 당김 '+state.pulledDistance.toFixed(2)+' · 대상 차단 '+(state.targetBlockedBy??'없음')+' · 높이 제외':' · 대상은 당기지 않았습니다.');return;}}hookLast=now;hookFrame=requestAnimationFrame(t=>drive(t,token));}
 function cast(){if(!$('hook-enable').checked)return;const origin=planarTrial.snapshot().position,choice=$('hook-target').value,aim=choice==='cliff'?[0,-15]:choice==='range'?[origin[0]+80,origin[1]]:$('trial-spawn').value==='B'?PLANAR_TRIAL.spawnA:PLANAR_TRIAL.spawnB,targets=choice==='range'?[]:[{id:'marker',center:aim,radius:.7,...($('pull-enable').checked?{velocity:$('pull-moving').checked?[0,2]:[0,0]}:{})}],result=hookTrial.cast({origin,aim,targets});if(!result.accepted){$('hook-status').textContent='시험 발사 거부: '+result.reason;return;}target.visible=targets.length>0;target.position.set(aim[0],.7,aim[1]);hookPaint(result.state);$('hook-status').textContent=$('pull-enable').checked?'시험 당김 진행 · 반경 0.7 대상의 평면 충돌만 검사합니다.':'시험 그랩 진행 · 고정 표식만 검사합니다.';hookLast=null;const token=++hookGeneration;hookFrame=requestAnimationFrame(t=>drive(t,token));}
 for(const id of ['hook-enable','hook-target','pull-enable','pull-moving'])$(id).disabled=false;$('hook-enable').checked=$('pull-enable').checked=$('pull-moving').checked=false;$('hook-status').textContent='그랩 진단을 켜면 Q 또는 버튼으로 시험합니다.';
 $('pull-enable').onchange=()=>{cancelHook();target.visible=false;hookTrial=$('pull-enable').checked?createMapPullTrial(layout,{study}):createMapHookTrial(layout,{study});};$('pull-moving').onchange=()=>{cancelHook();target.visible=false;};
 $('hook-enable').onchange=()=>{cancelHook();target.visible=false;const enabled=$('hook-enable').checked;$('hook-cast').disabled=$('hook-cancel').disabled=!enabled;};$('hook-target').onchange=()=>{cancelHook();target.visible=false;};$('hook-cast').onclick=cast;$('hook-cancel').onclick=cancelHook;
}
addEventListener('keydown',e=>{if(e.code!=='KeyQ'||e.repeat||!hookTrial||!$('hook-enable').checked||['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName))return;e.preventDefault();$('hook-cast').onclick();});


let flashAdapter=null,flashPaint=null;const flashIDs=['flash-enable','flash-policy','flash-direction','flash-distance','flash-preview','flash-apply'];
function clearFlashPreview(){flashPaint?.(null);}
function setupFlash(layout){
 flashAdapter=createMapFlashAdapter(layout,{study});const ghost=new THREE.Mesh(new THREE.SphereGeometry(FLASH_TRIAL.radius,16,10),new THREE.MeshStandardMaterial({color:0xb89cff,wireframe:true})),trail=line([new THREE.Vector3(),new THREE.Vector3()],0xb89cff);ghost.name='map-flash-diagnostic-landing';trail.name='map-flash-diagnostic-intent';scene.add(ghost,trail);ghost.visible=trail.visible=false;
 flashPaint=result=>{ghost.visible=trail.visible=!!result?.accepted;if(result?.accepted){ghost.position.set(result.position[0],.7,result.position[1]);const a=trail.geometry.attributes.position;a.setXYZ(0,result.from[0],.08,result.from[1]);a.setXYZ(1,result.position[0],.08,result.position[1]);a.needsUpdate=true;trail.geometry.computeBoundingSphere();}render();};
 const directions={east:[1,0],west:[-1,0],north:[0,-1],south:[0,1],northeast:[Math.SQRT1_2,-Math.SQRT1_2],southwest:[-Math.SQRT1_2,Math.SQRT1_2]};
 function resolve(){const origin=planarTrial.snapshot().position,d=directions[$('flash-direction').value],length=Number($('flash-distance').value);if(!d||!Number.isFinite(length)||length<=0)return{accepted:false,reason:'invalid-controls'};return flashAdapter.resolve({origin,aim:origin.map((x,i)=>x+d[i]*length),policy:$('flash-policy').value});}
 function act(apply){if(!$('flash-enable').checked)return;const result=resolve();flashPaint(result);if(!result.accepted){$('flash-status').textContent='시험 점멸 거부: '+result.reason+' · 위치는 그대로입니다.';return;}
  if(apply){planarControls.stop();cancelHook();planarControls.reset(result.position);}
  $('flash-status').textContent=(apply?'노란 시험 구체 이동: ':'목적지 미리보기: ')+result.position.map(x=>x.toFixed(2)).join(', ')+' · 거리 '+result.distance.toFixed(2)+' · '+result.reason+(result.crossesInteriorObstacle?' · 내부 벽 통과 정책 사용':' · 내부 벽 통과 없음')+' · 기본 경기/음원은 변경하지 않았습니다.';
 }
 for(const id of ['flash-enable','flash-policy','flash-direction','flash-distance'])$(id).disabled=false;$('flash-enable').checked=false;$('flash-policy').value='clear-path';$('flash-direction').value='east';$('flash-distance').value='4';$('flash-status').textContent='시험 점멸을 켜고 목적지를 확인하세요. 기본은 벽 앞 정지입니다.';
 $('flash-enable').onchange=()=>{clearFlashPreview();$('flash-preview').disabled=$('flash-apply').disabled=!$('flash-enable').checked;};for(const id of ['flash-policy','flash-direction','flash-distance'])$(id).onchange=clearFlashPreview;
 $('flash-preview').onclick=()=>act(false);$('flash-apply').onclick=()=>act(true);
}
