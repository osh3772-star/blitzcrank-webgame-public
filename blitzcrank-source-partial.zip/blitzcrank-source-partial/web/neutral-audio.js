/** Existing triangle cues, sharing the game's unlocked context. No event queue. */
export function createNeutralAudio({maxVoices = 6, onError = () => {}} = {}) {
  let context, paused = false, muted = false, disposed = false;
  const active = new Set();
  const limit = Number.isFinite(maxVoices) ? Math.max(1, Math.min(16, Math.floor(maxVoices))) : 6;
  const report = error => {try {onError(error, 'neutral');} catch {}};

  function release(record, stop = false) {
    active.delete(record);
    if (record.source) record.source.onended = null;
    if (stop) try {record.source?.stop();} catch {}
    try {record.source?.disconnect();} catch {}
    try {record.gain?.disconnect();} catch {}
  }
  function stopAll(preserve) {
    for (const record of [...active]) if (record.handle !== preserve) release(record, true);
  }
  function stateChanged() {
    // Audio time freezes while suspended. Never resume an old, frozen cue later.
    if (context?.state !== 'running') stopAll();
  }
  function attachContext(next) {
    if (disposed || context === next) return;
    stopAll();
    context?.removeEventListener?.('statechange', stateChanged);
    context = next;
    context?.addEventListener?.('statechange', stateChanged);
    stateChanged();
  }
  function play(freq, end, duration = .16) {
    stateChanged();
    if (disposed || paused || muted || context?.state !== 'running') return false;
    if (!Number.isFinite(freq) || freq <= 0 || !Number.isFinite(end) ||
        !Number.isFinite(duration) || duration <= 0 || duration > 1) return false;
    if (active.size >= limit) release(active.values().next().value, true);
    const record = {handle: Symbol('neutral-tone')};
    try {
      const now = context.currentTime, source = context.createOscillator();
      record.source = source;
      const gain = context.createGain(); record.gain = gain;
      // Preserve the original waveform, pitch sweep and absolute gain envelope.
      source.type = 'triangle';
      source.frequency.setValueAtTime(freq, now);
      source.frequency.exponentialRampToValueAtTime(Math.max(20, end), now + duration);
      gain.gain.setValueAtTime(.07, now);
      gain.gain.exponentialRampToValueAtTime(.001, now + duration);
      source.connect(gain); gain.connect(context.destination);
      source.onended = () => release(record);
      active.add(record);
      source.start(now); source.stop(now + duration);
      return record.handle;
    } catch (error) {release(record, true); report(error); return false;}
  }
  return {
    attachContext, play, stopAll: () => stopAll(),
    setMuted(value) {muted = Boolean(value); if (muted) stopAll();},
    setPaused(value, preserve = null) {
      paused = Boolean(value);
      // Only an already-active final impact may finish. New events stay blocked.
      if (paused) stopAll(preserve);
    },
    get status() {return {active: active.size, paused, muted, disposed};},
    dispose() {
      if (disposed) return;
      disposed = true; stopAll();
      context?.removeEventListener?.('statechange', stateChanged);
      context = null;
    },
  };
}
