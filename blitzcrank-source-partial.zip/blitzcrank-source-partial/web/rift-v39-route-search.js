// Bounded offline grid routing. Each accepted edge needs an external full audit.
export function findAuditedRoute({start,goal,bounds,step=1,maxExpanded=10000,edgeAudit}={}){
 const point=p=>Array.isArray(p)&&p.length===2&&p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024);
 if(!point(start)||!point(goal)||!Array.isArray(bounds)||bounds.length!==4||!bounds.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024)||bounds[0]>=bounds[2]||bounds[1]>=bounds[3]||!Number.isFinite(step)||step<.25||step>4||!Number.isInteger(maxExpanded)||maxExpanded<1||maxExpanded>20000||typeof edgeAudit!=='function')throw Error('Invalid bounded route options');
 const [xmin,zmin,xmax,zmax]=bounds,inside=p=>p[0]>=xmin&&p[0]<=xmax&&p[1]>=zmin&&p[1]<=zmax;
 if(!inside(start)||!inside(goal))throw Error('Endpoints outside search bounds');
 const nx=Math.floor((xmax-xmin)/step)+1,nz=Math.floor((zmax-zmin)/step)+1;
 if(nx*nz>20000)throw Error('Grid node budget exceeded');
 const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
 const key=(i,j)=>i+','+j,coords=id=>id==='S'?start:id==='G'?goal:id.split(',').map((s,k)=>[xmin,zmin][k]+Number(s)*step);
 const endpointLinks=p=>{const out=[];for(let i=Math.max(0,Math.floor((p[0]-xmin)/step)-1);i<=Math.min(nx-1,Math.ceil((p[0]-xmin)/step)+1);i++)for(let j=Math.max(0,Math.floor((p[1]-zmin)/step)-1);j<=Math.min(nz-1,Math.ceil((p[1]-zmin)/step)+1);j++)if(distance(p,[xmin+i*step,zmin+j*step])<=step*Math.SQRT2+1e-9)out.push(key(i,j));return out;};
 const startLinks=endpointLinks(start),goalLinks=new Set(endpointLinks(goal));
 const edgeCache=new Map(),rejectedReasons={};let checkedEdges=0,passedEdges=0,closest={position:start.slice(),distance:distance(start,goal)};
 function audit(a,b){const k=a+'|'+b;if(edgeCache.has(k))return edgeCache.get(k);const result=edgeAudit(coords(a).slice(),coords(b).slice());if(!result||typeof result.pass!=='boolean')throw Error('Edge audit must return an explicit boolean pass');checkedEdges++;if(result.pass)passedEdges++;else {const reason=result.reason??'audit-rejected';rejectedReasons[reason]=(rejectedReasons[reason]??0)+1;}edgeCache.set(k,result);return result;}
 // Start and goal validity are audited even when identical or disconnected.
 const startAudit=audit('S','S'),goalAudit=audit('G','G');
 const meta=()=>({step,bounds:bounds.slice(),gridNodes:nx*nz,checkedEdges,passedEdges,rejectedReasons,closestReachableToGoal:closest,adopted:false,browserGpuVerified:false});
 if(!startAudit.pass||!goalAudit.pass)return {...meta(),status:'invalid-endpoint',path:null};
 if(distance(start,goal)===0)return {...meta(),status:'found',path:[start.slice()],segments:[],length:0,expanded:0};
 function neighbors(id){
  if(id==='S')return [...startLinks,...(distance(start,goal)<=step*Math.SQRT2?['G']:[])];
  const [i,j]=id.split(',').map(Number),out=[];
  for(let di=-1;di<=1;di++)for(let dj=-1;dj<=1;dj++)if((di||dj)&&i+di>=0&&i+di<nx&&j+dj>=0&&j+dj<nz)out.push(key(i+di,j+dj));
  if(goalLinks.has(id))out.push('G');return out;
 }
 const open=[{id:'S',g:0,f:distance(start,goal)}],cost=new Map([['S',0]]),previous=new Map(),closed=new Set();let expanded=0;
 while(open.length&&expanded<maxExpanded){
  open.sort((a,b)=>a.f-b.f||a.g-b.g||a.id.localeCompare(b.id));const current=open.shift();
  if(closed.has(current.id)||current.g!==cost.get(current.id))continue;
  if(current.id==='G'){
   const ids=['G'];while(ids.at(-1)!=='S')ids.push(previous.get(ids.at(-1)));ids.reverse();
   const path=ids.map(id=>coords(id).slice()),segments=ids.slice(1).map((id,i)=>({from:path[i],to:path[i+1],audit:audit(ids[i],id)}));
   return {...meta(),status:'found',path,segments,length:current.g,expanded};
  }
  closed.add(current.id);expanded++;
  const remaining=distance(coords(current.id),goal);if(remaining<closest.distance)closest={position:coords(current.id).slice(),distance:remaining};
  for(const next of neighbors(current.id)){
   if(closed.has(next))continue;const g=current.g+distance(coords(current.id),coords(next));
   if(g>=(cost.get(next)??Infinity)||!audit(current.id,next).pass)continue;
   cost.set(next,g);previous.set(next,current.id);open.push({id:next,g,f:g+distance(coords(next),goal)});
  }
 }
 return {...meta(),status:open.length?'expansion-budget-exhausted':'no-route-in-grid',path:null,expanded,
  globalUnreachabilityProven:false};
}

export function createTriangleIndex(triangles,{cellSize=4,maxEntries=2000000}={}){
 if(!Number.isFinite(cellSize)||cellSize<.25||cellSize>32||!Number.isInteger(maxEntries)||maxEntries<1||maxEntries>2000000)throw Error('Invalid index limits');
 const cells=new Map();let entries=0;
 triangles.forEach((t,id)=>{
  const {min,max}=t.bounds;
  if(![min.x,min.z,max.x,max.z].every(Number.isFinite))throw Error('Invalid triangle bounds');
  const x0=Math.floor(min.x/cellSize),x1=Math.floor(max.x/cellSize),z0=Math.floor(min.z/cellSize),z1=Math.floor(max.z/cellSize);
  if(entries+(x1-x0+1)*(z1-z0+1)>maxEntries)throw Error('Spatial index budget exceeded');
  for(let x=x0;x<=x1;x++)for(let z=z0;z<=z1;z++){const k=x+','+z;if(!cells.has(k))cells.set(k,[]);cells.get(k).push(id);entries++;}
 });
 return {entries,query(from,to,halfExtent=.7){
  if(![from,to].every(p=>Array.isArray(p)&&p.length===2&&p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024))||!Number.isFinite(halfExtent)||halfExtent<0||halfExtent>2)throw Error('Invalid spatial query');
  const xmin=Math.min(from[0],to[0])-halfExtent,xmax=Math.max(from[0],to[0])+halfExtent,zmin=Math.min(from[1],to[1])-halfExtent,zmax=Math.max(from[1],to[1])+halfExtent;
  if((Math.floor(xmax/cellSize)-Math.floor(xmin/cellSize)+1)*(Math.floor(zmax/cellSize)-Math.floor(zmin/cellSize)+1)>100000)throw Error('Spatial query budget exceeded');
  const ids=new Set();
  for(let x=Math.floor(xmin/cellSize);x<=Math.floor(xmax/cellSize);x++)for(let z=Math.floor(zmin/cellSize);z<=Math.floor(zmax/cellSize);z++)for(const id of cells.get(x+','+z)??[])ids.add(id);
  return [...ids].sort((a,b)=>a-b).map(id=>triangles[id]).filter(t=>t.bounds.max.x>=xmin&&t.bounds.min.x<=xmax&&t.bounds.max.z>=zmin&&t.bounds.min.z<=zmax);
 }};
}
