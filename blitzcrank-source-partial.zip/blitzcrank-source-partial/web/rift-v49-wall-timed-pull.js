// Independent target-pull integration. Default gap encloses both horizontal AABBs.
import {PULL_TRIAL} from './rift-v39-pull.js';import {HOOK_TRIAL} from './rift-v39-hook.js';
const point=p=>{if(!Array.isArray(p)||p.length!==2||!p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024))throw Error('Finite XZ point required');return p.slice();};
const mix=(a,b,t)=>a.map((x,i)=>x+(b[i]-x)*t),distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
// Continuous contact of two linearly moving circles over this clamped tick.
function contactFraction(h0,h1,t0,t1){const p=h0.map((x,i)=>x-t0[i]),v=h1.map((x,i)=>x-h0[i]-(t1[i]-t0[i])),r=PULL_TRIAL.radius+HOOK_TRIAL.radius,c=p[0]**2+p[1]**2-r*r;if(c<=0)return 0;const a=v[0]**2+v[1]**2,b=p[0]*v[0]+p[1]*v[1],disc=b*b-a*c;if(!a||disc<0)return null;const t=(-b-Math.sqrt(disc))/a;return t>=0&&t<=1?t:null;}
export function createWallTimedPullTrial({body,hook,stopDistance=2*Math.hypot(.7,.7)+PULL_TRIAL.stopGap}={},checkpoint=null){
 if(!body||!hook||typeof body.sweep!=='function'||typeof hook.sweep!=='function'||!Number.isFinite(stopDistance)||stopDistance<1.55||stopDistance>4)throw Error('Audited colliders and valid stop distance required');let direction=null,offset=null;
 let state={phase:'idle',position:null,origin:null,travel:0,hit:null,reason:null,target:null,contact:null,targetBlockedBy:null,pulledDistance:0};
 if(checkpoint){state=structuredClone(checkpoint.state);direction=checkpoint.direction?.slice()??null;offset=checkpoint.offset?.slice()??null;}
 const snapshot=()=>structuredClone({...state,planarOnly:true,targetPull:true,heightCollision:false,gameplayChanged:false,networked:false});
 const push=(list,kind,from,to)=>{if(distance(from,to)>0)list.push({kind,from:from.slice(),to:to.slice()});};
 return Object.freeze({snapshot,fork(){return createWallTimedPullTrial({body,hook,stopDistance},{state,direction,offset});},cast({origin,aim,targets=[]}){
  origin=point(origin);aim=point(aim);if(!Array.isArray(targets)||targets.length>1)throw Error('당김 시험은 대상 한 개만 지원합니다.');let target=null;
  if(targets.length){const t=targets[0];if(!t||typeof t.id!=='string'||!t.id||t.radius!==PULL_TRIAL.radius)throw Error('대상 반경은 0.7이어야 합니다.');const center=point(t.center),velocity=point(t.velocity??[0,0]);if(Math.hypot(...velocity)>PULL_TRIAL.maxTargetSpeed)throw Error('시험 대상 속도를 초과했습니다.');target={id:t.id,center,velocity,radius:PULL_TRIAL.radius};}
  if(['outbound','pulling','returning'].includes(state.phase))return{accepted:false,reason:'busy'};
  if(!distance(origin,aim))return{accepted:false,reason:'zero-direction'};
  if(body.sweep(origin,origin).blockedBy)return{accepted:false,reason:'blocked-origin'};
  if(target&&body.sweep(target.center,target.center).blockedBy)return{accepted:false,reason:'blocked-target'};
  const length=distance(origin,aim);direction=aim.map((x,i)=>(x-origin[i])/length);offset=null;state={phase:'outbound',position:origin.slice(),origin:origin.slice(),travel:0,hit:null,reason:null,target,contact:null,targetBlockedBy:null,pulledDistance:0};return{accepted:true,state:snapshot()};
 },cancel(){state={...state,phase:'idle',position:null,hit:null,reason:'cancelled',contact:null};return snapshot();},step(dt,{home=state.origin}={}){
  if(!Number.isFinite(dt)||dt<0)throw Error('유한한 음수가 아닌 시간이 필요합니다.');home=home===null?null:point(home);const seconds=Math.min(dt,PULL_TRIAL.maxDt),segments=[];
  if(!seconds||!['outbound','pulling','returning'].includes(state.phase))return{...snapshot(),seconds,segments};
  if(!home)throw Error('복귀 기준점이 필요합니다.');if(body.sweep(home,home).blockedBy)return{...snapshot(),seconds:0,segments,homeRejected:true};
  const from=state.position.slice(),targetStart=state.target?.center.slice();let targetStopTime=1;
  if(state.phase==='outbound'){
   const amount=Math.min(HOOK_TRIAL.outSpeed*seconds,HOOK_TRIAL.maxRange-state.travel),to=from.map((x,i)=>x+direction[i]*amount),wall=hook.sweep(from,to);
   const t0=state.target?.center.slice(),move=t0?body.sweep(t0,t0.map((x,i)=>x+state.target.velocity[i]*seconds)):null,t1=move?.position;
   const requested=t0?Math.hypot(...state.target.velocity)*seconds:0;
   const stopTime=t0&&requested?(move.blockedBy?Math.min(1,Math.max(0,move.clearDistance/requested)):1):0;
   let f=null;
   if(t0){
    if(stopTime>0){const first=contactFraction(from,mix(from,to,stopTime),t0,t1);if(first!==null)f=first*stopTime;}
    if(f===null&&stopTime<1){const second=contactFraction(mix(from,to,stopTime),to,t1,t1);if(second!==null)f=stopTime+(1-stopTime)*second;}
   }
   const hit=f!==null&&(!wall.blockedBy||f*amount<wall.clearDistance-wall.resolution);
   if(t0){targetStopTime=hit?Math.min(f,stopTime):stopTime;state.target.center=hit&&stopTime>0?mix(t0,t1,Math.min(1,f/stopTime)):t1;state.targetBlockedBy=hit&&f<stopTime?null:move.blockedBy;push(segments,'target-free',t0,state.target.center);}
   if(hit){state.position=mix(from,to,f);state.travel+=amount*f;state.hit=state.target.id;state.contact=state.position.slice();offset=state.position.map((x,i)=>x-state.target.center[i]);state.phase='pulling';state.reason='target';}
   else if(wall.blockedBy){state.position=wall.position;state.travel+=wall.clearDistance;state.phase=wall.invalidOrigin?'blocked':'returning';state.reason='outbound-blocked:'+wall.blockedBy;state.contact=wall.contact;}
   else{state.position=to;state.travel+=amount;if(state.travel>=HOOK_TRIAL.maxRange){state.phase='returning';state.reason='range';}}
  }else if(state.phase==='pulling'){
   const t0=state.target.center.slice(),d=distance(t0,home),stop=stopDistance,amount=Math.min(PULL_TRIAL.pullSpeed*seconds,Math.max(0,d-stop));
   if(!amount){targetStopTime=0;state.phase='returning';state.reason='pulled';}
   else{const t1=mix(t0,home,amount/d),h1=t1.map((x,i)=>x+offset[i]),tw=body.sweep(t0,t1),hw=hook.sweep(from,h1),allowed=Math.min(amount,tw.clearDistance,hw.clearDistance),fraction=allowed/amount;state.target.center=mix(t0,t1,fraction);state.position=mix(from,h1,fraction);state.pulledDistance+=allowed;targetStopTime=Math.min(1,allowed/(PULL_TRIAL.pullSpeed*seconds));push(segments,'target-pulled',t0,state.target.center);
    if(tw.blockedBy||hw.blockedBy){state.targetBlockedBy=tw.blockedBy??hw.blockedBy;state.phase='returning';state.reason='pull-blocked:'+state.targetBlockedBy;}
    else if(amount>=d-stop-1e-10){state.phase='returning';state.reason='pulled';}
   }
  }else{
   const d=distance(from,home),amount=Math.min(d,HOOK_TRIAL.returnSpeed*seconds),to=d?mix(from,home,amount/d):home.slice(),wall=hook.sweep(from,to);state.position=wall.position;
   if(wall.blockedBy){state.phase='blocked';state.reason='return-blocked:'+wall.blockedBy;state.contact=wall.contact;}else if(amount===d)state.phase='idle';
  }
  push(segments,'hook',from,state.position);
  let targetTimeline=null;
  if(targetStart){const end=state.target.center.slice(),moved=distance(targetStart,end)>0;
   targetTimeline=moved&&targetStopTime>0&&targetStopTime<1?[{t:0,p:targetStart},{t:targetStopTime,p:end},{t:1,p:end.slice()}]:[{t:0,p:targetStart},{t:1,p:end}];
  }
  return{...snapshot(),seconds,segments,targetTimeline};
 }});
}
