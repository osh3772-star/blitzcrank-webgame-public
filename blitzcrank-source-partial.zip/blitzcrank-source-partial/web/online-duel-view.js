import {createRemoteSmoothing} from './online-remote-smoothing.js';
import * as DefaultThree from './vendor/three.module.js';
import {loadPlayerModel} from './model-codec.js';
import {PLAYER_MODELS} from './player-model-manifest.js';
import {loadSkillAsset} from './skill-animation.js';
import {SKILL_ASSET} from './skill-animation-manifest.js';
import {createFullbodyLocomotion} from './fullbody-locomotion.js';
import {createDuelAvatarFactory} from './duel-avatar.js';
import {createHookChain} from './hook-chain.js';
import {loadBlitzTextures,attachBlitzUV,blitzMaterialKey,createBlitzMaterial} from './blitz-materials.js';
import {createSkillVfx} from './skill-vfx.js';
import {createSkillAudio,SKILL_AUDIO_CUES,SKILL_AUDIO_EVENTS} from './skill-audio.js';
import {createGameAudio} from './game-audio.js';
import {AUDIO_CUES,AUDIO_EVENTS} from './audio-cues.js';
import {FLASH_AUDIO_CUES,FLASH_AUDIO_EVENTS} from './flash-audio.js';
import {SKILL_TUNING} from './skill-controller.js';
import {thirdPersonCameraPosition} from './core.js';
import {onlineArenaObstacles} from './online-duel-world.js';
export async function createOnlineView(canvas,{THREE=DefaultThree,createAudio=createGameAudio,now=()=>performance.now()}={}){
 const scene=new THREE.Scene();scene.background=new THREE.Color(0x10242e);scene.fog=new THREE.Fog(0x10242e,30,85);
 const renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.35;
 const camera=new THREE.PerspectiveCamera(64,innerWidth/innerHeight,.08,110);camera.rotation.order='YXZ';
 scene.add(new THREE.HemisphereLight(0xc7edec,0x17202a,2));const sun=new THREE.DirectionalLight(0xffe0a0,3.2);sun.position.set(-8,18,10);scene.add(sun);const rim=new THREE.DirectionalLight(0x52bace,2.5);rim.position.set(7,8,-20);scene.add(rim);
 const obstacles=onlineArenaObstacles();
 const material=new THREE.MeshStandardMaterial({color:0x203a44,roughness:.65,metalness:.4});
 for(const o of obstacles){const a=o.min,b=o.max,mesh=new THREE.Mesh(new THREE.BoxGeometry(b.x-a.x,b.y-a.y,b.z-a.z),material);mesh.position.set((a.x+b.x)/2,(a.y+b.y)/2,(a.z+b.z)/2);scene.add(mesh);}
 const grid=new THREE.GridHelper(52,26,0x486463,0x29454d);grid.position.set(0,.005,-13);scene.add(grid);
 const [data,skills]=await Promise.all([loadPlayerModel(PLAYER_MODELS.fullbody),loadSkillAsset(SKILL_ASSET)]),textures=await loadBlitzTextures(THREE,data);
 const body=new THREE.Group(),nodes=new Map(),meshes=new Map(),materials=new Map(),records=new Map(data.nodes.map(n=>[n.name,n]));
 for(const n of data.nodes){const node=new THREE.Group();node.name=n.name;nodes.set(n.name,node);}
 for(const n of data.nodes){const node=nodes.get(n.name),parent=nodes.get(n.parent);node.position.fromArray(n.position);if(parent){node.position.sub(new THREE.Vector3().fromArray(records.get(n.parent).position));parent.add(node);}else body.add(node);node.userData.base=node.position.toArray();}
 for(const p of data.parts){const node=nodes.get(p.name),record=records.get(p.name),g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p.vertices,3));g.setAttribute('normal',new THREE.Float32BufferAttribute(p.normals,3));g.setIndex(new THREE.BufferAttribute(ArrayBuffer.isView(p.triangles)?p.triangles:new Uint16Array(p.triangles),1));attachBlitzUV(THREE,g,p);g.translate(-record.position[0],-record.position[1],-record.position[2]);g.computeBoundingBox();g.computeBoundingSphere();const key=blitzMaterialKey(p);if(!materials.has(key))materials.set(key,createBlitzMaterial(THREE,p,undefined,textures));const mesh=new THREE.Mesh(g,materials.get(key));mesh.name=p.name+'_surface';mesh.userData.sourcePart=p.sourcePart||p.name;mesh.userData.skillRestPoint=record.position.slice();node.add(mesh);meshes.set(p.name,mesh);}
 body.scale.setScalar(.78);
 const factory=createDuelAvatarFactory(THREE,{body,nodes,meshes,createLocomotion:createFullbodyLocomotion}),actors={},ropes={},effects={},previous={},visualParents={},viewScene=new THREE.Scene();
 const audio=createAudio({cues:{...AUDIO_CUES,...SKILL_AUDIO_CUES,...FLASH_AUDIO_CUES},events:{...AUDIO_EVENTS,...SKILL_AUDIO_EVENTS,...FLASH_AUDIO_EVENTS}}),skillAudio={};
 for(const id of ['human','bot']){
  const parent=visualParents[id]=new THREE.Group();parent.name='Online visual offset '+id;parent.matrixAutoUpdate=false;scene.add(parent);
  actors[id]=factory.create({parent,visible:true,staticRestMatrices:true,reuseSkillSurfaceRestPose:true,stationaryW:true});// The loader's fresh JSON stays private until both actors are configured.
  // Custom dependencies keep the ordinary mutable-input validation contract.
  if(THREE===DefaultThree&&createAudio===createGameAudio)actors[id].configureLoadedSkills(skills.models.fullbody);
  else actors[id].configureSkills(skills.models.fullbody);
  ropes[id]=createHookChain(THREE);scene.add(ropes[id]);ropes[id].visible=false;
  effects[id]=createSkillVfx(THREE,{scene,viewScene,fullbody:actors[id].object,worldHands:actors[id].getSkillHands(),rRadius:SKILL_TUNING.rRadius,wDuration:SKILL_TUNING.wDuration,wSlowDuration:SKILL_TUNING.wSlowDuration});
  skillAudio[id]=createSkillAudio({playEvent:e=>audio.playEvent(e,{emitter:id}),playTone:(...args)=>audio.playTone(...args)});
 }
 let lastEvent=0,lastTick=-1,lastSession=null,local='human',remoteSmoothing=false,renderState=null;
 const smoothing=createRemoteSmoothing({obstacles});
 function resetPresentation(){
  smoothing.reset();remoteSmoothing=false;renderState=null;
  audio.setPaused(true);lastEvent=0;lastTick=-1;lastSession=null;local='human';
  for(const [index,id] of ['human','bot'].entries()){previous[id]=null;skillAudio[id].reset();effects[id].reset();ropes[id].visible=false;actors[id].reset({position:[0,0,index?-12:7],yaw:index?Math.PI:0,visible:true});}
 }
 function pose(id,a,dt=0){
  const old=previous[id]??a.position,h=a.hook,dy=a.position.y-1.7;
  actors[id].update(dt,{position:[a.position.x,dy,a.position.z],yaw:a.yaw,pitch:a.pitch,skill:a.skills.animation,locomotion:{deltaX:dt?a.position.x-old.x:0,deltaZ:dt?a.position.z-old.z:0,grounded:a.grounded,height:dy,velocityY:a.velocity.y},hook:h?{...h,position:[h.position.x,h.position.y,h.position.z]}:null},{rLocomotion:true,eArmRecovery:!(a.skills.boost||a.skills.slow),rArmRecovery:!(a.skills.armed||a.skills.boost||a.skills.slow)});
  if(a.punchTime>0&&!h&&!a.skills.animation){const t=Math.min(1,((a.punchDuration-a.punchTime)/a.punchDuration)/.65);actors[id].object.getObjectByName('BC_Pivot_Shoulder.R').rotation.x=-Math.sin(t*Math.PI)*1.3;}
 }
 function resize(){renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();}resize();
 return {
  skillClips:skills.models.fullbody.clips,obstacles,resize,reset:resetPresentation,unlock:()=>audio.unlock(),pauseAudio:()=>audio.setPaused(true),
  socket(id,a){pose(id,a);const s=actors[id].getSockets();return {origin:{x:s.homePalm[0],y:s.homePalm[1],z:s.homePalm[2]},bodyOrientation:s.homeOrientation};},
  show(snapshot,id='human',{remoteSmoothing:smooth=false,localPaused=false}={}){
   if(lastSession!==snapshot.session){resetPresentation();lastSession=snapshot.session;}
   local=id;remoteSmoothing=!!smooth;const other=id==='human'?'bot':'human',a=snapshot.actors[other];
   smoothing.push(snapshot,other,now(),{smooth:remoteSmoothing});renderState={id:other,position:{...a.position},yaw:a.yaw};
   const dt=lastTick<0||snapshot.tick<lastTick?0:Math.min(.1,(snapshot.tick-lastTick)/60);lastTick=snapshot.tick;
   audio.setPaused(localPaused||snapshot.paused||snapshot.closed);
   for(const playerId of ['human','bot']){
    const a=snapshot.actors[playerId];pose(playerId,a,dt);previous[playerId]={...a.position};const h=a.hook;ropes[playerId].visible=!!h&&['outbound','return'].includes(h.phase);
    if(ropes[playerId].visible){const s=actors[playerId].getSockets();ropes[playerId].update(new THREE.Vector3().fromArray(s.cable),new THREE.Vector3().fromArray(s.chain),{phase:h.phase,phaseTime:h.phaseTime,time:snapshot.tick/60});}
    skillAudio[playerId].update(a.skills);
   }
   for(const event of snapshot.events){if(event.serial<=lastEvent)continue;lastEvent=event.serial;
    if(event.type==='cast'){const {id:caster,skill}=event;if(skill==='W')skillAudio[caster].castW();if(skill==='E')skillAudio[caster].castE();if(skill==='R')skillAudio[caster].castR();if(skill==='Q')audio.playEvent('hookWindup',{emitter:caster});if(skill==='FLASH')audio.playEvent('flashCast',{emitter:caster});}
    if(event.type==='authority'&&event.event.type==='skill-impact'){
     const e=event.event,id=e.playerId;if(e.skill==='R'){effects[id].event('static_field_discharge',{position:e.origin,frameOffset:Math.max(0,dt-e.offset)});skillAudio[id].dischargeR();if(e.hit)effects[id].event('static_field_target',{position:e.position});}
     if(e.skill==='E'&&e.hit){effects[id].event('power_fist_hit',{position:e.position});skillAudio[id].hitE();}
    }
    if(event.type==='round-reset')for(const id of ['human','bot']){effects[id].reset();previous[id]=null;}
   }
   for(const id of ['human','bot']){const a=snapshot.actors[id];effects[id].update(snapshot.paused?0:dt,{status:a.skills,position:a.position,yaw:a.yaw,moving:Math.hypot(a.velocity.x,a.velocity.z)>.01,thirdPerson:true});}
   this.camera(snapshot.actors[local].yaw,snapshot.actors[local].pitch,snapshot);
  },
  camera(yaw,pitch,snapshot){const a=snapshot?.actors?.[local];if(!a)return;const pos=thirdPersonCameraPosition(a.position,yaw,pitch,obstacles);camera.position.set(pos.x,pos.y,pos.z);camera.rotation.set(pitch,yaw,0,'YXZ');},
  render(){
   const sample=smoothing.sample(now());
   if(!remoteSmoothing||!renderState||!sample?.smoothing){renderer.render(scene,camera);return;}
   const {id,position:a,yaw}=renderState,b=sample.position,parent=visualParents[id],angle=sample.yaw-yaw,c=Math.cos(angle),s=Math.sin(angle);
   // Apply only a temporary visual parent transform. Avatar TRS, authoritative
   // snapshots, collision and socket coordinates remain untouched outside render.
   parent.matrix.makeRotationY(angle);parent.matrix.setPosition(b.x-c*a.x-s*a.z,b.y-a.y,b.z+s*a.x-c*a.z);parent.matrixWorldNeedsUpdate=true;
   try{renderer.render(scene,camera);}finally{parent.matrix.identity();parent.matrixWorldNeedsUpdate=true;parent.updateMatrixWorld(true);}
  },
  inspect(){return {lastEvent,lastTick,lastSession,remoteSmoothing:smoothing.inspect(),actorCount:Object.keys(actors).length,parts:meshes.size,clips:skills.models.fullbody.clips.map(c=>c.name),obstacles:obstacles.length};}
 };
}
