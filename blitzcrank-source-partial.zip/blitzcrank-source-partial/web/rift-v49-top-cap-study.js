import {sectionMesh} from './rift-v49-mesh-section.js';
function edgeMap(faces){const edges=new Map();for(const face of faces)for(let k=0;k<3;k++){const a=face[k],b=face[(k+1)%3],key=a<b?a+':'+b:b+':'+a;if(!edges.has(key))edges.set(key,[]);edges.get(key).push([a,b]);}return edges;}
function closed(faces){return [...edgeMap(faces).values()].every(e=>e.length===2&&e[0][0]===e[1][1]&&e[0][1]===e[1][0]);}
// An independent derived volume, not a runtime collision permission or visual edit.
export function createTopCapStudy(THREE,mesh,{cutHeight=2.5,bodyTop=2.1}={}){
 if(!Number.isFinite(cutHeight)||!Number.isFinite(bodyTop)||cutHeight<=bodyTop)throw Error('Cap must be strictly above body top');
 const section=sectionMesh(mesh,cutHeight);if(!section.closed||section.loops.length!==1)throw Error('One simple nondegenerate cut loop required');
 const oldEdges=edgeMap(mesh.faces),open=[...oldEdges.values()].filter(e=>e.length!==2||e[0][0]!==e[1][1]||e[0][1]!==e[1][0]);
 if(open.some(e=>e.length!==1||e[0].some(i=>mesh.positions[i][1]<=cutHeight)))throw Error('Original openings must all lie above cut');
 const positions=mesh.positions.map(p=>p.slice()),faces=[],sourceFaces=[],caps=[],edgeCuts=new Map();let preservedTriangles=0,clippedTriangles=0;
 function cut(a,b){const lo=Math.min(a,b),hi=Math.max(a,b),key=lo+':'+hi;if(edgeCuts.has(key))return edgeCuts.get(key);const p=positions[lo],q=positions[hi],t=(cutHeight-p[1])/(q[1]-p[1]),id=positions.length;positions.push([p[0]+(q[0]-p[0])*t,cutHeight,p[2]+(q[2]-p[2])*t]);edgeCuts.set(key,id);return id;}
 for(const [sourceFace,f] of mesh.faces.entries()){if(f.every(i=>positions[i][1]<cutHeight)){faces.push(f.slice());sourceFaces.push(sourceFace);preservedTriangles++;continue;}if(f.every(i=>positions[i][1]>cutHeight))continue;const polygon=[];for(let k=0;k<3;k++){const a=f[k],b=f[(k+1)%3],inside=positions[a][1]<cutHeight,next=positions[b][1]<cutHeight;if(inside)polygon.push(a);if(inside!==next)polygon.push(cut(a,b));}for(let k=1;k<polygon.length-1;k++){faces.push([polygon[0],polygon[k],polygon[k+1]]);sourceFaces.push(sourceFace);}clippedTriangles++;}
 const boundary=[...edgeMap(faces).values()].filter(e=>e.length!==2||e[0][0]!==e[1][1]||e[0][1]!==e[1][0]);
 if(boundary.some(e=>e.length!==1||e[0].some(i=>positions[i][1]!==cutHeight)))throw Error('Unexpected uncapped edge away from cut');
 const next=new Map(),incoming=new Map();for(const [[a,b]]of boundary){if(next.has(a))throw Error('Branched cap boundary');next.set(a,b);incoming.set(b,(incoming.get(b)??0)+1);}if([...incoming.values()].some(n=>n!==1))throw Error('Noncyclic cap boundary');
 const start=next.keys().next().value,loop=[];let at=start;do{if(loop.includes(at)||!next.has(at))throw Error('Invalid cap loop');loop.push(at);at=next.get(at);}while(at!==start);if(loop.length!==boundary.length)throw Error('Multiple cap loops');
 const contour=loop.map(i=>new THREE.Vector2(positions[i][0],positions[i][2])),triangles=THREE.ShapeUtils.triangulateShape(contour,[]);if(!triangles.length)throw Error('Cap triangulation failed');for(const f of triangles)caps.push(f.map(i=>loop[i]));
 if(!closed([...faces,...caps]))for(const f of caps)f.reverse();if(!closed([...faces,...caps]))throw Error('Cap is not an oriented closed manifold');
 const all=[...faces,...caps];let volume=0;for(const [a,b,c]of all){const p=new THREE.Vector3(...positions[a]),q=new THREE.Vector3(...positions[b]),r=new THREE.Vector3(...positions[c]);volume+=p.dot(q.cross(r))/6;}if(!Number.isFinite(volume)||Math.abs(volume)<1e-8)throw Error('Nonzero finite volume required');
 return {positions,faces:all,sourceFaceForOutput:[...sourceFaces,...caps.map(()=>null)],capFaces:caps,cutHeight,bodyTop,preservedTriangles,clippedTriangles,capTriangles:caps.length,orientedClosed:true,signedVolume:volume,spawnPermission:false,selfIntersectionsVerified:false,visualMeshChanged:false};
}
