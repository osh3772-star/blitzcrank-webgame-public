// Separate simulation-time drills. Q-first eligibility/timing remains v1;
// E-first starts at the accepted E input and owns a separate record category.
export const COMBO_PRACTICE_RULES='q-e-r-v1';
export const COMBO_ER_RULES='e-r-v1';
export const COMBO_PRACTICE_TUNING=Object.freeze({attemptDuration:12,retryDelay:1.8});
export function createComboPractice(){
 let enabled=false,phase='ready',route=null,target=null,startedAt=null,endedAt=null,retryAt=null,attempts=0,successes=0,bests={qer:null,er:null},bestsFlash={qer:null,er:null},flashAssisted=false,last=null;
 const active=()=>['hook','pull','e','r'].includes(phase);
 function finish(success,now,reason=''){
  if(!active())return false;
  endedAt=now;phase=success?'success':'failed';retryAt=now+COMBO_PRACTICE_TUNING.retryDelay;
  const elapsed=Math.max(0,now-startedAt);last={success,elapsed,reason,route,flashAssisted};
  if(success){successes++;const records=flashAssisted?bestsFlash:bests;records[route]=records[route]===null?elapsed:Math.min(records[route],elapsed);}
  return true;
 }
 return {
  get enabled(){return enabled;},
  get active(){return active();},
  get canStart(){return enabled&&phase==='ready';},
  reset(value=false){enabled=!!value;phase='ready';route=null;target=null;startedAt=endedAt=retryAt=null;attempts=successes=0;bests={qer:null,er:null};bestsFlash={qer:null,er:null};flashAssisted=false;last=null;},
  start(now,path='qer'){if(!enabled||phase!=='ready'||!['qer','er'].includes(path))return false;attempts++;startedAt=now;endedAt=retryAt=null;target=null;route=path;flashAssisted=false;phase=path==='er'?'e':'hook';return true;},
  markFlash(){if(!enabled||!active())return false;flashAssisted=true;return true;},
  hooked(id){if(!enabled||phase!=='hook')return false;target=id;phase='pull';return true;},
  delivered(id){if(!enabled||phase!=='pull'||id!==target)return false;phase='e';return true;},
  powerHit(id,now){if(!enabled)return false;if(phase!=='e'||(target!==null&&id!==target)){finish(false,now,'같은 표적에 E + 펀치');return false;}target=id;phase='r';return true;},
  discharge(ids,now){if(!enabled)return false;return finish(phase==='r'&&ids.includes(target),now,phase==='r'?'R 사거리 안에서 적중':'E + 펀치 다음 R');},
  fail(now,reason){return enabled&&finish(false,now,reason);},
  step(now){if(!enabled)return false;if(active()&&now-startedAt>=COMBO_PRACTICE_TUNING.attemptDuration)finish(false,now,'12초 안에 연계');return retryAt!==null&&now>=retryAt;},
  ready(){if(!enabled||!['success','failed'].includes(phase))return false;phase='ready';route=null;flashAssisted=false;target=null;startedAt=endedAt=retryAt=null;return true;},
  snapshot(now=0){const selectedFlash=route?flashAssisted:!!last?.flashAssisted;return{enabled,phase,route,flashAssisted,target,attempts,successes,best:(selectedFlash?bestsFlash:bests)[route??last?.route??'qer'],bests:{...bests},bestsFlash:{...bestsFlash},last:last?{...last}:null,elapsed:startedAt===null?0:Math.max(0,(endedAt??now)-startedAt),active:active()};}
 };
}
