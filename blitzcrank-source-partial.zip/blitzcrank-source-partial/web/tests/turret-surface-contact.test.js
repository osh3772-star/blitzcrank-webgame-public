import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';
import {GLTFLoader} from '../vendor/GLTFLoader.js';
import {createTurretArena} from '../turret-view.js';
const read=async path=>{const bytes=fs.readFileSync(new URL(path,import.meta.url)),json=JSON.parse(bytes.subarray(20,20+bytes.readUInt32LE(12)));const {scene}=await new GLTFLoader().parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'');scene.updateMatrixWorld(true);const primitives={};scene.traverse(n=>{if(n.isMesh)primitives[n.parent.name+'/'+n.material.name]=n.geometry;});return{bytes,json,scene,primitives};};
// Pin the historical groove-edit asset; current weathering is covered separately.
const TURRET_MODEL_FILE='turret.5a9fd4b0b1c143e9.glb';
const before=await read('../validation/turret-surface-v2433/turret-v2432.glb'),after=await read('../assets/turret/'+TURRET_MODEL_FILE);
const changed=new Set(['StaticTower_Geometry/Slate masonry 1','StaticTower_Geometry/Slate masonry 3','StaticTower_Geometry/Dark stone cracks']);
test('historical surface-contact asset preserves exact hierarchy, palette, bounds and batching while reducing 16 triangles',()=>{
 assert.equal(TURRET_MODEL_FILE,'turret.'+crypto.createHash('sha256').update(after.bytes).digest('hex').slice(0,16)+'.glb');
 assert.deepEqual(after.json.nodes,before.json.nodes);assert.deepEqual(after.json.materials,before.json.materials);assert.deepEqual(new THREE.Box3().setFromObject(after.scene),new THREE.Box3().setFromObject(before.scene));
 assert.equal(after.json.meshes.length,3);assert.equal(Object.keys(after.primitives).length,22);assert((after.json.buffers||[]).every(x=>!x.uri));assert(!(after.json.images||[]).length);assert(!(after.json.animations||[]).length);
 const triangles=x=>Object.values(x.primitives).reduce((n,g)=>n+g.index.count/3,0);assert.equal(triangles(before),6069);assert.equal(triangles(after),6053);assert.equal(after.bytes.length,469644);
});
test('nineteen unaffected primitives retain exact decoded indices and every attribute, including prior shield correction',()=>{
 let n=0;for(const [name,a]of Object.entries(before.primitives)){if(changed.has(name))continue;const b=after.primitives[name];assert.deepEqual(b.index.array,a.index.array,name);assert.deepEqual(Object.keys(b.attributes),Object.keys(a.attributes));for(const key of Object.keys(a.attributes))assert.deepEqual(b.attributes[key].array,a.attributes[key].array,name+' '+key);n++;}assert.equal(n,19);
});
test('18 original surface positions intersect the new groove bottoms at 0.01 depth in actual runtime geometry',()=>{
 const samples=JSON.parse(fs.readFileSync(new URL('../validation/turret-surface-v2433/runtime-groove-rays.json',import.meta.url)));assert.equal(samples.length,18);const meshes=[];after.scene.traverse(n=>{if(n.isMesh&&/^(Slate masonry|Dark stone cracks)/.test(n.material.name))meshes.push(n);});let shieldOcclusions=0;
 for(const p of samples){const normal=new THREE.Vector3().fromArray(p.normal),surface=new THREE.Vector3().fromArray(p.surface),ray=new THREE.Raycaster(surface.clone().addScaledVector(normal,.05),normal.clone().negate(),0,.08);const hit=ray.intersectObjects(meshes)[0];assert(hit);assert.equal(hit.object.material.name,'Dark stone cracks');assert(Math.abs(hit.distance-.06)<2e-6);const full=ray.intersectObject(after.scene,true)[0];if(full.object.material.name==='Antique gold trim')shieldOcclusions++;else assert.equal(full.object.material.name,'Dark stone cracks');}
 // The unchanged shield intentionally covers part of the top path; do not claim all 18 samples are visible.
 assert(shieldOcclusions>0&&shieldOcclusions<18);
});
test('the groove faces stay on or inside the three original sloped stone planes, never floating in front',()=>{
 const paths=JSON.parse(fs.readFileSync(new URL('../validation/turret-surface-v2433/edit-details.json',import.meta.url))),toWorld=p=>new THREE.Vector3(p[0],p[2],-p[1]);const mesh=[];after.scene.traverse(n=>{if(n.isMesh&&n.material.name==='Dark stone cracks')mesh.push(n);});assert.equal(mesh.length,1);const pos=mesh[0].geometry.attributes.position;
 for(let i=0;i<pos.count;i++){const p=new THREE.Vector3().fromBufferAttribute(pos,i).applyMatrix4(mesh[0].matrixWorld);const matches=paths.filter(path=>{const points=path.surface_path.map(toWorld),lo=Math.min(...points.map(x=>x.y))-.03,hi=Math.max(...points.map(x=>x.y))+.03;return p.y>=lo&&p.y<=hi;});assert.equal(matches.length,1);const path=matches[0],offset=p.clone().sub(toWorld(path.surface_path[0])).dot(toWorld(path.face_normal).normalize());assert(offset<=2e-6&&offset>=-.010002,`surface offset ${offset}`);}
});
test('model replacement keeps aim, shot, damage, collider and muzzle behavior exact through 600 simulated frames',()=>{
 const make=asset=>{const obstacles=[],events=[];const arena=createTurretArena(new THREE.Scene(),asset.scene,obstacles,{onDamage:(n,e)=>events.push(['damage',n,e]),onAcquired:e=>events.push(['acquired',e]),onShot:e=>events.push(['shot',e])});return{obstacles,events,arena};};const a=make(before),b=make(after);assert.deepEqual(b.obstacles,a.obstacles);
 for(let i=0;i<600;i++){const player={x:-8+Math.sin(i*.01),y:1.7,z:-12};assert.deepEqual(b.arena.step(1/60,player),a.arena.step(1/60,player));for(const id of ['west','east']){const x=a.arena.visuals.get(id),y=b.arena.visuals.get(id);assert.deepEqual(y.muzzle.matrixWorld.elements,x.muzzle.matrixWorld.elements);assert.deepEqual(y.barrel.position,x.barrel.position);}}
 assert.deepEqual(b.events,a.events);assert(a.events.some(e=>e[0]==='shot'));assert(a.events.some(e=>e[0]==='damage'));
});
