import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const planarDistance=d=>Math.hypot(d.player.x-d.duelBot.position.x,d.player.z-d.duelBot.position.z);
function finitePositions(d){for(const p of [d.player,d.duelBot.position])assert(p.toArray().every(Number.isFinite),'both actors stay finite');}
async function start(hz=20){
 const r=await createGameplayHarness({delta:()=>1/hz});r.element('duelmode').click();
 r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,jump:false})});
 for(let n=0;n<hz*2&&r.qa.duel.match.phase!=='active';n++)r.frames(1);
 assert.equal(r.qa.duel.match.phase,'active');return r;
}
function cast(r,winner){if(winner==='human')r.key('KeyQ');else assert(r.game.data.duel.cast('bot'));}
function assertNextRound(r,winner,hz){
 for(let n=0;n<hz*4&&r.qa.duel.match.roundNumber===1;n++)r.frames(1);
 assert.equal(r.qa.duel.match.roundNumber,2);assert.equal(r.qa.duel.match.phase,'countdown');
 assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),winner==='human'?[1,0]:[0,1]);
 assert.equal(r.qa.duel.match.history.length,1);
 assert.deepEqual(r.game.data.player.toArray(),[0,1.7,7]);assert.deepEqual(r.game.data.duelBot.position.toArray(),[0,1.7,-12]);
 assert.equal(r.qa.hook,null);assert.equal(r.qa.duel.bot.hook,null);
}
for(const winner of ['human','bot'])for(const [label,distance,hz] of [['near',1.7,20],['near',1.7,30],['near',1.7,60],['near',1.7,120],['ordinary',6,20]]){
 test(`actual ${winner} ${label} grab at ${hz} Hz never repels the victim and resets the scored round`,async()=>{
  const r=await start(hz),d=r.game.data;d.duelBot.position.set(0,1.7,7-distance);
  const winnerStart=(winner==='human'?d.player:d.duelBot.position).clone();let previous=distance,scored=false;
  cast(r,winner);
  for(let n=0;n<hz;n++){
   r.frames(1);finitePositions(d);const current=planarDistance(d);
   assert(current<=previous+1e-9,`grab moved apart from ${previous}m to ${current}m`);previous=current;
   assert.deepEqual((winner==='human'?d.player:d.duelBot.position).toArray(),winnerStart.toArray(),'winner stays still');
   if(r.qa.duel.match.history.length){scored=true;assert.equal(r.qa.duel.match.history.length,1);assert.equal(r.qa.duel.match.history[0].winnerId,winner);}
  }
  assert(scored,'point must come from a real geometric Q contact');assert(Math.abs(previous-Math.min(distance,2.3))<1e-9);
  assert.equal(r.qa.session.score,0);assertNextRound(r,winner,hz);
 });
}
for(const winner of ['human','bot'])test(`actual ${winner} Q from exactly overlapping centers stays finite without inventing separation`,async()=>{
 const r=await start(),d=r.game.data;d.duelBot.position.copy(d.player);cast(r,winner);
 for(let n=0;n<20;n++){r.frames(1);finitePositions(d);assert.equal(planarDistance(d),0);}
 if(winner==='human')assertNextRound(r,winner,20);
 else{assert.equal(r.qa.duel.match.history.length,0,'existing behind-palm aim block is preserved');assert.equal(r.qa.duel.match.phase,'active');assert.equal(r.qa.duel.bot.hook,null);}
});
