import test from 'node:test';import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {collectStaticTriangles} from '../rift-v39-support-audit.js';
import {planarCoverage,sweptFootprint,polygonArea,auditStraightCorridor,triangleIntersectsPrism} from '../rift-v39-footprint-coverage.js';
function floor(x0,z0,x1,z1,y=0){const g=new THREE.PlaneGeometry(x1-x0,z1-z0);g.rotateX(-Math.PI/2);const m=new THREE.Mesh(g);m.name='Continuous_Terrain_Base_1';m.position.set((x0+x1)/2,y,(z0+z1)/2);return m;}
function triangles(...meshes){const s=new THREE.Scene();s.add(...meshes);return collectStaticTriangles(THREE,s);}
const clearProbe={probe:()=>({blockedBy:null})};
test('two floor triangles continuously cover a translated footprint including their seam',()=>{
 const a=planarCoverage(triangles(floor(7,-14,10,-10)),sweptFootprint([8,-12],[8,-12]));assert(a.covered);assert(a.missingArea<1e-12);
});
test('a sub-grid hole is found even when ordinary footprint samples could miss it',()=>{
 const ts=triangles(floor(-1,-1,1,.07),floor(-1,.09,1,1),floor(-1,.07,.07,.09),floor(.09,.07,1,.09));
 const a=planarCoverage(ts,sweptFootprint([0,0],[0,0]));assert.equal(a.covered,false);assert(Math.abs(a.missingArea-.0004)<1e-7);
});
test('overlapping duplicate triangles cannot hide missing area through area double-counting',()=>{
 const a=planarCoverage(triangles(floor(-1,-1,0,1),floor(-1,-1,0,1)),sweptFootprint([0,0],[0,0]));assert.equal(a.covered,false);assert(Math.abs(a.missingArea-.98)<1e-7);
});
test('triangles at a different height are not adopted as same-level support',()=>{
 assert.equal(planarCoverage(triangles(floor(-2,-2,2,2,.2)),sweptFootprint([0,0],[0,0])).covered,false);
});
test('swept square footprint has analytic area for axis-aligned and diagonal travel',()=>{
 assert(Math.abs(polygonArea(sweptFootprint([0,0],[3,0]))-6.16)<1e-9);
 assert(Math.abs(polygonArea(sweptFootprint([0,0],[3,3]))-10.36)<1e-9);
});
test('support present only at endpoints is not a supported corridor',()=>{
 const a=auditStraightCorridor(THREE,triangles(floor(-1,-1,1,1),floor(3,-1,5,1)),clearProbe,{from:[0,0],to:[4,0]});assert.equal(a.coverage.covered,false);assert.equal(a.conservativeChecksPassed,false);
});
test('thin obstruction between endpoints is caught by whole swept envelope',()=>{
 const beam=new THREE.Mesh(new THREE.BoxGeometry(.01,.1,.1));beam.position.set(1.5,1,0);beam.name='beam';
 const a=auditStraightCorridor(THREE,triangles(floor(-2,-2,5,2),beam),clearProbe,{from:[0,0],to:[3,0]});assert(a.coverage.covered);assert.equal(a.sweptBodySurfaceClear,false);
});
test('diagonal swept prism excludes obstacles in the unused enclosing-box corners',()=>{
 const beam=new THREE.Mesh(new THREE.BoxGeometry(.1,.1,.1));beam.position.set(0,1,3);
 const a=auditStraightCorridor(THREE,triangles(floor(-2,-2,5,5),beam),clearProbe,{from:[0,0],to:[3,3]});assert(a.sweptBodySurfaceClear);assert(a.conservativeChecksPassed);
 beam.position.set(1.5,1,1.5);
 const b=auditStraightCorridor(THREE,triangles(floor(-2,-2,5,5),beam),clearProbe,{from:[0,0],to:[3,3]});assert.equal(b.sweptBodySurfaceClear,false);
});
test('1000 seeded triangles agree with independent Box3 SAT for a stationary prism',()=>{
 let seed=42;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/2**32)*6-3;
 const footprint=sweptFootprint([0,0],[0,0]),box=new THREE.Box3(new THREE.Vector3(-.7,.01,-.7),new THREE.Vector3(.7,2.1,.7));
 for(let i=0;i<1000;i++){
  const t=new THREE.Triangle(...[0,1,2].map(()=>new THREE.Vector3(rand(),rand(),rand())));
  assert.equal(triangleIntersectsPrism(t,footprint,.01,2.1),box.intersectsTriangle(t),'triangle '+i);
 }
});
test('official planar sweep rejection cannot be overridden by geometry clearance',()=>{
 const a=auditStraightCorridor(THREE,triangles(floor(-2,-2,5,2)),{probe:()=>({blockedBy:'wall'})},{from:[0,0],to:[3,0]});assert.equal(a.conservativeChecksPassed,false);assert.equal(a.blockedBy,'wall');
});
test('finite bounded options and convex target polygons are required',()=>{
 for(const p of [[],[[0,0],[1,0],[NaN,1]],[[0,0],[2,0],[1,.5],[2,2],[0,2]]])assert.throws(()=>planarCoverage([],p));
 assert.throws(()=>sweptFootprint([0,0],[Infinity,0]));assert.throws(()=>planarCoverage([],sweptFootprint([0,0],[0,0]),{areaTolerance:1}));
});
