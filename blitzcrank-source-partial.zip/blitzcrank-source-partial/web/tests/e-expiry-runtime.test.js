import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// Actual main/controller with CPU Three.js and DOM/renderer doubles. This does
// not verify browser input ordering, GPU rendering or perceptual animation.
const h=await createGameplayHarness();
function fresh(){h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}}
function reachExpiry(withR){fresh();h.key('KeyE');h.release('KeyE');h.frames(52);assert.equal(h.qa.skills.phase,'E_Hold');assert.equal(h.qa.skills.armed,5);h.frames(withR?232:300);if(withR){h.key('KeyR');h.release('KeyR');h.frames(68);}}

for(const withR of [false,true])test(`actual runtime clears E HUD, electricity and empowered input at expiry${withR?' with R completion':''}`,()=>{
 reachExpiry(withR);
 assert.equal(h.qa.skills.armed,0);assert.equal(h.qa.skills.phase,null);
 assert.equal(h.element('skillstateE').textContent,'READY');
 assert.equal(h.element('skillE').attributes['aria-disabled'],'false');
 assert.equal(h.qa.skills.vfx.eStrength,0);
 h.punch();assert.notEqual(h.qa.skills.phase,'E_Strike');assert(h.game.data.punchCooldown>0);
 h.frames(24);assert.equal(h.qa.skills.metrics.powerHits,0);
 assert.equal(h.qa.skills.metrics.discharges,withR?1:0);
});

test('actual runtime pause preserves a still-valid charge immediately before expiry',()=>{
 fresh();h.key('KeyE');h.release('KeyE');h.frames(52+299);assert(h.qa.skills.armed>0);
 h.game.pause();const before=h.qa.skills;h.frames(120);assert.deepEqual(h.qa.skills,before);
 h.game.resume();h.punch();assert.equal(h.qa.skills.phase,'E_Strike');
});
