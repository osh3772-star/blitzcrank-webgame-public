import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

// Portable into tests/. Executes actual main.js/Three.js with the established
// mocked DOM, audio and renderer. No forced results or physical-device claim.
const root=process.env.RESULTS_VIEW_APP_ROOT||fileURLToPath(new URL('../',import.meta.url));
const {createGameplayHarness}=await import(pathToFileURL(path.join(root,'tests/helpers/runtime-harness.js')));
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'results-view-runtime-'));
const sourcePath=path.join(temporary,'main.mjs');
fs.writeFileSync(sourcePath,fs.readFileSync(process.env.RESULTS_VIEW_SOURCE||path.join(root,'main.js'),'utf8')+'\nwindow.__RESULTS_VIEW_TEST__={get data(){return{renderer,scene,viewScene,viewmodel};}};\n');
const writes=[],h=await createGameplayHarness({sourcePath,delta:()=>.05,storage:{getItem:()=>null,setItem:(...args)=>writes.push(args)}});
const extra=globalThis.__RESULTS_VIEW_TEST__,draws=[];
extra.data.renderer.render=(scene,camera)=>draws.push({scene,camera});
const until=condition=>{for(let i=0;i<300&&!condition();i++)h.frames(1);assert(condition(),'expected natural transition');};
const toggle=()=>h.element('viewtoggle').click();
function view(value){if(h.qa.view!==value)toggle();}
function start(mode='duel',initial='first'){
 document.hidden=false;h.docListeners.pointerdown({pointerType:'mouse'});
 if(mode==='duel')h.element('duelmode').click();else h.game.begin(false);
 view(initial);h.frames(1);
 if(mode==='duel')h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});
}
function finishDuel(skill,winner){
 for(let n=0;n<3;n++){
  until(()=>h.qa.duel.active);const d=h.game.data;d.duelBot.position.set(skill==='Q'?d.camera.position.x:0,1.7,skill==='Q'?1:5);
  if(skill==='Q'){assert.equal(winner,'human');h.key('KeyQ');h.release('KeyQ');}
  if(skill==='E'){h.key('KeyE');h.release('KeyE');until(()=>h.qa.skills.phase==='E_Hold');h.punch();}
  if(skill==='R'){if(winner==='human'){h.key('KeyR');h.release('KeyR');}else assert(d.duel.getSkills('bot').castR());}
  until(()=>h.qa.duel.match.history.length===n+1);assert.equal(h.qa.duel.match.history.at(-1).winnerId,winner);
 }
 until(()=>h.qa.state==='results');assert.equal(h.qa.duel.match.history.length,3);
 assert.deepEqual(h.qa.duel.match.scores.map(s=>s.points),winner==='human'?[3,0]:[0,3]);
}
function snapshot(){return structuredClone({state:h.qa.state,session:h.qa.session,duel:h.qa.duel,
 player:h.qa.player,health:h.qa.health,skills:h.qa.skills,flash:h.qa.flashAbility,flashFrames:h.qa.flashFrames,
 records:h.qa.records,audio:h.qa.audio,voice:h.qa.voice,targets:h.qa.targets,turrets:h.qa.turrets,
 keys:[...h.game.data.keys],shotCooldown:h.game.data.shotCooldown,punchCooldown:h.game.data.punchCooldown,
 results:h.element('results').innerHTML,intro:h.element('intro').textContent,score:h.element('score').textContent});}
function assertView(expected){
 const d=h.game.data;assert.equal(h.qa.view,expected);assert.match(h.element('viewtoggle').textContent,expected==='third'?/3인칭/:/1인칭/);
 assert.equal(d.fullbody.visible,expected==='third','world body visibility must match the selected view immediately');
 if(expected==='first')assert.deepEqual(d.camera.position.toArray(),d.player.toArray(),'first-person camera must return to player');
 else assert(d.camera.position.distanceTo(d.player)>1,'third-person camera must move behind player');
 assert(d.camera.position.toArray().every(Number.isFinite));
}
function assertResultSwitch(initial){
 const target=initial==='first'?'third':'first',before=snapshot(),priorWrites=structuredClone(writes);
 assertView(initial);h.key('KeyV');assert.equal(h.qa.view,initial,'global gameplay hotkey remains blocked on results');
 toggle();assertView(target);assert.deepEqual(snapshot(),before,'view change must not advance or reset gameplay/results/audio');
 draws.length=0;h.frames(3);assertView(target);assert.deepEqual(snapshot(),before);
 assert.equal(draws.filter(d=>d.scene===extra.data.scene).length,3);
 assert.equal(draws.filter(d=>d.scene===extra.data.viewScene).length,target==='first'?3:0,'first-person render pass must agree with the camera');
 toggle();assertView(initial);assert.deepEqual(snapshot(),before);
 toggle();assertView(target);assert.deepEqual(snapshot(),before);
 assert.deepEqual(writes,priorWrites,'view changes must not write records');
}
for(const [skill,winner] of [['Q','human'],['E','human'],['R','human'],['R','bot']])for(const initial of ['first','third'])test(`${winner} ${skill} natural match result: ${initial} view changes camera/body immediately and stays frozen`,()=>{
 start('duel',initial);finishDuel(skill,winner);assertResultSwitch(initial);
 const selected=h.qa.view;h.element('start').click();assert.equal(h.qa.state,'running');assertView(selected);
 assert.deepEqual(h.qa.duel.match.scores.map(s=>s.points),[0,0]);assert.equal(h.qa.duel.match.phase,'countdown');assert.equal(h.game.data.keys.size,0);
});
for(const initial of ['first','third'])test(`solo timeout result: ${initial} view switch uses the same stopped-scene lifecycle`,()=>{
 start('solo',initial);h.game.setElapsed(89.99);h.frames(1);assert.equal(h.qa.state,'results');assertResultSwitch(initial);
});
test('result-to-menu, solo and duel re-entry retain selected view with fresh gameplay',()=>{
 start('duel','first');finishDuel('R','human');toggle();assertView('third');
 h.element('mainmenu').click();assert.equal(h.qa.state,'menu');assert.equal(h.qa.duel,null);assert.equal(h.game.data.fullbody.visible,false);
 h.element('practice').click();h.frames(1);assert.equal(h.qa.duel,null);assertView('third');
 h.key('KeyF');h.key('ShiftLeft');h.frames(1);assert.equal(h.qa.flashAbility.casts,1);
 h.game.pause();h.element('mainmenu').click();h.element('duelmode').click();assertView('third');
 assert.equal(h.qa.duel.match.phase,'countdown');assert.deepEqual(h.qa.duel.match.scores.map(s=>s.points),[0,0]);
 assert.equal(h.qa.flashAbility.casts,0);assert.deepEqual(h.qa.skills.cooldown,{W:0,E:0,R:0});assert.equal(h.game.data.keys.size,0);
});
test('menu view remains a stored preference without revealing the hidden player body',()=>{
 h.game.pause();h.element('mainmenu').click();const before=h.game.data.camera.position.toArray();
 view('first');toggle();assert.equal(h.qa.view,'third');assert.equal(h.game.data.fullbody.visible,false);
 assert.deepEqual(h.game.data.camera.position.toArray(),before);assert.equal(h.qa.duel,null);
});
test('pause view changes remain immediate and resume without restart',()=>{
 start('duel','first');until(()=>h.qa.duel.active);h.game.pause();const before=snapshot();
 toggle();assertView('third');assert.deepEqual(snapshot(),before);h.frames(3);assert.deepEqual(snapshot(),before);
 h.game.resume();assert.equal(h.qa.state,'running');assertView('third');assert.equal(h.qa.duel.match.phase,'active');
});
