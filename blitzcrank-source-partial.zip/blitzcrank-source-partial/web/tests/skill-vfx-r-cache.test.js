import {capacityComparableVfxState as vfxState} from './helpers/vfx-capacity-comparison.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createSkillVfx} from '../skill-vfx.js';
import {createSkillVfx as baseline} from './fixtures/skill-vfx-v0.24.48-baseline.js';
import {createSkillVfxHarness,vfxStatus} from './helpers/skill-vfx-harness.js';
const position={x:2,y:1.7,z:-3},settings={status:vfxStatus(),position,yaw:.4};
const field=h=>h.owned.find(o=>o.name==='R_ivory_branched_web');
const versions=h=>Object.fromEntries(Object.entries(field(h).geometry.attributes).map(([k,a])=>[k,a.version]));
let comparisons=0;
function pair(){const a=createSkillVfxHarness(baseline),b=createSkillVfxHarness(createSkillVfx),identity=[a,b].map(h=>({arrays:h.arrays.slice(),geometry:h.geometries.slice(),material:h.materials.slice()}));
 const same=()=>{assert.deepEqual(vfxState(b),vfxState(a));for(const [i,h] of [a,b].entries()){assert(h.arrays.every((x,j)=>x===identity[i].arrays[j]));assert(h.geometries.every((x,j)=>x===identity[i].geometry[j]));assert(h.materials.every((x,j)=>x===identity[i].material[j]));}comparisons++;};
 return {a,b,same,event(args={position}){assert.equal(b.vfx.event('static_field_discharge',args),a.vfx.event('static_field_discharge',args));same();},tick(dt,extra={}){for(const h of [a,b])h.vfx.update(dt,{...settings,...extra});same();},reset(){for(const h of [a,b])h.vfx.reset();same();},dispose(){for(const h of [a,b])h.vfx.dispose();same();}};
}
test('R same-tick settled field retains arrays/uploads while continuous fade changes',()=>{
 const p=pair();p.event();p.tick(.601);const before=versions(p.b),alpha=field(p.b).material.uniforms.uOpacity.value;
 p.tick(.002);assert.deepEqual(versions(p.b),before);assert(field(p.b).material.uniforms.uOpacity.value<alpha);assert(field(p.b).visible);assert.equal(field(p.b).geometry.drawRange.count,1206*6);
 p.tick(.031);assert.notDeepEqual(versions(p.b),before);p.dispose();
});
test('R growing radius invalidates even inside one source tick; flash continues after growth',()=>{
 const p=pair();p.event();p.tick(.201);const before=versions(p.b),array=field(p.b).geometry.attributes.position.array.slice();p.tick(.002);assert.notDeepEqual(versions(p.b),before);assert.notDeepEqual(field(p.b).geometry.attributes.position.array,array);
 p.tick(.018);const settled=versions(p.b),release=field(p.b).parent.children.find(o=>o.isSprite),opacity=release.material.opacity;p.tick(.002);assert.deepEqual(versions(p.b),settled);assert(release.material.opacity<opacity);assert(release.visible);p.tick(.016);const cutoff=versions(p.b);p.tick(.002);assert.deepEqual(versions(p.b),cutoff);assert(!release.visible);p.dispose();
});
test('R gaps use epsilon-shifted source frame even when geometry tick has not changed',()=>{
 const p=pair();p.event();
 for(const boundary of [15/30,17/30,21/30,22/30]){
  const before=boundary-4e-9,current=p.b.vfx.inspect().fieldAge;if(before>current)p.tick(before-current);
  const oldTick=Math.floor(p.b.vfx.inspect().fieldAge*30);p.tick(2e-9);assert.equal(Math.floor(p.b.vfx.inspect().fieldAge*30),oldTick);
  const source=Math.floor(p.b.vfx.inspect().fieldAge*30+1e-7),gap=[15,16,21].includes(source);assert.equal(field(p.b).geometry.drawRange.count===0,gap);
  p.tick(5e-9);
 }
 p.dispose();
});
test('R current v48 full state remains exact at 30/60/120 Hz and irregular updates',()=>{
 const p=pair();for(const hz of [30,60,120]){p.reset();p.event({position,groundY:-.2,targets:[{x:1,y:1,z:2}]});for(let i=0;i<=hz;i++)p.tick(1/hz,{moving:i%2===0,thirdPerson:i%3===0,status:vfxStatus('E_Hold',i/hz,{armed:3,boost:2})});}
 p.reset();p.event();for(const dt of [.001,.13,.0001,.087,.001,.02,.009,.1,.001,.05,.15,.003,.2,1000])p.tick(dt);p.dispose();
});
test('R consecutive discharges, reset, expired field and new positions never reuse stale geometry',()=>{
 const p=pair();p.event();const first=field(p.b).geometry.attributes.position.array.slice();p.event({position:{x:-4,y:8,z:3},groundY:2});assert.notDeepEqual(field(p.b).geometry.attributes.position.array,first);
 p.tick(.601);p.reset();p.event();p.tick(.601);p.tick(.3);assert.equal(field(p.b).geometry.drawRange.count,0);p.event();p.tick(.601);p.event({position:{x:NaN,y:1,z:0}});p.tick(.002);p.dispose();
});
test('R invalid and paused updates preserve cache; dispose remains inert',()=>{
 const p=pair();p.event();p.tick(.601);const v=versions(p.b);for(const dt of [0,-1,NaN,Infinity,undefined])p.tick(dt);assert.deepEqual(versions(p.b),v);p.tick(.002);assert.deepEqual(versions(p.b),v);p.dispose();p.tick(.1);p.event();p.reset();
});
test('R cache is instance-local and direct delayed expiry preserves original flash material state',()=>{
 const p=pair(),other=createSkillVfxHarness(createSkillVfx);p.event();p.tick(.601);const before=versions(p.b);
 other.vfx.event('static_field_discharge',{position:{x:7,y:4,z:1}});other.vfx.update(.8,settings);other.vfx.reset();other.vfx.dispose();p.tick(.002);assert.deepEqual(versions(p.b),before);
 p.reset();p.event();p.tick(1000);p.dispose();
});
test('R differential comparison count is recorded',()=>{console.log('R_CACHE_EXACT_STATES '+comparisons);assert(comparisons>280);});
