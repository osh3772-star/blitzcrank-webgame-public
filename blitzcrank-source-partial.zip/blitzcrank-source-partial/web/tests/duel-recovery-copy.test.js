import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

const root=process.env.DUEL_INTERRUPT_APP_ROOT||fileURLToPath(new URL('../',import.meta.url));
const {createGameplayHarness}=await import(pathToFileURL(path.join(root,'tests/helpers/runtime-harness.js')));
const source=fs.readFileSync(process.env.DUEL_INTERRUPT_SOURCE||path.join(root,'main.js'),'utf8');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'duel-recovery-copy-'));
const normal=path.join(tmp,'main.mjs'),failed=path.join(tmp,'failed.mjs');
fs.writeFileSync(normal,source);
const match=source.match(/import \{planDuelPullPath,sampleDuelPullPath\} from '([^']+)';/);assert(match);
fs.writeFileSync(failed,source.replace(match[0],`import {sampleDuelPullPath} from '${match[1]}'; const planDuelPullPath=()=>({ok:false,code:'TEST_UNSUPPORTED_ROUTE'});`));
let r;
const until=p=>{for(let i=0;i<300&&!p();i++)r.frames(1);assert(p(),'expected natural transition');};
const quiet=()=>r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0})});
const snapshot=()=>structuredClone({state:r.qa.state,duel:r.qa.duel,player:r.qa.player,hook:r.qa.hook,session:r.qa.session});
const lost=()=>{let prevented=false;r.element('game').listeners.webglcontextlost({preventDefault(){prevented=true;}});assert(prevented);};
const restored=()=>r.element('game').listeners.webglcontextrestored();
function score(){const count=r.qa.duel.match.history.length;r.game.data.duelBot.position.set(0,1.7,5);r.key('KeyR');until(()=>r.qa.duel.match.history.length===count+1);}
function start(){document.hidden=false;restored();r.element('duelmode').click();quiet();until(()=>r.qa.duel.active);}
function failedPull(){
 start();score();until(()=>r.qa.duel.active);r.game.data.duelBot.position.set(0,1.7,1);r.key('KeyQ');until(()=>r.qa.state==='paused');
 assert(r.qa.duel.pendingGrab);assert.deepEqual(r.qa.duel.match.scores.map(x=>x.points),[1,0]);assert.equal(r.qa.duel.match.history.length,1);
 assert.match(r.element('intro').textContent,/안전하게 계산하지 못해/);assert.match(r.element('start').innerHTML,/대전 새로 시작/);
}
r=await createGameplayHarness({sourcePath:failed,delta:()=>.05});
for(const action of ['enter','start','practice','pause'])test(`graphics recovery after refused Q route preserves restart explanation until explicit ${action}`,()=>{
 failedPull();const state=snapshot(),intro=r.element('intro').textContent,oldSession=r.qa.duel.match.sessionId;
 lost();assert.deepEqual(snapshot(),state);assert.equal(r.element('intro').textContent,intro,'a second interruption must not replace the route failure with a continue promise');
 for(const id of ['start','practice','duelmode','combopractice'])assert.equal(r.element(id).disabled,true);
 r.key('Enter');r.element('start').click();r.element('practice').click();r.element('pause').click();r.frames(20);assert.deepEqual(snapshot(),state,'graphics loss still blocks all recovery actions');
 restored();assert.deepEqual(snapshot(),state);assert.equal(r.element('intro').textContent,intro);assert.match(r.element('loadstatus').textContent,/대전 새로 시작/);assert.doesNotMatch(r.element('loadstatus').textContent,/계속하기/);
 assert.match(r.element('start').innerHTML,/대전 새로 시작/);assert.equal(r.element('pause').attributes['aria-label'],'대전 새로 시작');
 r.winListeners.blur();document.hidden=true;r.docListeners.visibilitychange();document.hidden=false;lost();restored();assert.deepEqual(snapshot(),state);assert.equal(r.element('intro').textContent,intro);
 if(action==='enter')r.key('Enter');else r.element(action).click();quiet();assert.notEqual(r.qa.duel.match.sessionId,oldSession);assert.equal(r.qa.duel.match.phase,'countdown');assert.deepEqual(r.qa.duel.match.scores.map(x=>x.points),[0,0]);assert.equal(r.qa.duel.pendingGrab,null);assert.equal(r.qa.hook,null);
});
test('leaving route failure during graphics loss clears stale restart guidance before ordinary play',()=>{
 failedPull();lost();r.element('mainmenu').click();restored();assert.equal(r.qa.state,'menu');assert.equal(r.qa.duel,null);assert.match(r.element('intro').innerHTML,/수정 마법사/);assert.doesNotMatch(r.element('loadstatus').textContent,/대전 새로 시작/);
 r.element('practice').click();assert.equal(r.qa.duel,null);assert.equal(r.qa.session.score,0);
});
test('valid pending Q remains a resumable same-session pull after graphics recovery and scores once',async()=>{
 r=await createGameplayHarness({sourcePath:normal,delta:()=>.05});start();r.game.data.duelBot.position.set(0,1.7,1);r.key('KeyQ');until(()=>!!r.qa.duel.pendingGrab);
 lost();const state=snapshot(),session=r.qa.duel.match.sessionId;r.frames(60);assert.deepEqual(snapshot(),state);restored();assert.match(r.element('loadstatus').textContent,/계속하기/);assert.doesNotMatch(r.element('intro').textContent,/안전하게 계산하지 못해/);assert.deepEqual(snapshot(),state);
 r.key('Enter');assert.equal(r.qa.duel.match.sessionId,session);until(()=>r.qa.duel.match.history.length===1);assert.equal(r.qa.duel.match.remainingMs,3000);r.frames(59);assert.equal(r.qa.duel.match.phase,'roundReset');r.frames(1);assert.equal(r.qa.duel.match.phase,'countdown');assert.equal(r.qa.duel.match.roundNumber,2);assert.equal(r.qa.duel.match.history.length,1);
});
for(const phase of ['roundReset','matchComplete'])test(`ordinary ${phase} graphics pause resumes the same score and remaining three-second hold`,()=>{
 start();for(let point=1;point<=(phase==='matchComplete'?3:1);point++){score();if(point<(phase==='matchComplete'?3:1))until(()=>r.qa.duel.active);}
 assert.equal(r.qa.duel.match.phase,phase);r.frames(5);lost();const state=snapshot(),session=r.qa.duel.match.sessionId;r.frames(80);restored();assert.deepEqual(snapshot(),state);assert.match(r.element('loadstatus').textContent,/계속하기/);
 r.element('start').click();assert.equal(r.qa.duel.match.sessionId,session);r.frames(54);assert.equal(r.qa.state,'running');r.frames(1);assert.equal(phase==='matchComplete'?r.qa.state:r.qa.duel.match.phase,phase==='matchComplete'?'results':'countdown');
});
