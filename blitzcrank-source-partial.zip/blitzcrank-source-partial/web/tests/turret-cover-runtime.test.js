import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const h=await createGameplayHarness();
function run(position){h.game.begin(true);h.game.data.player.set(...position);const events=[];for(let i=0;i<120;i++){h.frames(1);events.push(...h.game.data.turretArena.sim.events);}return events;}
test('actual scene cover stops a radius-grazing shot before it reaches a legal player position',()=>{
 const p=[-7.4,1.7,-27];h.game.begin(true);assert(h.game.data.obstacles.every(o=>!(p[0]>o.min.x-.42&&p[0]<o.max.x+.42&&p[2]>o.min.z-.42&&p[2]<o.max.z+.42&&p[1]-1.7<o.max.y)));
 const records=h.qa.records,events=run(p);assert.equal(h.qa.health,100);assert.equal(events.filter(e=>e.type==='shot').length,1);assert.equal(events.filter(e=>e.type==='hit').length,0);assert.equal(events.filter(e=>e.type==='blocked').length,1);assert.equal(h.qa.turrets.bullets,0);assert.equal(h.qa.state,'running');assert.equal(h.qa.session.practice,true);assert.deepEqual(h.qa.records,records);
});
test('actual unobstructed scene shot retains one 18-point damage event',()=>{
 const events=run([-8,1.7,-12]);assert.equal(h.qa.health,82);assert.equal(events.filter(e=>e.type==='hit').length,1);assert.equal(events.find(e=>e.type==='hit').damage,18);assert.equal(h.qa.state,'running');
});
