import test from 'node:test';
import assert from 'node:assert/strict';
import {read,rules,style,scope,value,verify,overlap} from './helpers/mobile-layout-model.js';
const flashRules=rules(read('flash-controls.css'));
function box(c){
 const vars=style(scope,c),root={...style('#flashcontrol',c,flashRules),...style(scope+' #flashcontrol',c,flashRules)},button={...style('#flashbutton',c,flashRules),...style(scope+' #flashbutton',c,flashRules)},caption={...style('#flashcontrol>small',c,flashRules),...style(scope+' #flashcontrol>small',c,flashRules)},n=s=>value(s,c,vars),height=n(button.height)+(caption.display==='none'?0:n(root.gap)+n(caption['line-height']));
 return {x:root.left==='auto'?c.width-n(root.right)-n(root.width):n(root.left),y:c.height-n(root.bottom)-height,w:n(root.width),h:height};
}
test('icon control keeps one semantic button/status and the existing stylesheet order',()=>{const html=read('index.html');for(const id of ['flashcontrol','flashbutton','flashstatus'])assert.equal((html.match(new RegExp('id="'+id+'"','g'))||[]).length,1);assert.match(html,/id="flashbutton" type="button"[^>]+aria-describedby="flashstatus"/);assert(html.indexOf('href="flash-controls.css?')>html.indexOf('href="mobile-interface.css?'));assert.match(read('flash-controls.css'),/touch-action:none/);});
test('flash icon control stays in safe area and separate from existing touch inputs across viewport sweep',()=>{
 let count=0;
 for(let width=320;width<=1024;width+=16)for(let height=320;height<=1104;height+=28){
  if(width<=height&&height<568||width>height&&width<480)continue;
  for(const safe of [{},{'safe-area-inset-left':width>height?44:16,'safe-area-inset-right':width>height?44:16,'safe-area-inset-top':width>height?0:59,'safe-area-inset-bottom':width>height?21:34}]){
   const c={width,height,safe},old=verify(c),flash=box(c);
   assert(flash.x>=(safe['safe-area-inset-left']||0)&&flash.y>=(safe['safe-area-inset-top']||0));assert(flash.x+flash.w<=width-(safe['safe-area-inset-right']||0));assert(flash.y+flash.h<=height-(safe['safe-area-inset-bottom']||0));assert(flash.w>=44&&flash.h>=44);
   for(const [name,b] of Object.entries(old))assert.equal(overlap(flash,b),0,`${width}x${height} flash/${name}`);
   count++;
  }
 }
 assert(count>1800);
});

// Source box calculations only, not browser layout. Local text metrics below were
// measured with Pillow and the installed Noto Sans CJK KR regular/bold fonts.
function content(c,touch){
 const button={...style('#flashbutton',c,flashRules),...(touch?style(scope+' #flashbutton',c,flashRules):{})},n=parseFloat;
 const columns=button['grid-template-columns'].split(' ').map(n),rows=button['grid-template-rows'].split(' ').map(n);
 const gapX=n(button['column-gap']),gapY=n(button['row-gap']),w=n(button.width),h=n(button.height),padding=n(button.padding),border=n(button.border);
 const contentW=w-2*(padding+border),contentH=h-2*(padding+border),gridW=columns.reduce((a,b)=>a+b)+gapX,gridH=rows.reduce((a,b)=>a+b)+gapY*(rows.length-1);
 const x=(w-gridW)/2,y=(h-gridH)/2,copy=style('#flashbutton .flash-copy',c,flashRules),label=style('#flashbutton .flash-name',c,flashRules),status=style('#flashbutton small',c,flashRules),copyH=n(label['line-height'])+n(copy.gap)+n(status['line-height']);
 return {w,h,contentW,contentH,gridW,gridH,icon:{x,y,w:32,h:32},copy:{x:x+columns[0]+gapX,y:(h-copyH)/2,w:n(copy.width),h:copyH},key:touch?null:{x,y:y+rows[0]+gapY,w:columns[0],h:rows[1]},label,status};
}
test('original 76px button footprint fits separate icon, key, name and cooldown lanes',()=>{
 for(const touch of [false,true]){
  const c={width:touch?390:1280,height:touch?844:800},b=content(c,touch);
  assert.equal(b.w,76);assert.equal(b.h,touch?50:54);
  assert(b.gridW<=b.contentW);assert(b.gridH<=b.contentH);
  const lanes=[b.icon,b.copy,...(b.key?[b.key]:[])];
  for(const lane of lanes){assert(lane.x>=4&&lane.y>=4);assert(lane.x+lane.w<=b.w-4);assert(lane.y+lane.h<=b.h-4);}
  for(let i=0;i<lanes.length;i++)for(let j=i+1;j<lanes.length;j++)assert.equal(overlap(lanes[i],lanes[j]),0);
  // The local font's measured maximum status width includes every integer 1..15.
  for(const measurement of [{width:22.09375,height:12,size:12,line:b.label},{width:22.34375,height:11,size:11,line:b.status}]){
   assert.equal(parseFloat(measurement.line['font-size']),measurement.size);
   assert(measurement.width<b.copy.w);assert(measurement.height<=parseFloat(measurement.line['line-height']));
  }
  if(b.key){assert(5.84375+6<=b.key.w);assert(8<=b.key.h);}
 }
});
test('Flash remains separate when existing touch buttons are visually pressed in edge-size layouts',()=>{
 for(const [width,height] of [[320,568],[390,844],[480,320],[568,320],[844,390],[1024,768]]){
  const c={width,height,safe:{'safe-area-inset-left':width>height?44:16,'safe-area-inset-right':width>height?44:16,'safe-area-inset-top':width>height?0:59,'safe-area-inset-bottom':width>height?21:34}},flash=box(c);
  for(const [name,b] of Object.entries(verify(c,{pressed:63})))assert.equal(overlap(flash,b),0,`${width}x${height} flash/pressed ${name}`);
 }
});

test('mobile Flash belongs to the right action cluster while desktop footprint and inner labels stay intact',()=>{
 for(const c of [{width:320,height:568},{width:390,height:844},{width:480,height:320},{width:844,height:390}]){
  const root=style(scope+' #flashcontrol',c,flashRules),f=box(c);assert.equal(root.left,'auto');assert(f.x+f.w/2>c.width/2);assert.equal(f.w,76);assert.equal(f.h,50);assert.equal(style(scope+' #flashcontrol>small',c,flashRules).display,'none');assert.notEqual(style('#flashbutton .flash-copy',c,flashRules).display,'none');
 }
 assert.equal(style('#flashcontrol',{width:1280,height:800},flashRules).width,'76px');assert.equal(style('#flashbutton',{width:1280,height:800},flashRules).height,'54px');
});
test('right Flash has no overlap even when it and other mobile buttons independently depress by2px',()=>{
 let count=0,min=Infinity;
 for(let width=320;width<=1024;width+=16)for(let height=320;height<=1104;height+=28){
  if(width<=height&&height<568||width>height&&width<480)continue;
  for(const safe of [{},{'safe-area-inset-left':width>height?44:16,'safe-area-inset-right':width>height?44:16,'safe-area-inset-top':width>height?0:59,'safe-area-inset-bottom':width>height?21:34}])for(const mask of [0,63])for(const flashPressed of [false,true]){
   const c={width,height,safe},f=box(c);f.y+=flashPressed?2:0;
   assert(f.x>=(safe['safe-area-inset-left']||0)&&f.y>=(safe['safe-area-inset-top']||0));assert(f.x+f.w<=width-(safe['safe-area-inset-right']||0)&&f.y+f.h<=height-(safe['safe-area-inset-bottom']||0));
   for(const [name,b]of Object.entries(verify(c,{pressed:mask}))){assert.equal(overlap(f,b),0,`${width}x${height} flash/${name} pressed=${flashPressed}`);if(['W','E','R','jump','punch','Q','joystick','brand','view','pause'].includes(name)){const dx=Math.max(0,b.x-f.x-f.w,f.x-b.x-b.w),dy=Math.max(0,b.y-f.y-f.h,f.y-b.y-b.h);min=Math.min(min,Math.hypot(dx,dy));}}
   count++;
  }
 }
 assert.equal(count,9648);assert.equal(min,6,'Flash pressed moves down2px, reducing landscape8px gap to6px');
});
test('right Flash meets all128 independent press masks at compact portrait and landscape safe-area sizes',()=>{
 for(const [width,height]of [[320,568],[390,844],[480,320],[568,320],[844,390],[1024,768]])for(let mask=0;mask<128;mask++){
  const c={width,height,safe:{'safe-area-inset-left':width>height?44:16,'safe-area-inset-right':width>height?44:16,'safe-area-inset-top':width>height?0:59,'safe-area-inset-bottom':width>height?21:34}},f=box(c);if(mask&64)f.y+=2;
  for(const [name,b]of Object.entries(verify(c,{pressed:mask&63})))assert.equal(overlap(f,b),0,`${width}x${height} mask${mask} ${name}`);
 }
});
