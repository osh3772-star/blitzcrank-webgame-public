import * as THREE from '../vendor/three.module.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createHookMatrixHarness} from './helpers/hook-matrix-harness.js';

const coverage=new Map();
let deferredMatrixEvidence=null;
function snapshot({fullbody,fullbodySocket,hook}){
 const objects=[];fullbody.traverse(object=>objects.push(object));
 for(let object=fullbody.parent;object;object=object.parent)objects.push(object);
 return {objects,states:objects.map(object=>({position:object.position.toArray(),quaternion:object.quaternion.toArray(),rotation:object.rotation.toArray(),scale:object.scale.toArray(),matrix:object.matrix.elements.slice(),matrixWorld:object.matrixWorld.elements.slice(),matrixAutoUpdate:object.matrixAutoUpdate,matrixWorldAutoUpdate:object.matrixWorldAutoUpdate,matrixWorldNeedsUpdate:object.matrixWorldNeedsUpdate,visible:object.visible})),socket:fullbodySocket.toArray(),hook:hook?{phase:hook.phase,phaseTime:hook.phaseTime,position:hook.position.toArray(),direction:hook.direction.toArray(),bodyOrientation:hook.bodyOrientation?.toArray(),orientation:hook.orientation?.toArray(),returnStart:hook.returnStart?.toArray(),returnDuration:hook.returnDuration}:null};
}
function restore(saved,{fullbodySocket}){
 saved.objects.forEach((object,index)=>{
  const state=saved.states[index];object.position.fromArray(state.position);object.scale.fromArray(state.scale);
  // Restore the exact pre-call Euler and quaternion, without triggering an
  // onChange conversion and introducing rounding into the comparison inputs.
  [object.quaternion._x,object.quaternion._y,object.quaternion._z,object.quaternion._w]=state.quaternion;
  [object.rotation._x,object.rotation._y,object.rotation._z,object.rotation._order]=state.rotation;
  object.matrix.fromArray(state.matrix);object.matrixWorld.fromArray(state.matrixWorld);
  for(const key of ['matrixAutoUpdate','matrixWorldAutoUpdate','matrixWorldNeedsUpdate','visible'])object[key]=state[key];
 });
 fullbodySocket.fromArray(saved.socket);
}
function exactFields(actual,expected,fields,label,objects){
 assert.equal(actual.length,expected.length,label+' object count');
 for(let i=0;i<actual.length;i++)for(const field of fields){
  const a=actual[i][field],b=expected[i][field],where=label+' '+i+' '+objects[i].name+' '+field;
  if(Array.isArray(a)){assert.equal(a.length,b.length,where+' length');for(let j=0;j<a.length;j++)assert(Object.is(a[j],b[j]),where+'['+j+']: '+String(a[j])+' != '+String(b[j]));}
  else assert(Object.is(a,b),where+': '+String(a)+' != '+String(b));
 }
}
function compare(candidate,reference,getData){
 const data=getData(),before=snapshot(data),phase=data.hook?.phase||'idle';
 const fields=Object.keys(before.states[0]);
 const localFields=fields.filter(field=>field!=='matrix'&&field!=='matrixWorld'&&field!=='matrixWorldNeedsUpdate');
 let passes=0;const original=data.fullbody.updateMatrixWorld;
 data.fullbody.updateMatrixWorld=function(...args){passes++;return original.apply(this,args);};
 try{
  reference();const expectedImmediate=snapshot(data),baselinePasses=passes;
  // Three's normal renderer refreshes the scene before consuming descendants.
  // The approved hand-path optimization defers unrelated idle descendants to
  // this boundary; it does not defer sockets or the detached hand subtree.
  data.scene.updateMatrixWorld();const expectedRendered=snapshot(data);
  restore(before,data);passes=0;candidate();const actualImmediate=snapshot(data),candidatePasses=passes;
  if(!deferredMatrixEvidence){
   const index=before.objects.findIndex((o,i)=>o.name==='E_charged_fist_BC_Palm.L_surface'&&actualImmediate.states[i].matrix.some((v,k)=>!Object.is(v,expectedImmediate.states[i].matrix[k])));
   if(index>=0){deferredMatrixEvidence={phase,index,name:before.objects[index].name,matrixAutoUpdate:actualImmediate.states[index].matrixAutoUpdate,referenceMatrixAutoUpdate:expectedImmediate.states[index].matrixAutoUpdate,actualMatrix:actualImmediate.states[index].matrix,expectedMatrix:expectedImmediate.states[index].matrix};console.log('DEFERRED_LOCAL_MATRIX_CONTRACT '+JSON.stringify(deferredMatrixEvidence));}
  }
  assert.deepEqual(actualImmediate.socket,expectedImmediate.socket,phase+' immediate home socket');
  assert.deepEqual(actualImmediate.hook,expectedImmediate.hook,phase+' immediate hook state');
  exactFields(actualImmediate.states,expectedImmediate.states,localFields,phase+' immediate local transforms',before.objects);
  const detached=phase==='outbound'||phase==='return';
  if(detached)exactFields(actualImmediate.states,expectedImmediate.states,fields,phase+' immediate detached subtree',before.objects);
  else {
   // localToWorld refreshes the actual palm path even without a whole-tree pass.
   assert(data.palm?.isMesh,'actual right palm mesh is present');
   for(let node=data.palm;node;node=node.parent){
    const index=before.objects.indexOf(node);assert(index>=0,'complete palm ancestor chain is captured');
    exactFields([actualImmediate.states[index]],[expectedImmediate.states[index]],['matrix','matrixWorld'],phase+' immediate palm-chain matrices',[node]);
   }
  }
  assert.equal(baselinePasses,detached?3:1);assert.equal(candidatePasses,detached?1:0);
  data.scene.updateMatrixWorld();const actualRendered=snapshot(data);
  exactFields(actualRendered.states,expectedRendered.states,fields,phase+' normal-render transforms and dirty flags',before.objects);
  assert.deepEqual(actualRendered.socket,expectedRendered.socket,phase+' rendered socket');
  assert.deepEqual(actualRendered.hook,expectedRendered.hook,phase+' rendered hook state');
  coverage.set(phase,(coverage.get(phase)||0)+1);
 }catch(error){error.stack=error.name+': '+error.message;throw error;}finally{data.fullbody.updateMatrixWorld=original;}
}
const h=await createHookMatrixHarness({compare});
function fresh(third=false){h.game.begin(true);if((h.qa.view==='third')!==third)h.key('KeyV');for(const target of h.game.data.targets){target.active=false;target.respawn=Infinity;target.group.visible=false;}h.frames(1);}
function key(code){h.key(code);h.release(code);}
function mirror(){
 const {fullbody,fist,rope}=h.matrix.data,before={body:fullbody.visible,fist:fist.visible,start:rope.userData.start?.toArray(),end:rope.userData.end?.toArray(),count:rope.links.count,array:rope.links.instanceMatrix.array.slice()};
 const token=h.matrix.prepareMirrorBody();assert.equal(fullbody.visible,true);assert.equal(fist.visible,false);
 if(token.chain){assert.deepEqual(rope.userData.start.toArray(),h.matrix.fullbodyCableSocket().toArray());assert.deepEqual(rope.userData.end.toArray(),h.matrix.fullbodyChainSocket().toArray());}
 h.matrix.restoreMirrorBody(token);
 assert.equal(fullbody.visible,before.body);assert.equal(fist.visible,before.fist);
 assert.deepEqual(rope.userData.start?.toArray(),before.start);assert.deepEqual(rope.userData.end?.toArray(),before.end);assert.equal(rope.links.count,before.count);
 // Only active instances are rendered; unused tail slots can retain the mirror
 // preparation's longer chain and are intentionally ignored by Three.js.
 assert.deepEqual(rope.links.instanceMatrix.array.slice(0,before.count*16),before.array.slice(0,before.count*16));
}

test('idle, moving/rotating roots and basic punch match all legacy matrices exactly',()=>{
 for(const third of [false,true]){fresh(third);h.frames(20);h.key('KeyD');for(let i=0;i<30;i++){h.matrix.aim(2,-.2);h.frames(1);}h.release('KeyD');h.punch();h.frames(55);}
});
test('Q phases keep exact matrices, home socket and orientation while moving and switching views',()=>{
 for(const third of [false,true]){fresh(third);key('KeyQ');h.key('KeyS');for(let i=0;i<240;i++){h.matrix.aim(1,.1);if(i===23||i===51)key('KeyV');h.frames(1);if(h.matrix.data.hook?.phase==='return')assert(h.matrix.data.fullbodySocket.distanceTo(h.matrix.data.hook.position)>0);}h.release('KeyS');assert.equal(h.qa.hook,null);}
 for(const phase of ['idle','windup','outbound','return','recover'])assert(coverage.get(phase)>0,phase);
});
test('E hold and W boost preserve authored surface matrices through Q interruption and recovery',()=>{
 for(const third of [false,true]){fresh(third);key('KeyE');h.frames(53);assert.equal(h.qa.skills.phase,'E_Hold');assert(h.matrix.data.fullbodySurfaces.every(mesh=>!mesh.matrixAutoUpdate));key('ShiftLeft');key('KeyQ');h.key('KeyD');for(let i=0;i<150;i++){h.matrix.aim(.4,0);h.frames(1);}h.release('KeyD');assert.equal(h.qa.hook,null);assert.equal(h.qa.skills.phase,'E_Hold');h.punch();h.frames(110);key('KeyR');h.frames(90);}
});
test('mirror preparation/restoration preserves exact chain and visibility in every hook phase',()=>{
 for(const third of [false,true]){fresh(third);mirror();key('KeyQ');for(let i=0;i<150;i++){h.frames(1);mirror();}assert.equal(h.qa.hook,null);}
});
test('paused hook view switches and restart preserve exact transforms and attachment state',()=>{
 fresh();key('KeyQ');h.frames(20);h.game.pause();const position=h.matrix.data.hook.position.toArray();key('KeyV');mirror();h.frames(40);assert.deepEqual(h.matrix.data.hook.position.toArray(),position);h.game.resume();h.frames(150);assert.equal(h.qa.hook,null);fresh();h.frames(1);assert(h.matrix.data.fullbodySurfaces.every(mesh=>mesh.matrixAutoUpdate));
});
test('detached hook fallback orientation and refreshed scene ancestors match legacy exactly',t=>{
 fresh(true);key('KeyQ');h.frames(20);const {scene,hook}=h.matrix.data;
 hook.bodyOrientation=undefined;scene.position.set(.2,-.1,.4);scene.rotation.set(.1,.2,-.05);scene.scale.setScalar(1.1);
 try{h.matrix.updateFullbodyHand();h.frames(3);}finally{scene.position.set(0,0,0);scene.rotation.set(0,0,0);scene.scale.setScalar(1);scene.updateMatrixWorld(true);}
 h.frames(150);assert.equal(h.qa.hook,null);t.diagnostic('Exact legacy-oracle call coverage: '+JSON.stringify(Object.fromEntries(coverage)));
});


test('contract oracle rejects immediate socket and post-render descendant matrix corruption',t=>{
 function fixture(){
  const scene=new THREE.Scene(),fullbody=new THREE.Group(),geometry=new THREE.BoxGeometry(.1,.1,.1),material=new THREE.MeshBasicMaterial();
  const palm=new THREE.Mesh(geometry,material),leaf=new THREE.Mesh(geometry,material);palm.name='auditPalm';leaf.name='auditUnrelatedChild';
  fullbody.add(palm,leaf);scene.add(fullbody);palm.position.set(.2,.3,.4);leaf.position.set(-.2,.1,.5);
  const data={scene,fullbody,palm,hook:null,fullbodySocket:new THREE.Vector3()};
  const refresh=eager=>{if(eager)fullbody.updateMatrixWorld(true);data.fullbodySocket.copy(palm.localToWorld(new THREE.Vector3()));};
  t.after(()=>{geometry.dispose();material.dispose();});
  return {data,leaf,reference:()=>refresh(true),candidate:()=>refresh(false)};
 }
 const valid=fixture();compare(valid.candidate,valid.reference,()=>valid.data);
 const socket=fixture();assert.throws(()=>compare(()=>{socket.candidate();socket.data.fullbodySocket.x+=.01;},socket.reference,()=>socket.data),/immediate home socket/);
 const matrix=fixture(),update=matrix.data.scene.updateMatrixWorld;let renders=0;
 matrix.data.scene.updateMatrixWorld=function(...args){const result=update.apply(this,args);if(++renders===2)matrix.leaf.matrixWorld.elements[12]+=.01;return result;};
 assert.throws(()=>compare(matrix.candidate,matrix.reference,()=>matrix.data),/normal-render transforms and dirty flags .*matrixWorld\[12\]/);
 t.diagnostic('Negative controls rejected: immediate socket +0.01; unrelated descendant world-matrix[12] +0.01 after normal render. Unmodified control passed.');
});
