import {assertApprovedSkillClips,POSE_BOUNDARY_REPLAY_COUNT} from './helpers/approved-skill-clips.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {THREE,poseFixture,poseState} from './helpers/pose-run-harness.js';
import {createFullbodyPoseApplicator,clearFullbodySkillPose} from '../skill-animation.js';
import {createFullbodyPoseApplicator as original} from './fixtures/skill-animation-v0.24.48-baseline.js';
const p=(n=0)=>({p:[n,.2*n,-n],q:[.1*n,.2*n,.3*n,1],s:[1+n*.01,1,1-n*.01]});
function tiny(posesA,posesB){const surfaces=posesA.map((_,i)=>{const o=new THREE.Object3D();o.name='mesh'+i;o.userData.skillRestPoint=[i*.2,-i*.1,i*.3];return o;});return {surfaces,clip:{fps:1,duration:1,loop:false,frames:[{poses:posesA},{poses:posesB}]}};}
function compareTiny(posesA,posesB){const a=tiny(posesA,posesB),b=tiny(posesA,posesB),apply=createFullbodyPoseApplicator(THREE),ref=original(THREE);return {a,b,check(time){apply(a.clip,time,a.surfaces);ref(b.clip,time,b.surfaces);assert.deepEqual(poseState(a),poseState(b));}};}
test('actual 279 surfaces match frozen v48 at every authored frame and midpoint, boundaries and replay',()=>{
 const a=poseFixture(),b=poseFixture(),apply=createFullbodyPoseApplicator(THREE),ref=original(THREE);let comparisons=0;
 for(let ci=0;ci<a.clips.length;ci++) {const clip=a.clips[ci],times=[-1,0,clip.duration,clip.duration+1,100];for(let i=0;i<clip.frames.length;i++){times.push(i/clip.fps,(i+.37)/clip.fps);}times.push(.1,.1,0);
  for(const t of times){apply(clip,t,a.surfaces);ref(b.clips[ci],t,b.surfaces);assert.deepEqual(poseState(a),poseState(b));assert.deepEqual(poseState(a,{world:true}),poseState(b,{world:true}));comparisons++;}
  clearFullbodySkillPose(a.surfaces);clearFullbodySkillPose(b.surfaces);assert.deepEqual(poseState(a),poseState(b));
 }
 assertApprovedSkillClips(a.clips);assert.equal(POSE_BOUNDARY_REPLAY_COUNT,444);assert.equal(comparisons,POSE_BOUNDARY_REPLAY_COUNT);
});
test('adjacent shared endpoints reuse compose once per actual source run',()=>{
 const h=poseFixture(),apply=createFullbodyPoseApplicator(THREE),compose=THREE.Matrix4.prototype.compose;let calls=0;
 THREE.Matrix4.prototype.compose=function(...args){calls++;return compose.apply(this,args);};
 try{apply(h.clips[0],.13,h.surfaces);}finally{THREE.Matrix4.prototype.compose=compose;}
 assert.equal(h.surfaces.length,279);assert.equal(calls,163);
});
test('shared poses keep independent rest transforms and never reuse across calls or time',()=>{
 const x=p(1),y=p(4),h=compareTiny([x,x,x],[y,y,y]);for(const t of [0,.17,.93,1,.17])h.check(t);
 x.p[0]=8;x.q[2]=.7;y.s[0]=1.4;h.check(.17);
 h.a.surfaces[1].userData.skillRestPoint[0]=7;h.b.surfaces[1].userData.skillRestPoint[0]=7;h.check(.17);
 assert.notDeepEqual(h.a.surfaces[0].matrix.toArray(),h.a.surfaces[1].matrix.toArray());
});
test('either endpoint changing forces interpolation and nonadjacent repeats are safe',()=>{
 const x=p(1),y=p(2),z=p(3);const h=compareTiny([x,x,z,x],[y,z,z,y]);for(const t of [0,.23,1,.5])h.check(t);
});
test('call-local reuse survives different clips, reordered surfaces and empty calls',()=>{
 const a=poseFixture(),b=poseFixture(),apply=createFullbodyPoseApplicator(THREE),ref=original(THREE);
 for(const ci of [0,6,2,0,4]) {apply(a.clips[ci],.19,a.surfaces);ref(b.clips[ci],.19,b.surfaces);assert.deepEqual(poseState(a),poseState(b));apply(a.clips[ci],.19,[]);}
 const order=a.surfaces.map((_,i)=>i).reverse();a.surfaces=order.map(i=>a.surfaces[i]);b.surfaces=order.map(i=>b.surfaces[i]);
 const ac={...a.clips[0],frames:a.clips[0].frames.map(f=>({poses:order.map(i=>f.poses[i])}))},bc={...b.clips[0],frames:b.clips[0].frames.map(f=>({poses:order.map(i=>f.poses[i])}))};apply(ac,.2,a.surfaces);ref(bc,.2,b.surfaces);assert.deepEqual(poseState(a),poseState(b));
});
test('reused endpoints still validate each rest point and malformed first endpoint throws',()=>{
 const x=p(1),h=tiny([x,x],[x,x]);delete h.surfaces[1].userData.skillRestPoint;assert.throws(()=>createFullbodyPoseApplicator(THREE)(h.clip,.5,h.surfaces),/Missing skill rest/);
 for(const value of [null,undefined]){const h=tiny([value],[value]);assert.throws(()=>createFullbodyPoseApplicator(THREE)(h.clip,.5,h.surfaces),TypeError);assert.throws(()=>original(THREE)(h.clip,.5,h.surfaces),TypeError);}
});
