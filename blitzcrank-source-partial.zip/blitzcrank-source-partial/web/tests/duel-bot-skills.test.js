import test from 'node:test';
import assert from 'node:assert/strict';
import { createDuelBotInputs } from '../duel-bot-inputs.js';
const tuning = {playerSpeed:6.4, hookSpeed:42, maxRange:32, cooldown:2.2, windup:.25};
const make = (options={}) => createDuelBotInputs({seed:42,tuning,arena:{min:{x:-30,z:-40},max:{x:30,z:30}},...options});
const obs = (self={}, extra={}) => ({active:true,dt:1/60,canSeeOpponent:true,self:{position:{x:0,y:1.7,z:0},yaw:0,pitch:0,cooldown:0,canCastQ:false,skills:{phase:null,cooldown:{E:0,R:0},armed:0},...self},opponent:{position:{x:0,y:1.7,z:-3},velocity:{x:0,y:0,z:0}},...extra});
const run = (bot, observation, frames=120) => Array.from({length:frames},()=>bot.step(observation));
const noSkills = out => !out.castE && !out.strikeE && !out.castR;

test('skill commands wait for perception and E charge precedes an armed strike',()=>{
 const bot=make();
 assert.ok(run(bot,obs(),13).every(noSkills));
 assert.ok(run(bot,obs()).some(out=>out.castE));
 assert.ok(run(bot,obs({skills:{phase:'E_Charge',cooldown:{E:4,R:0},armed:0}})).every(noSkills));
 const hold=run(bot,obs({skills:{phase:'E_Hold',cooldown:{E:4,R:0},armed:4}}));
 assert.ok(hold.some(out=>out.strikeE)); assert.ok(hold.every(out=>!out.castE&&!out.castR));
});

test('R is a delayed in-range alternative while E is unavailable',()=>{
 const frames=run(make(),obs({skills:{phase:null,cooldown:{E:3,R:0},armed:0}}));
 assert.ok(frames.some(out=>out.castR)); assert.ok(frames.every(out=>!out.castE&&!out.strikeE));
});

test('explicit restrictions, hook, phases, invalid cooldown and unarmed hold suppress skills',()=>{
 for(const self of [
  {canCastE:false,canCastR:false}, {hookActive:true},
  {skills:{phase:'R_Cast',cooldown:{E:0,R:0},armed:0}},
  {skills:{phase:null,cooldown:{E:NaN,R:Infinity},armed:0}},
  {skills:{phase:'E_Hold',cooldown:{E:0,R:0},armed:0}},
  {skills:{phase:'E_Hold',cooldown:{E:0,R:0},armed:4},canStrikeE:false},
 ]) assert.ok(run(make(),obs(self)).every(noSkills),JSON.stringify(self));
});

test('skill range decisions cannot react immediately to newly observed close target',()=>{
 const bot=make();run(bot,obs({}, {opponent:{position:{x:0,y:1.7,z:-20}}}));
 assert.ok(run(bot,obs(),13).every(noSkills));
 assert.ok(run(bot,obs()).some(out=>out.castE));
});

test('cover suppresses skill casts and reacquisition restarts reaction delay',()=>{
 const bot=make();run(bot,obs({canCastE:false,canCastR:false}));
 assert.ok(run(bot,obs({}, {canSeeOpponent:false})).every(noSkills));
 assert.ok(run(bot,obs(),13).every(noSkills));
 assert.ok(run(bot,obs()).some(out=>out.castE));
 const wall={min:{x:-4,y:0,z:-2},max:{x:4,y:4,z:-1}};
 assert.ok(run(make({obstacles:[wall]}),obs()).every(noSkills));
});

test('skill mode can still choose a close E attack within its mixed movement',()=>{
 const bot=make();let position={x:0,y:1.7,z:16};let minimum=Infinity,charged=false,struck=false;
 for(let i=0;i<600;i++){
  const skills=charged?{phase:'E_Hold',cooldown:{E:4,R:0},armed:4}:{phase:null,cooldown:{E:0,R:0},armed:0};
  const out=bot.step(obs({position,skills}));charged ||=out.castE;struck ||=out.strikeE;
  position={x:position.x+out.move.x*6.4/60,y:1.7,z:position.z+out.move.z*6.4/60};
  minimum=Math.min(minimum,Math.hypot(position.x,position.z+3));
 }
 assert.ok(minimum<3);assert.ok(charged);assert.ok(struck);
});

test('skill cadence uses command edges, replays on reset and pauses without time changes',()=>{
 for(const self of [{},{skills:{phase:null,cooldown:{E:2,R:0},armed:0}},{skills:{phase:'E_Hold',cooldown:{E:2,R:0},armed:4}}]){
  const bot=make(), first=run(bot,obs(self),900);
  for(let i=1;i<first.length;i++)for(const k of ['castE','strikeE','castR'])assert.ok(!(first[i][k]&&first[i-1][k]));
  const state=bot.snapshot();assert.ok(run(bot,obs(self,{active:false})).every(noSkills));assert.deepEqual(bot.snapshot(),state);
  bot.reset();assert.deepEqual(run(bot,obs(self),900),first);
 }
});

test('without self.skills optional tuning cannot change legacy Q, movement, or random state',()=>{
 const a=make(),b=make({tuning:{...tuning,eRange:1,rRadius:2,eCooldown:1,rCooldown:1}});
 const observation=obs({skills:undefined,canCastQ:true});
 assert.deepEqual(run(a,observation,600),run(b,observation,600));assert.deepEqual(a.snapshot(),b.snapshot());
 assert.ok(run(a,observation).every(noSkills));
});
