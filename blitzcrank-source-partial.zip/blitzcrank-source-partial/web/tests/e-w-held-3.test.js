import {test,assert,THREE,baseline,fresh,snapshot,replay,createGameplayHarness} from './helpers/e-w-held-replay.js';
test('touch E W and actual captured joystick produce same presentation and gameplay as keys',async()=>{const a=await replay(undefined),b=await replay(undefined,{touch:true});assert.deepEqual(a,b);});
