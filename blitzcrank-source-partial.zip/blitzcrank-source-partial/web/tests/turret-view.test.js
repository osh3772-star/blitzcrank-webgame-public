import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import * as THREE from '../vendor/three.module.js';import {loadTurretModel,createTurretArena} from '../turret-view.js';
const asset=await loadTurretModel(async path=>{const b=fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url));return{ok:true,arrayBuffer:async()=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)};});
function fixture(){const scene=new THREE.Scene(),obstacles=[],hits=[];const arena=createTurretArena(scene,asset,obstacles,{onDamage:d=>hits.push(d)});return{arena,scene,obstacles,hits};}
test('actual turret GLB preserves static tower, yaw pivot, barrel and muzzle; two colliders placed',()=>{const{arena,obstacles}=fixture();assert.equal(arena.sim.turrets.length,2);assert.equal(obstacles.length,2);for(const v of arena.visuals.values()){assert(v.root.getObjectByName('StaticTower'));assert(v.head);assert(v.barrel);assert(v.muzzle);const height=new THREE.Box3().setFromObject(v.root).getSize(new THREE.Vector3()).y;assert(Math.abs(height-4.8)<1e-5);assert(v.root.position.y<0);}});
test('range warning, aimed muzzle shot, recoil and HP damage integrate without WebGL',()=>{const{arena,hits}=fixture(),player={x:-8,y:1.7,z:-12};arena.step(.1,player);assert(arena.warning);const v=arena.visuals.get('west');assert(v.line.visible);let shot;for(let i=0;i<50;i++){for(const e of arena.step(1/60,player)){if(e.type==='shot'&&!shot){shot=e;const muzzle=v.muzzle.getWorldPosition(new THREE.Vector3()),direction=v.muzzle.getWorldDirection(new THREE.Vector3()),velocity=new THREE.Vector3(e.velocity.x,e.velocity.y,e.velocity.z).normalize();assert(muzzle.distanceTo(new THREE.Vector3(e.position.x,e.position.y,e.position.z))<1e-6);assert(direction.dot(velocity)>.9999);}}}assert(shot);for(let i=0;i<60;i++)arena.step(1/60,player);assert(hits.length>0);assert.equal(hits[0],18);});
test('cover cancels acquisition and reset removes projectiles and warning visuals',()=>{const{arena,obstacles}=fixture(),player={x:-8,y:1.7,z:-12};arena.step(.2,player);assert(arena.warning);obstacles.push({min:new THREE.Vector3(-11,0,-16),max:new THREE.Vector3(-9,10,-13)});arena.step(.2,player);assert.equal(arena.warning,false);obstacles.pop();for(let i=0;i<60;i++)arena.step(1/60,player);arena.reset();assert.equal(arena.sim.bullets.length,0);assert.equal(arena.bulletMeshes.size,0);for(const v of arena.visuals.values()){assert.equal(v.line.visible,false);assert.equal(v.flare.visible,false);assert.equal(v.recoil,0);}});

test('acquisition callback runs once per lock while warning repeats, impacts retain hit identity',()=>{
 const acquisitions=[],warnings=[],shots=[],hits=[],lost=[];
 const arena=createTurretArena(new THREE.Scene(),asset,[],{
  onAcquired:e=>acquisitions.push(e),onLost:e=>lost.push(e),onWarning:e=>warnings.push(e),
  onShot:e=>shots.push(e),onDamage:(damage,e)=>hits.push({damage,event:e}),
 });
 const p={x:-8,y:1.7,z:-12};
 for(let i=0;i<480;i++) arena.step(1/60,p);
 assert.equal(acquisitions.length,1);assert.equal(acquisitions[0].type,'acquired');
 assert.ok(warnings.length>=3);assert.ok(shots.length>=3);assert.ok(hits.length>=3);
 assert.ok(hits.every(h=>h.event.type==='hit'&&h.event.damage===h.damage));
 assert.equal(new Set(hits.map(h=>h.event.bulletId)).size,hits.length);
 arena.step(.1,{x:0,y:1.7,z:7});assert.equal(lost.length,1);
 arena.step(.1,p);assert.equal(acquisitions.length,2);
 arena.reset();arena.step(.1,p);assert.equal(acquisitions.length,3);
});

test('reset from acquisition callback stops stale warnings, shots and hits',()=>{
 let arena;const warnings=[],shots=[],hits=[];
 arena=createTurretArena(new THREE.Scene(),asset,[],{
  onAcquired:()=>arena.reset(),onWarning:e=>warnings.push(e),onShot:e=>shots.push(e),onDamage:e=>hits.push(e),
 });
 arena.step(2,{x:-8,y:1.7,z:-12});
 assert.deepEqual(warnings,[]);assert.deepEqual(shots,[]);assert.deepEqual(hits,[]);
 assert.equal(arena.sim.bullets.length,0);assert.equal(arena.bulletMeshes.size,0);
 assert.ok(arena.sim.turrets.every(t=>!t.acquired));
});

test('blocked projectile never dispatches damage callback',()=>{
 const{arena,obstacles,hits}=fixture(),p={x:-8,y:1.7,z:-12};
 arena.step(.75,p);
 obstacles.push({min:new THREE.Vector3(-11,0,-16),max:new THREE.Vector3(-9,10,-13)});
 const events=[];for(let i=0;i<90;i++)events.push(...arena.step(1/60,p));
 assert.ok(events.some(e=>e.type==='blocked'));assert.equal(hits.length,0);
});


test('reset from lost callback clears the old warning and permits a clean new lock',()=>{
 let arena;const locks=[],lost=[];
 arena=createTurretArena(new THREE.Scene(),asset,[],{onAcquired:e=>locks.push(e),onLost:e=>{lost.push(e);arena.reset();}});
 const p={x:-8,y:1.7,z:-12};arena.step(.1,p);assert(arena.warning);
 arena.step(.1,{x:0,y:1.7,z:7});assert.equal(lost.length,1);assert.equal(arena.warning,false);
 assert.equal(arena.sim.bullets.length,0);assert.ok(arena.sim.turrets.every(t=>!t.acquired));
 for(const v of arena.visuals.values()){assert.equal(v.line.visible,false);assert.equal(v.flare.visible,false);}
 arena.step(.1,p);assert.equal(locks.length,2);assert(arena.warning);
});

test('lethal-hit reset stops further damage when one step generated multiple hits',()=>{
 let arena;const hits=[];
 arena=createTurretArena(new THREE.Scene(),asset,[],{onDamage:(amount,event)=>{hits.push({amount,event});arena.reset();}});
 const events=arena.step(6,{x:-8,y:1.7,z:-12});
 assert.ok(events.filter(e=>e.type==='hit').length>=2);assert.equal(hits.length,1);
 assert.equal(hits[0].event.type,'hit');assert.equal(hits[0].amount,18);
 assert.equal(arena.sim.bullets.length,0);assert.equal(arena.bulletMeshes.size,0);assert.equal(arena.warning,false);
});
