import test from 'node:test';import assert from 'node:assert/strict';import {fixture} from './turret-cover-fixture.js';
test('real west projectile grazes existing cover side and must block before player impact',()=>{
 const {a,hits}=fixture(),p={x:-7.4,y:1.7,z:-27},events=[];
 for(let i=0;i<120;i++)events.push(...a.step(1/60,p));
 assert.equal(events.filter(e=>e.type==='shot').length,1,'point sight remains clear and turret fires');
 assert.equal(events.filter(e=>e.type==='blocked').length,1);
 assert.equal(hits.length,0,'cover radius prevents the grazing shot from damaging player');
 assert.equal(a.sim.bullets.length,0);assert.equal(a.bulletMeshes.size,0);
});
test('clear west shot still hits exactly once',()=>{const {a,hits}=fixture();for(let i=0;i<120;i++)a.step(1/60,{x:-8,y:1.7,z:-12});assert.equal(hits.length,1);});
import {sweptSphereBox} from '../turret-view.js';
test('sphere-box corners do not falsely block expanded-AABB corner misses',()=>{
 const min={x:0,y:0,z:0},max={x:1,y:1,z:1};
 assert.equal(sweptSphereBox({x:-1,y:1.1,z:1.1},{x:2,y:1.1,z:1.1},min,max,.12),null);
 assert.ok(sweptSphereBox({x:-1,y:1.08,z:1.08},{x:2,y:1.08,z:1.08},min,max,.12)!==null);
 assert.equal(sweptSphereBox({x:.5,y:.5,z:.5},{x:.5,y:.5,z:.5},min,max,.12),0);
 assert.ok(Math.abs(sweptSphereBox({x:-1,y:.5,z:.5},{x:2,y:.5,z:.5},min,max,.12)-.88/3)<1e-12);
});
import {resolveFlashDestination} from './turret-cover-fixture.js';
test('real cross-turret Flash with jumping retains independent bullets and lethal reset clears all generations',()=>{
 let a;const f=fixture(()=>a.reset());a=f.a;let p={x:-1.2,y:1.7,z:-22.9},events=[];
 for(let i=0;i<45;i++)events.push(...a.step(1/60,p));
 const dest=resolveFlashDestination({position:p,yaw:-Math.atan2(24,11),isBlocked:(x,z)=>f.obs.some(o=>x>o.min.x-.42&&x<o.max.x+.42&&z>o.min.z-.42&&z<o.max.z+.42&&p.y-1.7<o.max.y)});
 assert.ok(dest);p=dest.position;let vy=7,overlap=false;
 for(let i=0;i<90;i++){vy-=20/60;p.y=Math.max(1.7,p.y+vy/60);events.push(...a.step(1/60,p));if(new Set(a.sim.bullets.map(b=>b.turretId)).size===2)overlap=true;if(f.hits.length)break;}
 assert.ok(overlap);assert.deepEqual(events.filter(e=>e.type==='shot').map(e=>e.turretId),['west','east']);
 assert.ok(events.some(e=>e.type==='blocked'&&e.turretId==='west'));assert.equal(f.hits.length,1);assert.equal(f.hits[0].turretId,'east');
 assert.equal(a.sim.bullets.length,0);assert.equal(a.bulletMeshes.size,0);assert.equal(a.warning,false);
 for(const v of a.visuals.values()){assert.equal(v.line.visible,false);assert.equal(v.flare.visible,false);}
 const newEvents=a.step(1/60,p);assert.equal(newEvents.filter(e=>e.type==='hit').length,0);assert.ok(newEvents.some(e=>e.type==='acquired'&&e.turretId==='east'));
});
test('sphere-box mathematical boundaries: tangent, initial overlap, large segment and miss',()=>{
 const min={x:0,y:0,z:0},max={x:1,y:1,z:1};
 const tangent=sweptSphereBox({x:-1,y:1.12,z:.5},{x:2,y:1.12,z:.5},min,max,.12);
 assert.ok(tangent!==null&&Math.abs(tangent-1/3)<1e-7);
 assert.equal(sweptSphereBox({x:-.1,y:.5,z:.5},{x:-2,y:.5,z:.5},min,max,.12),0);
 assert.ok(Math.abs(sweptSphereBox({x:-100,y:.5,z:.5},{x:100,y:.5,z:.5},min,max,.12)-99.88/200)<1e-12);
 assert.equal(sweptSphereBox({x:-2,y:2,z:2},{x:-2,y:2,z:2},min,max,.12),null);
});
test('nominal decimal tangent is stable while a 1e-10 outward near miss stays clear',()=>{
 const min={x:0,y:0,z:0},max={x:1,y:1,z:1};
 for(const x of [-.5,-1]){
  const hit=sweptSphereBox({x,y:1.12,z:.5},{x:1,y:1.12,z:.5},min,max,.12);
  assert.ok(hit!==null);assert.ok(Math.abs(hit-(-x)/(1-x))<1e-7);
  assert.equal(sweptSphereBox({x,y:1.12+1e-10,z:.5},{x:1,y:1.12+1e-10,z:.5},min,max,.12),null);
 }
});
test('wrapper handles zero-travel overlap without treating clear stationary projectiles as blocked',()=>{
 // Instrumented boundary: existing level does not naturally spawn a stationary
 // bullet in this cover. Exercise the real simulation->obstruction wrapper.
 for(const x of [-7.6,-7.7]){
  const {a,hits}=fixture();a.sim.bullets.push({id:999,turretId:'west',position:{x,y:2,z:-25},velocity:{x:0,y:0,z:0},age:0,active:true});
  const events=a.step(1/60,{x:0,y:1.7,z:7});
  assert.equal(events.filter(e=>e.type==='blocked').length,x===-7.6?1:0);
  assert.equal(a.sim.bullets.length,x===-7.6?0:1);assert.equal(hits.length,0);
 }
});
test('long-sweep decimal near misses do not gain collision from discriminant tolerance',()=>{
 const min={x:0,y:0,z:0},max={x:1,y:1,z:1};
 assert.equal(sweptSphereBox({x:-10000,y:1.12+1e-10,z:.5},{x:10000,y:1.12+1e-10,z:.5},min,max,.12),null);
});

test('positive-discriminant roots retain first contact despite floating-point distance residuals',()=>{
 const cases=[{"f":{"x":4.5612082607112825,"y":-32.95584959210828,"z":-37.51020090887323},"t":{"x":3.162381686270237,"y":-50.371737303212285,"z":-20.059264730662107},"min":{"x":-3.7334823049604893,"y":-39.75455330684781,"z":-29.625358376652002},"max":{"x":4.297989378683269,"y":-38.374258684925735,"z":-20.971165732480586},"r":0.9405420343391597,"a":null,"b":0.3985548671341071},{"f":{"x":3.752055277582258,"y":-26.367026057559997,"z":7.001129554118961},"t":{"x":15.982634648680687,"y":-34.95538436807692,"z":13.704883810132742},"min":{"x":14.411459919065237,"y":-35.46972708776593,"z":9.060078766196966},"max":{"x":21.187362405471504,"y":-29.04414280783385,"z":17.37179649528116},"r":0.12,"a":0.8715371789068123,"b":0.8617257058474439}];
 for(const c of cases){const actual=sweptSphereBox(c.f,c.t,c.min,c.max,c.r);assert.notEqual(actual,null);assert.ok(Math.abs(actual-c.b)<1e-10);}
});
