import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';import * as THREE from '../vendor/three.module.js';import {createGameplayHarness} from './helpers/runtime-harness.js';import{TARGET_MODEL_FILES}from'../target-models.js';
let delta=1/60;const h=await createGameplayHarness({delta:()=>delta,sourcePath:process.env.CHARACTER_GRAB_BASELINE || undefined});
function fresh(type,third,side=0){for(const k of ['KeyW','KeyD','KeyQ','Space'])h.release(k);h.game.begin(true);h.frames(1);if((h.qa.view==='third')!==third)h.element('viewtoggle').onclick();h.game.data.player.set(0,1.7,-20);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.group.visible=false;t.respawn=Infinity;}const t=h.game.data.targets.find(t=>t.type===type);t.active=t.group.visible=true;t.amplitude=0;t.anchor.set(h.game.data.camera.position.x+side,1.7,-26);t.group.position.copy(t.anchor);return t;}
function cast(){h.key('KeyQ');h.release('KeyQ');}
const frozenModel=t=>{const meshes=[];t.character.traverse(n=>{if(n.isMesh)meshes.push([n.geometry,n.material,n.position.toArray(),n.quaternion.toArray(),n.scale.toArray()]);});return{meshes,root:[t.character.position.toArray(),t.character.quaternion.toArray(),t.character.scale.toArray()],bounds:[t.bounds.min.toArray(),t.bounds.max.toArray()]};};
for(const type of ['mage','guardian','cannon'])for(const hz of [20,60,120])for(const third of [false,true])test(`${type} ${hz}Hz ${third?'third':'first'}: captured model keeps its original contact through moving/view-switched return`,()=>{
 delta=1/hz;const t=fresh(type,third,.35),model=frozenModel(t);cast();let contact=null,samples=0,paused=false;
 for(let f=0;f<5*hz;f++){
  if(contact){h.key('KeyD');if(f%3===0)h.docListeners.mousemove?.({target:h.element('game'),movementX:3,movementY:.2});}h.frames(1);const q=h.game.data.hook;
  if(q?.hit&&q.phase==='return'){
   const offset=t.group.position.clone().sub(q.position);
   if(!contact){contact=offset.clone();assert.equal(q.target,t);assert(offset.length()>.1);}
   else{assert(offset.distanceTo(contact)<1e-12,'model contact slipped independently of the returning hook');samples++;}
   assert.deepEqual(frozenModel(t),model,'model shape/normalization/collider changed');
   t.group.updateWorldMatrix(true,true);const worldBox=new THREE.Box3().setFromObject(t.character);assert(worldBox.min.distanceTo(t.bounds.min.clone().add(t.group.position))<1e-12);assert(worldBox.max.distanceTo(t.bounds.max.clone().add(t.group.position))<1e-12);
   if(!paused){const target=t.group.position.toArray(),hook=q.position.toArray();h.game.pause();h.element('viewtoggle').onclick();h.frames(9);assert.deepEqual(t.group.position.toArray(),target);assert.deepEqual(q.position.toArray(),hook);h.game.resume();paused=true;}
  }
  if(contact&&q?.phase==='recover')break;
 }
 assert(contact);assert(samples>=3);assert.equal(h.qa.session.catches,1);assert.equal(h.qa.session.hits,1);assert.equal(h.qa.session.score,100);assert(!t.active&&!t.captured&&!t.group.visible);h.release('KeyD');h.frames(3*hz);assert(t.active&&t.group.visible);assert.equal(h.qa.hook,null);assert.deepEqual(frozenModel(t),model);
});
test('cancel/restart clears ownership and later catches do not reuse an old character contact',()=>{
 delta=1/60;let previous=null;for(const [type,third,side]of[['cannon',true,.4],['mage',false,-.4],['guardian',true,0]]){const t=fresh(type,third,side);cast();for(let i=0;i<180&&!h.game.data.hook?.hit;i++)h.frames(1);const q=h.game.data.hook;assert(q?.hit);assert(q.targetContactOffset);if(previous)assert.notEqual(q.targetContactOffset,previous);previous=q.targetContactOffset;h.frames(2);h.game.finish();assert.equal(h.qa.hook,null);assert(!t.captured);assert.equal(h.qa.session.catches,0);}
});
test('all three active assets remain embedded, immutable, static reference reconstructions',()=>{
 const manifest=JSON.parse(fs.readFileSync(new URL('../assets/targets/source-manifest.json',import.meta.url)));for(const row of manifest){const b=fs.readFileSync(new URL('../assets/targets/'+TARGET_MODEL_FILES[row.asset],import.meta.url));assert.equal(crypto.createHash('sha256').update(b).digest('hex'),row.sha256);const g=JSON.parse(b.subarray(20,20+b.readUInt32LE(12)));assert.equal(g.animations?.length??0,0);assert.equal(g.skins?.length??0,0);assert(g.buffers.every(x=>!x.uri));}
});
test('non-character placeholder retains its original fixed-offset return contract',()=>{
 delta=1/60;const t=fresh('cannon',false),character=t.character;t.character=null;try{cast();let checked=0;for(let f=0;f<120;f++){h.frames(1);const q=h.game.data.hook;if(q?.hit&&q.phase==='return'&&q.phaseTime>0){assert.equal(q.targetContactOffset,undefined);assert.deepEqual(t.group.position.toArray(),q.position.clone().addScaledVector(q.direction,.6).toArray());checked++;}if(q?.phase==='recover')break;}assert(checked>2);assert.equal(h.qa.session.catches,1);}finally{t.character=character;}
});
