import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../',import.meta.url).pathname.replace(/\/$/,'');
const modulePath=root+'/skill-controller.js';
const {createSkillController:create,SKILL_TUNING:T}=await import(modulePath);
const {SKILL_ASSET}=await import(root+'/skill-animation-manifest.js');
const clips=JSON.parse(fs.readFileSync(root+'/'+SKILL_ASSET.raw)).models.fullbody.clips;
let failures=0,checks=0;function check(ok,label,data){checks++;if(!ok)failures++;test(label,()=>assert.ok(ok,JSON.stringify(data)));}
function frames(c,n,hz){for(let i=0;i<n;i++)c.step(1/hz);}
for(const hz of [30,60,120]){
 for(const k of ['W','E','R']){const c=create(clips);c['cast'+k]();if(k==='E'){frames(c,hz,hz);c.strikeE();frames(c,4*hz-1,hz);}else frames(c,12*hz-1,hz);check(c.blockReason(k)==='cooldown',`${k} not ready early ${hz}`,c.status);c.step(1/hz);check(c.status.cooldown[k]===0,`${k} cooldown zero ${hz}`,c.status.cooldown);check(c['cast'+k](),`${k} recast ${hz}`,c.status);}
 const c=create(clips);c.castW();frames(c,4*hz-1,hz);check(c.moveMultiplier===1.55,'boost before endpoint '+hz,c.status);c.step(1/hz);check(c.status.boost===0&&c.status.slow===2&&c.moveMultiplier===.65&&c.attackMultiplier===1,'boost endpoint '+hz,c.status);frames(c,2*hz,hz);check(c.status.slow===0&&c.moveMultiplier===1,'slow endpoint '+hz,c.status);
 // Isolate slow subtraction from the preceding boost boundary.
 const s=create(clips);s.castW();s.step(4);frames(s,2*hz,hz);check(s.status.slow===0&&s.moveMultiplier===1,'isolated slow endpoint '+hz,s.status);
}
for(const k of ['W','E','R']){const c=create(clips);c['cast'+k]();c.step(T[k.toLowerCase()+'Cooldown']-1e-9);check(c.status.cooldown[k]>9.9e-10&&c.blockReason(k)==='cooldown','real cooldown nanosecond '+k,c.status);}
const c=create(clips);c.castW();c.step(4-1e-9);check(c.status.boost>9.9e-10&&c.moveMultiplier===1.55,'real boost nanosecond',c.status);c.step(1e-9+1e-14);c.step(2-1e-9);check(c.status.slow>9.9e-10&&c.moveMultiplier===.65,'real slow nanosecond',c.status);const before=JSON.stringify(c.status);for(const dt of [0,-1,NaN,Infinity])c.step(dt);check(JSON.stringify(c.status)===before,'invalid delta unchanged',c.status);
const {createSkillAudio}=await import(root+'/skill-audio.js');
for(const hz of [30,60,120]){const c=create(clips),sounds=[];let frame=0;const audio=createSkillAudio({playEvent:name=>{sounds.push({name,frame});return true;},playTone:()=>{throw Error('Unexpected fallback')}});c.castW();audio.castW();for(frame=1;frame<=7*hz;frame++){c.step(1/hz);audio.update(c.status);}check(sounds.length===2&&sounds[0].name==='overdriveStart'&&sounds[1].name==='overdriveEnd','exactly one W exit sound '+hz,sounds);check(sounds[1].frame===4*hz,'W exit sound endpoint '+hz,sounds);console.log('audio',hz,JSON.stringify(sounds));}
// Preserve existing oversized-step semantics: a boost-expiring step starts the
// full slow interval; it does not consume leftover dt from that new interval.
const oversized=create(clips);oversized.castW();oversized.castR();oversized.step(100);check(oversized.status.boost===0&&oversized.status.slow===2&&oversized.status.cooldown.W===0&&oversized.status.cooldown.R===0,'oversized step semantics',oversized.status);
console.log(JSON.stringify({checks,failures}));process.exitCode=failures?1:0;
