import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from '../vendor/three.module.js';
import * as core from '../core.js';
import * as irregularTargets from '../irregular-targets.js';
import * as turretDirection from '../turret-direction.js';
import * as comboPractice from '../combo-practice.js';
import * as modeRecords from '../mode-records.js';
import * as flashController from '../flash-controller.js';
import * as duelAvatar from '../duel-avatar.js';
import * as duelSimulation from '../duel-simulation.js';
import * as duelBotInputs from '../duel-bot-inputs.js';
import * as duelPullPath from '../duel-pull-path.js';

const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const flush=()=>new Promise(resolve=>setImmediate(resolve));
async function failStartup(kind){
 const jobs=Object.fromEntries(['viewmodel','fullbody','characters','turret','skills','flash'].map(k=>[k,deferred()]));
 // Some jobs are deliberately not requested at the natural menu boundary.
 // Observe fixture-owned rejections without changing the promise returned to production.
 for(const job of Object.values(jobs))job.promise.catch(()=>{});
 const elements=new Map(),errors=[];let frame,renderCalls=0;
 const element=id=>{if(!elements.has(id))elements.set(id,{style:{},textContent:'',disabled:['start','practice','combopractice','duelmode'].includes(id),classList:{add(){},remove(){},toggle(){}},addEventListener(){},setAttribute(){},firstElementChild:{style:{}}});return elements.get(id);};
 class Renderer{constructor(){if(kind==='graphics')throw new Error('TEST: WebGL context creation failed');this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}clearDepth(){}render(){renderCalls++;}}
 const deps={
  './irregular-targets.js':irregularTargets,'./turret-direction.js':turretDirection,
  './vendor/three.module.js':{...THREE,WebGLRenderer:Renderer},
  './model-codec.js':{loadPlayerModel:entry=>jobs[entry].promise},
  './player-model-manifest.js':{PLAYER_MODELS:{viewmodel:'viewmodel',fullbody:'fullbody'}},
  './skill-animation.js':{validateSkillSourceParts(){},bindSkillClips(){},createFullbodyPoseApplicator:()=>()=>{},clearFullbodySkillPose(){},loadSkillAsset:()=>jobs.skills.promise},
  './skill-vfx.js':{createSkillVfx(){}},'./skill-audio.js':{createSkillAudio:()=>({}),SKILL_AUDIO_CUES:{},SKILL_AUDIO_EVENTS:{}},
  './w-stationary-layer.js':{createFullbodyWStationaryLayer:()=>()=>{}},
  './fullbody-locomotion.js':{createFullbodyLocomotion(){}},
  './skill-controller.js':{createSkillController(){},SKILL_TUNING:{}},'./skill-animation-manifest.js':{SKILL_ASSET:{}},
  './flash-frame-vfx.js':{loadFlashFrameTexture:()=>jobs.flash.promise,createFlashFrameVfx(){}},'./flash-frame-manifest.js':{FLASH_FRAMES:{}},
  './duel-avatar.js':duelAvatar,'./duel-simulation.js':duelSimulation,'./duel-bot-inputs.js':duelBotInputs,'./duel-pull-path.js':duelPullPath,
  './combo-practice.js':comboPractice,'./mode-records.js':modeRecords,'./flash-controller.js':flashController,'./flash-audio.js':{FLASH_AUDIO_CUES:{},FLASH_AUDIO_EVENTS:{}},
  './core.js':core,'./mouse-look.js':{createMouseLook:()=>({mode:'test',reset(){},refresh(){},request(){}})},
  './hook-chain.js':{createHookChain:()=>new THREE.Group()},'./training-mirror.js':{createTrainingMirror:()=>new THREE.Group()},
  './game-audio.js':{createGameAudio:()=>({})},'./audio-cues.js':{AUDIO_CUES:{},AUDIO_EVENTS:{}},
  './voice-cues.js':{VOICE_CUES:{},VOICE_EVENTS:{},RANDOM_VOICE_EVENTS:[],START_VOICE_EVENT:'start',DEATH_VOICE_EVENT:'death'},
  './voice-schedule.js':{createVoiceSchedule:()=>({})},
  './blitz-materials.js':{createBlitzMaterial(){},blitzMaterialKey(){},loadBlitzTextures:async()=>{},attachBlitzUV(){}},
  './target-models.js':{loadCharacterTargets:()=>jobs.characters.promise,attachCharacterTarget(){}},
  './turret-view.js':{loadTurretModel:()=>jobs.turret.promise,createTurretArena(){}},
 };
 Object.assign(globalThis,{__startupDeps:deps,document:{getElementById:element,querySelector:element,addEventListener(){},pointerLockElement:null},window:{},localStorage:{getItem:()=>null},matchMedia:()=>({matches:false}),addEventListener(){},requestAnimationFrame:f=>frame=f,devicePixelRatio:1,innerWidth:1280,innerHeight:720});
 let source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8');
 source=source.replace(/import \* as (\w+) from '([^']+)';/g,(_,name,path)=>`const ${name}=globalThis.__startupDeps[${JSON.stringify(path.split('?')[0])}];`).replace(/import (\{[^}]+\}) from '([^']+)';/g,(_,names,path)=>`const ${names}=globalThis.__startupDeps[${JSON.stringify(path.split('?')[0])}];`);
 const originalError=console.error;console.error=e=>errors.push(e?.message||String(e));
 try{
  const run=import('data:text/javascript;base64,'+Buffer.from(source+'\n// '+kind).toString('base64'));
  if(kind==='network')jobs.fullbody.reject(new Error('TEST: HTTP 503'));
  if(kind==='decode')jobs.fullbody.reject(new Error('TEST: Invalid model header'));
  if(kind==='scene')for(const job of Object.values(jobs))job.resolve({});
  await run;
  const status=element('loadstatus').textContent;
  assert.equal(window.__HOOK_ARENA__.state,'error');
  // The view control remains harmless even when WebGL failed before camera creation.
  assert.doesNotThrow(()=>element('viewtoggle').onclick());assert.equal(window.__HOOK_ARENA__.view,'third');
  assert.doesNotThrow(()=>element('viewtoggle').onclick());assert.equal(window.__HOOK_ARENA__.view,'first');
  assert.equal(window.__HOOK_ARENA__.state,'error');
  if(kind==='graphics')assert.match(status,/WebGL/);else assert.doesNotMatch(status,/WebGL/);
  if(['network','decode'].includes(kind))assert.match(status,/파일/);
  if(kind==='scene')assert.match(status,/모델/);
  // Successful late requests and a separate late failure must never replace fatal UI.
  for(const [key,job]of Object.entries(jobs)){if(key==='turret')job.reject(new Error('TEST: late failure'));else job.resolve({});}
  await flush();await flush();
  assert.equal(element('loadstatus').textContent,status);assert.equal(window.__HOOK_ARENA__.state,'error');
  assert.equal(element('start').textContent,'불러오기 실패');assert.equal(element('start').disabled,true);assert.equal(element('practice').disabled,true);assert.equal(element('combopractice').disabled,true);assert.equal(element('duelmode').disabled,true);
  frame?.();assert.equal(renderCalls,0,'a failed startup must not render the incomplete arena/mirror');
  assert.equal(errors.length,1);
 }finally{console.error=originalError;}
}
for(const kind of ['graphics','network','decode','scene'])test(`startup ${kind} failure remains actionable after late requests`,()=>failStartup(kind));

test('entry module and model manifest cache keys match the release, not just visible labels',()=>{
 const version=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url))).version.replace(/\.0$/,'');
 const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8'),main=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8');
 assert.equal(html.match(/src="main\.js\?v=([^"]+)"/)[1],version);
 assert.equal(main.match(/from '\.\/player-model-manifest\.js\?v=([^']+)'/)[1],version);
 assert.equal(main.match(/from '\.\/skill-vfx\.js\?v=([^']+)'/)[1],version);
 assert.equal(main.match(/from '\.\/fullbody-locomotion\.js\?v=([^']+)'/)[1],version);
});


test('Flash controller, manifest, VFX and controls carry the current release cache key',()=>{
 const version=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url))).version;
 const main=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8'),html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
 for(const name of ['flash-controller','flash-frame-manifest','flash-frame-vfx','mouse-look','duel-avatar','duel-simulation','duel-bot-inputs','duel-pull-path'])assert(main.includes("from './"+name+".js?v="+version+"'"));
 assert(html.includes('href="flash-controls.css?v='+version+'"'));
});
