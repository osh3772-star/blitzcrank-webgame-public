import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

test('Q award particles originate at the pulled victim; E/R keep authoritative impact locations',async()=>{
 for(const [skill,winner] of [['Q','human'],['Q','bot'],['E','human'],['R','human']]){
  const r=await createGameplayHarness({delta:()=>1/60});r.element('duelmode').click();
  r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});
  for(let n=0;n<120&&!r.qa.duel.active;n++)r.frames(1);
  assert(r.qa.duel.active);const d=r.game.data;d.duelBot.position.set(0,1.7,skill==='Q'?0:skill==='E'?5:3);
  const origins=[],add=d.scene.add;
  d.scene.add=function(...objects){for(const object of objects)if(object.geometry?.parameters.width===.055&&object.geometry?.parameters.height===.055&&object.geometry?.parameters.depth===.055)origins.push(object.position.clone());return add.apply(this,objects);};
  if(skill==='Q')assert(d.duel.cast(winner));
  if(skill==='E'){assert(d.duel.getSkills(winner).castE());r.frames(60);assert(d.duel.getSkills(winner).strikeE());}
  if(skill==='R')assert(d.duel.getSkills(winner).castR());
  for(let n=0;n<180&&!r.qa.duel.match.history.length;n++)r.frames(1);
  assert.equal(r.qa.duel.match.history.length,1);assert.equal(origins.length,16);
  const victim=winner==='human'?d.duelBot.position:d.player;
  const expected=skill==='Q'?victim:d.duel.contact.position;
  for(const origin of origins)assert(origin.distanceTo(expected)<1e-9,`${winner} ${skill} reward origin ${origin.toArray()} must equal ${JSON.stringify(expected)}`);
  if(skill==='Q')assert(victim.distanceTo(d.duel.contact.position)>1,'fixture distinguishes old contact from final pull');
 }
});
