import test from 'node:test';
import assert from 'node:assert/strict';
import {createModeRecords,MODE_RECORD_KEYS as keys} from '../mode-records.js';
import {COMBO_PRACTICE_RULES as rules} from '../combo-practice.js';
const challenge=score=>JSON.stringify({version:1,mode:'challenge90',score});
const combo=seconds=>JSON.stringify({version:1,mode:'combo',rules,seconds});
function memory(initial={}){const data=new Map(Object.entries(initial)),writes=[];return{data,writes,getItem:key=>data.get(key)??null,setItem(key,value){writes.push([key,value]);data.set(key,value);}};}
const create=storage=>createModeRecords({getStorage:()=>storage});
const run=score=>({practice:false,done:true,score});
const success=elapsed=>({success:true,elapsed});
const emptyFlash=(issue=null)=>Object.fromEntries(['challengeFlash','comboFlash','comboERFlash'].map(mode=>[mode,{best:null,saved:false,issue}]));

test('missing records do not write or read/migrate legacy values, including malformed legacy bytes',()=>{
 for(const raw of ['987654','NaN','{bad','',JSON.stringify({score:50})]){
  const storage=memory({'rocket-hand-best':raw}),get=storage.getItem;storage.getItem=key=>{assert.notEqual(key,'rocket-hand-best');return get(key);};
  const records=create(storage);assert.deepEqual(records.snapshot(),{challenge:{best:null,saved:false,issue:null},combo:{best:null,saved:false,issue:null},comboER:{best:null,saved:false,issue:null},...emptyFlash()});assert.equal(storage.writes.length,0);
  assert(records.recordChallenge(run(100)));assert(records.recordCombo(success(3.25)));assert.equal(storage.data.get('rocket-hand-best'),raw);
 }
});
test('challenge saves nonnegative safe-integer scores only from finished non-practice sessions',()=>{
 const storage=memory(),records=create(storage);
 for(const session of [{score:100},{practice:false,done:false,score:200},{practice:true,done:true,score:10000},{practice:true,done:false,score:20000},null])assert.equal(records.recordChallenge(session),false);
 for(const score of [-1,1.5,NaN,Infinity,-Infinity,'100',Number.MAX_SAFE_INTEGER+1,null,undefined])assert.equal(records.recordChallenge(run(score)),false);
 assert.equal(storage.writes.length,0);assert(records.recordChallenge(run(0)));assert.equal(records.snapshot().challenge.best,0);assert.equal(storage.data.get(keys.challenge),challenge(0));
 assert(records.recordChallenge(run(400)));assert(records.recordChallenge(run(300)));assert(records.recordChallenge(run(400)));assert.equal(storage.writes.length,2);assert.equal(records.snapshot().challenge.best,400);
});
test('combo saves only successful positive finite eligible elapsed seconds and retains fastest precision',()=>{
 const storage=memory(),records=create(storage);
 for(const elapsed of [0,-1,NaN,Infinity,-Infinity,12.001,'3',null,undefined])assert.equal(records.recordCombo(success(elapsed)),false);
 assert.equal(records.recordCombo({success:false,elapsed:2}),false);assert.equal(records.recordCombo(null),false);assert.equal(storage.writes.length,0);
 for(const elapsed of [4.123456789,5,4.123456789,3.987654321])assert(records.recordCombo(success(elapsed)));
 assert.equal(storage.writes.length,2);assert.equal(storage.data.get(keys.combo),combo(3.987654321));assert.equal(records.snapshot().combo.best,3.987654321);
});
test('separate record schemas and keys survive reload without cross-mode contamination',()=>{
 const storage=memory(),records=create(storage);records.recordChallenge(run(500));records.recordCombo(success(3));
 const reloaded=create(storage);assert.deepEqual(reloaded.snapshot(),{challenge:{best:500,saved:true,issue:null},combo:{best:3,saved:true,issue:null},comboER:{best:null,saved:false,issue:null},...emptyFlash()});
 assert.equal(reloaded.recordChallenge({practice:true,done:true,score:50000}),false);assert.equal(storage.data.get(keys.challenge),challenge(500));assert.equal(storage.data.get(keys.combo),combo(3));
 const snapshot=reloaded.snapshot();snapshot.challenge.best=99999;assert.equal(reloaded.snapshot().challenge.best,500);
});
test('malformed/unknown records stay byte-for-byte unchanged and block only their own key',()=>{
 const invalid=['',' ','{','null','[]','42','true','"3"','{}','{"version":1,"mode":"challenge90","score":-1}',challenge(1.5),challenge('100'),challenge(null),' {"version":2,"mode":"challenge90","score":10} ',JSON.stringify({version:1,mode:'challenge90',score:10,extra:'future'}),combo(3)];
 for(const raw of invalid){const storage=memory({[keys.challenge]:raw}),records=create(storage);assert.equal(records.snapshot().challenge.issue,'invalid',raw);assert.equal(records.recordChallenge(run(100)),false);assert.deepEqual(records.snapshot().challenge,{best:100,saved:false,issue:'invalid'});assert.equal(storage.data.get(keys.challenge),raw);assert(records.recordCombo(success(4)));assert.equal(storage.writes.length,1);}
 for(const raw of [challenge(30),combo(0),combo(-2),combo(13),combo('3'),combo(null),JSON.stringify({version:1,mode:'combo',rules:'future-v2',seconds:3}),JSON.stringify({version:2,mode:'combo',rules,seconds:3})]){const storage=memory({[keys.combo]:raw}),records=create(storage);assert.equal(records.recordCombo(success(4)),false);assert.equal(storage.data.get(keys.combo),raw);assert(records.recordChallenge(run(100)));}
});
test('storage property getter can throw before any method exists without stopping play',()=>{
 let calls=0;const records=createModeRecords({getStorage(){calls++;throw new Error('SecurityError');}});
 assert.equal(records.recordChallenge(run(200)),false);assert.equal(records.recordCombo(success(3)),false);assert.deepEqual(records.snapshot(),{challenge:{best:200,saved:false,issue:'unavailable'},combo:{best:3,saved:false,issue:'unavailable'},comboER:{best:null,saved:false,issue:'unavailable'},...emptyFlash('unavailable')});assert(calls>=4);
});
test('missing storage API falls back to page-only records without breaking construction',()=>{
 for(const storage of [undefined,null,{}]){const records=create(storage);assert.equal(records.recordChallenge(run(100)),false);assert.equal(records.recordCombo(success(4)),false);assert.equal(records.snapshot().challenge.best,100);assert.equal(records.snapshot().combo.best,4);assert.equal(records.snapshot().combo.saved,false);}
});
test('getItem errors preserve stored bytes and prohibit writes on unreadable keys',()=>{
 const storage=memory({[keys.challenge]:challenge(700),[keys.combo]:combo(2)});storage.getItem=()=>{throw new Error('SecurityError');};const records=create(storage);
 assert.equal(records.recordChallenge(run(400)),false);assert.equal(records.recordCombo(success(4)),false);assert.equal(storage.writes.length,0);assert.equal(storage.data.get(keys.challenge),challenge(700));assert.equal(storage.data.get(keys.combo),combo(2));
});
test('quota/write failure never claims a temporary best was saved and reload sees old values',()=>{
 const storage=memory({[keys.challenge]:challenge(100),[keys.combo]:combo(4)}),set=storage.setItem;storage.setItem=()=>{throw new Error('QuotaExceededError');};const records=create(storage);
 assert.equal(records.recordChallenge(run(500)),false);assert.equal(records.recordCombo(success(3)),false);assert.deepEqual(records.snapshot(),{challenge:{best:500,saved:false,issue:'unavailable'},combo:{best:3,saved:false,issue:'unavailable'},comboER:{best:null,saved:false,issue:null},...emptyFlash()});
 const reload=create(storage);assert.equal(reload.snapshot().challenge.best,100);assert.equal(reload.snapshot().combo.best,4);assert(reload.snapshot().combo.saved);
 storage.setItem=set;assert(records.recordChallenge(run(200)));assert(records.recordCombo(success(3.5)));assert.equal(storage.data.get(keys.challenge),challenge(500));assert.equal(storage.data.get(keys.combo),combo(3));
});
test('storage read/write method getters can throw safely too',()=>{
 for(const method of ['getItem','setItem']){const storage=memory();Object.defineProperty(storage,method,{get(){throw Error('blocked method');}});const records=create(storage);assert.equal(records.recordChallenge(run(100)),false);assert.equal(records.snapshot().challenge.saved,false);assert.equal(storage.data.size,0);}
});
test('existing better other-tab values win at commit without unnecessary writes',()=>{
 const storage=memory(),a=create(storage),b=create(storage);
 assert(a.recordChallenge(run(500)));assert(a.recordCombo(success(3)));const count=storage.writes.length;
 assert(b.recordChallenge(run(200)));assert(b.recordCombo(success(4)));assert.equal(storage.writes.length,count);assert.equal(b.snapshot().challenge.best,500);assert.equal(b.snapshot().combo.best,3);
 assert(b.recordChallenge(run(700)));assert(b.recordCombo(success(2.5)));a.refresh();assert.equal(a.snapshot().challenge.best,700);assert.equal(a.snapshot().combo.best,2.5);
});
test('corruption introduced after loading cannot be overwritten by a new result',()=>{
 const storage=memory({[keys.challenge]:challenge(100),[keys.combo]:combo(4)}),records=create(storage);
 storage.data.set(keys.challenge,'malformed newer bytes');storage.data.set(keys.combo,'{"version":9}');assert.equal(records.recordChallenge(run(200)),false);assert.equal(records.recordCombo(success(3)),false);
 assert.equal(storage.data.get(keys.challenge),'malformed newer bytes');assert.equal(storage.data.get(keys.combo),'{"version":9}');assert.equal(storage.writes.length,0);assert.equal(records.snapshot().combo.issue,'invalid');
});
test('refresh never writes or loses an unsaved page best if a record disappears',()=>{
 const storage=memory({[keys.combo]:combo(3)}),records=create(storage);storage.data.delete(keys.combo);records.refresh();assert.deepEqual(records.snapshot().combo,{best:3,saved:false,issue:'unsaved'});assert.equal(storage.writes.length,0);
});
