import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/status-runtime-harness.js';
// Real main.js/controller with controlled DOM, renderer, clock; not browser paint.
const h=await createGameplayHarness(),el=h.element;
function begin(){h.docEvent('pointerdown',{pointerType:'touch'});h.game.begin(true);h.frames(1);}
function check(key,text,active,cooling,disabled){assert.equal(el('skillstate'+key).textContent,text);assert.equal(el('skill'+key).classList.s.has('active'),active);assert.equal(el('skill'+key).classList.s.has('cooling'),cooling);assert.equal(el('skill'+key).attributes['aria-disabled'],String(disabled));assert.equal(el('skill'+key).disabled,false,'aria-disabled does not erase keyboard focus');}
test('real HUD ready, boost, slow, cooling, reset and E/R cast states',()=>{
 begin();for(const k of 'WER')check(k,'준비',false,false,false);
 h.game.castW();h.game.updateHud();assert.match(el('skillstateW').textContent,/^가속 /);check('W',el('skillstateW').textContent,true,false,true);
 h.setDelta(.05);let steps=0;while(h.game.data.skills.status.boost>0&&steps++<300)h.frames(1);
 assert.match(el('skillstateW').textContent,/^감속 /);check('W',el('skillstateW').textContent,true,false,true);
 while(h.game.data.skills.status.slow>0&&steps++<500)h.frames(1);
 assert.match(el('skillstateW').textContent,/^\d+\.\ds$/);check('W',el('skillstateW').textContent,false,true,true);
 begin();check('W','준비',false,false,false);
 h.game.castE();h.game.updateHud();check('E','시전',true,false,true);
 steps=0;while(h.game.data.skills.status.phase!=='E_Hold'&&steps++<100)h.frames(1);
 assert.match(el('skillstateE').textContent,/^강화 /);check('E',el('skillstateE').textContent,true,false,true);
 begin();h.game.castR();h.game.updateHud();check('R','시전',true,false,true);
 begin();for(const k of 'WER')check(k,'준비',false,false,false);
});
