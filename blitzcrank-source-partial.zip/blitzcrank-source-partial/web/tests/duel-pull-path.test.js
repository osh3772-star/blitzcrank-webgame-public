import test from 'node:test';
import assert from 'node:assert/strict';
import {planDuelPullPath, sampleDuelPullPath, projectBlockedDuelPullEnd,
  certifyDuelPullFrameChords, segmentCrossesOpenBox} from '../duel-pull-path.js';

const p = (x, z, y = 1.7) => ({x, y, z});
const box = (x0, z0, x1, z1, y0 = 0, y1 = 3) => ({min: {x: x0, y: y0, z: z0}, max: {x: x1, y: y1, z: z1}});
const bounds = {min: {x: -23.4, z: -42.5}, max: {x: 23.4, z: 15.5}};
const cover = box(-10.5, -9.5, -7.5, -6.5, 0, 2.8);
const covers = [cover, box(7, -15.5, 11, -12.5, 0, 3.2), box(-7.5, -26.5, -4.5, -23.5, 0, 3.4),
  box(14, -31, 18, -27, 0, 4), box(-20.5, -36, -15.5, -32)];
const surfaces = [box(-26, -48, 26, 22, -.33, -.03), box(-26.5, -45.5, -25.5, 19.5, -.2, 8.8),
  box(25.5, -45.5, 26.5, 19.5, -.2, 8.8), box(-26, -46.5, 26, -45.5, -.5, 12.5),
  box(-4.5, -45.17, 4.5, -45.05, .25, 7.25)];
const obstacles = [...surfaces, ...covers];
const from = p(-6, -9);
const originalEnd = winner => {
  const x = from.x - winner.x, z = from.z - winner.z, distance = Math.hypot(x, z), stop = Math.min(2.3, distance);
  return p(winner.x + (distance ? x / distance * stop : 0), winner.z + (distance ? z / distance * stop : 0));
};
const expand = (o, radius = .42, feet = 1.7, top = 0) => ({min: {x: o.min.x - radius, y: o.min.y - top, z: o.min.z - radius},
  max: {x: o.max.x + radius, y: o.max.y + feet, z: o.max.z + radius}});

// Independent interval-intersection oracle. Not imported from the planner.
function intersects(a, b, o) {
  const intervals = ['x', 'y', 'z'].map(axis => {
    if (a[axis] === b[axis]) return a[axis] > o.min[axis] && a[axis] < o.max[axis] ? [-Infinity, Infinity] : null;
    const roots = [(o.min[axis] - a[axis]) / (b[axis] - a[axis]), (o.max[axis] - a[axis]) / (b[axis] - a[axis])].sort((a, b) => a - b);
    return roots;
  });
  return intervals.every(Boolean) && Math.max(0, ...intervals.map(r => r[0])) < Math.min(1, ...intervals.map(r => r[1]));
}
function safeLeg(a, b, obs = obstacles, radius = .42) {
  for (const o of obs) assert(!intersects(a, b, expand(o, radius)), `segment enters ${JSON.stringify(o)}: ${JSON.stringify([a, b])}`);
}
function certifyPlan(plan, obs = obstacles, radius = .42) {
  assert(plan.ok, JSON.stringify(plan));
  assert.deepEqual(sampleDuelPullPath(plan, 0), plan.from);
  assert.deepEqual(sampleDuelPullPath(plan, 1), plan.to);
  for (let i = 1; i < plan.points.length; i++) safeLeg(plan.points[i - 1], plan.points[i], obs, radius);
  for (const q of plan.points) {
    assert(q.x >= bounds.min.x && q.x <= bounds.max.x && q.z >= bounds.min.z && q.z <= bounds.max.z);
  }
}
const smooth = u => u * u * (3 - 2 * u);

test('clear path is the original componentwise lerp and preserves exact endpoints', () => {
  const a = p(0, 7, 3.2), b = p(0, -12);
  const plan = planDuelPullPath({from: a, to: b, obstacles, maxProgressStep: .25, projectBlockedDestination: true});
  assert.equal(plan.kind, 'direct'); assert.equal(plan.endpointAdjusted, false);
  for (let i = 0; i <= 100; i++) {
    const u = smooth(i / 100), actual = sampleDuelPullPath(plan, u);
    if (i === 0 || i === 100) assert.deepEqual(actual, i ? b : a);
    else for (const axis of ['x', 'y', 'z']) assert.equal(actual[axis], a[axis] + (b[axis] - a[axis]) * u);
  }
  assert.equal(plan.frameChords.maxProgressStep, 1);
  certifyPlan(plan);
});

test('real clear-endpoint Q fixture requires only one continuous corner bend', () => {
  const to = originalEnd(p(-10, -4));
  assert(intersects(from, to, expand(cover)));
  const plan = planDuelPullPath({from, to, obstacles});
  certifyPlan(plan); assert.equal(plan.kind, 'polyline'); assert.equal(plan.points.length, 3);
  assert.deepEqual(plan.to, to); assert.equal(plan.endpointAdjusted, false);
  assert(plan.extraLength < .53); assert.equal(plan.frameChords.code, 'NOT_REQUESTED');
});

test('tiny-clearance polyline explicitly fails the frame-chord certificate', () => {
  const plan = planDuelPullPath({from, to: originalEnd(p(-10, -4)), obstacles});
  const result = certifyDuelPullFrameChords(plan, {obstacles, maxProgressStep: .215});
  assert.equal(result.code, 'FRAME_CHORD_UNSAFE');
  const blocked = planDuelPullPath({from, to: originalEnd(p(-10, -4)), obstacles, maxProgressStep: .215, maxCornerPadding: .00001});
  assert.equal(blocked.code, 'FRAME_CHORD_UNSAFE'); assert(!blocked.points);
});

for (const [name, human, expectedAdjustment] of [['clear', p(-10, -4), 0], ['margin', p(-9.6, -4.5), .21599826171896908], ['blocked', p(-9.4, -4.8), .5076632026272163]]) {
  test(`real ${name} fixture: certified chords, original height/timing, minimal endpoint adjustment`, () => {
    const to = originalEnd(human), maxProgressStep = 1.5 * .05 / .35;
    const plan = planDuelPullPath({from, to, obstacles, projectBlockedDestination: true, maxProgressStep});
    certifyPlan(plan); assert(plan.frameChords.ok); assert.deepEqual(plan.originalEnd, to);
    assert(Math.abs(plan.adjustment.distance - expectedAdjustment) < 1e-12);
    if (expectedAdjustment) { assert.equal(plan.to.x, to.x); assert.equal(plan.to.z, -6.08); }
    assert(plan.cornerPadding <= .35); assert.equal(plan.to.y, 1.7);
    for (const hz of [20, 60, 120]) {
      let previous = sampleDuelPullPath(plan, 0);
      for (let frame = 1; frame <= Math.ceil(.35 * hz); frame++) {
        const phase = Math.min(1, frame / hz / .35), next = sampleDuelPullPath(plan, smooth(phase));
        safeLeg(previous, next); previous = next;
      }
      assert.deepEqual(previous, plan.to);
    }
    // Dense all-pair regression supplements the analytic envelope certificate.
    for (let i = 0; i <= 240; i++) {
      const a = sampleDuelPullPath(plan, i / 240);
      for (let j = i + 1; j <= Math.min(240, Math.floor(i + maxProgressStep * 240)); j++) safeLeg(a, sampleDuelPullPath(plan, j / 240));
    }
  });
}

test('the precise legal-keyboard endpoint fixture has an explicit strict failure', () => {
  const to = p(-8.159300450873092, -6.31287055002459);
  assert.equal(planDuelPullPath({from, to, obstacles}).code, 'ENDPOINT_BLOCKED');
  const result = projectBlockedDuelPullEnd({end: to, obstacles});
  assert(result.ok); assert.deepEqual(result.originalEnd, to); assert.equal(result.end.z, -6.08);
  assert.equal(result.adjustment.x, 0); assert.equal(result.end.y, to.y);
});

test('overlapping rectangles require global projection, not an illegal single-box face', () => {
  const obs = [box(-3, -1, 3, 1), box(-1, -3, 1, 3)];
  const result = projectBlockedDuelPullEnd({end: p(0, 0), obstacles: obs, radius: 0});
  assert(result.ok); assert.deepEqual(result.end, p(-1, -1)); assert.equal(result.adjustment.distance, Math.SQRT2);
  safeLeg(result.end, result.end, obs, 0);
  assert.deepEqual(projectBlockedDuelPullEnd({end: p(0, 0), obstacles: obs.slice().reverse(), radius: 0}).end, result.end);
});

test('global projection respects arena boundaries and reports completely covered domains', () => {
  const limits = {min: {x: -2, z: -2}, max: {x: 2, z: 2}};
  const result = projectBlockedDuelPullEnd({end: p(0, 0), bounds: limits, radius: 0, obstacles: [box(-3, -1, 1, 3)]});
  assert(result.ok); assert.deepEqual(result.end, p(0, -1)); assert.equal(result.adjustment.distance, 1);
  assert.equal(projectBlockedDuelPullEnd({end: p(0, 0), bounds: limits, obstacles: [box(-5, -5, 5, 5)]}).code, 'ENDPOINT_PROJECTION_FAILED');
});

test('projection never moves legal, airborne, out-of-bounds, below-floor, or start points', () => {
  const legal = p(-6, -9), airborne = p(-9, -8, 5);
  assert.deepEqual(projectBlockedDuelPullEnd({end: legal, obstacles}).end, legal);
  assert.deepEqual(projectBlockedDuelPullEnd({end: airborne, obstacles}).end, airborne);
  assert.equal(projectBlockedDuelPullEnd({end: p(24, 0), obstacles}).code, 'ENDPOINT_OUT_OF_BOUNDS');
  assert.equal(projectBlockedDuelPullEnd({end: p(0, 0, 1.6), obstacles}).code, 'ENDPOINT_BELOW_FLOOR');
  const badStart = planDuelPullPath({from: p(-9, -8), to: legal, obstacles, projectBlockedDestination: true});
  assert.equal(badStart.code, 'ENDPOINT_BLOCKED'); assert.equal(badStart.endpoint, 'from');
});

test('airborne clear segment is preserved; conservative height routing failure is explicit', () => {
  const obs = [box(-2, -2, 2, 2, 0, 2)];
  const high = planDuelPullPath({from: p(-4, 0, 5), to: p(4, 0, 5), obstacles: obs});
  assert.equal(high.kind, 'direct'); certifyPlan(high, obs);
  assert.equal(planDuelPullPath({from: p(-1, 0, 5), to: p(3, 0), obstacles: obs}).code, 'HEIGHT_PROJECTION_BLOCKED');
  const vertical = planDuelPullPath({from: p(5, 0, 4), to: p(5, 0), obstacles: obs});
  assert.equal(vertical.kind, 'direct'); assert.equal(vertical.length, 0);
  assert.deepEqual(sampleDuelPullPath(vertical, .5), p(5, 0, 2.85));
});

test('height overlap excludes floor, walls outside actor bounds, and an overhead box', () => {
  const obs = [...surfaces, box(-1, -1, 1, 1, 3, 4)];
  const plan = planDuelPullPath({from: p(-2, 0), to: p(2, 0), obstacles: obs});
  assert.equal(plan.kind, 'direct'); certifyPlan(plan, obs);
  assert.equal(planDuelPullPath({from: p(0, 0), to: p(2, 0), obstacles: obs, eyeToTop: 1.4}).code, 'ENDPOINT_BLOCKED');
});

test('exact boundary contacts are legal; thin obstacles cannot be skipped', () => {
  const b = box(-1, -1, 1, 1);
  assert(!segmentCrossesOpenBox(p(-2, 1), p(2, 1), b));
  assert(segmentCrossesOpenBox(p(-100, 0), p(100, 0), box(-1e-9, -1, 1e-9, 1)));
  assert(!segmentCrossesOpenBox(p(1, 1), p(1, 1), b));
  assert(segmentCrossesOpenBox(p(0, 0), p(0, 0), b));
});

test('narrow continuous path can retry exact corners; complete wall fails without fallback', () => {
  const limits = {min: {x: -3, z: -.500005}, max: {x: 3, z: .500005}}, obs = [box(-.5, -.5, .5, .5)];
  const narrow = planDuelPullPath({from: p(-2, 0), to: p(2, 0), obstacles: obs, bounds: limits, radius: 0});
  certifyPlan(narrow, obs, 0); assert.equal(narrow.cornerPadding, 0); assert.equal(narrow.diagnostics.attempts, 2);
  const wall = planDuelPullPath({from: p(-2, 0), to: p(2, 0), obstacles: [box(-.5, -3, .5, 3)], radius: 0,
    bounds: {min: {x: -3, z: -2}, max: {x: 3, z: 2}}});
  assert.equal(wall.code, 'NO_SAFE_PATH_FOUND'); assert(!wall.points);
  assert.throws(() => sampleDuelPullPath(wall, .5));
});

test('bounded graph/input failures and invalid progress are explicit', () => {
  assert.equal(planDuelPullPath({from, to: originalEnd(p(-10, -4)), obstacles, maxNodes: 2}).code, 'NODE_BUDGET_EXCEEDED');
  assert.equal(planDuelPullPath({from, to: p(0, 0), obstacles: Array(65).fill(cover)}).code, 'OBSTACLE_BUDGET_EXCEEDED');
  assert.equal(planDuelPullPath({from: p(NaN, 0), to: from}).code, 'INVALID_INPUT');
  assert.equal(planDuelPullPath({from, to: p(0, 0), obstacles: [{}]}).code, 'INVALID_OBSTACLE');
  assert.equal(planDuelPullPath({from, to: p(0, 0), maxProgressStep: 2}).code, 'INVALID_INPUT');
  const direct = planDuelPullPath({from: p(0, 0), to: p(1, 0)});
  assert.throws(() => sampleDuelPullPath(direct, NaN));
  assert.deepEqual(sampleDuelPullPath(direct, -1), direct.from); assert.deepEqual(sampleDuelPullPath(direct, 2), direct.to);
});

test('plans are deterministic, input-immutable, and reversed obstacle order gives the same route', () => {
  const frozen = JSON.parse(JSON.stringify({from, to: originalEnd(p(-9.4, -4.8)), obstacles, projectBlockedDestination: true, maxProgressStep: .215}));
  const before = JSON.stringify(frozen);
  const deepFreeze = o => {Object.freeze(o); for (const v of Object.values(o)) if (v && typeof v === 'object') deepFreeze(v);};
  deepFreeze(frozen);
  const a = planDuelPullPath(frozen), b = planDuelPullPath(frozen);
  assert.deepEqual(a, b); assert.equal(JSON.stringify(frozen), before);
  assert.deepEqual(planDuelPullPath({...frozen, obstacles: frozen.obstacles.slice().reverse()}).points, a.points);
});

test('seeded arena cases certify every successful route and finite frame chord', () => {
  let seed = 314159, succeeded = 0, failures = {};
  const random = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 2 ** 32);
  for (let i = 0; i < 250; i++) {
    const a = p(-23 + 46 * random(), -42 + 57 * random()), b = p(-23 + 46 * random(), -42 + 57 * random());
    const plan = planDuelPullPath({from: a, to: b, obstacles, projectBlockedDestination: true, maxProgressStep: .12});
    if (!plan.ok) { failures[plan.code] = (failures[plan.code] ?? 0) + 1; continue; }
    succeeded++; certifyPlan(plan);
    for (let j = 0; j < 30; j++) {
      const u = random(), v = Math.min(1, u + random() * .12);
      safeLeg(sampleDuelPullPath(plan, u), sampleDuelPullPath(plan, v));
    }
  }
  assert(succeeded > 150);
  console.log(JSON.stringify({seededArenaCases: 250, succeeded, explicitFailures: failures}));
});
