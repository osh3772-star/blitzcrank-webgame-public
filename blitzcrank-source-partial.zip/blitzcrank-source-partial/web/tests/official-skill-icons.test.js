import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
const root=new URL('../',import.meta.url),read=p=>fs.readFileSync(new URL(p,root),'utf8');
const html=read('index.html'),css=read('style.css'),touch=read('touch-layout.css');
const manifest=JSON.parse(read('assets/ui/skills/source-manifest.json'));
const expected={Q:'RocketGrab',W:'Overdrive',E:'PowerFist',R:'StaticField'};
test('Q W E R icons retain exact official Riot Data Dragon bytes and 64-square dimensions',()=>{
 assert.equal(manifest.publisher,'Riot Games');assert.equal(manifest.version,'16.22.1');assert.equal(manifest.champion.key,'53');assert.equal(manifest.assets.length,4);
 for(const record of manifest.assets){
  assert.equal(record.ability_id,expected[record.key]);assert.equal(record.filename,record.ability_id+'.png');
  assert.equal(record.source_url,`https://ddragon.leagueoflegends.com/cdn/${manifest.version}/img/spell/${record.filename}`);
  const b=fs.readFileSync(new URL('assets/ui/skills/'+record.filename,root));
  assert.equal(b.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(b.readUInt32BE(16),64);assert.equal(b.readUInt32BE(20),64);
  assert.equal(b.length,record.bytes);assert.equal(createHash('sha256').update(b).digest('hex'),record.sha256);assert.equal(record.source_bytes_modified,false);
 }
});
test('icon markup preserves native controls, key hints and live state descriptions',()=>{
 for(const key of ['W','E','R']){
  const m=html.match(new RegExp(`<button id="skill${key}"([^>]+)>([\\s\\S]*?)<\\/button>`));assert(m,key);
  assert(m[1].includes('type="button"'));assert(m[1].includes(`aria-describedby="skillstate${key}"`));assert(m[1].includes('aria-label="'));
  assert(m[2].includes(`src="assets/ui/skills/${expected[key]}.png"`));assert(m[2].includes('alt=""'));assert(m[2].includes('draggable="false"'));
  assert(m[2].includes(`id="skillstate${key}"`));assert(m[2].includes(key==='W'?'<b><kbd class="keyboard-hint">SHIFT</kbd><small>W</small></b>':`<b>${key}</b>`));
 }
 assert.equal((html.match(/src="assets\/ui\/skills\/RocketGrab.png"/g)||[]).length,2,'Q HUD and Q touch action use the same real icon');
 assert(html.includes('WASD 이동'));assert(html.includes('Shift 폭주'));
});
test('official images fit without crop and cannot intercept the button action',()=>{
 assert(css.includes('object-fit:contain'));assert(!css.includes('object-fit:cover'));
 for(const selector of ['#skillbar .skill-icon','#touchhook img.official-skill-icon','.ability>b img.official-skill-icon']){
  const parts=css.split(selector+'{').slice(1).map(part=>part.split('}')[0]);assert(parts.some(rule=>rule.includes('pointer-events:none')));
 }
 assert(touch.includes('--skill-height: 64px;'));assert(touch.includes('--skill-width: 56px;'));
 assert(css.includes('#skillbar button.cooling{opacity:1;'),'cooldown text stays readable');
 assert(css.includes('#skillbar button.cooling .skill-icon{filter:grayscale(.75) brightness(.65)}'));
 assert(css.includes('#skillbar button.active em{background:#143b38;color:#b8ffec}'));
 assert(css.includes('#skillbar button:focus-visible{outline:2px solid #f0cd83;outline-offset:2px;z-index:2}'));
});
test('Q art remains a square above the label on smallest touch controls',()=>{
 assert(css.includes('#touchhook img.official-skill-icon{flex-shrink:0;width:48px;height:48px;'));
 assert(css.includes('gap:5px;padding:9px}'));
 assert(css.includes('#touchhook span{font-size:10px;line-height:12px;'));
 assert(touch.includes('.ability>b small {display:none;}'),'redundant Q HUD key cannot paint into bottom safe inset');
 // Border-box stack: two 2px borders, two 9px pads, icon, 5px gap, 12px label.
 // Scope excludes Korean glyph shaping; source has an explicit label line height.
 assert(touch.includes('#touchhook em {display:block;font-size:9px;line-height:11px;'));
 for(const [button,icon,gap] of [[76,32,2],[68,30,0]])assert(icon+2*gap+12+11<=button-4-8);
});
