import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';
import {GLTFLoader} from '../vendor/GLTFLoader.js';
import {TARGET_MODEL_FILES,attachCharacterTarget} from '../target-models.js';
const crystalSurface=JSON.parse(fs.readFileSync(new URL('./fixtures/mage-crystal-surface.json',import.meta.url)));
const load=async file=>{const b=fs.readFileSync(file);const json=JSON.parse(b.subarray(20,20+b.readUInt32LE(12)).toString());assert((json.buffers||[]).every(b=>!b.uri));assert(!(json.images||[]).length);const gltf=await new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');return{scene:gltf.scene,json,bytes:b};};
function summary(a){let triangles=0;const materials={};a.scene.traverse(n=>{if(!n.isMesh)return;triangles+=n.geometry.index.count/3;const m=n.material;materials[m.name]={color:m.color.toArray(),metalness:m.metalness,roughness:m.roughness,opacity:m.opacity,transparent:m.transparent,side:m.side};});return{triangles,materials,dimensions:new THREE.Box3().setFromObject(a.scene).getSize(new THREE.Vector3()).toArray()};}
for(const kind of ['mage','guardian','cannon']){
 const baseline=kind==='cannon'?'../validation/reference-models-v2413/cannon-v2412.glb':'../validation/reference-models-v2412/'+kind+'-v2411.glb';
 const before=await load(new URL(baseline,import.meta.url));
 const after=await load(new URL('../assets/targets/'+TARGET_MODEL_FILES[kind],import.meta.url));
 test(`${kind} updated asset filename is content-addressed and still embedded-only`,()=>{
  const hash=crypto.createHash('sha256').update(after.bytes).digest('hex');assert.equal(TARGET_MODEL_FILES[kind],kind+'.'+hash.slice(0,16)+'.glb');assert(!(after.json.animations||[]).length);assert(!(after.json.images||[]).length);
 });
 test(`${kind} reference edits preserve verified palette, overall dimensions, batching and bounded topology`,()=>{
  const a=summary(before),b=summary(after);if(kind==='mage')for(const row of crystalSurface.materials){const m=a.materials[row.name],v=row.after;m.color=v['Base Color'].slice(0,3);m.metalness=v.Metallic;m.roughness=v.Roughness;}assert.deepEqual(b.materials,a.materials);for(let i=0;i<3;i++)assert(Math.abs(a.dimensions[i]-b.dimensions[i])<1e-6);assert.equal(after.json.meshes.length,1);assert.equal(after.json.meshes[0].primitives.length,{mage:18,guardian:9,cannon:7}[kind]);assert.equal(b.triangles,{mage:2548,guardian:4636,cannon:9998}[kind]);
 });
 test(`${kind} actual runtime normalization and collider envelope stay unchanged`,()=>{
  for(const position of [[0,0,0],[12,3,-18],[-9,1.8,4]]){
   const create=scene=>{const group=new THREE.Group(),ring=new THREE.Group();group.position.fromArray(position);group.add(ring);return attachCharacterTarget({group,ring},{scene,id:kind,label:kind});};
   const x=create(before.scene),y=create(after.scene);assert(x.bounds.min.distanceTo(y.bounds.min)<1e-6);assert(x.bounds.max.distanceTo(y.bounds.max)<1e-6);assert(x.character.scale.distanceTo(y.character.scale)<1e-6);assert(x.character.position.distanceTo(y.character.position)<1e-6);
  }
 });
}
test('entry module refreshes the immutable target asset loader',()=>{
 const version=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url))).version;const main=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8');assert.equal(main.match(/from '\.\/target-models\.js\?v=([^']+)'/)[1],version);
});

const oldCannon=await load(new URL('../validation/reference-models-v2413/cannon-v2412.glb',import.meta.url));
const newCannon=await load(new URL('../assets/targets/'+TARGET_MODEL_FILES.cannon,import.meta.url));
test('all 12 cannon blue muzzle accents are the first visible front surface in actual Three ray tests',()=>{
 const samples=JSON.parse(fs.readFileSync(new URL('../validation/reference-models-v2413/front-ray-samples.json',import.meta.url)));
 assert.equal(samples.length,24);oldCannon.scene.updateMatrixWorld(true);newCannon.scene.updateMatrixWorld(true);
 for(const p of samples){
  const ray=new THREE.Raycaster(new THREE.Vector3(p[0],p[1],10),new THREE.Vector3(0,0,-1));
  const before=ray.intersectObject(oldCannon.scene,true)[0],after=ray.intersectObject(newCannon.scene,true)[0];
  assert.equal(before.object.material.name,'Beveled silver steel');assert.equal(after.object.material.name,'Royal blue enamel');
 }
});
// Historical muzzle-only preservation remains checked against its preserved output.
// Current rear-plate deltas are tightly constrained in cannon-rear-shield.test.js.
const muzzleCannon=await load(new URL('../validation/reference-models-v2430/cannon-v2429.glb',import.meta.url));
test('historical cannon muzzle edit retains exact non-enamel decoded geometry',()=>{
 const primitives=scene=>{const p={};scene.traverse(n=>{if(n.isMesh)p[n.material.name]=n.geometry;});return p;};
 const a=primitives(oldCannon.scene),b=primitives(muzzleCannon.scene);let unchanged=0;
 for(const name of Object.keys(a))if(name!=='Royal blue enamel'){
  assert.deepEqual(Array.from(b[name].index.array),Array.from(a[name].index.array),name+' indices');
  assert.deepEqual(Object.keys(b[name].attributes).sort(),Object.keys(a[name].attributes).sort());
  for(const key of Object.keys(a[name].attributes))assert.deepEqual(Array.from(b[name].attributes[key].array),Array.from(a[name].attributes[key].array),name+' '+key);
  unchanged++;
 }
 assert.equal(unchanged,6);
});
