import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=process.env.DUEL_PUNCH_APP_ROOT||fileURLToPath(new URL('../',import.meta.url));
const {createGameplayHarness}=await import(pathToFileURL(path.join(root,'tests/helpers/runtime-harness.js')));
// Real game/Three CPU execution, simulated DOM/audio/renderer; no GPU claim.
const h=await createGameplayHarness({sourcePath:process.env.DUEL_PUNCH_SOURCE||path.join(root,'main.js'),delta:()=>.05});
const until=p=>{for(let i=0;i<150&&!p();i++)h.frames(1);assert(p(),'bounded transition');};
const shown=(text,disabled)=>{for(const key of 'ER'){assert.equal(h.element('skillstate'+key).textContent,text,key+' readiness');assert.equal(h.element('skill'+key).attributes['aria-disabled'],String(disabled));}};
const points=()=>assert.deepEqual(h.qa.duel.match.scores.map(s=>s.points),[0,0]);
function start(touch,hit=true){
 h.docListeners.pointerdown({pointerType:touch?'touch':'mouse'});h.game.begin(true,false,true);
 h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0})});
 until(()=>h.qa.duel.active);h.game.data.duelBot.position.set(hit?0:12,1.7,5);
}
function punch(touch){if(touch)h.element('touchpunch').onpointerdown({button:0,pointerType:'touch',preventDefault(){}});else h.punch();}
function cast(key,touch){if(touch)h.element('skill'+key).onclick({detail:0});else h.key('Key'+key);}
for(const touch of [false,true]){
 const ready=touch?'준비':'READY',busy=touch?'펀치 중':'PUNCHING',wait=touch?'라운드 대기':'ROUND WAIT';
 for(const hit of [true,false])test(`${touch?'touch':'desktop'} ordinary punch ${hit?'hit':'miss'} refreshes E/R synchronously, rejects casts and recovers`,()=>{
  start(touch,hit);shown(ready,false);const notice=h.element('hitnotice').textContent;punch(touch);shown(busy,true);
  if(hit)assert.equal(h.element('hitnotice').textContent,touch?'펀치 명중':'PUNCH · 명중');else assert.equal(h.element('hitnotice').textContent,notice);
  points();assert.equal(h.qa.duel.match.history.length,0);assert.equal(h.qa.session.score,0);
  const skills=h.qa.skills;cast('E',touch);cast('R',touch);assert.deepEqual(h.qa.skills,skills,'rejected E/R do not spend cooldown');
  const cooldown=h.game.data.punchCooldown;assert(cooldown>0);punch(touch);assert.equal(h.game.data.punchCooldown,cooldown,'repeat input cannot restart punch');
  shown(busy,true);h.frames(1);shown(busy,true);
  h.game.castW();assert(h.qa.skills.boost>0,'W remains independent');
  until(()=>h.element('skillstateE').textContent===ready);shown(ready,false);assert.equal(h.game.data.punchCooldown,0);points();
  cast('E',touch);assert.equal(h.qa.skills.phase,'E_Charge');assert(h.qa.skills.cooldown.E>0);
 });
 test(`${touch?'touch':'desktop'} hit readiness stays correct through pause/resume and restart countdown`,()=>{
  start(touch);punch(touch);h.frames(1);shown(busy,true);h.game.pause();shown(touch?'일시정지':'PAUSED',true);
  const frozen=structuredClone(h.qa.skills),cooldown=h.game.data.punchCooldown;h.frames(5);cast('E',touch);cast('R',touch);assert.deepEqual(h.qa.skills,frozen);assert.equal(h.game.data.punchCooldown,cooldown);
  h.game.resume();shown(busy,true);h.game.begin(true,false,true);shown(wait,true);assert.equal(h.game.data.punchCooldown,0);assert.deepEqual(h.qa.skills.cooldown,{W:0,E:0,R:0});
  h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0})});until(()=>h.qa.duel.active);shown(ready,false);points();
 });
 test(`${touch?'touch':'desktop'} hit preserves an existing R cooldown and ordinary solo-mode readiness`,()=>{
  start(touch,false);cast('R',touch);until(()=>h.qa.skills.phase===null);assert(h.qa.skills.cooldown.R>0);points();
  h.game.data.duelBot.position.set(0,1.7,5);punch(touch);h.frames(1);assert.equal(h.element('skillstateE').textContent,busy);assert.equal(h.element('skillstateR').textContent,busy);assert.equal(h.element('skillR').attributes['aria-disabled'],'true');
  const before=h.qa.skills;cast('R',touch);assert.deepEqual(h.qa.skills,before);until(()=>h.element('skillstateE').textContent===ready);assert.match(h.element('skillstateR').textContent,/^\d+\.\ds$/);assert(h.qa.skills.cooldown.R>0);
  h.game.begin(true,false,false);assert.equal(h.qa.duel,null);shown(ready,false);assert.deepEqual(h.qa.skills.cooldown,{W:0,E:0,R:0});
 });
}
