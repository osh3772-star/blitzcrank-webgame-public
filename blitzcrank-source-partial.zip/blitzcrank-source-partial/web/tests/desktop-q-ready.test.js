import test from 'node:test';import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const h=await createGameplayHarness();
function fresh(combo=false){h.game.begin(true,combo);h.frames(1);}
function blockedMustNotSayReady(){h.game.updateHud();const shots=h.qa.session.shots;h.key('KeyQ');assert.equal(h.qa.session.shots,shots,'Q is actually blocked');assert.notEqual(h.element('hookstate').textContent,'READY','HUD falsely promises ready Q');}
for(const [name,setup] of [['E charge',()=>h.key('KeyE')],['E strike',()=>{h.key('KeyE');h.frames(53);h.punch();}],['R cast',()=>h.key('KeyR')],['basic punch',()=>h.punch()]])test('Q HUD reports action lock: '+name,()=>{fresh();setup();blockedMustNotSayReady();});
test('Q HUD reports combo route lock while E armed',()=>{fresh(true);h.key('KeyE');h.frames(53);blockedMustNotSayReady();});
test('ordinary desktop Q can recast after 30 real cooldown cycles',()=>{fresh();for(let i=0;i<30;i++){h.key('KeyQ');h.release('KeyQ');assert.equal(h.qa.session.shots,i+1);h.frames(150);assert.equal(h.qa.hook,null);assert.equal(h.game.data.shotCooldown,0);}assert.equal(h.element('hookstate').textContent,'READY');});
test('E hold allows Q outside combo',()=>{fresh();h.key('KeyE');h.frames(53);h.key('KeyQ');assert(h.qa.hook);});
test('repeat suppression is intentional, new Q keydown recasts',()=>{fresh();h.key('KeyQ');h.frames(150);h.dispatchKey({code:'KeyQ',repeat:true});assert.equal(h.qa.hook,null);h.release('KeyQ');h.key('KeyQ');assert(h.qa.hook);});

test('Q ready label, action styling and touch eligibility agree through action recovery',()=>{
 fresh();assert.equal(h.element('hookability').attributes['data-ready'],'true');h.key('KeyE');assert.equal(h.element('hookstate').textContent,'CASTING');assert.equal(h.element('touchhookstate').textContent,'시전 중');assert.equal(h.element('touchhook').attributes['aria-disabled'],'true');
 h.frames(53);assert.equal(h.element('hookstate').textContent,'READY');assert.equal(h.element('hookability').attributes['data-ready'],'true');assert.equal(h.element('touchhook').attributes['aria-disabled'],'false');h.key('KeyQ');assert.equal(h.qa.session.shots,1);
});
test('combo attempt lock and retry are explicit without resetting route or records',()=>{
 fresh(true);h.key('KeyE');h.frames(53);assert.equal(h.element('hookstate').textContent,'COMBO ACTIVE');const attempt=h.qa.comboPractice.attempts,started=h.qa.comboPractice.elapsed;
 h.key('KeyQ');assert.equal(h.qa.comboPractice.attempts,attempt);assert.equal(h.qa.comboPractice.route,'er');assert.equal(h.qa.comboPractice.elapsed,started);assert.equal(h.element('hitnotice').textContent,'Q · 연계 진행 중');
 h.frames(670);assert.equal(h.qa.comboPractice.phase,'failed');assert.equal(h.element('hookstate').textContent,'RETRY WAIT');h.frames(115);assert.equal(h.qa.comboPractice.phase,'ready');assert.equal(h.element('hookstate').textContent,'READY');h.key('KeyQ');assert.equal(h.qa.comboPractice.route,'qer');
});
test('Q no longer claims READY on pause/capture loss and updates immediately on resume',()=>{
 fresh();assert.equal(h.element('hookstate').textContent,'READY');h.game.pause();assert.equal(h.element('hookstate').textContent,'PAUSED');assert.equal(h.element('touchhook').attributes['aria-disabled'],'true');h.key('KeyQ');assert.equal(h.qa.session.shots,0);h.game.resume();assert.equal(h.element('hookstate').textContent,'READY');h.key('KeyQ');assert.equal(h.qa.session.shots,1);
});
test('capturing the canvas removes a sensitivity focus trap before Q input',()=>{
 fresh();h.game.pause();const canvas=h.element('game'),slider=h.element('sensitivity');canvas.tagName='CANVAS';slider.tagName='INPUT';document.activeElement=slider;let focusOptions;
 canvas.focus=options=>{focusOptions=options;document.activeElement=canvas;};h.game.begin(true);assert.equal(document.activeElement,canvas);assert.deepEqual(focusOptions,{preventScroll:true});
 h.dispatchKey({code:'KeyQ',target:document.activeElement});assert.equal(h.qa.session.shots,1);
});
test('pending capture never steals settings focus or presents READY',async()=>{
 fresh();h.game.pause();const canvas=h.element('game'),slider=h.element('sensitivity'),request=canvas.requestPointerLock;document.activeElement=slider;canvas.requestPointerLock=()=>Promise.resolve();h.game.begin(true);await Promise.resolve();assert.equal(document.activeElement,slider);assert.equal(h.element('hookstate').textContent,'CAPTURE MOUSE');assert(!h.qa.playing);h.key('KeyQ');assert.equal(h.qa.session.shots,0);
 canvas.requestPointerLock=request;h.element('mousecapture').onclick();assert.equal(document.activeElement,canvas);assert.equal(h.element('hookstate').textContent,'READY');h.dispatchKey({code:'KeyQ',target:document.activeElement});assert.equal(h.qa.session.shots,1);
});
test('text and range editing guards remain intact rather than hijacking their keys',()=>{
 fresh();for(const target of [{tagName:'INPUT'},{tagName:'TEXTAREA'},{tagName:'SELECT'},{tagName:'DIV',isContentEditable:true}])h.dispatchKey({code:'KeyQ',target});assert.equal(h.qa.session.shots,0);h.dispatchKey({code:'KeyQ',target:{tagName:'CANVAS'}});assert.equal(h.qa.session.shots,1);
});
for(const shift of ['ShiftLeft','ShiftRight'])test(`W stays forward movement; ${shift} alone casts Overdrive`,()=>{
 fresh();const before=h.qa.player.z;h.key('KeyW');h.frames(10);assert(h.qa.player.z<before);assert.equal(h.qa.skills.boost,0);h.key(shift);assert.equal(h.qa.skills.boost,4);assert.equal(h.element('hitnotice').textContent,'SHIFT  OVERDRIVE');h.frames(20);const boost=h.qa.skills.boost;h.dispatchKey({code:shift,repeat:true});assert.equal(h.qa.skills.boost,boost);h.release('KeyW');h.release(shift);
});

test('ordinary and powered punch update Q blocked state before the next animation frame',()=>{
 fresh();h.punch();assert.equal(h.element('hookstate').textContent,'PUNCHING');assert.equal(h.element('hookability').attributes['data-ready'],'false');
 fresh();h.key('KeyE');h.frames(53);assert.equal(h.element('hookstate').textContent,'READY');h.punch();assert.equal(h.element('hookstate').textContent,'CASTING');assert.equal(h.element('touchhook').attributes['aria-disabled'],'true');
});
