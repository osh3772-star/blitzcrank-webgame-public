import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// Real game logic and Three scene graph; simulated DOM, pointer lock and GPU.
const h=await createGameplayHarness({delta:()=>.05});
const mouse=(button=0,extra={})=>h.element('game').listeners.pointerdown({pointerType:'mouse',button,preventDefault(){},...extra});
const until=predicate=>{for(let n=0;n<100&&!predicate();n++)h.frames(1);assert(predicate(),'bounded state transition');};
const modes=[['challenge',false,false,false],['practice',true,false,false],['combo',true,true,false],['duel',true,false,true]];
function start([,practice,combo,duel]){
 h.docListeners.pointerdown({pointerType:'mouse'});h.game.begin(practice,combo,duel);
 if(duel){h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0})});until(()=>h.qa.duel.active);h.game.data.duelBot.position.set(12,1.7,-12);}
 else for(const target of h.game.data.targets){target.active=target.group.visible=false;target.respawn=Infinity;}
}
for(const mode of modes){
 test(`${mode[0]}: only left click consumes E charge, without Q or Flash`,()=>{
  start(mode);h.key('KeyE');until(()=>h.qa.skills.phase==='E_Hold');
  for(const button of [2,1])mouse(button);assert.equal(h.qa.skills.phase,'E_Hold');assert.equal(h.game.data.punchCooldown,0);
  mouse();assert.equal(h.qa.skills.phase,'E_Strike');assert(h.game.data.punchCooldown>0);const cd=h.game.data.punchCooldown;
  mouse();h.element('game').listeners.click?.({detail:1});assert.equal(h.game.data.punchCooldown,cd);
  assert.equal(h.qa.hook,null);assert.equal(h.qa.flashAbility.casts,0);
 });
 if(mode[0]!=='combo')for(const third of [false,true])test(`${mode[0]} ${third?'third':'first'} person: left click punches once and Q stays independent`,()=>{
  start(mode);if((h.qa.view==='third')!==third)h.key('KeyV');
  mouse(2);assert.equal(h.game.data.punchCooldown,0);mouse();assert(h.game.data.punchCooldown>0);assert.equal(h.qa.hook,null);
  h.key('KeyQ');assert.equal(h.qa.hook,null,'Q waits for the existing punch animation');
  h.frames(30);h.key('KeyQ');assert(h.qa.hook,'Q still launches its separate grab');const hook=h.qa.hook;
  mouse();mouse(2);assert.equal(h.game.data.punchCooldown,0,'neither button interrupts a grab');assert.equal(h.qa.hook.phase,hook.phase);
 });
}
test('menu, pause and results canvas left click never attacks; resume does not punch',()=>{
 h.game.pause();h.element('mainmenu').onclick();assert.equal(h.qa.state,'menu');mouse();assert.equal(h.game.data.punchCooldown,0);
 start(modes[1]);h.game.pause();mouse();mouse(2);assert.equal(h.game.data.punchCooldown,0);
 h.game.resume();assert.equal(h.game.data.punchCooldown,0);mouse();assert(h.game.data.punchCooldown>0);
 start(modes[0]);h.game.finish();assert.equal(h.qa.state,'results');mouse();assert.equal(h.game.data.punchCooldown,0);
});
test('touch look and compatibility mouse events do not punch; touch attack remains usable',()=>{
 start(modes[1]);mouse(0,{pointerType:'touch',pointerId:41,clientX:800,clientY:400});assert.equal(h.game.data.punchCooldown,0);
 mouse(0,{sourceCapabilities:{firesTouchEvents:true}});assert.equal(h.game.data.punchCooldown,0);
 h.element('touchpunch').onpointerdown({pointerType:'touch',button:0,preventDefault(){}});assert(h.game.data.punchCooldown>0);
});
test('all current desktop instructions say left click and Q remains the grab key',()=>{
 const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8'),main=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8');
 assert.match(html,/<kbd>LEFT CLICK<\/kbd><span>근접 펀치/);assert.match(html,/<kbd>E → 좌클릭<\/kbd>/);
 assert.match(html,/aria-label="E 강철 주먹, 충전 후 마우스 좌클릭"/);assert(!/우클릭|RIGHT CLICK/.test(html+main));
 assert.match(html,/<kbd>Q<\/kbd><span>로켓 손/);assert.match(main,/if\(e.code==='KeyQ'\)fireHook\(\)/);
});
