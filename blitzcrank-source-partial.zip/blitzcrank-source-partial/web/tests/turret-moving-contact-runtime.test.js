import test from'node:test';import assert from'node:assert/strict';import{createGameplayHarness}from'./helpers/runtime-harness.js';
const h=await createGameplayHarness(),d=h.game.data;
function begin(){for(const k of['KeyW','KeyA','KeyS','KeyD'])h.release(k);h.game.begin(true);d.player.set(-8,1.7,-10);}
for(const view of['first','third'])test('actual normal turret shot and legal rightward walking register mid-frame contact in '+view+' person',()=>{
 begin();if(h.qa.view!==view)h.element('viewtoggle').click();let hits=0,shots=0;for(let f=0;f<76;f++){if(f===68)h.key('KeyD');h.frames(1);for(const e of d.turretArena.sim.events){if(e.type==='hit'){hits++;assert.equal(f,73);assert.equal(e.damage,18);}if(e.type==='shot')shots++;}if(f===72)assert.equal(h.qa.health,100);if(f===73)assert.equal(h.qa.health,82);}assert.equal(hits,1);assert.equal(shots,1);assert.equal(d.turretArena.sim.bullets.length,0);assert.equal(h.qa.state,'running');
});
test('range entry, normal damage and cover retain their existing clocks and damage',()=>{
 begin();d.player.set(0,1.7,7);h.frames(10);assert.equal(d.turretArena.sim.events.length,0);assert.equal(h.qa.health,100);d.player.set(-8,1.7,-12);let acquired=0,shot=-1,hit=-1;for(let f=0;f<120;f++){h.frames(1);for(const e of d.turretArena.sim.events){if(e.type==='acquired')acquired++;if(e.type==='shot')shot=f;if(e.type==='hit')hit=f;}}assert.equal(acquired,1);assert.equal(shot,44);assert(hit>shot);assert.equal(h.qa.health,82);
 begin();d.player.set(-7.4,1.7,-27);const e=[];for(let f=0;f<120;f++){h.frames(1);e.push(...d.turretArena.sim.events);}assert.equal(e.filter(x=>x.type==='blocked').length,1);assert.equal(e.filter(x=>x.type==='hit').length,0);assert.equal(h.qa.health,100);
});
test('main forwards only continuous movement after Flash, without sweeping the teleport path',()=>{
 begin();d.player.set(0,1.7,0);const observations=[],original=d.turretArena.step;d.turretArena.step=(dt,p,alive,start)=>{observations.push({dt,p:p.toArray(),start:start?.toArray()});return original(dt,p,alive,start);};try{const old=d.player.clone();h.game.castFlash();const destination=d.player.clone();assert(destination.distanceTo(old)>3);h.frames(1);assert.deepEqual(observations.at(-1).start,destination.toArray());assert.deepEqual(observations.at(-1).p,destination.toArray());}finally{d.turretArena.step=original;}
});
test('pause preserves bullet positions; restart, combo and bot mode do not retain a stale movement segment',()=>{
 begin();for(let f=0;f<50;f++)h.frames(1);assert(d.turretArena.sim.bullets.length);const old=structuredClone(d.turretArena.sim.bullets);h.game.pause();h.frames(10);assert.deepEqual(d.turretArena.sim.bullets,old);h.game.begin(true);h.frames(1);assert.equal(h.qa.health,100);assert.equal(d.turretArena.sim.bullets.length,0);h.game.begin(true,true);h.frames(2);assert.equal(h.qa.health,100);assert.equal(d.turretArena.sim.bullets.length,0);h.game.begin(false,false,true);h.frames(2);assert.equal(d.turretArena.sim.bullets.length,0);
});
