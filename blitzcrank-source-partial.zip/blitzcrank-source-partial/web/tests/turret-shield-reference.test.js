import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';import {GLTFLoader} from '../vendor/GLTFLoader.js';import {TURRET_MODEL_FILE,createTurretArena} from '../turret-view.js';
const load=async path=>{const bytes=fs.readFileSync(new URL(path,import.meta.url));const json=JSON.parse(bytes.subarray(20,20+bytes.readUInt32LE(12)).toString());const g=await new GLTFLoader().parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'');g.scene.updateMatrixWorld(true);return{bytes,json,scene:g.scene};};
const before=await load('../validation/turret-shield-v2425/turret-v2424.glb'),after=await load('../assets/turret/'+TURRET_MODEL_FILE),shield=await load('../validation/turret-surface-v2433/turret-v2432.glb');
test('turret reference asset is immutable, embedded-only and refreshed by current loader',()=>{
 assert.equal(TURRET_MODEL_FILE,'turret.'+crypto.createHash('sha256').update(after.bytes).digest('hex').slice(0,16)+'.glb');assert(after.json.buffers.every(b=>!b.uri));assert.equal((after.json.images||[]).length,0);assert.equal((after.json.animations||[]).length,0);
 const version=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url))).version;assert(fs.readFileSync(new URL('../main.js',import.meta.url),'utf8').includes(`from './turret-view.js?v=${version}'`));
});
test('historical turret shield correction preserves exact hierarchy, materials, bounds, primitive count and triangles',()=>{
 const after=shield;
 assert.deepEqual(after.json.nodes,before.json.nodes);assert.deepEqual(after.json.materials,before.json.materials);assert.deepEqual(new THREE.Box3().setFromObject(after.scene),new THREE.Box3().setFromObject(before.scene));assert.equal(after.json.meshes.length,3);assert.equal(after.json.meshes.flatMap(m=>m.primitives).length,22);const triangles=m=>m.json.meshes.flatMap(m=>m.primitives).reduce((n,p)=>n+m.json.accessors[p.indices].count/3,0);assert.equal(triangles(after),6069);assert.equal(triangles(after),triangles(before));
});
test('historical shield edit preserves twenty unaffected turret primitives and bounded unused UV rounding',()=>{
 const after=shield;
 const geometries=m=>{const result={};m.scene.traverse(n=>{if(n.isMesh)result[n.parent.name+'/'+n.material.name]=n.geometry;});return result;},a=geometries(before),b=geometries(after);let n=0;
 for(const name of Object.keys(a))if(!['StaticTower_Geometry/Antique gold trim','StaticTower_Geometry/Shield blue enamel'].includes(name)){
  assert.deepEqual(b[name].index.array,a[name].index.array,name);assert.deepEqual(b[name].attributes.position.array,a[name].attributes.position.array,name+' positions');assert.deepEqual(b[name].attributes.normal.array,a[name].attributes.normal.array,name+' normals');const x=a[name].attributes.uv?.array,y=b[name].attributes.uv?.array;if(x){assert.equal(y.length,x.length);for(let i=0;i<x.length;i++)assert(Math.abs(x[i]-y[i])<=6e-8,name+' unused UV');}n++;
 }assert.equal(n,20);
});
for(const x of [-.5,.5])test(`turret deeper V clears the old lower shoulder at x=${x}`,()=>{
 const cast=m=>new THREE.Raycaster(new THREE.Vector3(x,3.4,3),new THREE.Vector3(0,0,-1)).intersectObject(m.scene,true)[0];const a=cast(before),b=cast(after);assert.equal(a.object.material.name,'Antique gold trim');assert.match(b.object.material.name,/^Slate masonry/);assert(b.point.z<a.point.z-.2);
});
test('turret aim, muzzle, recoil, colliders and event stream are identical over 300 moving-player steps',()=>{
 const pair=[before,after].map(m=>{const obstacles=[];return{obstacles,arena:createTurretArena(new THREE.Scene(),m.scene,obstacles)};});assert.deepEqual(pair[1].obstacles,pair[0].obstacles);let shots=0;
 for(let i=0;i<300;i++){const p={x:-8+Math.sin(i*.01),y:1.7,z:-12},a=pair[0].arena.step(1/60,p),b=pair[1].arena.step(1/60,p);assert.deepEqual(b,a);shots+=a.filter(e=>e.type==='shot').length;for(const id of ['west','east']){const x=pair[0].arena.visuals.get(id),y=pair[1].arena.visuals.get(id);assert.deepEqual(y.muzzle.matrixWorld.elements,x.muzzle.matrixWorld.elements);assert.deepEqual(y.barrel.position,x.barrel.position);}}
 assert(shots>=2);
});
