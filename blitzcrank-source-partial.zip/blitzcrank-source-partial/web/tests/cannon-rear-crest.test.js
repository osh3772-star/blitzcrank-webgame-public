import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {TARGET_TYPES,TARGET_MODEL_FILES,loadCharacterTargets} from '../target-models.js';
const file=path=>fileURLToPath(new URL(path,import.meta.url));
const expected='1720a299e7573d6faa0a868d55d12bd4297ea48d066ac444df2e11377fcfea73';
test('historical cannon rear crest remains immutable and current loader matches its manifest',async()=>{
 const historical=fs.readFileSync(file('../assets/targets/cannon.'+expected.slice(0,16)+'.glb'));assert.equal(crypto.createHash('sha256').update(historical).digest('hex'),expected);
 const bytes=fs.readFileSync(file('../assets/targets/'+TARGET_MODEL_FILES.cannon));const currentHash=crypto.createHash('sha256').update(bytes).digest('hex');assert.equal(TARGET_MODEL_FILES.cannon,'cannon.'+currentHash.slice(0,16)+'.glb');assert.equal(historical.length,683572);
 const row=JSON.parse(fs.readFileSync(file('../assets/targets/source-manifest.json'))).find(x=>x.asset==='cannon');assert.equal(row.file,TARGET_MODEL_FILES.cannon);assert.equal(row.sha256,currentHash);assert.equal(row.bytes,bytes.length);assert.equal(row.triangles,9998);assert.equal(row.materials,7);assert.equal(row.draw_primitives,7);
 const requested=[],allowed=TARGET_TYPES.map(type=>'./assets/targets/'+TARGET_MODEL_FILES[type.id]);
 const assets=await loadCharacterTargets(async url=>{assert(allowed.includes(url));requested.push(url);const data=fs.readFileSync(file('../'+url.slice(2)));const json=JSON.parse(data.subarray(20,20+data.readUInt32LE(12)));assert(json.buffers.every(buffer=>!buffer.uri));assert.equal((json.images||[]).length,0);return{ok:true,arrayBuffer:async()=>data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength)};});
 assert.deepEqual(requested,allowed);assert.deepEqual(assets.map(x=>x.id),TARGET_TYPES.map(x=>x.id));let triangles=0;assets.find(x=>x.id==='cannon').scene.traverse(o=>{if(o.isMesh)triangles+=o.geometry.index.count/3;});assert.equal(triangles,9998);
});
test('historical cannon rear crest preserves exact decoded scope, 1029 front rays, 24 muzzle rays and actual collider',()=>{
 const report=JSON.parse(execFileSync(process.execPath,['--max-old-space-size=128',file('../validation/cannon-rear-crest-v2474/regression.mjs'),'--baseline',file('../validation/recovered-assets/cannon.ea1159ec02004cd1.glb'),'--candidate',file('../assets/targets/cannon.'+expected.slice(0,16)+'.glb'),'--three',file('../vendor/three.module.js'),'--loader',file('../vendor/GLTFLoader.js'),'--target-models',file('../target-models.js'),'--fixture',file('../validation/cannon-rear-crest-v2474/regression-fixture.json')],{encoding:'utf8',timeout:20000,maxBuffer:1024*1024}));
 assert.equal(report.pass,true);assert.equal(report.inputs.candidate.sha256,expected);assert.equal(report.meshCount,1);assert.equal(report.primitiveCount,7);assert.equal(report.materialDefinitionsExact,true);assert.equal(report.nodesExact,true);assert.equal(report.runtimeEnvelopeExact,true);assert.equal(report.muzzleRaysExact24,true);assert.deepEqual(report.frontHelmet,{probes:1029,exactPositionsAndMaterials:true,existingSilverCrestHits:50});assert.equal(report.rearStripSilverHits,8);assert.equal(report.decoded.filter(x=>x.exact).length,5);assert.deepEqual(report.decoded.filter(x=>!x.exact).map(x=>[x.name,x.removed.triangles,x.added.triangles]),[['Steel edge highlights',0,20],['Royal blue enamel',18,26]]);assert.equal(report.networkCalls,0);assert.equal(report.externalResourceCallbacks,0);assert.equal(report.filesWrittenByScript,0);
});
