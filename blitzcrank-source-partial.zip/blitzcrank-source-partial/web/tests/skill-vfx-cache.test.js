import test from 'node:test';
import assert from 'node:assert/strict';
import {createSkillVfx} from '../skill-vfx.js';
import {createSkillVfxHarness, vfxStatus, vfxState} from './helpers/skill-vfx-harness.js';

function eResources(h) {
  const meshes = h.owned.filter(o => o.name.startsWith('E_lavender_fist_lightning_'));
  return {geometries: [...new Set(meshes.map(m => m.geometry))], materials: [...new Set(meshes.map(m => m.material))]};
}
const versions = geometries => geometries.map(g => Object.values(g.attributes).map(a => a.version));
const tick = (h, dt, status = vfxStatus(), extra = {}) => h.vfx.update(dt, {status, position: {x: 2, y: 1.7, z: -3}, yaw: .4, ...extra});

test('E reuses one source tick but strength and glow still change each simulation update', () => {
  const h = createSkillVfxHarness(createSkillVfx), e = eResources(h);
  tick(h, .005, vfxStatus('E_Charge', 0));
  const before = versions(e.geometries), arrays = e.geometries.map(g => g.attributes.position.array.slice());
  tick(h, .006, vfxStatus('E_Charge', .06));
  assert.deepEqual(versions(e.geometries), before);
  assert.equal(h.vfx.inspect().eStrength, .45 + .55 * .5);
  for (const material of e.materials) assert.equal(material.uniforms.uOpacity.value, h.vfx.inspect().eStrength);
  const glow = h.owned.find(o => o.isSprite && o.parent.name.startsWith('E_charged_fist_')).material;
  assert.equal(glow.opacity, .72 * h.vfx.inspect().eStrength);
  e.geometries.forEach((g, i) => assert.deepEqual(g.attributes.position.array, arrays[i]));
  tick(h, .024, vfxStatus('E_Charge', .1));
  assert.notDeepEqual(versions(e.geometries), before);
  e.geometries.forEach((g, i) => assert.notDeepEqual(g.attributes.position.array, arrays[i])); h.vfx.dispose();
});

test('E same-tick deactivation/reactivation restores cleared ranges and does not reuse a hidden batch', () => {
  const h = createSkillVfxHarness(createSkillVfx), e = eResources(h);
  tick(h, .005, vfxStatus('E_Hold', .2, {armed: 3}));
  const arrays = e.geometries.map(g => g.attributes.position.array.slice());
  tick(h, .001); for (const g of e.geometries) assert.equal(g.drawRange.count, 0);
  const cleared = versions(e.geometries);
  tick(h, .001, vfxStatus('E_Hold', .2, {armed: 3}));
  assert.notDeepEqual(versions(e.geometries), cleared);
  e.geometries.forEach((g, i) => { assert.equal(g.drawRange.count, 108 * 6); assert.deepEqual(g.attributes.position.array, arrays[i]); });
  h.vfx.dispose();
});

test('E cached geometry preserves Q/R charge and exact event-driven strike consumption', () => {
  const h = createSkillVfxHarness(createSkillVfx), e = eResources(h);
  tick(h, .001, vfxStatus('E_Hold', .2, {armed: 3})); const before = versions(e.geometries);
  for (const phase of ['Q_Launch', 'R_Cast']) tick(h, .001, vfxStatus(phase, .2, {armed: 2}));
  assert.deepEqual(versions(e.geometries), before); assert.equal(h.vfx.inspect().eStrength, 1);
  tick(h, .001, vfxStatus('E_Strike', .2)); h.vfx.event('power_fist_hit');
  tick(h, .001, vfxStatus('E_Strike', .21)); assert.equal(h.vfx.inspect().eStrength, 0);
  assert(!h.vfx.inspect().impactVisible); for (const g of e.geometries) assert.equal(g.drawRange.count, 0);
  h.vfx.dispose();
});

test('E reset invalidates cache, pause is a no-op, and delayed frames regenerate current tick only', () => {
  const h = createSkillVfxHarness(createSkillVfx), e = eResources(h);
  tick(h, .005, vfxStatus('E_Hold', .2, {armed: 3}));
  const frame = vfxState(h), original = versions(e.geometries);
  for (const dt of [0, -1, NaN, Infinity]) tick(h, dt);
  assert.deepEqual(vfxState(h), frame); assert.deepEqual(versions(e.geometries), original);
  h.vfx.reset(); const afterReset = versions(e.geometries);
  tick(h, .005, vfxStatus('E_Hold', .2, {armed: 3}));
  assert.notDeepEqual(versions(e.geometries), afterReset);
  for (const g of e.geometries) assert.equal(g.drawRange.count, 108 * 6);
  const beforeDelay = e.geometries.map(g => g.attributes.position.version);
  tick(h, 1000, vfxStatus('E_Hold', .2, {armed: 3}));
  e.geometries.forEach((g, i) => assert.equal(g.attributes.position.version, beforeDelay[i] + 1)); h.vfx.dispose();
});
