import test from 'node:test';import {rayBox} from '../core.js';import assert from 'node:assert/strict';import fs from 'node:fs';import * as RealThree from '../vendor/three.module.js';
// CPU-only smoke harness. It runs the actual game module and Three.js scene graph,
// but deliberately does not claim GPU rendering or physical-browser input coverage.
class Classes{constructor(){this.s=new Set();}toggle(x,force){if(force===undefined)force=!this.s.has(x);force?this.s.add(x):this.s.delete(x);}add(x){this.s.add(x);}remove(x){this.s.delete(x);}}
class Element{constructor(){this.style={};this.classList=new Classes();this.firstElementChild={style:{}};this.parentElement={classList:new Classes()};this.value='1';this.disabled=false;this.listeners={};this.textContent='';this.innerHTML='';}addEventListener(k,f){const previous=this.listeners[k];this.listeners[k]=e=>{previous?.(e);f(e);};}setAttribute(){}querySelector(){return new Element();}getBoundingClientRect(){return{left:0,top:0,width:110,height:110};}setPointerCapture(){}requestPointerLock(){document.pointerLockElement=this;docListeners.pointerlockchange?.();return Promise.resolve();}click(){this.onclick?.();}getContext(){return{fillRect(){},fillText(){},fillStyle:'',textAlign:'',font:''};}}
const elements=new Map(),docListeners={},winListeners={};let callback;
const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
globalThis.document={getElementById:element,querySelector:element,createElement:()=>new Element(),addEventListener:(n,f)=>docListeners[n]=f,pointerLockElement:null,exitPointerLock(){this.pointerLockElement=null;docListeners.pointerlockchange?.();}};globalThis.window=globalThis;globalThis.innerWidth=1280;globalThis.innerHeight=720;globalThis.devicePixelRatio=1;globalThis.matchMedia=()=>({matches:false});globalThis.localStorage={getItem:()=>null,setItem(){}};globalThis.addEventListener=(n,f)=>winListeners[n]=f;globalThis.requestAnimationFrame=f=>{callback=f;};globalThis.fetch=async(path)=>({ok:true,arrayBuffer:async()=>{const b=fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);},json:async()=>JSON.parse(fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url)))});
class Renderer{constructor(){this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}render(){}clearDepth(){}}
class Clock{getDelta(){return 1/60;}}
const sampleSources=[],synthSources=[],audioContexts=[];
class AudioContextMock{
 constructor(){this.state='suspended';this.currentTime=1;this.destination={};this.oscillators=[];this.listeners=new Set();audioContexts.push(this);}
 addEventListener(type,listener){if(type==='statechange')this.listeners.add(listener);}
 removeEventListener(type,listener){if(type==='statechange')this.listeners.delete(listener);}
 setState(state){this.state=state;for(const listener of this.listeners)listener();}
 advance(seconds){if(this.state!=='running')return;this.currentTime+=seconds;for(const o of this.oscillators)if(o.started&&!o.ended&&this.currentTime>=o.stopAt)o.end();}
 resume(){if(this.resumeGate)return this.resumeGate.then(()=>this.setState('running'));this.setState('running');return Promise.resolve();}
 createGain(){return{connect(){},disconnect(){},gain:{cancelScheduledValues(){},setValueAtTime(){},exponentialRampToValueAtTime(){}}};}
 decodeAudioData(data){const b=Buffer.from(data);let rate=0,size=0;for(let o=12;o+8<=b.length;){const n=b.readUInt32LE(o+4),kind=b.toString('ascii',o,o+4);if(kind==='fmt ')rate=b.readUInt32LE(o+16);if(kind==='data')size=n;o+=8+n+(n%2);}return Promise.resolve({duration:size&&rate?size/rate:(data.byteLength>120000?.73:.57),byteLength:data.byteLength});}
 createBufferSource(){const o={connect(){},disconnect(){},start(){o.started=true;},stop(){o.stopped=true;o.onended?.();}};sampleSources.push(o);return o;}
 createOscillator(){const ctx=this,o={context:ctx,stopAt:Infinity,connect(){},disconnect(){o.disconnected=true;},start(){o.started=true;},stop(when=ctx.currentTime){o.stopAt=when;if(when<=ctx.currentTime)o.end();},end(){if(o.ended)return;o.ended=true;o.onended?.();},get audible(){return Boolean(ctx.state==='running'&&o.started&&!o.ended&&!o.disconnected);},frequency:{setValueAtTime(v){o.freq=v;},exponentialRampToValueAtTime(){}}};this.oscillators.push(o);synthSources.push(o);return o;}
}
globalThis.AudioContext=AudioContextMock;
class TextureLoader{async loadAsync(path){assert(fs.existsSync(new URL('../'+path.replace('./',''),import.meta.url)));return new RealThree.Texture();}}
globalThis.testThree={...RealThree,WebGLRenderer:Renderer,Clock,TextureLoader};
let source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8').replace("import * as THREE from './vendor/three.module.js';",'const THREE = globalThis.testThree;').replace("from './hook-chain.js'",`from '${new URL('../hook-chain.js',import.meta.url).href}'`).replace("from './training-mirror.js'",`from '${new URL('../training-mirror.js',import.meta.url).href}'`).replace("from './game-audio.js'",`from '${new URL('../game-audio.js',import.meta.url).href}'`).replace("from './audio-cues.js'",`from '${new URL('../audio-cues.js',import.meta.url).href}'`).replace("from './voice-cues.js'",`from '${new URL('../voice-cues.js',import.meta.url).href}'`).replace("from './voice-schedule.js'",`from '${new URL('../voice-schedule.js',import.meta.url).href}'`).replace("from './blitz-materials.js'",`from '${new URL('../blitz-materials.js',import.meta.url).href}'`).replace("from './core.js'",`from '${new URL('../core.js',import.meta.url).href}'`).replace("from './mouse-look.js'",`from '${new URL('../mouse-look.js',import.meta.url).href}'`).replace("from './target-models.js'",`from '${new URL('../target-models.js',import.meta.url).href}'`).replace("from './turret-view.js'",`from '${new URL('../turret-view.js',import.meta.url).href}'`);
source+=`\nwindow.__MOTION__={get data(){return{hook,fist,rope,parts,projectileParts,camera,viewCamera,viewmodel,targets,obstacles,fullbodySocket,player,turretArena,fullbodyNodes,fullbodyMeshes}},prepareMirrorBody,restoreMirrorBody,fullbodyCableSocket,fullbodyChainSocket,get mirror(){return trainingMirror},handPoint,cableSocket,chainHandSocket,nearestRay,begin,pause,resume,finish,damagePlayer,audio,gameAudio,setDuelBotSource(source){duelBrain=source}};`;
source=source.replace("from './model-codec.js'",`from '${new URL('../model-codec.js',import.meta.url).href}'`).replace("from './player-model-manifest.js'",`from '${new URL('../player-model-manifest.js',import.meta.url).href}'`);
source=source.replace(/from '\.\/([^']+)'/g,(_,path)=>`from '${new URL('../'+path,import.meta.url).href}'`);
// This fixture exercises initialized gameplay, not the natural first selection.
source+='\nif(typeof ensureGameplayAssets==="function")await ensureGameplayAssets();';
await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const punch=()=>element('game').listeners.pointerdown({pointerType:'mouse',button:0,preventDefault(){}});
const key=code=>winListeners.keydown({code,repeat:false,preventDefault(){}}),release=code=>winListeners.keyup({code});const frames=n=>{for(let i=0;i<n;i++){for(const ctx of audioContexts)ctx.advance(1/60);callback();}};

const qa=window.__HOOK_ARENA__,motion=window.__MOTION__;
function fresh(third=false){motion.begin(true);if((qa.view==='third')!==third)key('KeyV');frames(1);}
function launch(){key('KeyQ');frames(16);assert.equal(motion.data.hook.phase,'outbound');}

async function ready(){fresh();await motion.gameAudio.unlock();await motion.gameAudio.preload();frames(1);motion.gameAudio.stopAll();sampleSources.length=0;synthSources.length=0;}
test('game sample starts once at accepted Q windup and does not double on launch',async()=>{await ready();key('KeyQ');assert.equal(qa.hook.phase,'windup');assert.equal(sampleSources.length,1);assert.equal(motion.data.hook.samplePlayed,true);key('KeyQ');assert.equal(sampleSources.length,1);frames(16);assert.equal(qa.hook.phase,'outbound');assert.equal(sampleSources.length,1);assert(!synthSources.some(o=>o.freq===650));});
test('original punch sample only accompanies a successful melee hit',async()=>{await ready();for(const t of motion.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}punch();assert.equal(sampleSources.length,0);assert(synthSources.some(o=>o.freq===125));await ready();for(const t of motion.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}const t=motion.data.targets.find(t=>t.type==='mage');t.active=true;t.group.visible=true;t.group.position.set(0,1.7,5);punch();assert.equal(qa.session.score,40);assert.equal(sampleSources.length,1);assert.equal(sampleSources[0].buffer.duration,.57);assert(!synthSources.some(o=>o.freq===700||o.freq===125));});
test('game mute and pause stop current sounds and do not replay old samples',async()=>{await ready();key('KeyQ');assert.equal(qa.audio.active,1);element('sound').onclick();assert.equal(qa.audio.muted,true);assert.equal(qa.audio.active,0);element('sound').onclick();assert.equal(qa.audio.active,0);motion.pause();assert.equal(qa.audio.paused,true);motion.resume();assert.equal(qa.audio.paused,false);assert.equal(qa.audio.active,0);});
test('restart clears old audio and capture loss pauses playback',async()=>{await ready();key('KeyQ');const previous=sampleSources[0];motion.begin(true);assert.equal(previous.stopped,true);assert.equal(qa.audio.active,1,'new run starts its own voice');assert(motion.gameAudio.isGroupPlaying('voice'));key('KeyQ');assert.equal(qa.audio.active,2);document.exitPointerLock();assert.equal(qa.state,'paused');assert.equal(qa.audio.active,0);assert.equal(qa.audio.paused,true);});

test('new training speaks the requested start once; resume only restarts ordinary interval',async()=>{await ready();sampleSources.length=0;motion.begin(true);assert.equal(sampleSources.length,1);assert(motion.gameAudio.isGroupPlaying('voice'));motion.pause();motion.resume();frames(2);assert.equal(sampleSources.length,1,'resume must not replay start');motion.gameAudio.stopAll();frames(1201);assert.equal(sampleSources.length,2);assert(qa.voice.last?.startsWith('voice:'));assert.notEqual(qa.voice.last,'voice:age-of-man');});
test('muted start is discarded rather than appearing on later unmute',async()=>{await ready();element('sound').onclick();sampleSources.length=0;motion.begin(true);await motion.gameAudio.unlock();frames(30);assert.equal(sampleSources.length,0);element('sound').onclick();frames(2);assert.equal(sampleSources.length,0);assert.equal(qa.voice.pendingStart,false);});
test('confirmed death plays once and survives delayed pointer-lock loss, while a new run stops it',async()=>{await ready();sampleSources.length=0;motion.damagePlayer(100);assert.equal(qa.state,'results');assert.equal(qa.voice.running,false);assert.equal(qa.audio.active,1);assert.equal(sampleSources.length,1);docListeners.pointerlockchange?.();frames(10);assert.equal(qa.audio.paused,false);assert.equal(qa.audio.active,1);motion.damagePlayer(100);assert.equal(sampleSources.length,1);const death=sampleSources[0];motion.begin(true);assert.equal(death.stopped,true);});

test('leaving the window stops the result-screen death voice without replay on return',async()=>{await ready();sampleSources.length=0;motion.damagePlayer(100);assert.equal(qa.audio.active,1);const death=sampleSources[0];winListeners.blur();assert.equal(qa.state,'results');assert.equal(qa.audio.active,0);assert.equal(death.stopped,true);docListeners.pointerlockchange?.();frames(2);assert.equal(qa.audio.active,0);assert.equal(sampleSources.length,1);});
test('hiding the tab stops the result-screen death voice even without a blur event',async()=>{await ready();sampleSources.length=0;motion.damagePlayer(100);assert.equal(qa.audio.active,1);document.hidden=true;docListeners.visibilitychange();assert.equal(qa.state,'results');assert.equal(qa.audio.active,0);document.hidden=false;docListeners.visibilitychange();frames(2);assert.equal(qa.audio.active,0);assert.equal(sampleSources.length,1);});


for(const action of ['mute','pause','menu','restart','blur','hidden','capture loss','finish']){
 test(`neutral tones stop immediately on ${action} and never replay`,async()=>{
  await ready();motion.audio(220,700,.2);const tone=synthSources.at(-1);assert.equal(tone.audible,true);
  try{
   if(action==='mute')element('sound').onclick();
   if(action==='pause')motion.pause();
   if(action==='menu')element('mainmenu').onclick();
   if(action==='restart')motion.begin(true);
   if(action==='blur')winListeners.blur();
   if(action==='hidden'){document.hidden=true;docListeners.visibilitychange();}
   if(action==='capture loss')document.exitPointerLock();
   if(action==='finish')motion.finish();
   assert.equal(tone.audible,false,`${action} must stop an already audible neutral oscillator`);
  }finally{if(qa.audio.muted)element('sound').onclick();document.hidden=false;}
  motion.resume();assert.equal(tone.audible,false,'later resume must not resurrect the tone');
 });
}
test('neutral events during suspended unlock are discarded instead of starting later',async()=>{
 await ready();motion.audio(220,700,.2);const context=synthSources.at(-1).context;context.advance(1);
 let release;context.resumeGate=new Promise(resolve=>release=resolve);context.setState('suspended');
 const before=synthSources.length;motion.audio(130,430,.3);const resumed=motion.gameAudio.unlock();motion.pause();release();await resumed;delete context.resumeGate;
 assert.equal(context.state,'running','the resumed context must remain silent despite being runnable');
 assert.equal(synthSources.length,before,'a suspended event must not create a scheduled oscillator');
 assert(!synthSources.some(o=>o.context===context&&o.audible),'resuming must not replay a paused event');
});

test('lethal impact alone finishes its exact tail across results and early death-voice end',async()=>{
 await ready();motion.audio(220,700,.25);const previous=synthSources.at(-1);motion.damagePlayer(100);const impact=synthSources.at(-1);
 assert.equal(qa.state,'results');assert.equal(impact.freq,95);assert.equal(previous.audible,false);assert.equal(impact.audible,true);assert.equal(qa.audio.activeTones,1);assert.equal(qa.audio.tonesPaused,true);
 docListeners.pointerlockchange?.();assert.equal(impact.audible,true);
 const count=synthSources.length;assert.equal(motion.audio(130,430,.3),false);assert.equal(synthSources.length,count,'result state must reject unrelated tones');
 sampleSources.at(-1).onended();frames(1);assert.equal(qa.audio.paused,true);assert.equal(impact.audible,true,'voice end must not truncate the damage cue');
 frames(7);assert.equal(impact.audible,true);frames(3);assert.equal(impact.audible,false);assert.equal(qa.audio.activeTones,0);assert.equal(impact.disconnected,true);
});
for(const action of ['mute','menu','restart','blur','hidden']){
 test(`lethal impact is still cancelled by ${action}`,async()=>{
  await ready();motion.damagePlayer(100);const impact=synthSources.at(-1);assert.equal(impact.audible,true);
  try{
   if(action==='mute')element('sound').onclick();
   if(action==='menu')element('mainmenu').onclick();
   if(action==='restart')motion.begin(true);
   if(action==='blur')winListeners.blur();
   if(action==='hidden'){document.hidden=true;docListeners.visibilitychange();}
   assert.equal(impact.audible,false);docListeners.pointerlockchange?.();assert.equal(impact.audible,false);
  }finally{if(qa.audio.muted)element('sound').onclick();document.hidden=false;}
 });
}
test('neutral playback shares the sampled AudioContext and never resumes it from a game event',async()=>{
 await ready();assert.equal(audioContexts.length,1);const context=audioContexts[0];let resumes=0;const original=context.resume;
 context.resume=function(){resumes++;return original.call(this);};
 try{motion.audio(220,700,.2);motion.damagePlayer(1);assert.equal(resumes,0);assert.equal(audioContexts.length,1);}finally{context.resume=original;}
});
test('rapid actual-game restart, pause, resume and mute cannot revive stopped tones',async()=>{
 await ready();
 for(let i=0;i<20;i++){
  motion.audio(220,700,.2);const previous=synthSources.at(-1);motion.pause();assert.equal(previous.audible,false);
  motion.resume();element('sound').onclick();motion.begin(true);element('sound').onclick();
  assert.equal(previous.audible,false);assert.equal(qa.audio.activeTones,0);
 }
});

const skillSampleCount=bytes=>sampleSources.filter(s=>s.buffer?.byteLength===bytes).length;
test('official W excerpt starts only on accepted cast, ending once after simulated pause/resume',async()=>{
 await ready();key('ShiftLeft');key('ShiftLeft');assert.equal(skillSampleCount(263084),1);assert(!synthSources.some(s=>s.freq===220));
 frames(120);motion.pause();const count=sampleSources.length;frames(600);assert.equal(sampleSources.length,count);motion.resume();frames(125);
 assert.equal(skillSampleCount(343724),1);frames(180);assert.equal(skillSampleCount(343724),1);
});
test('official E charge and true hit samples are distinct; a miss does not play impact',async()=>{
 await ready();for(const t of motion.data.targets){t.active=false;t.respawn=Infinity;}key('KeyE');key('KeyE');assert.equal(skillSampleCount(236204),1);frames(53);punch();frames(25);assert.equal(skillSampleCount(259244),0);
 await ready();for(const t of motion.data.targets){t.active=false;t.respawn=Infinity;}const t=motion.data.targets[0];t.active=true;t.group.visible=true;t.anchor.set(0,1.7,5);t.group.position.copy(t.anchor);t.amplitude=0;key('KeyE');frames(53);punch();frames(25);
 assert.equal(skillSampleCount(236204),1);assert.equal(skillSampleCount(259244),1);assert.equal(qa.skills.metrics.powerHits,1);assert(!synthSources.some(s=>s.freq===650));assert.equal(sampleSources.length,2);
});
test('official R composite starts once at cast and has no duplicate discharge audio',async()=>{
 await ready();key('KeyR');key('KeyR');assert.equal(skillSampleCount(313004),1);frames(25);assert.equal(qa.skills.metrics.discharges,1);assert.equal(skillSampleCount(313004),1);assert(!synthSources.some(s=>s.freq===130||s.freq===1200));
});
test('cancelled W does not play an ending excerpt in a later run',async()=>{
 await ready();key('ShiftLeft');frames(100);motion.begin(true);sampleSources.length=0;frames(400);assert.equal(skillSampleCount(343724),0);
});
for(const keyCode of ['ShiftLeft','KeyE','KeyR'])test(`new skill sample ${keyCode} obeys mute, pause and no stale replay`,async()=>{
 await ready();key(keyCode);const source=sampleSources[0];assert(source?.started);element('sound').onclick();assert(source.stopped);assert.equal(qa.audio.active,0);element('sound').onclick();assert.equal(qa.audio.active,0);motion.pause();motion.resume();assert.equal(qa.audio.active,0);
});

for(const keyCode of ['KeyQ','ShiftLeft','KeyE','KeyR'])test(`decoded ${keyCode} sample is discarded on audio-only interruption`,async()=>{
 await ready();key(keyCode);const source=sampleSources.at(-1),count=sampleSources.length,ctx=audioContexts.at(-1);assert(source?.started);assert(!source.stopped);assert.equal(qa.state,'running');
 ctx.setState('interrupted');assert(source.stopped);assert.equal(qa.audio.active,0);assert.equal(qa.state,'running');
 ctx.setState('running');assert.equal(sampleSources.length,count);assert.equal(qa.audio.active,0);assert(source.stopped);
 assert(motion.gameAudio.playEvent('punchHit'));assert.equal(qa.audio.active,1);assert.equal(sampleSources.length,count+1);
});
test('audio-only interruption drops result voice without changing results or restarting it',async()=>{
 await ready();motion.damagePlayer(100);assert.equal(qa.state,'results');const source=sampleSources.at(-1),count=sampleSources.length,ctx=audioContexts.at(-1);assert(source?.started);assert(!source.stopped);
 ctx.setState('suspended');assert(source.stopped);assert.equal(qa.audio.active,0);ctx.setState('running');frames(5);assert.equal(qa.state,'results');assert.equal(sampleSources.length,count);assert.equal(qa.audio.active,0);
});

test('actual turret simulation connects acquisition, each shot and actual damage to separate recordings',async()=>{
 await ready();const d=motion.data,boxes=d.obstacles.splice(0),events=[];d.player.set(-12,1.7,-10);
 try{for(let i=0;i<180;i++)events.push(...d.turretArena.step(1/60,d.player,true));
  const count=t=>events.filter(e=>e.type===t).length,samples=duration=>sampleSources.filter(s=>Math.abs(s.buffer.duration-duration)<1e-8).length;
  assert.equal(count('acquired'),1);assert(count('shot')>=1);assert(count('hit')>=1);
  assert.equal(samples(.44),count('acquired'));assert.equal(samples(.53),count('shot'));assert.equal(samples(.56),count('hit'));
  assert.equal(qa.health,100-18*count('hit'));assert(!synthSources.some(s=>[480,270,95].includes(s.freq)),'no duplicate synthetic turret sounds');
 }finally{d.obstacles.push(...boxes);}
});
test('windup, cancelled, obstructed and expired turret events do not claim a hit or acquisition recording',async()=>{
 await ready();const arena=motion.data.turretArena,original=arena.sim.step;
 try{arena.sim.step=()=>['windup','cancel','blocked','expired','lost'].map(type=>({type,turretId:'west'}));arena.step(1/60,motion.data.player,true);assert.equal(sampleSources.length,0);assert.equal(qa.health,100);}finally{arena.sim.step=original;}
});
test('lethal turret recording finishes after early death voice end and delayed pointer-lock loss',async()=>{
 await ready();motion.damagePlayer(100,true);assert.equal(qa.state,'results');assert.equal(sampleSources.length,2);const impact=sampleSources.find(s=>s.buffer.duration===.56),death=sampleSources.find(s=>s!==impact);
 assert(impact?.started);assert(!impact.stopped);death.onended();frames(1);docListeners.pointerlockchange?.();assert.equal(qa.audio.paused,false);assert(!impact.stopped);assert.equal(qa.audio.active,1);impact.onended();frames(1);assert.equal(qa.audio.paused,true);assert.equal(qa.audio.active,0);
});
for(const action of ['mute','pause','restart','blur','hidden'])test(`turret sample is cancelled by ${action} and never replayed`,async()=>{
 await ready();motion.damagePlayer(1,true);const sample=sampleSources.at(-1);assert.equal(sample.buffer.duration,.56);
 try{if(action==='mute')element('sound').onclick();if(action==='pause')motion.pause();if(action==='restart')motion.begin(true);if(action==='blur')winListeners.blur();if(action==='hidden'){document.hidden=true;docListeners.visibilitychange();}assert.equal(sample.stopped,true);const count=sampleSources.length;frames(2);assert.equal(sampleSources.length,count);}
 finally{if(qa.audio.muted)element('sound').onclick();document.hidden=false;}
});
test('turret audio failure or pending decode drops the event without synthetic replacement or delayed replay',async()=>{
 await ready();const play=motion.gameAudio.playEvent;let requested=[];motion.gameAudio.playEvent=event=>{requested.push(event);return false;};
 try{motion.damagePlayer(1,true);assert.deepEqual(requested,['turretImpact']);assert.equal(sampleSources.length,0);assert.equal(synthSources.length,0);assert.equal(qa.health,99);}finally{motion.gameAudio.playEvent=play;}
 frames(1);assert.equal(sampleSources.length,0);
});


function fixedDuelBot(castQ=true){return{reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ,jump:false})};}
async function readyDuel(){await ready();motion.begin(true,false,true);motion.setDuelBotSource(fixedDuelBot());await motion.gameAudio.unlock();motion.gameAudio.stopAll();sampleSources.length=0;synthSources.length=0;}
test('bot Q starts the existing recording once at accepted windup, not every held intent or launch',async()=>{
 await readyDuel();frames(90);assert.equal(qa.duel.match.phase,'countdown');assert.equal(sampleSources.length,0);frames(7);assert.equal(qa.duel.bot.hook.phase,'windup');assert.equal(sampleSources.length,1);assert.equal(sampleSources[0].buffer.byteLength,fs.statSync(new URL('../assets/audio/hook-cast.wav',import.meta.url)).size);frames(16);assert.equal(qa.duel.bot.hook.phase,'outbound');assert.equal(sampleSources.length,1);
});


test('simultaneous player and bot Q keep their own recording and stop on pause without replay',async()=>{
 await readyDuel();frames(97);const opponent=sampleSources[0];key('KeyQ');const local=sampleSources[1];assert.equal(sampleSources.length,2);assert.equal(opponent.stopped,undefined);assert.strictEqual(local.buffer,opponent.buffer);
 motion.pause();assert(opponent.stopped);assert(local.stopped);const count=sampleSources.length;frames(30);motion.resume();frames(2);assert.equal(sampleSources.length,count);
});
test('muted bot Q is dropped and is not replayed by unmute, rematch or menu',async()=>{
 await readyDuel();element('sound').onclick();try{frames(97);assert.equal(qa.duel.bot.hook.phase,'windup');assert.equal(sampleSources.length,0);}finally{element('sound').onclick();}
 frames(16);assert.equal(sampleSources.length,0);motion.begin(true,false,true);motion.setDuelBotSource(fixedDuelBot(false));const count=sampleSources.length;frames(100);assert.equal(sampleSources.length,count);motion.pause();element('mainmenu').click();assert.equal(qa.audio.active,0);frames(20);assert.equal(sampleSources.length,count);
});
test('unready bot Q is discarded without synthetic substitute or late launch replay',async()=>{
 await readyDuel();const original=motion.gameAudio.playEvent,events=[];motion.gameAudio.playEvent=(event,options)=>{events.push({event,options});return false;};
 try{frames(113);assert.equal(qa.duel.bot.hook.phase,'outbound');assert.deepEqual(events,[{event:'hookWindup',options:{emitter:'duel-bot'}}]);assert.equal(sampleSources.length,0);assert.equal(synthSources.length,0);}finally{motion.gameAudio.playEvent=original;}
 frames(1);assert.equal(sampleSources.length,0);
});

// Graphics context loss audio regressions.
// Reuses the actual-main CPU fixture and fake AudioContext; this does not
// exercise a real browser, GPU, or speaker.
const graphicsLoss = () => {
 let prevented = false;
 element('game').listeners.webglcontextlost({preventDefault(){prevented=true;}});
 assert.equal(prevented,true);
};
const restoreGraphics = () => element('game').listeners.webglcontextrestored({});
const assertAudioStopped = () => {
 assert.equal(qa.audio.active,0,'all decoded samples stop');
 assert.equal(qa.audio.activeTones,0,'all neutral tones stop');
 assert.equal(qa.audio.paused,true,'sample playback stays blocked');
 assert.equal(qa.audio.tonesPaused,true,'neutral playback stays blocked');
};

for (const interruption of ['graphics','blur','hidden']) {
 for (const tail of ['death-and-neutral','neutral-after-death','death-and-recorded','recorded-after-death']) {
  test(`${interruption} cancels result ${tail} immediately, without restoring old audio`,async()=>{
   await ready();
   const recorded=tail.includes('recorded');
   const expectedActive=tail==='death-and-recorded'?2:tail==='neutral-after-death'?0:1;
   motion.damagePlayer(100,recorded);
   const existingSamples=sampleSources.slice(),existingTones=synthSources.slice();
   if(tail.endsWith('after-death')){
    existingSamples.find(s=>s.buffer.duration!==.56).onended();
    frames(1);
   }
   assert.equal(qa.state,'results');
   assert.equal(qa.audio.active,expectedActive);
   assert.equal(qa.audio.activeTones,recorded?0:1);
   // Ordinary pointer unlock intentionally does not truncate final playback.
   docListeners.pointerlockchange?.();
   assert.equal(qa.audio.paused,tail==='neutral-after-death');
   assert.equal(qa.audio.active,expectedActive);
   if(!recorded)assert.equal(existingTones.at(-1).audible,true);
   const counts=[sampleSources.length,synthSources.length];
   const ctx=audioContexts.at(-1),originalResume=ctx.resume;
   let resumeCalls=0;
   ctx.resume=function(){resumeCalls++;return originalResume.call(this);};
   try{
    if(interruption==='graphics')graphicsLoss();
    if(interruption==='blur')winListeners.blur();
    if(interruption==='hidden'){document.hidden=true;docListeners.visibilitychange();}
    assert.equal(qa.state,'results','graphics failure must not turn results into a paused match');
    assertAudioStopped();
    for(const sample of existingSamples.filter(s=>!tail.endsWith('after-death')||s.buffer.duration===.56))assert.equal(sample.stopped,true);
    for(const tone of existingTones)assert.equal(tone.audible,false);
    // Check immediately, before frame polling can clear stale result flags.
    docListeners.pointerlockchange?.();
    assertAudioStopped();
    assert.equal(motion.gameAudio.playEvent('punchHit'),false);
    if(interruption==='graphics'){graphicsLoss();restoreGraphics();}
    if(interruption==='hidden'){document.hidden=false;docListeners.visibilitychange();}
    docListeners.pointerlockchange?.();
    frames(2);
    assert.equal(qa.state,'results');
    assertAudioStopped();
    assert.deepEqual([sampleSources.length,synthSources.length],counts,'return must not replay old events');
    assert.equal(resumeCalls,0,'loss/restore must not resume AudioContext');
    if(interruption==='graphics'){
     element('start').onclick();await motion.gameAudio.unlock();frames(1);
     assert.equal(qa.state,'running');assert.equal(qa.playing,true);
     assert.equal(qa.audio.paused,false);
     assert.equal(sampleSources.length,counts[0]+1,'a deliberate new run starts exactly its own voice');
     assert.equal(motion.gameAudio.isGroupPlaying('voice'),true);
     assert.equal(qa.voice.dead,false);
     for(const sample of existingSamples.filter(s=>!tail.endsWith('after-death')||s.buffer.duration===.56))assert.equal(sample.stopped,true);
     for(const tone of existingTones)assert.equal(tone.audible,false);
    }
   }finally{
    ctx.resume=originalResume;
    document.hidden=false;
    if(interruption==='graphics')restoreGraphics();
   }
  });
 }
}

for(const initialState of ['running','paused','menu','results']) {
 test(`graphics loss/restoration from ${initialState} keeps audio stopped until deliberate play`,async()=>{
  await ready();
  key('KeyQ');motion.audio(220,700,.2);
  const oldSample=sampleSources.at(-1),oldTone=synthSources.at(-1);
  assert(oldSample.started);assert(oldTone.audible);
  if(initialState==='paused')motion.pause();
  if(initialState==='menu')element('mainmenu').onclick();
  if(initialState==='results')motion.finish(); // Non-defeat result is intentionally silent.
  const expectedState=initialState==='running'?'paused':initialState;
  const ctx=audioContexts.at(-1),originalResume=ctx.resume;
  let resumeCalls=0;
  ctx.resume=function(){resumeCalls++;return originalResume.call(this);};
  try{
   graphicsLoss();
   assert.equal(qa.state,expectedState);assert.equal(qa.playing,false);
   assert.equal(oldSample.stopped,true);assert.equal(oldTone.audible,false);
   assertAudioStopped();
   for(const id of ['start','practice','combopractice','duelmode'])assert.equal(element(id).disabled,true);
   const frozen={time:qa.session.elapsed,health:qa.health};
   const counts=[sampleSources.length,synthSources.length];
   element('start').onclick();motion.resume();frames(3);
   assert.equal(qa.state,expectedState);
   assert.deepEqual({time:qa.session.elapsed,health:qa.health},frozen);
   assert.deepEqual([sampleSources.length,synthSources.length],counts);
   restoreGraphics();
   for(const id of ['start','practice','combopractice','duelmode'])assert.equal(element(id).disabled,false);
   docListeners.pointerlockchange?.();frames(3);
   assert.equal(qa.state,expectedState);assert.equal(qa.playing,false);
   assertAudioStopped();
   assert.deepEqual([sampleSources.length,synthSources.length],counts);
   assert.equal(resumeCalls,0);
   element('start').onclick();
   await motion.gameAudio.unlock();frames(1);
   assert.equal(qa.state,'running');assert.equal(qa.playing,true);
   assert.equal(qa.audio.paused,false);assert.equal(qa.audio.tonesPaused,false);
   assert(resumeCalls>0,'deliberate play can unlock audio again');
   if(expectedState==='paused')assert.deepEqual([sampleSources.length,synthSources.length],counts,'resume does not replay start or interrupted Q');
   assert.equal(oldSample.stopped,true);assert.equal(oldTone.audible,false);
   motion.gameAudio.stopAll();
   const before=sampleSources.length;
   motion.damagePlayer(1,true);
   assert.equal(sampleSources.length,before+1,'a fresh real gameplay event plays normally');
   assert.equal(sampleSources.at(-1).buffer.duration,.56);
   assert.equal(sampleSources.at(-1).stopped,undefined);
  }finally{ctx.resume=originalResume;restoreGraphics();}
 });
}


test('graphics loss during a pending audio unlock stays silent when that unlock resolves',async()=>{
 await ready();key('KeyQ');
 const oldSample=sampleSources.at(-1),ctx=audioContexts.at(-1);
 ctx.setState('suspended');motion.pause();
 let release;
 ctx.resumeGate=new Promise(resolve=>release=resolve);
 try{
  motion.resume();const pending=motion.gameAudio.unlock();
  assert.equal(qa.state,'running');assert.equal(ctx.state,'suspended');
  graphicsLoss();release();await pending;
  assert.equal(ctx.state,'running','audio resume can finish after graphics interruption');
  assert.equal(qa.state,'paused');assertAudioStopped();
  assert.equal(oldSample.stopped,true);
  const counts=[sampleSources.length,synthSources.length];
  restoreGraphics();docListeners.pointerlockchange?.();frames(3);
  assert.equal(qa.state,'paused');assertAudioStopped();
  assert.deepEqual([sampleSources.length,synthSources.length],counts);
  delete ctx.resumeGate;
  motion.resume();await motion.gameAudio.unlock();frames(1);
  assert.equal(qa.playing,true);assert.equal(qa.audio.paused,false);
  assert.deepEqual([sampleSources.length,synthSources.length],counts);
  motion.damagePlayer(1,true);
  assert.equal(sampleSources.length,counts[0]+1);
  assert.equal(oldSample.stopped,true);
 }finally{release?.();delete ctx.resumeGate;restoreGraphics();}
});
