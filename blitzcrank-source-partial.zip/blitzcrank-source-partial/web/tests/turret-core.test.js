import test from 'node:test';
import assert from 'node:assert/strict';
import { createTurretSimulation, segmentSphereHit } from '../turret-core.js';
const make = (extra={}) => createTurretSimulation({turrets:[{id:'a',position:{x:0,y:0,z:0}}],...extra});
const player = (x=10,z=0) => ({position:{x,y:1.3,z},radius:.5});
const has = (events,type) => events.some(e=>e.type===type);
test('inclusive planar range, independent of target height',()=>{
 const sim=make(); assert.equal(sim.step(.1,player(12.001)).length,0);
 const p=player(12);p.position.y=100;assert.ok(has(sim.step(.1,p),'windup'));
 assert.equal(sim.turrets[0].state,'windup');
});
test('telegraph precedes firing; cooldown and reacquisition are timed',()=>{
 const sim=make(); assert.ok(!has(sim.step(.74,player()),'shot'));
 assert.ok(has(sim.step(.01,player()),'shot'));
 assert.equal(sim.turrets[0].state,'cooldown');
 assert.ok(!has(sim.step(1.6,player()),'shot'));
 assert.ok(!has(sim.step(.74,player()),'shot'));
 assert.ok(has(sim.step(.01,player()),'shot'));
});
test('cover prevents acquisition and cancels warning; leaving range cancels',()=>{
 const sim=make(); const cover={isVisible:()=>false};
 assert.equal(sim.step(1,player(),cover).length,0);
 sim.step(.3,player());assert.ok(has(sim.step(.1,player(),cover),'cancel'));
 assert.equal(sim.turrets[0].state,'idle');sim.step(.3,player());
 assert.ok(has(sim.step(.5,player(13)),'cancel'));
 assert.ok(!has(sim.step(.5,player()),'shot'));
});
test('shot aims at latest position and player can dodge after launch',()=>{
 const sim=make();sim.step(.7,player());
 const events=sim.step(.05,player(0,10)); const shot=events.find(e=>e.type==='shot');
 assert.ok(shot.velocity.z>0);assert.equal(shot.velocity.x,0);
 assert.ok(!has(sim.step(.7,player(10,0)),'hit'));
});
test('swept collision catches player during a large time step',()=>{
 const sim=make();sim.step(.75,player());
 const hit=sim.step(1,player()).find(e=>e.type==='hit');
 assert.equal(hit.damage,18);assert.equal(sim.bullets.length,0);
});
test('nearest cover blocks shots, farther obstruction does not',()=>{
 const sim=make();sim.step(.75,player());
 const events=sim.step(1,player(),{obstruction:()=>.1});
 assert.ok(has(events,'blocked'));assert.ok(!has(events,'hit'));
 const other=make();other.step(.75,player());assert.ok(has(other.step(1,player(),{obstruction:()=>.9}),'hit'));
});
test('dead players cannot acquire or take hits; reset clears respawn state',()=>{
 const sim=make();sim.step(.75,player());
 assert.ok(!has(sim.step(.5,{...player(),alive:false}),'hit'));
 sim.reset();assert.equal(sim.bullets.length,0);assert.equal(sim.events.length,0);
 assert.equal(sim.turrets[0].state,'idle');assert.equal(sim.turrets[0].remaining,0);
 assert.ok(!has(sim.step(.7,player()),'shot'));
});
test('projectiles expire; finite states survive zero-length aim and large dt',()=>{
 const sim=make();sim.step(20,player(0));
 for(const t of sim.turrets) assert.ok(Number.isFinite(t.remaining));
 for(const b of sim.bullets) for(const v of Object.values(b.velocity)) assert.ok(Number.isFinite(v));
 const other=make();other.step(.75,player());
 const events=other.step(5,player(100));assert.ok(has(events,'expired'));assert.equal(other.bullets.length,0);
 assert.throws(()=>sim.step(NaN,player()));assert.throws(()=>make({cooldown:0}));
});
test('segment sphere edge cases',()=>{
 assert.equal(segmentSphereHit({x:0,y:0,z:0},{x:100,y:0,z:0},{x:10,y:0,z:0},1),.09);
 assert.equal(segmentSphereHit({x:0,y:0,z:0},{x:0,y:0,z:0},{x:0,y:0,z:0},1),0);
 assert.equal(segmentSphereHit({x:0,y:0,z:0},{x:0,y:0,z:0},{x:10,y:0,z:0},1),null);
});

test('dynamic side-mounted muzzle and callback retain base-centered range',()=>{
 const sim=make();sim.turrets[0].muzzlePosition={x:2,y:3,z:1};
 const shot=sim.step(.75,player(12)).find(e=>e.type==='shot');
 assert.deepEqual(shot.position,{x:2,y:3,z:1});
 sim.reset();assert.equal(sim.turrets[0].muzzlePosition,undefined);
 const shot2=sim.step(.75,player(),{getMuzzle:()=>({x:-2,y:2,z:0})}).find(e=>e.type==='shot');
 assert.deepEqual(shot2.position,{x:-2,y:2,z:0});
});
