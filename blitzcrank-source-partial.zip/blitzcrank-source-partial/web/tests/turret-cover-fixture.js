import fs from 'node:fs';import * as T from '../vendor/three.module.js';import {loadTurretModel,createTurretArena} from '../turret-view.js';import {resolveFlashDestination} from '../flash-controller.js';
const asset=await loadTurretModel(async p=>{const b=fs.readFileSync(new URL('../'+p.slice(2),import.meta.url));return{ok:true,arrayBuffer:async()=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)}});
function fixture(onDamage=()=>{}){const obs=[];for(const [x,y,z,w,h,d]of [[0,-.18,-13,52,.3,70],[-26,4.3,-13,1,9,65],[26,4.3,-13,1,9,65],[0,6,-46,52,13,1],[-9,1.4,-8,3,2.8,3],[9,1.6,-14,4,3.2,3],[-6,1.7,-25,3,3.4,3],[16,2,-29,4,4,4],[-18,1.5,-34,5,3,4]])obs.push({min:new T.Vector3(x-w/2,y-h/2,z-d/2),max:new T.Vector3(x+w/2,y+h/2,z+d/2)});const hits=[];const a=createTurretArena(new T.Scene(),asset,obs,{onDamage:(d,e)=>{hits.push(e);onDamage(d,e)}});return{a,obs,hits}}


export {fixture,asset,T,resolveFlashDestination};
