import test from 'node:test';import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const newRuntime=()=>createGameplayHarness();
for(const style of ['delayed-state','delayed-event'])test(`release ${style} waits for explicit capture and later real loss still pauses`,async()=>{
 const h=await newRuntime(),canvas=h.element('game');let finishRelease,requests=0;
 const capture=canvas.requestPointerLock.bind(canvas);canvas.requestPointerLock=()=>{requests++;return capture();};
 h.game.begin();await Promise.resolve();assert.equal(requests,1);
 document.exitPointerLock=()=>{if(style==='delayed-event')document.pointerLockElement=null;finishRelease=()=>{document.pointerLockElement=null;h.docListeners.pointerlockchange();};};
 h.game.pause();h.game.resume();assert.equal(requests,1);finishRelease();
 assert.equal(h.qa.state,'running');assert.equal(h.qa.playing,false);assert.equal(requests,1);
 assert.equal(h.element('captureprompt').classList.s.has('hidden'),false);assert.equal(h.element('overlay').classList.s.has('hidden'),true);assert.equal(canvas.style.cursor,'');
 const elapsed=h.qa.session.elapsed;h.frames(60);assert.equal(h.qa.session.elapsed,elapsed);assert.equal(requests,1);
 canvas.listeners.pointerdown({pointerType:'mouse',button:0});await Promise.resolve();assert.equal(requests,2);assert.equal(h.qa.playing,true);assert.equal(h.qa.state,'running');
 document.pointerLockElement=null;h.docListeners.pointerlockchange();assert.equal(h.qa.state,'paused');
});
test('late paused grant cleanup waits for click after resume, then actual capture loss pauses',async()=>{
 const h=await newRuntime(),canvas=h.element('game');let resolveCapture,finishRelease,requests=0;
 const capture=canvas.requestPointerLock.bind(canvas);canvas.requestPointerLock=()=>{requests++;return new Promise(resolve=>{resolveCapture=resolve;});};
 document.exitPointerLock=()=>{document.pointerLockElement=null;finishRelease=()=>h.docListeners.pointerlockchange();};
 h.game.begin();h.game.pause();document.pointerLockElement=canvas;h.docListeners.pointerlockchange();resolveCapture();await Promise.resolve();
 h.game.resume();finishRelease();assert.equal(h.qa.state,'running');assert.equal(h.qa.playing,false);assert.equal(requests,1);
 assert.equal(h.element('captureprompt').classList.s.has('hidden'),false);canvas.requestPointerLock=()=>{requests++;return capture();};
 canvas.listeners.pointerdown({pointerType:'mouse',button:0});await Promise.resolve();assert.equal(requests,2);assert.equal(h.qa.playing,true);
 document.pointerLockElement=null;h.docListeners.pointerlockchange();assert.equal(h.qa.state,'paused');
});
