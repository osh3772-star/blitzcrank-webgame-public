import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// This is a deliberately close-range fixture, not the historical twelve-second
// circling scenario (which now ends with a legal Q win before R is in range).
// Only the initial positions/facing are arranged. The real brain, controllers,
// movement, cooldowns, hit geometry and round authority remain unmodified.
test('unaligned real bot takes a legal close-range R opportunity and shared authority scores it once',async()=>{
 const hz=60,r=await createGameplayHarness({delta:()=>1/hz});r.element('duelmode').click();
 const d=r.game.data,brain=d.duelBrain;
 for(let i=0;i<2*hz&&!d.duel.active;i++)r.frames(1);
 assert(d.duel.active,'normal countdown must finish before fixture placement');
 assert.equal(d.duel.state.history.length,0);
 assert.equal(brain.snapshot().time,0,'fixture starts before the first active brain observation');
 d.player.set(0,1.7,7);d.duelBot.position.set(0,1.7,4);d.duelBot.yaw=0;
 const observed=[],edges=[];let frame=0;
 r.game.setBotCommandSource({reset:options=>brain.reset(options),step:obs=>{
  const out=brain.step(obs),state=brain.snapshot();
  const record=structuredClone({frame,obs,out,state});observed.push(record);
  if(out.castQ||out.castE||out.strikeE||out.castR)edges.push(record);
  return out;
 }});
 for(frame=0;frame<2*hz&&!d.duel.state.history.length;frame++)r.frames(1);
 const casts=edges.filter(x=>x.out.castR);
 assert.equal(casts.length,1,'real brain must emit exactly one R edge');
 assert.equal(edges.length,1,'no scripted Q/E intervention or alternative attack may cause this win');
 const cast=casts[0],{obs,out,state}=cast;
 assert(obs.canSeeOpponent&&obs.self.canCastR&&!obs.self.hookActive);
 assert.equal(obs.self.skills.cooldown.R,0);assert.equal(obs.self.skills.phase,null);
 assert(state.freshPerception&&state.time>=state.reactionDelay);
 assert(observed.some(x=>!x.state.freshPerception),'reaction delay must actually be exercised');
 assert(observed.filter(x=>x.state.time<state.reactionDelay).every(x=>!x.out.castR));
 assert.equal(state.settleTime,0,'radial R must not require settled directional aim');
 const p=state.perceived,s=obs.self.position;
 const delayedDistance=Math.hypot(p.position.x-s.x,p.position.y-s.y,p.position.z-s.z);
 const lead=Math.min(.7,Math.max(0,state.time-p.sampledAt)+Math.min(.35,(.25+delayedDistance/42)*.45));
 const predicted={x:p.position.x+p.velocity.x*lead,y:p.position.y+p.velocity.y*lead,z:p.position.z+p.velocity.z*lead};
 const predictedDistance=Math.hypot(predicted.x-s.x,predicted.y-s.y,predicted.z-s.z);
 assert(delayedDistance<=6.3&&predictedDistance<=7,'fixture must satisfy both unchanged R range gates');
 const desired=Math.atan2(-(predicted.x-s.x),-(predicted.z-s.z));
 const difference=Math.abs(Math.atan2(Math.sin(desired-out.yaw),Math.cos(desired-out.yaw)));
 assert(difference>Math.PI/2,'bot is still facing away at actual R selection');
 assert.equal(d.duel.state.history.length,1);assert.equal(d.duel.state.history[0].winnerId,'bot');
 assert.equal(d.duel.contact.skill,'R');assert.equal(d.duel.contact.attackerId,'bot');
 assert.equal(d.duel.contact.targetId,'human');assert.equal(d.duel.state.phase,'roundReset');
 assert.deepEqual(d.duel.state.scores,[{playerId:'human',points:0},{playerId:'bot',points:1}]);
 assert.equal(r.qa.session.score,0,'duel score never leaks into solo points');
 console.log('VALID_RADIAL_R '+JSON.stringify({castFrame:cast.frame,brainTime:state.time,reactionDelay:state.reactionDelay,delayedDistance,predictedDistance,angleError:difference,contact:d.duel.contact,history:d.duel.state.history,score:r.qa.session.score}));
});
