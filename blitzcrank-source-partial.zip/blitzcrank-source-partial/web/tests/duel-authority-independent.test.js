import test from 'node:test';
import assert from 'node:assert/strict';
const root=new URL('..',import.meta.url).href.replace(/\/$/,'');
const {createDuelSimulation,DUEL_SHAPE}=await import(root+'/duel-simulation.js');
const {CONFIG}=await import(root+'/core.js');
const clip=(name,duration=1,events=[])=>({name,duration,events});
const skillClips=[clip('W_Start'),clip('W_Loop',1),clip('W_End'),clip('E_Charge'),clip('E_Hold',1),clip('E_Strike',1.5,[{time:.4,type:'power_fist_hit'}]),clip('R_Cast',1.2,[{time:.3,type:'static_field_discharge'}])];
const point=(x,y=1.7,z=0)=>({x,y,z});
function fixture(distance=2){
 const sim=createDuelSimulation({sessionId:'independent-review',config:CONFIG,countdownMs:0,roundResetMs:1200,skillClips});sim.prepare();
 const frame={actors:[{playerId:'human',shape:DUEL_SHAPE,motion:{type:'linear',from:point(0),to:point(0)}},{playerId:'bot',shape:DUEL_SHAPE,motion:{type:'linear',from:point(distance),to:point(distance)}}],obstacles:[],sockets:{human:{origin:point(0),home:point(0),direction:point(1,0)},bot:{origin:point(distance),home:point(distance),direction:point(-1,0)}}};
 const step=(dt=.05,n=1)=>{for(let i=0;i<n;i++)assert(sim.step(dt,frame));};
 const scores=()=>sim.state.scores.map(x=>x.points);
 const arm=id=>{assert(sim.getSkills(id).castE());step(.05,21);assert.equal(sim.getSkills(id).status.phase,'E_Hold');};
 return {sim,frame,step,scores,arm};
}
for(const id of ['human','bot'])for(const skill of ['E','R'])test(`${id} ${skill} scores once only from authored impact`,()=>{
 const f=fixture(),c=f.sim.getSkills(id);if(skill==='E'){f.arm(id);assert(c.strikeE());f.step(.05,7);f.step(.04);}else{assert(c.castR());f.step(.05,5);f.step(.04);}
 assert.deepEqual(f.scores(),[0,0]);f.step(.02);assert.deepEqual(f.scores(),id==='human'?[1,0]:[0,1]);assert.equal(f.sim.contact.skill,skill);assert.equal(f.sim.state.history.length,1);assert.equal(c.castR(),false);f.step(.05,20);assert.equal(f.sim.state.history.length,1);
});
for(const hz of [20,30,60,120])test(`E/R equal authored impacts replay the same round at ${hz}Hz`,()=>{
 const f=fixture();f.arm('human');assert(f.sim.getSkills('human').strikeE());f.step(1/hz,hz/10);assert(f.sim.getSkills('bot').castR());f.step(1/hz,Math.ceil(hz*.3));
 assert.deepEqual(f.scores(),[0,0]);assert(f.sim.tieRemaining>0);assert.equal(f.sim.state.history.length,0);assert.equal(f.sim.state.roundNumber,1);
});
for(const first of ['human','bot'])test(`earlier R within same frame wins for ${first}`,()=>{
 const f=fixture(),second=first==='human'?'bot':'human';assert(f.sim.getSkills(first).castR());f.step(.01);assert(f.sim.getSkills(second).castR());f.step(.05,5);f.step(.015);f.step(.05);
 assert.deepEqual(f.scores(),first==='human'?[1,0]:[0,1]);assert.equal(f.sim.tieRemaining,0);assert.equal(f.sim.drainEvents().filter(x=>x.type==='skill-impact').length,1);
});
for(const delay of [0,.04])test(`Q/R arbitration uses actual impact order with R head start ${delay}`,()=>{
 const f=fixture();assert(f.sim.getSkills('bot').castR());if(delay)f.step(delay);assert(f.sim.cast('human'));f.step(.05,6);
 if(!delay){assert.deepEqual(f.scores(),[0,0]);assert(f.sim.pendingGrab);assert.equal(f.sim.active,false);for(let n=0;n<30&&f.sim.pendingGrab;n++)f.step();}
 assert.deepEqual(f.scores(),delay?[0,1]:[1,0]);assert.equal(f.sim.contact.skill,delay?'R':'Q');assert.equal(f.sim.drainEvents().filter(x=>x.type==='round-scored').length,1);
});
for(const skill of ['E','R'])test(`${skill} moving-target geometry uses authored offset rather than frame endpoint`,()=>{
 const f=fixture(2),c=f.sim.getSkills('human');if(skill==='E'){f.arm('human');c.strikeE();f.step(.05,7);f.step(.04);}else{c.castR();f.step(.05,5);f.step(.04);}
 const far=skill==='E'?6:10;f.frame.actors[1].motion={type:'linear',from:point(2),to:point(far)};f.step(.05);assert.deepEqual(f.scores(),[1,0]);
});
for(const skill of ['E','R'])test(`${skill} respects cover and clearing old casts on restart`,()=>{
 const f=fixture(),c=f.sim.getSkills('human');f.frame.obstacles=[{obstacleId:'wall',min:point(.9,0,-2),max:point(1.1,4,2)}];if(skill==='E'){f.arm('human');c.strikeE();}else c.castR();f.step(.05,12);assert.deepEqual(f.scores(),[0,0]);assert.equal(f.sim.state.phase,'active');
 f.sim.restart();f.sim.prepare();f.frame.obstacles=[];f.step(.05,12);assert.deepEqual(f.scores(),[0,0]);assert.equal(f.sim.state.history.length,0);assert.equal(f.sim.getSkills('human').status.phase,null);
});
test('mixed offensive winners still complete 3–2 on round five and refuse a sixth',()=>{
 const f=fixture();for(const [id,skill]of [['human','E'],['bot','R'],['human','Q'],['bot','E'],['human','R']]){
  const c=f.sim.getSkills(id);if(skill==='E'){f.arm(id);c.strikeE();}else if(skill==='R')c.castR();else f.sim.cast(id);
  for(let i=0;i<30&&f.sim.state.phase==='active';i++)f.step();assert.equal(f.sim.state.history.at(-1).winnerId,id);
  if(f.sim.state.phase!=='matchComplete'){for(let i=0;i<25;i++)f.step();assert.equal(f.sim.state.phase,'preparing');f.sim.prepare();}
 }
 assert.equal(f.sim.state.phase,'matchComplete');assert.equal(f.sim.state.roundNumber,5);assert.deepEqual(f.scores(),[3,2]);f.step(.05,100);assert.equal(f.sim.state.history.length,5);assert.equal(f.sim.getSkills('bot').castR(),false);
});
for(const hz of [20,30,60,120])test(`E/R equal interior-frame impacts replay at ${hz}Hz despite accumulated clip rounding`,()=>{
 const f=fixture();f.arm('human');assert(f.sim.getSkills('human').strikeE());f.step(1/hz,hz/10);assert(f.sim.getSkills('bot').castR());f.step(.003);for(let n=0;n<Math.ceil(hz*.3)&&f.sim.active;n++)f.step(1/hz);
 assert.deepEqual(f.scores(),[0,0]);assert(f.sim.tieRemaining>0);assert.equal(f.sim.state.history.length,0);
});
for(const lead of [1e-7,1e-10])test(`genuine ${lead}s lead remains a win rather than a numerical tie`,()=>{
 const f=fixture();f.arm('human');assert(f.sim.getSkills('human').strikeE());f.step(.05,2);f.step(lead);assert(f.sim.getSkills('bot').castR());f.step(.003);for(let n=0;n<36&&f.sim.active;n++)f.step(1/120);
 assert.deepEqual(f.scores(),[1,0]);assert.equal(f.sim.tieRemaining,0);
});
const {createSkillTimeline}=await import(root+'/skill-timeline.js');
test('numerically snapped event is emitted exactly once across later steps',()=>{
 const seen=[],t=createSkillTimeline({onEvent:event=>seen.push(event.type)});t.play({name:'E',duration:1.5,events:[{time:.4,type:'impact'}]});for(let n=0;n<8;n++)t.step(.05);assert.deepEqual(seen,['impact']);assert.equal(t.state.time,.4);for(let n=0;n<8;n++)t.step(.05);assert.deepEqual(seen,['impact']);
});
test('numerically snapped looping duration wraps to zero without replaying interior events',()=>{
 const seen=[],t=createSkillTimeline({onEvent:event=>seen.push(event.type)});t.play({name:'loop',duration:.4,loop:true,events:[{time:0,type:'start'},{time:.2,type:'mid'}]});for(let n=0;n<8;n++)t.step(.05);assert.deepEqual(seen,['start','mid','start']);assert.equal(t.state.time,0);t.step(.05);assert.deepEqual(seen,['start','mid','start']);
});
test('snapped event callback can stop or replace its timeline without stale completion',()=>{
 for(const replacement of [false,true]){let done=0,seen=0;const t=createSkillTimeline({onEvent:()=>{seen++;if(replacement)t.play({name:'next',duration:1});else t.stop();},onComplete:()=>done++});t.play({name:'ending',duration:.4,events:[{time:.4,type:'impact'}]});for(let n=0;n<8;n++)t.step(.05);assert.equal(seen,1);assert.equal(done,0);assert.equal(t.state?.name??null,replacement?'next':null);}
});
