import test from 'node:test';
import assert from 'node:assert/strict';
import {createModeRecords,MODE_RECORD_KEYS as keys,MODE_RECORD_FLASH_RULES as flashRules} from '../mode-records.js';
const definitions={
 challenge:{mode:'challenge90',field:'score',value:600},
 combo:{mode:'combo',field:'seconds',rules:'q-e-r-v1',value:3.5},
 comboER:{mode:'combo-er',field:'seconds',rules:'e-r-v1',value:2.5},
 challengeFlash:{mode:'challenge90-flash',field:'score',rules:'challenge90-flash15-v1',value:900},
 comboFlash:{mode:'combo-flash',field:'seconds',rules:'q-e-r-v1+flash15-v1',value:3.123456789},
 comboERFlash:{mode:'combo-er-flash',field:'seconds',rules:'e-r-v1+flash15-v1',value:2.123456789}
};
const assisted=['challengeFlash','comboFlash','comboERFlash'],ordinary=['challenge','combo','comboER'];
const encode=(mode,value=definitions[mode].value)=>{const d=definitions[mode];return JSON.stringify({version:1,mode:d.mode,...(d.rules?{rules:d.rules}:{}),[d.field]:value});};
const better=(mode,value)=>mode.startsWith('challenge')?value+100:value-.5;
const worse=(mode,value)=>mode.startsWith('challenge')?value-100:value+.5;
function memory(initial={}){return{data:new Map(Object.entries(initial)),reads:[],writes:[],getItem(key){this.reads.push(key);return this.data.get(key)??null;},setItem(key,value){this.writes.push([key,value]);this.data.set(key,value);}};}
const create=storage=>createModeRecords({getStorage:()=>storage});
function persist(records,mode,value=definitions[mode].value,overrides={}){const flashAssisted=mode.endsWith('Flash');return mode.startsWith('challenge')?records.recordChallenge({practice:false,done:true,score:value,flashAssisted,...overrides}):records.recordCombo({success:true,route:mode.startsWith('comboER')?'er':'qer',elapsed:value,flashAssisted,...overrides});}
const initial=modes=>Object.fromEntries(modes.map(mode=>[keys[mode],' \n'+encode(mode)+'\t']));
const empty={best:null,saved:false,issue:null};

test('six immutable keys and three assisted rules are explicit and distinct from all old contracts',()=>{
 assert.deepEqual(keys,{challenge:'rocket-hand-record-challenge90-v1',combo:'rocket-hand-record-combo-v1',comboER:'rocket-hand-record-combo-er-v1',challengeFlash:'rocket-hand-record-challenge90-flash15-v1',comboFlash:'rocket-hand-record-combo-flash15-v1',comboERFlash:'rocket-hand-record-combo-er-flash15-v1'});
 assert.deepEqual(flashRules,{challengeFlash:'challenge90-flash15-v1',comboFlash:'q-e-r-v1+flash15-v1',comboERFlash:'e-r-v1+flash15-v1'});
 assert(Object.isFrozen(keys));assert(Object.isFrozen(flashRules));assert.equal(new Set(Object.values(keys)).size,6);
});
test('old callers without any flag retain their exact original schemas, including default QER route',()=>{
 const s=memory(),r=create(s);assert(r.recordChallenge({practice:false,done:true,score:600}));assert(r.recordCombo({success:true,elapsed:3.5}));assert(r.recordCombo({success:true,route:'er',elapsed:2.5}));
 for(const mode of ordinary)assert.equal(s.data.get(keys[mode]),encode(mode));for(const mode of assisted)assert.deepEqual(r.snapshot()[mode],empty);assert.equal(s.writes.length,3);
});
test('only literal true selects Flash records; absent, false and truthy non-booleans stay ordinary',()=>{
 for(const flag of [undefined,null,false,0,1,'true',{},[],new Boolean(true)]){const s=memory(),r=create(s);for(const mode of assisted)assert(persist(r,mode,definitions[mode].value,{flashAssisted:flag}));assert.deepEqual(s.writes.map(([key])=>key),ordinary.map(mode=>keys[mode]));}
 const s=memory(),r=create(s);for(const mode of assisted)assert(persist(r,mode));assert.deepEqual(s.writes.map(([key])=>key),assisted.map(mode=>keys[mode]));
});
test('assisted runs never overwrite old best bytes, even when the assisted result is faster or higher',()=>{
 const bytes=initial(ordinary),s=memory({...bytes,'rocket-hand-best':'old { malformed bytes'}),r=create(s);
 for(const mode of assisted){assert(persist(r,mode));assert.equal(s.data.get(keys[mode]),encode(mode));}
 for(const mode of ordinary)assert.equal(s.data.get(keys[mode]),bytes[keys[mode]]);
 assert.equal(s.data.get('rocket-hand-best'),'old { malformed bytes');assert(!s.reads.includes('rocket-hand-best'));assert.equal(s.writes.length,3);
});
test('ordinary runs preserve all assisted bytes and all six bests are independent',()=>{
 const bytes=initial(assisted),s=memory(bytes),r=create(s);for(const mode of ordinary)assert(persist(r,mode));for(const mode of assisted)assert.equal(s.data.get(keys[mode]),bytes[keys[mode]]);
 assert.equal(s.writes.length,3);for(const mode of Object.keys(definitions))assert.deepEqual(r.snapshot()[mode],{best:definitions[mode].value,saved:true,issue:null});
});
test('assisted QER defaults only when route is absent and unknown routes cannot touch any category',()=>{
 const s=memory(),r=create(s);for(const route of ['',false,0,'ER','q-r','future',{},[]])assert.equal(r.recordCombo({success:true,flashAssisted:true,route,elapsed:1}),false);
 assert.equal(s.writes.length,0);assert(Object.values(r.snapshot()).every(v=>v.best===null));
 assert(r.recordCombo({success:true,flashAssisted:true,elapsed:3}));assert.equal(s.data.get(keys.comboFlash),encode('comboFlash',3));assert.deepEqual(r.snapshot().combo,empty);assert.deepEqual(r.snapshot().comboERFlash,empty);
});
test('assisted challenge still rejects unfinished/practice runs and invalid scores',()=>{
 const s=memory(),r=create(s);for(const overrides of [{done:false},{done:undefined},{done:1},{practice:true},{practice:undefined},{practice:0}])assert.equal(persist(r,'challengeFlash',900,overrides),false);
 for(const score of [-1,1.5,NaN,Infinity,-Infinity,Number.MAX_SAFE_INTEGER+1,'900',null,undefined])assert.equal(r.recordChallenge({practice:false,done:true,flashAssisted:true,score}),false);
 assert.equal(s.writes.length,0);assert(persist(r,'challengeFlash',0));assert(persist(r,'challengeFlash',Number.MAX_SAFE_INTEGER));assert.equal(s.data.get(keys.challengeFlash),encode('challengeFlash',Number.MAX_SAFE_INTEGER));assert.deepEqual(r.snapshot().challenge,empty);
});
test('both assisted combos retain success, positive finite time, and 12-second eligibility checks',()=>{
 const s=memory(),r=create(s);for(const mode of ['comboFlash','comboERFlash']){
  for(const elapsed of [0,-1,12.000001,NaN,Infinity,-Infinity,'2',null,undefined])assert.equal(r.recordCombo({success:true,route:mode==='comboFlash'?'qer':'er',flashAssisted:true,elapsed}),false);
  for(const success of [false,undefined,null,1,'true'])assert.equal(persist(r,mode,2,{success}),false);
 }
 assert.equal(s.writes.length,0);for(const mode of ['comboFlash','comboERFlash']){assert(persist(r,mode,12));assert(persist(r,mode,Number.MIN_VALUE));assert.equal(s.data.get(keys[mode]),encode(mode,Number.MIN_VALUE));}
});
for(const mode of assisted){
 test(mode+': precision, best direction, identical/slower suppression, reload and snapshot isolation',()=>{
  const s=memory(),r=create(s),value=definitions[mode].value;assert(persist(r,mode));assert(persist(r,mode,worse(mode,value)));assert(persist(r,mode));assert.equal(s.writes.length,1);
  const best=better(mode,value);assert(persist(r,mode,best));assert.equal(s.writes.length,2);assert.equal(s.data.get(keys[mode]),encode(mode,best));
  const reloaded=create(s);assert.deepEqual(reloaded.snapshot(),r.snapshot());const snap=reloaded.snapshot();snap[mode].best=-1;assert.equal(reloaded.snapshot()[mode].best,best);for(const other of Object.keys(definitions).filter(v=>v!==mode))assert.deepEqual(snap[other],empty);
 });
 test(mode+': malformed/unknown/other-category schemas retain exact bytes and block only themselves',()=>{
  const valid=JSON.parse(encode(mode)),field=definitions[mode].field;
  const malformed=['',' ','{','null','[]','42','true','"3"','{}',...Object.keys(definitions).filter(other=>other!==mode).map(other=>encode(other)),
   JSON.stringify({...valid,version:2}),JSON.stringify({...valid,mode:'future'}),JSON.stringify({...valid,rules:'future'}),JSON.stringify({...valid,extra:true}),JSON.stringify({...valid,rules:undefined}),JSON.stringify({...valid,[field]:undefined}),JSON.stringify({...valid,[field]:null}),JSON.stringify({...valid,[field]:'2'}),JSON.stringify({...valid,[field]:-1}),mode==='challengeFlash'?encode(mode,1.5):encode(mode,12.001)];
  for(const raw of malformed){const s=memory({[keys[mode]]:raw}),r=create(s);assert.equal(r.snapshot()[mode].issue,'invalid',raw);assert.equal(persist(r,mode),false,raw);assert.equal(s.data.get(keys[mode]),raw);assert.deepEqual(r.snapshot()[mode],{best:definitions[mode].value,saved:false,issue:'invalid'});
   for(const other of Object.keys(definitions).filter(v=>v!==mode))assert(persist(r,other));assert.equal(s.writes.length,5);assert(s.writes.every(([key])=>key!==keys[mode]));}
 });
 test(mode+': unreadable storage never writes and does not block healthy categories',()=>{
  const bytes=initial(Object.keys(definitions)),s=memory(bytes),get=s.getItem;s.getItem=function(key){if(key===keys[mode])throw Error('read blocked');return get.call(this,key);};const r=create(s);assert.equal(persist(r,mode),false);assert.equal(s.data.get(keys[mode]),bytes[keys[mode]]);assert.deepEqual(r.snapshot()[mode],{best:definitions[mode].value,saved:false,issue:'unavailable'});
  for(const other of Object.keys(definitions).filter(v=>v!==mode))assert(persist(r,other,better(other,definitions[other].value)));assert.equal(s.writes.length,5);assert(s.writes.every(([key])=>key!==keys[mode]));
 });
 test(mode+': failed writes keep page best, reload keeps old bytes, recovery saves the page best',()=>{
  const bytes=initial([mode]),s=memory(bytes),set=s.setItem;s.setItem=function(key,value){if(key===keys[mode])throw Error('quota');return set.call(this,key,value);};const r=create(s),best=better(mode,definitions[mode].value);
  assert.equal(persist(r,mode,best),false);assert.equal(s.data.get(keys[mode]),bytes[keys[mode]]);assert.deepEqual(r.snapshot()[mode],{best,saved:false,issue:'unavailable'});assert.equal(create(s).snapshot()[mode].best,definitions[mode].value);
  s.setItem=set;assert(persist(r,mode));assert.equal(s.data.get(keys[mode]),encode(mode,best));assert.deepEqual(r.snapshot()[mode],{best,saved:true,issue:null});
 });
 test(mode+': newer other-tab best wins at commit and corruption introduced after load stays intact',()=>{
  const s=memory(),a=create(s),b=create(s),best=better(mode,definitions[mode].value);assert(persist(a,mode,best));const raw=s.data.get(keys[mode]);assert(persist(b,mode));assert.equal(s.writes.length,1);assert.equal(s.data.get(keys[mode]),raw);assert.equal(b.snapshot()[mode].best,best);
  const corrupted=' {"version":99,"mode":"future"} ';s.data.set(keys[mode],corrupted);assert.equal(persist(b,mode,better(mode,best)),false);assert.equal(s.writes.length,1);assert.equal(s.data.get(keys[mode]),corrupted);assert.equal(b.snapshot()[mode].issue,'invalid');
 });
 test(mode+': refresh is read-only and deletion retains a clearly unsaved page best',()=>{
  const s=memory(initial([mode])),r=create(s);s.data.delete(keys[mode]);r.refresh();assert.equal(s.writes.length,0);assert.deepEqual(r.snapshot()[mode],{best:definitions[mode].value,saved:false,issue:'unsaved'});
 });
}
test('corrupt old schemas never prevent any new assisted record or mutate old bytes',()=>{
 const bytes=Object.fromEntries(ordinary.map(mode=>[keys[mode],'unrecognized old '+mode])),s=memory(bytes),r=create(s);for(const mode of assisted)assert(persist(r,mode));for(const mode of ordinary){assert.equal(s.data.get(keys[mode]),bytes[keys[mode]]);assert.equal(r.snapshot()[mode].issue,'invalid');}assert.equal(s.writes.length,3);
});
test('storage getter, missing API, and method getters remain safe for every assisted category',()=>{
 const cases=[()=>{throw Error('storage getter');},()=>undefined,()=>null,()=>({}),...['getItem','setItem'].map(method=>()=>{const s=memory();Object.defineProperty(s,method,{get(){throw Error('method getter');}});return s;})];
 for(const getStorage of cases){const r=createModeRecords({getStorage});for(const mode of assisted){assert.equal(persist(r,mode),false);assert.deepEqual(r.snapshot()[mode],{best:definitions[mode].value,saved:false,issue:'unavailable'});}}
});
test('all six records coexist and refresh/reconstruction never performs a migration or redundant write',()=>{
 const bytes=initial(Object.keys(definitions)),s=memory(bytes),r=create(s);r.refresh();assert.equal(s.writes.length,0);for(const mode of Object.keys(definitions)){assert(persist(r,mode));assert.equal(s.data.get(keys[mode]),bytes[keys[mode]]);}assert.equal(s.writes.length,0);assert.deepEqual(create(s).snapshot(),r.snapshot());assert.deepEqual(Object.keys(r.snapshot()),Object.keys(keys));
});
