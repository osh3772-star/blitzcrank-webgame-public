import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createGameplayHarness} from './helpers/runtime-harness.js';
// Real gameplay/Three scene graph; simulated DOM, audio and renderer, not GPU QA.
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'punch-probe-'));
const source=fs.readFileSync(process.env.PUNCH_SOURCE||new URL('../main.js',import.meta.url),'utf8');
const file=path.join(temp,'main.js');
fs.writeFileSync(file,source+'\nwindow.__PUNCH_ENDPOINT__={get oneShot(){return oneShot},get clip(){return clipName},setTimers(value,name="Basic_Punch"){punchCooldown=oneShot=value;clipName=name;}};');
let dt=.05,h;try{h=await createGameplayHarness({sourcePath:file,delta:()=>dt});}finally{fs.rmSync(temp,{recursive:true});}
const probe=window.__PUNCH_ENDPOINT__;
function start(duel){dt=.05;h.docListeners.pointerdown({pointerType:'mouse'});h.game.begin(true,false,duel);if(duel){h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0})});for(let n=0;n<100&&!h.qa.duel.active;n++)h.frames(1);assert(h.qa.duel.active);h.game.data.duelBot.position.set(12,1.7,-12);}else for(const t of h.game.data.targets){t.active=t.group.visible=false;t.respawn=Infinity;}}
for(const duel of [false,true]){
 for(const [boost,hz,count] of [[false,20,13],[false,60,39],[false,120,78],[true,30,13],[true,60,26],[true,120,52]])for(const action of ['punch','Q','E','R'])test(`${duel?'duel':'solo'} ${boost?'W boosted':'ordinary'} ${hz}Hz endpoint accepts ${action}`,()=>{
  start(duel);if(boost)h.key('ShiftLeft');dt=1/hz;h.punch();assert(h.game.data.punchCooldown>0);assert(probe.oneShot>0);h.frames((action==='punch'?count:hz/(boost?1.5:1))-1);assert(probe.oneShot>0);if(action==='punch'){assert(h.game.data.punchCooldown>0);const cd=h.game.data.punchCooldown;h.punch();assert.equal(h.game.data.punchCooldown,cd);}else{h.key('Key'+action);assert.equal(h.qa.hook,null);assert.notEqual(h.qa.skills.phase,'E_Charge');assert.notEqual(h.qa.skills.phase,'R_Cast');}h.frames(1);
  console.log('endpoint',duel,boost,hz,h.game.data.punchCooldown,probe.oneShot,h.element('skillstateE').textContent);
  const endpoint={cooldown:h.game.data.punchCooldown,oneShot:probe.oneShot,E:h.element('skillstateE').textContent,R:h.element('skillstateR').textContent,disabled:h.element('skillE').attributes['aria-disabled']};
  if(action==='punch'){h.punch();assert(h.game.data.punchCooldown>1e-6,'left click starts a new punch rather than retaining residue');}else{h.key('Key'+action);if(action==='Q')assert(h.qa.hook,'Q launches at the animation endpoint');else assert.equal(h.qa.skills.phase,action==='E'?'E_Charge':'R_Cast');}
  assert.equal(endpoint.cooldown,0);if(action==='punch'){assert(endpoint.oneShot>0,'authored animation remains longer than recast');}else{assert.equal(endpoint.oneShot,0);assert.equal(endpoint.E,'READY');assert.equal(endpoint.R,'READY');assert.equal(endpoint.disabled,'false');}
  assert.equal(h.qa.session.score,0);if(duel)assert.deepEqual(h.qa.duel.match.scores.map(s=>s.points),[0,0]);
 });
 for(const hz of [60,120])for(const boost of [false,true])test(`${duel?'duel':'solo'} E ${boost?'with W':'alone'} ${hz}Hz strike endpoint permits left click`,()=>{
  start(duel);h.key('KeyE');for(let n=0;n<100&&h.qa.skills.phase!=='E_Hold';n++)h.frames(1);assert.equal(h.qa.skills.phase,'E_Hold');if(boost)h.key('ShiftLeft');dt=1/hz;h.punch();assert.equal(h.qa.skills.phase,'E_Strike');h.frames(44*hz/30-1);assert(h.game.data.punchCooldown>0);h.frames(1);console.log('E endpoint',duel,boost,hz,h.game.data.punchCooldown);assert.equal(h.game.data.punchCooldown,0);assert.equal(h.qa.skills.phase,null);h.punch();assert(h.game.data.punchCooldown>0);assert.equal(h.qa.session.score,0);
 });
 test(`${duel?'duel':'solo'} genuine threshold remainder, zero-time refresh and pause remain blocking`,()=>{
  start(duel);h.punch();probe.setTimers(5e-13);dt=0;h.frames(1);assert.equal(probe.oneShot,5e-13);assert.equal(h.game.data.punchCooldown,5e-13);for(const value of [1e-9,1e-12]){probe.setTimers(value*2);dt=value;h.frames(1);assert.equal(h.game.data.punchCooldown,value);assert.equal(probe.oneShot,value);h.punch();assert.equal(h.game.data.punchCooldown,value);dt=0;h.frames(1);assert.equal(probe.oneShot,value);assert.equal(h.game.data.punchCooldown,value);h.game.pause();dt=.05;h.frames(2);assert.equal(probe.oneShot,value);assert.equal(h.game.data.punchCooldown,value);h.game.resume();}
 });
}
test('cleanup is restricted to punch animation, preserving unrelated recover time',()=>{start(false);probe.setTimers(1e-13,'Q_Launch');dt=1e-14;h.frames(1);assert(probe.oneShot>0);});
test('duel countdown and scored hold do not age cooldown or accept a left click',()=>{
 start(true);h.game.data.duelBot.position.set(0,1.7,5);h.key('KeyR');for(let n=0;n<100&&h.qa.duel.active;n++)h.frames(1);assert.equal(h.qa.duel.match.phase,'roundReset');
 for(const phase of ['roundReset','countdown']){if(phase==='countdown')h.game.begin(true,false,true);assert.equal(h.qa.duel.match.phase,phase);probe.setTimers(5e-13);dt=.05;h.frames(1);assert.equal(h.game.data.punchCooldown,5e-13);h.punch();assert.equal(h.game.data.punchCooldown,5e-13);assert.equal(h.qa.duel.match.phase,phase);}
});
