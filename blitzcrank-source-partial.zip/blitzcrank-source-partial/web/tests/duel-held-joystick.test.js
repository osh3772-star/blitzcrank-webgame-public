import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// Actual main handlers/simulation, synthetic pointer capture, mocked DOM/WebGL.
// Set a relative DUEL_JOYSTICK_SOURCE to run identical cases on a saved baseline.
const sourcePath=new URL(process.env.DUEL_JOYSTICK_SOURCE||'../main.js',import.meta.url);
const r=await createGameplayHarness({sourcePath,delta:()=>.05}),stick=r.element('joystick'),canvas=r.element('game');
const xy=()=>[r.qa.player.x,r.qa.player.z];
const event=(id=2,x=55,y=17)=>({pointerId:id,pointerType:'touch',button:0,clientX:x,clientY:y,preventDefault(){}});
const until=(fn,max=250)=>{for(let n=0;n<max&&!fn();n++)r.frames(1);assert(fn(),'phase transition timed out');};
const tap=id=>r.element(id).onpointerdown(event(9));
const down=(e=event())=>{r.docListeners.pointerdown(e);stick.onpointerdown(e);return e;};
const end=(name,e=event())=>{stick.releasePointerCapture(e.pointerId);stick[name](e);};
function start(active=false){
 document.hidden=false;r.docListeners.pointerdown(event());r.element('duelmode').click();quiet();
 assert(r.qa.playing);assert.equal(r.qa.duel.match.phase,'countdown');assert.deepEqual(r.game.data.joystick,{x:0,y:0});
 if(active)until(()=>r.qa.duel.active);
}
function quiet(){r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});}
function score(skill='R',held=true){
 const d=r.game.data,n=r.qa.duel.match.history.length;
 d.duelBot.position.set(d.player.x,1.7,d.player.z-(skill==='Q'?6:2));
 if(skill==='E'){tap('skillE');until(()=>r.qa.skills.phase==='E_Hold');}
 if(held)down();
 tap(skill==='Q'?'touchhook':skill==='E'?'touchpunch':'skillR');
 if(skill==='Q'){
  until(()=>!!r.qa.duel.pendingGrab);assert.equal(r.qa.duel.match.history.length,n,'first Q contact must not score');
  const frozen=xy();while(r.qa.duel.pendingGrab){r.frames(1);assert.deepEqual(xy(),frozen,'pull blocks attacker movement');}
  assert(Math.abs(d.duelBot.position.z-(d.player.z-2.3))<1e-9,'Q completes the pull to its stand-off before point');
 }
 until(()=>r.qa.duel.match.history.length===n+1);
 assert.equal(r.qa.duel.match.history.at(-1).winnerId,'human');assert.equal(d.duel.contact.skill,skill);
}
function nextRound(){
 const frozen=xy();r.frames(59);assert.equal(r.qa.duel.match.phase,'roundReset');assert.deepEqual(xy(),frozen,'full three-second hold blocks walking');
 r.frames(1);assert.equal(r.qa.duel.match.phase,'countdown');assert.equal(r.qa.duel.match.remainingMs,1600);assert.deepEqual(xy(),[0,7]);assert.deepEqual(r.qa.duel.bot.position,[0,1.7,-12]);
 until(()=>r.qa.duel.active);assert.deepEqual(xy(),[0,7],'countdown remains frozen');
}
for(const [name,x,y,expected]of [['forward',55,17,[0,6.68]],['back',55,93,[0,7.32]],['left',17,55,[-.32,7]],['right',93,55,[.32,7]]])test(`${name}: countdown contact resumes on first active frame without retouch/move`,()=>{
 start();down(event(2,x,y));until(()=>r.qa.duel.active);assert.deepEqual(xy(),[0,7]);r.frames(1);
 expected.forEach((value,i)=>assert(Math.abs(xy()[i]-value)<1e-9,'held contact was discarded'));
 end('onpointerup');const stopped=xy();r.frames(2);assert.deepEqual(xy(),stopped);
});
test('countdown direction updates remain frozen and diagonal movement is normalized',()=>{
 start();const e=down(event(2,93,55));stick.onpointermove({...e,clientX:17,clientY:17});r.frames(3);assert.deepEqual(xy(),[0,7]);
 until(()=>r.qa.duel.active);r.frames(1);assert(r.qa.player.x<0&&r.qa.player.z<7);assert(Math.abs(Math.hypot(r.qa.player.x,r.qa.player.z-7)-.32)<1e-9);
});
for(const skill of ['Q','E','R'])test(`live contact survives real ${skill} score and three-second hold without early movement`,()=>{
 start(true);score(skill);nextRound();r.frames(1);assert(Math.abs(r.qa.player.z-6.68)<1e-9,'round transition discarded captured contact');
 assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[1,0]);assert.equal(r.qa.duel.match.history.length,1);
});
test('simultaneous R replay preserves captured contact but awards no point and never walks during hold',()=>{
 start(true);r.game.data.duelBot.position.set(0,1.7,5);down();tap('skillR');assert(r.game.data.duel.getSkills('bot').castR());until(()=>r.qa.duel.tieRemaining>0);
 const frozen=xy();r.frames(59);assert(r.qa.duel.tieRemaining>0);assert.deepEqual(xy(),frozen);assert.equal(r.qa.duel.match.history.length,0);
 until(()=>r.qa.duel.match.phase==='countdown');until(()=>r.qa.duel.active);assert.deepEqual(xy(),[0,7]);r.frames(1);assert(r.qa.player.z<7);assert.equal(r.qa.duel.match.roundNumber,1);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[0,0]);
});
for(const phase of ['countdown','pull','score','next-countdown'])for(const ending of ['onpointerup','onpointercancel','onlostpointercapture'])test(`${ending} during ${phase} permanently clears that contact`,()=>{
 start(phase!=='countdown');down();
 if(phase==='pull'){r.game.data.duelBot.position.set(0,1.7,5);tap('touchhook');until(()=>!!r.qa.duel.pendingGrab);}
 if(phase==='score'||phase==='next-countdown'){score();if(phase==='next-countdown')until(()=>r.qa.duel.match.phase==='countdown');}
 end(ending);assert.deepEqual(r.game.data.joystick,{x:0,y:0});stick.onpointermove(event());
 until(()=>r.qa.duel.active);const before=xy();stick.onpointermove(event());r.frames(3);assert.deepEqual(xy(),before);assert.deepEqual(r.game.data.joystick,{x:0,y:0});
});
for(const phase of ['countdown','score'])test(`new contact during ${phase} tracks direction without queuing actions/jump`,()=>{
 start(phase==='score');if(phase==='score')score('R',false);const frozen=xy();const e=down(event(2,93,55));
 for(const id of ['touchhook','touchpunch','touchjump','skillW','skillE','skillR','flashbutton'])tap(id);
 r.frames(1);assert.deepEqual(xy(),frozen);stick.onpointermove({...e,clientX:17});
 if(phase==='score')until(()=>r.qa.duel.match.phase==='countdown');until(()=>r.qa.duel.active);r.frames(4);
 assert(Math.abs(r.qa.player.x+1.28)<1e-9);assert.equal(r.qa.player.y,1.7);assert.equal(r.qa.player.z,7);assert.equal(r.qa.hook,null);assert.equal(r.qa.skills.phase,null);
 assert.equal(r.qa.skills.boost,0);assert.equal(r.qa.skills.armed,0);assert.deepEqual(r.qa.skills.cooldown,{W:0,E:0,R:0});assert.equal(r.qa.flashAbility.casts,0);assert.equal(r.game.data.punchCooldown,0);
 tap('touchjump');r.frames(1);assert(r.qa.player.y>1.7,'fresh active action still works');
});
test('multi-touch ignores non-owner movement/up/cancel/loss and keeps look separate; round boundaries still clear look drag',()=>{
 start();const e=down();canvas.listeners.pointerdown(event(3,800,350));canvas.listeners.pointermove(event(3,820,350));assert.notEqual(r.qa.player.yaw,0);
 stick.onpointerdown(event(4,93,55));stick.onpointermove(event(4,93,55));for(const end of ['onpointerup','onpointercancel','onlostpointercapture'])stick[end](event(4));assert.deepEqual(r.game.data.joystick,{x:0,y:-1});
 until(()=>r.qa.duel.active);const yaw=r.qa.player.yaw;canvas.listeners.pointermove(event(3,900,350));assert.equal(r.qa.player.yaw,yaw,'round start clears look owner');
 r.frames(1);assert.notDeepEqual(xy(),[0,7]);end('onpointerup',e);
 canvas.listeners.pointerdown(event(5,800,350));score('R',false);const afterScoreYaw=r.qa.player.yaw;canvas.listeners.pointermove(event(5,900,350));assert.equal(r.qa.player.yaw,afterScoreYaw,'score clears look owner');
});
for(const phase of ['countdown','active','score'])test(`silent capture loss during ${phase} cannot be adopted by stale move or next round`,()=>{
 start(phase!=='countdown');down();if(phase==='score')score();stick.releasePointerCapture(2);
 const before=xy();if(phase==='active')r.frames(1);else until(()=>r.qa.duel.active);
 stick.onpointermove(event());const stopped=xy();r.frames(2);assert.deepEqual(xy(),stopped);if(phase==='active')assert.deepEqual(stopped,before);
 assert.deepEqual(r.game.data.joystick,{x:0,y:0});stick.setPointerCapture(2);stick.onpointermove(event());r.frames(1);assert.deepEqual(xy(),stopped,'capture appearing again is not a new down');
 down();r.frames(1);assert(r.qa.player.z<stopped[1],'fresh down can establish a new contact');
});
test('silent capture loss is detected before a same-owner move even during a hold',()=>{
 start();down();stick.releasePointerCapture(2);stick.onpointermove(event());assert.deepEqual(r.game.data.joystick,{x:0,y:0});stick.setPointerCapture(2);stick.onpointermove(event());until(()=>r.qa.duel.active);r.frames(1);assert.deepEqual(xy(),[0,7]);
});
test('capture failure or refusal leaves no owner; stale moves never create one',()=>{
 for(const mode of ['throw','refuse']){start(true);stick.pointerCaptures?.clear();const capture=stick.setPointerCapture;stick.setPointerCapture=()=>{if(mode==='throw')throw new Error('no active pointer');};try{assert.doesNotThrow(()=>down());}finally{stick.setPointerCapture=capture;}stick.onpointermove(event());r.frames(1);assert.deepEqual(xy(),[0,7]);assert.deepEqual(r.game.data.joystick,{x:0,y:0});down();r.frames(1);assert(r.qa.player.z<7);}
});
for(const interruption of ['pause','blur','hidden','pointer-lock','graphics','menu','restart','resize'])test(`${interruption} fully clears contact and resumed stale events cannot move`,()=>{
 start(true);down();r.frames(1);
 if(interruption==='pause')r.game.pause();
 if(interruption==='blur')r.winListeners.blur();
 if(interruption==='hidden'){document.hidden=true;r.docListeners.visibilitychange();}
 if(interruption==='pointer-lock'){r.element('mousecapture').click();document.pointerLockElement=null;r.docListeners.pointerlockchange();}
 if(interruption==='graphics')canvas.listeners.webglcontextlost({preventDefault(){}});
 if(interruption==='menu'){r.game.pause();r.element('mainmenu').click();}
 if(interruption==='restart')r.element('duelmode').click();
 if(interruption==='resize'){innerWidth=innerWidth===1280?720:1280;r.winListeners.resize();}
 assert.deepEqual(r.game.data.joystick,{x:0,y:0});stick.onpointermove(event());assert.deepEqual(r.game.data.joystick,{x:0,y:0});
 if(interruption==='hidden')document.hidden=false;if(interruption==='graphics')canvas.listeners.webglcontextrestored();
 r.docListeners.pointerdown({pointerType:'touch'});if(interruption==='menu')r.element('duelmode').click();else if(!['restart','resize'].includes(interruption))r.game.resume();quiet();
 until(()=>r.qa.duel.active);const before=xy();stick.onpointermove(event());r.frames(2);assert.deepEqual(xy(),before);down();r.frames(1);assert(r.qa.player.z<before[1]);
});
test('first to three preserves final hold but results and explicit rematch clear contact',()=>{
 start(true);for(let point=1;point<=3;point++){score();assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[point,0]);if(point<3){nextRound();r.frames(1);}}
 assert.equal(r.qa.duel.match.maxRounds,5);assert.equal(r.qa.duel.match.history.length,3);assert.equal(r.qa.duel.match.phase,'matchComplete');const frozen=xy();r.frames(59);assert.equal(r.qa.state,'running');assert.deepEqual(xy(),frozen);r.frames(1);assert.equal(r.qa.state,'results');assert.deepEqual(r.game.data.joystick,{x:0,y:0});
 stick.onpointermove(event());r.frames(3);assert.equal(r.qa.state,'results');r.element('start').click();quiet();until(()=>r.qa.duel.active);stick.onpointermove(event());r.frames(2);assert.deepEqual(xy(),[0,7]);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[0,0]);
});
test('solo live joystick movement and release still work',()=>{
 r.docListeners.pointerdown(event());r.element('practice').click();down(event(2,93,55));r.frames(1);assert(Math.abs(r.qa.player.x-.32)<1e-9);end('onpointerup');const before=xy();r.frames(2);assert.deepEqual(xy(),before);
});
test('fresh pointerdown replaces only a silently lost owner without waiting for a frame',()=>{
 start(true);down();stick.releasePointerCapture(2);down(event(3,93,55));assert.deepEqual(r.game.data.joystick,{x:1,y:0});
 stick.onpointermove(event(2,17,55));for(const ending of ['onpointerup','onpointercancel','onlostpointercapture'])stick[ending](event(2));
 down(event(4,17,55));assert.deepEqual(r.game.data.joystick,{x:1,y:0},'a valid captured owner still rejects a second finger');
 r.frames(1);assert(Math.abs(r.qa.player.x-.32)<1e-9);assert.equal(r.qa.player.z,7);end('onpointerup',event(3));
});
