import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createOnlineDuelWorld} from '../online-duel-world.js';
import {createOnlineSession,validSnapshot} from '../online-duel-session.js';
import {makeInput,ONLINE_ACTIONS as A,ONLINE_PROTOCOL} from '../online-duel-protocol.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';
const session='packet_boundary_fixture_0001';
const skillClips=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))).models.fullbody.clips;
function world(){return createOnlineDuelWorld({session,skillClips,countdownMs:0});}
const wire=s=>JSON.parse(JSON.stringify(s));
function guest(){const states=[],statuses=[],sent=[];const client=createOnlineSession({role:'guest',session,send:v=>(sent.push(v),true),onState:s=>states.push(s),onStatus:s=>statuses.push(s)});return {client,states,statuses,sent};}
const invalidCases=[
 ['zero punch duration creates a nonfinite punch rotation',s=>{s.actors.human.punchDuration=0;s.actors.human.punchTime=.2;}],
 ['punch remaining exceeds its total duration',s=>{s.actors.bot.punchDuration=.2;s.actors.bot.punchTime=.3;}],
 ['boolean animation presentation reaches an invalid avatar clip',s=>{s.actors.human.skills.animation={name:'W_Loop',time:0,presentation:false};}],
 ['nonfinite quaternion norm cannot be normalized',s=>{s.actors.bot.hook={phase:'outbound',position:{x:0,y:2,z:0},phaseTime:.1,bodyOrientation:[1e308,1e308,1e308,1e308]};}],
 ['boolean hook quaternion reaches invalid vector input',s=>{s.actors.bot.hook={phase:'outbound',position:{x:0,y:2,z:0},phaseTime:.1,bodyOrientation:false};}],
 ['missing R origin cannot produce a valid field event',s=>{s.events=[{serial:1,type:'authority',event:{type:'skill-impact',skill:'R',playerId:'human',hit:false,position:null,offset:0,tied:false}}];}],
 ['string impact offset must not reach effect clocks',s=>{s.events=[{serial:1,type:'authority',event:{type:'skill-impact',skill:'E',playerId:'human',hit:true,position:{x:0,y:2,z:0},origin:{x:0,y:2,z:0},offset:'bad',tied:false}}];}],
 ['scores must use the two fixed participant slots',s=>{s.match.playerIds=['alice','bob'];s.match.scores=[{playerId:'alice',points:0},{playerId:'bob',points:0}];}],
 ['active flag is a boolean',s=>{s.active='yes';}],
 ['result-ready flag is a boolean',s=>{s.resultReady='yes';}],
 ['tie clock is finite and bounded',s=>{s.tieRemaining=-1;}],
 ['closed state must also be paused',s=>{s.closed=true;s.paused=false;}],
 ['ready-result state requires a completed match',s=>{s.resultReady=true;}],
 ['oversize skill cooldown does not reach HUD/VFX',s=>{s.actors.human.skills.cooldown.W=1e308;}],
];
for(const [label,mutate] of invalidCases)test('reject malformed snapshot: '+label,()=>{const s=wire(world().snapshot());mutate(s);assert.equal(validSnapshot(s,session),false);});
test('malformed same-session snapshot fails closed before rendering and cannot resume from later packets',()=>{const f=guest(),s=wire(world().snapshot());assert(f.client.receive(s));const bad=structuredClone(s);bad.actors.bot.punchDuration=0;bad.actors.bot.punchTime=.1;assert(!f.client.receive(bad));assert.equal(f.statuses.at(-1),'invalid-state');assert(f.states.at(-1).closed&&f.states.at(-1).paused);assert.equal(f.states.at(-1).actors.bot.punchDuration,s.actors.bot.punchDuration);assert(!f.client.ready(true));assert(!f.client.input(makeInput({session,epoch:s.epoch,seq:0})));assert(!f.client.receive({...s,tick:s.tick+1}));assert.equal(f.sent.length,0);});
test('ordinary delayed snapshot remains ignored without disconnecting a healthy session',()=>{const f=guest(),w=world();w.setReady('human',true);w.setReady('bot',true);const old=wire(w.snapshot());assert(f.client.receive(old));w.step();const next=wire(w.snapshot());assert(f.client.receive(next));assert(!f.client.receive(old));assert.deepEqual(f.client.snapshot,next);assert.deepEqual(f.statuses,[]);assert(f.client.ready(true));});
test('repeated terminal snapshot cannot reopen a gracefully closed guest',()=>{const f=guest(),w=world();assert(f.client.receive(wire(w.snapshot())));w.disconnect();const end=wire(w.snapshot());assert(f.client.receive(end));assert(f.client.snapshot.closed);assert(!f.client.ready(true));const reopened={...end,closed:false,paused:false,tick:end.tick+1};assert(!f.client.receive(reopened));assert(f.client.snapshot.closed);});
test('valid full scoring, cooldown, pause and rematch snapshots survive the strict renderer boundary',()=>{const w=world();let count=0,seq=0;function verify(){assert(validSnapshot(wire(w.snapshot()),session),'frame '+count);w.drainEvents();count++;}function step(n){for(let i=0;i<n;i++){w.step();verify();}}function command(actions=0,z=0){assert(w.submit('human',makeInput({...w.scope,seq:seq++,actions,z})));}
 verify();w.setReady('human',true);w.setReady('bot',true);verify();
 command(A.W|A.JUMP|A.PUNCH);step(100);w.pause();verify();w.setReady('human',true);verify();w.setReady('bot',true);verify();
 for(let round=0;round<3;round++){for(let i=0;i<120;i++){command(0,-1);step(1);}command(A.R);for(let i=0;i<60&&w.snapshot().match.history.length<=round;i++)step(1);assert.equal(w.snapshot().match.history.length,round+1);if(round<2)step(180);}
 step(180);assert(w.restart());verify();assert.deepEqual(w.snapshot().match.scores.map(x=>x.points),[0,0]);w.disconnect();verify();assert(count>1000);
});
test('guest cannot forge another slot, scores, positions or authority clocks while legal actions still work',()=>{const w=world(),host=createOnlineSession({role:'host',session,world:w,send:()=>true});host.ready(true);host.receive({type:'ready',protocol:ONLINE_PROTOCOL,session,epoch:w.scope.epoch,ready:true});const before=w.snapshot();for(let i=0;i<1000;i++){const command=makeInput({...w.scope,seq:i,actions:A.R});assert(!host.receive({...command,playerId:'human',score:3,position:{x:100,y:100,z:100},tick:999999}));}assert.deepEqual(w.snapshot(),before);assert(host.receive(makeInput({...w.scope,seq:1001,actions:A.W,yaw:Math.PI})));host.step();assert(w.snapshot().actors.bot.skills.boost>0);assert.equal(w.snapshot().actors.human.skills.boost,0);assert.deepEqual(w.snapshot().match.scores.map(x=>x.points),[0,0]);});
