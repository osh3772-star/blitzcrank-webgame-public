import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import {createModeRecords,MODE_RECORD_KEYS} from '../mode-records.js';

// Real main.js and Three.js scene graph, with the existing CPU-only harness.
// No forced finish/results state, browser, GPU, or audio playback is used.
const storage={
 data:new Map([['rocket-hand-best','legacy mixed record, preserved verbatim']]),
 writes:[],
 getItem(key){return this.data.get(key)??null;},
 setItem(key,value){this.writes.push([key,value]);this.data.set(key,value);}
};
const records=createModeRecords({getStorage:()=>storage});
records.recordChallenge({practice:false,done:true,score:1000});
records.recordChallenge({practice:false,done:true,score:2000,flashAssisted:true});
for(const route of ['qer','er'])for(const flashAssisted of [false,true]){
 records.recordCombo({success:true,route,flashAssisted,elapsed:4});
}
assert.equal(storage.data.size,Object.keys(MODE_RECORD_KEYS).length+1);
const h=await createGameplayHarness({storage});
const savedBytes=()=>[...storage.data.entries()];
const resultActions={button:()=>h.element('start').click(),Enter:()=>h.key('Enter'),R:()=>h.key('KeyR'),pause:()=>h.element('pause').click()};
const modes={challenge:{practice:false,combo:false},free:{practice:true,combo:false},combo:{practice:true,combo:true}};
function assertMode(mode){
 assert.equal(h.qa.state,'running');
 assert.equal(h.qa.session.practice,mode.practice);
 assert.equal(h.qa.comboPractice.enabled,mode.combo);
 assert.equal(h.element('timer').textContent,mode.combo?'0.00초':mode.practice?'∞':'01:30');
}
function assertFresh(mode){
 assertMode(mode);
 assert.equal(h.qa.session.elapsed,0);
 assert.equal(h.qa.session.score,0);
 assert.equal(h.qa.session.done,false);
 assert.equal(h.qa.health,100);
 assert.equal(h.qa.hook,null);
 assert.equal(h.qa.turrets.bullets,0);
 assert.equal(h.qa.comboPractice.attempts,0);
 assert.equal(h.qa.comboPractice.successes,0);
 assert.equal(h.element('results').classList.s.has('hidden'),true);
}
function freePracticeDeath(){
 h.game.begin(true);
 h.game.setScore(99999);
 // Put the player in an existing turret lane. The unmodified projectile,
 // collision, damage and finish path must produce the result screen itself.
 h.game.data.player.set(-15,1.7,-17);
 const damage=[];
 for(let frame=0;frame<1800&&h.qa.state==='running';frame++){
  const health=h.qa.health;
  h.frames(1);
  if(h.qa.health!==health)damage.push(h.qa.health);
 }
 assert.deepEqual(damage,[82,64,46,28,10,0]);
 assert.equal(h.qa.state,'results');
 assert.equal(h.qa.session.practice,true);
 assert.equal(h.qa.session.done,true);
 assert.equal(h.qa.comboPractice.enabled,false);
 assert.match(h.element('start').innerHTML,/다시 도전/);
}
function challengeTimeout(score=250,{fullDuration=false,flash=false}={}){
 h.game.begin(false);
 if(flash)h.key('KeyF');
 h.game.setScore(score);
 if(fullDuration)h.frames(5401);
 else{h.game.setElapsed(89.99);h.frames(1);}
 assert.equal(h.qa.state,'results');
 assert.equal(h.qa.session.elapsed,90);
 assert.equal(h.qa.session.practice,false);
 assert.equal(h.qa.session.done,true);
 assert.equal(h.qa.health,100);
 assert.equal(h.qa.comboPractice.enabled,false);
}
function toMenu(){
 if(h.qa.state==='running')h.game.pause();
 h.element('mainmenu').click();
 assert.equal(h.qa.state,'menu');
}

for(const [name,retry] of Object.entries(resultActions))test(`natural free-practice turret death: ${name} retries unlimited practice without touching saved records`,()=>{
 const bytes=savedBytes(),writes=storage.writes.length;
 freePracticeDeath();
 assert.deepEqual(savedBytes(),bytes);
 retry();
 assertFresh(modes.free);
 h.game.setElapsed(89.99);h.frames(2);
 assert.equal(h.qa.state,'running');
 assert(h.qa.session.elapsed>90);
 assert.equal(h.element('timer').textContent,'∞');
 assert.deepEqual(savedBytes(),bytes);
 assert.equal(storage.writes.length,writes);
});

for(const [name,retry] of Object.entries(resultActions))test(`challenge timeout: ${name} retries a fresh 90-second challenge`,()=>{
 const bytes=savedBytes(),writes=storage.writes.length;
 challengeTimeout(250,{fullDuration:name==='button'});
 retry();
 assertFresh(modes.challenge);
 h.game.setElapsed(89.99);h.frames(1);
 assert.equal(h.qa.state,'results');
 assert.equal(h.qa.session.elapsed,90);
 assert.deepEqual(savedBytes(),bytes);
 assert.equal(storage.writes.length,writes);
});

for(const [name,mode] of Object.entries(modes))test(`${name}: paused button, Enter and pause-toggle resume without resetting the round`,()=>{
 const bytes=savedBytes(),writes=storage.writes.length;
 for(const resume of [()=>h.element('start').click(),()=>h.key('Enter'),()=>h.element('pause').click()]){
  h.game.begin(mode.practice,mode.combo);
  h.game.setScore(321);h.frames(60);
  h.game.pause();
  const session=h.qa.session,combo=h.qa.comboPractice,health=h.qa.health;
  h.frames(60);
  assert.equal(h.qa.state,'paused');
  assert.deepEqual(h.qa.session,session);
  resume();
  assert.equal(h.qa.state,'running');
  assert.deepEqual(h.qa.session,session);
  assert.deepEqual(h.qa.comboPractice,combo);
  assert.equal(h.qa.health,health);
 }
 assert.deepEqual(savedBytes(),bytes);
 assert.equal(storage.writes.length,writes);
});

for(const [name,mode] of Object.entries(modes))test(`${name}: paused restart preserves the mode and saved records`,()=>{
 const bytes=savedBytes(),writes=storage.writes.length;
 h.game.begin(mode.practice,mode.combo);
 h.game.setScore(321);h.frames(60);h.key('KeyF');
 h.game.pause();
 assert.equal(h.element('practice').textContent,'새로 시작');
 h.element('practice').click();
 assertFresh(mode);
 assert.equal(h.qa.flashAbility.remaining,0);
 assert.deepEqual(savedBytes(),bytes);
 assert.equal(storage.writes.length,writes);
});

test('returning to the main menu keeps default button/Enter challenge and explicit free/combo selectors',()=>{
 const bytes=savedBytes(),writes=storage.writes.length;
 for(const previous of Object.values(modes))for(const [selector,expected] of [
  [()=>h.element('start').click(),modes.challenge],
  [()=>h.key('Enter'),modes.challenge],
  [()=>h.element('pause').click(),modes.challenge],
  [()=>h.element('practice').click(),modes.free],
  [()=>h.element('combopractice').click(),modes.combo]
 ]){
  h.game.begin(previous.practice,previous.combo);toMenu();selector();assertFresh(expected);
 }
 freePracticeDeath();toMenu();h.element('start').click();assertFresh(modes.challenge);
 assert.deepEqual(savedBytes(),bytes);
 assert.equal(storage.writes.length,writes);
});

test('result-screen free/combo buttons explicitly select their mode instead of copying the completed mode',()=>{
 const bytes=savedBytes(),writes=storage.writes.length;
 for(const finish of [freePracticeDeath,challengeTimeout])for(const [id,expected] of [
  ['practice',modes.free],['combopractice',modes.combo]
 ]){finish();h.element(id).click();assertFresh(expected);}
 assert.deepEqual(savedBytes(),bytes);
 assert.equal(storage.writes.length,writes);
});

test('result Enter/R autorepeat and focused controls retain existing keyboard behavior',()=>{
 freePracticeDeath();
 for(const code of ['Enter','KeyR']){
  h.dispatchKey({code,repeat:true});
  assert.equal(h.qa.state,'results');
 }
 for(const target of [{tagName:'INPUT'},{tagName:'SELECT'},{tagName:'TEXTAREA'},{isContentEditable:true},{tagName:'BUTTON',id:'start'},{tagName:'A'}]){
  h.dispatchKey({code:'Enter',target});
  assert.equal(h.qa.state,'results','focused controls are not intercepted by global Enter');
 }
 // The browser's native Enter activation invokes the button's click handler.
 h.element('start').click();assertFresh(modes.free);
});

test('combo practice remains unlimited and nonlethal instead of manufacturing a combo result screen',()=>{
 h.element('combopractice').click();
 h.game.data.player.set(-15,1.7,-17);
 h.game.setElapsed(89.99);h.frames(900);
 assert.equal(h.qa.state,'running');
 assert.equal(h.qa.session.practice,true);
 assert.equal(h.qa.comboPractice.enabled,true);
 assert.equal(h.qa.health,100);
 assert.equal(h.qa.turrets.bullets,0);
 assert.equal(h.qa.turrets.warning,false);
});

test('challenge restarts preserve stored categories and clear only current-round Flash assistance',()=>{
 const before=new Map(storage.data);
 challengeTimeout(2500,{flash:true});
 assert.equal(h.qa.records.challengeFlash.best,2500);
 assert.equal(h.qa.records.challenge.best,1000);
 h.element('start').click();assertFresh(modes.challenge);
 assert.equal(h.qa.flashAbility.remaining,0);
 h.game.setScore(3000);h.game.setElapsed(89.99);h.frames(1);
 assert.equal(h.qa.state,'results');
 assert.equal(h.qa.records.challenge.best,3000);
 assert.equal(h.qa.records.challengeFlash.best,2500);
 h.key('Enter');assertFresh(modes.challenge);
 for(const [key,value] of before){
  if(key!==MODE_RECORD_KEYS.challenge&&key!==MODE_RECORD_KEYS.challengeFlash)assert.equal(storage.data.get(key),value);
 }
 const bytes=savedBytes(),writes=storage.writes.length;
 h.game.setScore(99999);h.game.pause();h.element('practice').click();
 assertFresh(modes.challenge);
 assert.deepEqual(savedBytes(),bytes,'abandoning/restarting an unfinished round must not save its score');
 assert.equal(storage.writes.length,writes);
});

test('top control label follows menu start, running pause, paused resume and result retry',()=>{
 toMenu();assert.equal(h.element('pause').attributes['aria-label'],'훈련 시작');
 h.element('start').click();assert.equal(h.element('pause').attributes['aria-label'],'일시정지');
 h.element('pause').click();assert.equal(h.element('pause').attributes['aria-label'],'계속하기');
 h.element('pause').click();assert.equal(h.element('pause').attributes['aria-label'],'일시정지');
 challengeTimeout();assert.equal(h.element('pause').attributes['aria-label'],'다시 도전');
 h.element('pause').click();assertFresh(modes.challenge);
});
