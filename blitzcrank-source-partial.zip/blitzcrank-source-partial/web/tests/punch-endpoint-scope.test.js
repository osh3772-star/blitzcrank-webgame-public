import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8');
const cooldown='punchCooldown=Math.max(0,punchCooldown-dt);if(dt>0&&punchCooldown<1e-12)punchCooldown=0;';
const animation="oneShot=Math.max(0,oneShot-dt);if(dt>0&&clipName==='Basic_Punch'&&oneShot<1e-12)oneShot=0;";
test('cleanup remains at the two existing cooldown sites and Basic_Punch animation only',()=>{
 assert.equal(source.split(cooldown).length-1,2);assert.equal(source.split(animation).length-1,1);
 assert(source.includes('punchCooldown=.65/punchPlaybackRate;'));assert(source.includes('punchCooldown=44/30;'));assert(source.includes('oneShot=clips.Basic_Punch.duration/punchPlaybackRate;'));
 const duel=source.slice(source.indexOf('function advanceDuel(dt)'),source.indexOf('function advanceDuel(dt)')+1200);
 assert(duel.indexOf('if(duel.active){')<duel.indexOf(cooldown));assert(duel.includes('if(!Number.isFinite(dt)||dt<=0)return'));
});
for(const dt of [0,-1,NaN,Infinity])test(`countdown arithmetic keeps existing invalid/zero dt behavior for ${dt}`,()=>{
 const run=new Function('punchCooldown','oneShot','dt','clipName',cooldown+animation+'return [punchCooldown,oneShot];');
 for(const remaining of [5e-13,1e-12,1e-9,.65])assert.deepEqual(run(remaining,remaining,dt,'Basic_Punch'),[Math.max(0,remaining-dt),Math.max(0,remaining-dt)]);
});
