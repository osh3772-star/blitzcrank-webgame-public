import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const sourcePath=new URL('../main.js',import.meta.url);
function until(r,p){for(let i=0;i<600&&!p();i++)r.frames(1);assert(p());}
async function start(hz=60,third=false){let delta=1/hz;const r=await createGameplayHarness({sourcePath,delta:()=>delta});r.setDelta=v=>delta=v;r.element('duelmode').click();r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:Math.atan2(r.game.data.player.y-1.7,r.game.data.player.z-r.game.data.duelBot.position.z)})});until(r,()=>r.qa.duel.active);if(third)r.key('KeyV');return r;}
function matrixSnapshot(r){r.game.data.fullbody.updateWorldMatrix(true,true);return [...r.game.data.fullbodyMeshes].map(([name,m])=>[name,m.matrixWorld.toArray()]);}
function soleMin(r,side){const m=r.game.data.fullbodyMeshes.get('BC_FootSole.'+side);m.updateWorldMatrix(true,false);const b=m.geometry.boundingBox;let min=Infinity;for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z])min=Math.min(min,new THREE.Vector3(x,y,z).applyMatrix4(m.matrixWorld).y);return min;}
function geometry(r){for(const [,m]of matrixSnapshot(r))assert(m.every(Number.isFinite));for(const side of ['L','R'])assert(soleMin(r,side)>-.0001,'sole below floor');}
function groundedPose(r){assert.equal(r.qa.player.y,1.7);const j=r.qa.motion.locomotion.jump;assert.equal(j.active,false);assert.equal(j.airborne,false);assert.equal(j.weight,0);for(const side of ['L','R']){assert(Math.abs(soleMin(r,side))<1e-6);assert.deepEqual(r.game.data.fullbodyNodes.get('BC_Pivot_Hip.'+side).quaternion.toArray(),[0,0,0,1]);}geometry(r);}
function beginHit(r,skill,jumping,hz){const d=r.game.data;d.duelBot.position.set(0,1.7,4);if(skill==='Q'){assert(d.duel.cast('bot'));r.frames(Math.floor(.2*hz));if(jumping)r.key('Space');until(r,()=>!!d.duel.pendingGrab);}else{const s=d.duel.getSkills('bot');assert(s.castE());until(r,()=>s.status.phase==='E_Hold');if(jumping)r.key('Space');assert(s.strikeE());until(r,()=>!!r.qa.duel.humanKnockup);}return r.qa.player;}

for(const skill of ['E','R'])test(`${skill} exact tie finishes airborne reaction/landing, then replays without a point`,async()=>{
 const r=await start(),d=r.game.data;d.duelBot.position.set(0,1.7,5);
 if(skill==='E'){for(const id of ['human','bot'])assert(d.duel.getSkills(id).castE());until(r,()=>d.skills.status.phase==='E_Hold');r.key('Space');r.game.aim(0,240);for(const id of ['human','bot'])assert(d.duel.getSkills(id).strikeE());}else{r.key('Space');for(const id of ['human','bot'])assert(d.duel.getSkills(id).castR());}
 until(r,()=>d.duel.tieRemaining>0);assert.equal(d.duel.state.history.length,0);const x=d.player.x,z=d.player.z;r.frames(120);groundedPose(r);assert.equal(d.player.x,x);assert.equal(d.player.z,z);assert.equal(d.duel.state.phase,'active');assert(d.duel.tieRemaining>0);assert.equal(d.duel.state.history.length,0);until(r,()=>d.duel.state.phase==='countdown');groundedPose(r);assert.deepEqual(d.player.toArray(),[0,1.7,7]);assert.equal(d.duel.state.history.length,0);
});
