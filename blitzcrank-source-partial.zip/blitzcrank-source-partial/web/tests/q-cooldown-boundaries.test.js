import test from 'node:test';import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import {CONFIG} from '../core.js';
let dt=1/60;const h=await createGameplayHarness({delta:()=>dt});
for(const hz of [30,60,120])test(`solo Q exact endpoint and genuine early remainder ${hz}Hz`,()=>{
 dt=1/hz;h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}
 h.game.data.player.set(0,1.7,-20);h.frames(1);h.key('KeyQ');h.release('KeyQ');h.frames(Math.round(CONFIG.cooldown*hz)-1);assert.equal(h.qa.hook,null);assert(h.game.data.shotCooldown>0);assert.equal(h.qa.session.shots,1);
 const remaining=h.game.data.shotCooldown;dt=remaining-1e-9;h.frames(1);assert(h.game.data.shotCooldown>9.9e-10);h.key('KeyQ');h.release('KeyQ');assert.equal(h.qa.session.shots,1);
 dt=1e-9+1e-14;h.frames(1);assert.equal(h.game.data.shotCooldown,0);assert.equal(h.element('hookstate').textContent,'READY');h.key('KeyQ');h.release('KeyQ');assert.equal(h.qa.session.shots,2);
 // Unpartitioned frame endpoint is the original reproduction.
 dt=1/hz;h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;}h.game.data.player.set(0,1.7,-20);h.frames(1);h.key('KeyQ');h.release('KeyQ');h.frames(Math.round(CONFIG.cooldown*hz));assert.equal(h.qa.hook,null);assert.equal(h.game.data.shotCooldown,0);assert.equal(h.element('touchhook').attributes['aria-disabled'],'false');h.key('KeyQ');h.release('KeyQ');assert.equal(h.qa.session.shots,2);
});
import {createDuelSimulation,DUEL_SHAPE} from '../duel-simulation.js';
const ids=['human','bot'],point=(x,y=1.7,z=0)=>({x,y,z});
function fixture(){const sim=createDuelSimulation({sessionId:'q-endpoint',config:CONFIG,countdownMs:0});sim.prepare();const frame={actors:ids.map((playerId,i)=>({playerId,shape:DUEL_SHAPE,motion:{type:'linear',from:point(i*40),to:point(i*40)}})),obstacles:[],sockets:Object.fromEntries(ids.map((id,i)=>[id,{origin:point(i*40),home:point(i*40),direction:point(0,0,-1),blockedAim:true}]))};return {sim,frame};}
for(const hz of [30,60,120])for(const id of ids)test(`duel ${id} Q exact endpoint ${hz}Hz`,()=>{const {sim,frame}=fixture();assert(sim.cast(id));for(let i=0;i<Math.round(CONFIG.cooldown*hz)-1;i++)sim.step(1/hz,frame);assert.equal(sim.getHook(id),null);assert(sim.cooldown(id)>0);assert(!sim.cast(id));sim.step(1/hz,frame);assert.equal(sim.cooldown(id),0);assert(sim.cast(id));assert.equal(sim.cooldown(ids.find(x=>x!==id)),0);assert.equal(sim.state.history.length,0);});
for(const id of ids)test(`duel ${id} preserves genuine nanosecond and invalid dt`,()=>{const {sim,frame}=fixture();sim.cast(id);for(let i=0;i<43;i++)sim.step(.05,frame);const before=sim.cooldown(id);for(const invalid of [0,-1,NaN,Infinity])assert.equal(sim.step(invalid,frame),false);assert.equal(sim.cooldown(id),before);sim.step(before-1e-9,frame);assert(sim.cooldown(id)>9.9e-10);assert(!sim.cast(id));sim.step(1e-9+1e-14,frame);assert.equal(sim.cooldown(id),0);assert(sim.cast(id));sim.cancel();assert.equal(sim.cooldown(id),0);});

test('solo Q pause preserves pending cooldown and restart resets it',()=>{dt=1/60;h.game.begin(true);h.frames(1);h.key('KeyQ');h.release('KeyQ');h.frames(30);h.game.pause();const before=h.game.data.shotCooldown;h.frames(120);assert.equal(h.game.data.shotCooldown,before);h.game.resume();h.frames(1);assert(h.game.data.shotCooldown<before);h.game.begin(true);assert.equal(h.game.data.shotCooldown,0);assert.equal(h.qa.hook,null);assert.equal(h.element('hookstate').textContent,'READY');});
