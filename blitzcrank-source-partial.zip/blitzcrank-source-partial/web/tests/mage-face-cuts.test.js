import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {TARGET_MODEL_FILES,loadCharacterTargets,TARGET_TYPES} from '../target-models.js';
const local=p=>fileURLToPath(new URL(p,import.meta.url));
const expected='adda0e7dff7aac779b6af9e63bf8a32f5c78d894a9f8e0eb1f82e3ff17c5de94';
test('historical mage face-cut asset stays immutable and the current loader retains its topology contract',async()=>{
 const name='mage.'+expected.slice(0,16)+'.glb';
 const bytes=fs.readFileSync(local('../assets/targets/'+name));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),expected);assert.equal(bytes.length,207620);
 const row=JSON.parse(fs.readFileSync(local('../assets/targets/source-manifest.json'))).find(x=>x.asset==='mage');assert.equal(row.file,TARGET_MODEL_FILES.mage);assert.equal(row.sha256,crypto.createHash('sha256').update(fs.readFileSync(local('../assets/targets/'+TARGET_MODEL_FILES.mage))).digest('hex'));assert.equal(row.bytes,fs.statSync(local('../assets/targets/'+TARGET_MODEL_FILES.mage)).size);assert.equal(row.triangles,2548);assert.equal(row.materials,18);assert.equal(row.draw_primitives,18);
 const allowed=TARGET_TYPES.map(x=>'./assets/targets/'+TARGET_MODEL_FILES[x.id]),requested=[];
 const models=await loadCharacterTargets(async url=>{assert(allowed.includes(url));requested.push(url);const b=fs.readFileSync(local('../'+url.slice(2))),j=JSON.parse(b.subarray(20,20+b.readUInt32LE(12)));assert(j.buffers.every(x=>!x.uri));assert.equal((j.images||[]).length,0);return{ok:true,arrayBuffer:async()=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)};});
 assert.deepEqual(requested,allowed);let triangles=0;models.find(x=>x.id==='mage').scene.traverse(n=>{if(n.isMesh)triangles+=n.geometry.index.count/3;});assert.equal(triangles,2548);
});
test('historical mage surface cuts retain winding, precise local deltas, visible recessed hits and runtime envelopes',()=>{
 const r=JSON.parse(execFileSync(process.execPath,['--max-old-space-size=128',local('../validation/mage-face-v2477/portable-regression.mjs'),local('../'),local('../validation/recovered-assets/mage.976c71bc6d1e06e4.glb'),local('../assets/targets/mage.'+expected.slice(0,16)+'.glb')],{encoding:'utf8',timeout:20000,maxBuffer:1024*1024}));
 assert.equal(r.after.sha256,expected);assert.equal(r.after.triangles,2548);assert.equal(r.before.triangles,2554);assert.deepEqual(r.after.bounds,r.before.bounds);assert.equal(r.after.primitives,18);assert.equal(r.after.meshes,1);
 assert.equal(r.unchangedMaterialArrays.length,15);assert.deepEqual(r.deltas,{'Ancient steel armor':{before:265,after:271,removed:1,added:7},'Steel engraved marks':{before:416,after:396,removed:36,added:16},'Steel bevel highlight':{before:4,after:12,removed:1,added:9}});
 assert.equal(r.frontCutRays,15);assert.equal(r.obliqueCutRays,30);assert.equal(r.preservedRays,724);assert.equal(r.normalization.length,3);assert.equal(r.windingPreserved,true);assert.equal(r.readOnly,true);assert.equal(r.networkCalls,0);assert.equal(r.externalCalls,0);
});
