import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createGameAudio} from '../game-audio.js';
import {TURRET_AUDIO_CUES as cues,TURRET_AUDIO_EVENTS as events} from '../audio-cues.js';

test('continued target schedules exactly .44 seconds; shot and impact keep durations and can overlap',async()=>{
 const sources=[],errors=[];
 const node=()=>({connect(){},disconnect(){}});
 const ctx={state:'running',currentTime:2,destination:{},resume:async()=>{},createGain:()=>({...node(),gain:{cancelScheduledValues(){},setValueAtTime(){}}}),createBufferSource(){const s={...node(),start(...args){this.args=args;},stop(){this.stopped=true;this.onended?.();}};sources.push(s);return s;},decodeAudioData:async b=>({duration:(b.byteLength-44)/2/48000})};
 const audio=createGameAudio({cues,events,createContext:()=>ctx,onError:e=>errors.push(e),fetchImpl:async url=>({ok:true,arrayBuffer:async()=>{const b=fs.readFileSync(new URL('../'+url,import.meta.url));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);}})});
 assert.equal(audio.playEvent('turretAcquired'),false);await audio.unlock();assert.deepEqual(errors,[]);
 assert.equal(audio.playEvent('turretAcquired'),true);assert.deepEqual(sources[0].args,[2,0,.44]);
 assert.equal(audio.playEvent('turretShot'),true);assert.deepEqual(sources[1].args,[2,0,.53]);assert.equal(sources[0].stopped,undefined);
 assert.equal(audio.playEvent('turretImpact'),true);assert.deepEqual(sources[2].args,[2,0,.56]);assert.equal(audio.status.active,3);
 audio.setMuted(true);assert.equal(audio.status.active,0);assert.equal(audio.playEvent('turretAcquired'),false);
 audio.setMuted(false);assert.equal(audio.status.active,0);audio.playEvent('turretAcquired');audio.setPaused(true);assert.equal(audio.status.active,0);
});

test('preserved historical continuous acquisition crop retains its original source evidence',()=>{
 const old=fs.readFileSync(new URL('../assets/audio/turrets/turret-target.wav',import.meta.url));
 const next=fs.readFileSync(new URL('../assets/audio/turrets/turret-target-extended.wav',import.meta.url));
 const manifest=JSON.parse(fs.readFileSync(new URL('../validation/turret-single-warning-v71/previous-source-manifest.json',import.meta.url)));
 const row=manifest.find(r=>r.id==='turret-target'),ratio=row.linear_gain/51.01238757330206;
 const pcm=b=>{let o=12;while(o+8<=b.length){const n=b.readUInt32LE(o+4);if(b.toString('ascii',o,o+4)==='data')return b.subarray(o+8,o+8+n);o+=8+n+(n%2);}throw Error('no PCM');};
 const a=pcm(old),b=pcm(next);assert.equal(a.length/2,11520);assert.equal(b.length/2,21120);assert.equal((b.length-a.length)/2,9600);
 for(let i=0;i<10560;i++)assert(Math.abs(b.readInt16LE(i*2)-a.readInt16LE(i*2)*ratio)<=1.01,`pre-fade sample ${i} changed shape or alignment`);
 let sum=0,nz=0;for(let i=11520;i<21120;i++){const v=b.readInt16LE(i*2);sum+=(v/32768)**2;if(v)nz++;}
 assert(nz>9500);assert(20*Math.log10(Math.sqrt(sum/9600))>-20);
 assert.equal(row.source_start_seconds,9.63);assert.equal(row.source_end_seconds,10.07);assert.equal(row.extension_seconds,.2);assert.equal(row.source_sha256,'c42467f3d4567f4bfade7237b9d29f92218dd23ea30ae61d85f8b70268ccc9a7');
});
