import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from '../vendor/three.module.js';
import {thirdPersonCameraPosition,rayBox,CONFIG} from '../core.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// Real loaded runtime geometry and camera transforms. Renderer/DOM are stubbed:
// these are CPU projection and gameplay regressions, not mobile GPU/device QA.
const sourcePath=new URL('./fixtures/portrait-camera-runtime.js',import.meta.url);
fs.writeFileSync(sourcePath,fs.readFileSync(new URL('../main.js',import.meta.url),'utf8')+`\nwindow.__PORTRAIT_CAMERA_TEST__={resize,aim,toggleView,syncCamera,camera,viewCamera,fullbody,fullbodyMeshes,obstacles,nearestRay,meleeHit,handPoint};`);
let h;
try{h=await createGameplayHarness({sourcePath});}finally{fs.unlinkSync(sourcePath);}
const a=globalThis.__PORTRAIT_CAMERA_TEST__;
const near=(actual,expected,tolerance=1e-9)=>assert(Math.abs(actual-expected)<=tolerance,`${actual} != ${expected}`);
function viewport(width,height){globalThis.innerWidth=width;globalThis.innerHeight=height;a.resize();}
function fresh(width=390,height=844,third=true,pitch=0){viewport(width,height);h.game.begin(true);if((h.qa.view==='third')!==third)h.key('KeyV');a.aim(0,-pitch/.0021);h.frames(1);}
function direction(){return a.camera.getWorldDirection(new THREE.Vector3());}
function disableTargets(){for(const t of h.game.data.targets){t.active=false;t.group.visible=false;t.respawn=Infinity;}}
function isolateTarget(x=.9,y=2.5,z=5){disableTargets();const t=h.game.data.targets[0];t.active=true;t.group.visible=true;t.captured=false;t.knockup=null;t.anchor.set(x,y,z);t.group.position.copy(t.anchor);t.amplitude=0;t.speed=0;return t;}
function bodyBounds(){
 a.fullbody.updateMatrixWorld(true);a.camera.updateMatrixWorld(true);
 const v=new THREE.Vector3();let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity,count=0,inside=0;
 a.fullbody.traverseVisible(o=>{const position=o.geometry?.attributes?.position;if(!o.isMesh||!position)return;
  for(let i=0;i<position.count;i++){v.fromBufferAttribute(position,i).applyMatrix4(o.matrixWorld).project(a.camera);if(v.z < -1 || v.z > 1)continue;
   const x=(v.x+1)*innerWidth/2,y=(1-v.y)*innerHeight/2;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);count++;if(x>=0&&x<=innerWidth&&y>=0&&y<=innerHeight)inside++;
  }
 });return{x0,y0,x1,y1,count,inside};
}

test('first-person and landscape retain exact world/viewmodel projection matrices',()=>{
 for(const [w,ht] of [[320,568],[390,844],[768,1024],[844,390],[1280,720]]){
  fresh(w,ht,false);assert.equal(a.camera.fov,64);assert.deepEqual(a.camera.projectionMatrix.elements,new THREE.PerspectiveCamera(64,w/ht,.08,110).projectionMatrix.elements);
  assert.equal(a.viewCamera.fov,w<ht?72:54);
  if(w>=ht){a.toggleView();assert.equal(a.camera.fov,64);assert.deepEqual(a.camera.projectionMatrix.elements,new THREE.PerspectiveCamera(64,w/ht,.08,110).projectionMatrix.elements);}
 }
});

test('portrait projection updates immediately on toggles/resizes and stays bounded near square or very narrow windows',()=>{
 fresh();for(let repeat=0;repeat<3;repeat++)for(const [w,ht] of [[390,844],[844,390],[768,1024],[320,932],[1000,1000],[999,1000],[1001,1000],[200,1000]]){
  viewport(w,ht);const expected=w<ht?Math.max(64,Math.min(120,THREE.MathUtils.radToDeg(2*Math.atan(Math.tan(Math.PI/6)/(w/ht))))):64;
  near(a.camera.fov,expected);assert(a.camera.fov<=120&&a.camera.fov>=64);assert(a.camera.projectionMatrix.elements.every(Number.isFinite));
  const position=a.camera.position.clone(),quaternion=a.camera.quaternion.clone();
  a.toggleView();assert.equal(a.camera.fov,64);a.toggleView();near(a.camera.fov,expected);
  assert(a.camera.position.distanceTo(position)<1e-10);assert(a.camera.quaternion.angleTo(quaternion)<1e-7);
 }
 h.game.pause();viewport(390,844);a.toggleView();assert.equal(a.camera.fov,64);a.toggleView();near(a.camera.fov,102.655566772743);h.game.resume();
});

test('invalid transient resize dimensions preserve the last finite projections',()=>{
 fresh();const world=a.camera.projectionMatrix.elements.slice(),view=a.viewCamera.projectionMatrix.elements.slice(),aspect=a.camera.aspect;
 for(const [w,ht] of [[0,844],[390,0],[-1,844],[390,-1],[NaN,844],[390,Infinity]]){viewport(w,ht);assert.equal(a.camera.aspect,aspect);assert.deepEqual(a.camera.projectionMatrix.elements,world);assert.deepEqual(a.viewCamera.projectionMatrix.elements,view);}
 viewport(390,844);a.toggleView();assert.equal(a.camera.fov,64);a.toggleView();near(a.camera.fov,102.655566772743);
});

test('actual neutral body fits five portrait sizes throughout the existing allowed pitch range',()=>{
 for(const [w,ht] of [[320,568],[360,800],[390,844],[768,1024],[320,932]])for(const pitch of [-1.15,-.7,0,.3,.5]){
  fresh(w,ht,true,pitch);h.frames(29);const b=bodyBounds();assert(b.count>150000);assert.equal(b.inside,b.count,`${w}x${ht} pitch ${pitch}: ${JSON.stringify(b)}`);
  assert(b.x0>w*.04,`less than 4% horizontal margin at ${w}x${ht}, pitch ${pitch}`);
 }
});

test('portrait optics preserve the center ray, collision boom and nearest target across resize',()=>{
 fresh();const t=isolateTarget(),position=a.camera.position.clone(),quaternion=a.camera.quaternion.clone(),dir=direction();
 const nearest=a.nearestRay(position,dir,CONFIG.maxRange);assert.equal(nearest.target,t);
 for(const [w,ht] of [[320,568],[390,844],[844,390],[1280,720]]){
  viewport(w,ht);a.camera.updateMatrixWorld(true);const ray=new THREE.Raycaster();ray.setFromCamera(new THREE.Vector2(0,0),a.camera);
  assert(ray.ray.direction.distanceTo(dir)<1e-10);assert(a.camera.position.distanceTo(position)<1e-10);assert(a.camera.quaternion.angleTo(quaternion)<1e-7);
  const hit=a.nearestRay(a.camera.position,ray.ray.direction,CONFIG.maxRange);assert.equal(hit.target,t);near(hit.distance,nearest.distance);
 }
 for(const [x,y,z] of [[-9,1.7,-12],[23.4,1.7,15.5],[0,1.7,-42.5]]){
  fresh();h.game.data.player.set(x,y,z);a.syncCamera();const p=h.game.data.player,expected=thirdPersonCameraPosition(p,h.qa.player.yaw,h.qa.player.pitch,a.obstacles);
  assert(a.camera.position.distanceTo(new THREE.Vector3(expected.x,expected.y,expected.z))<1e-10);
  const offset=a.camera.position.clone().sub(p),distance=offset.length();for(const o of a.obstacles)assert.equal(rayBox(p,offset.clone().normalize(),o.min,o.max,distance),null);
 }
});

test('portrait Q keeps center-ray convergence across pitches and respects close blocked aim',()=>{
 for(const [w,ht] of [[320,568],[390,844]])for(const pitch of [-.15,0,.2]){
  fresh(w,ht,true,pitch);disableTargets();h.key('KeyQ');h.frames(16);const hook=h.game.data.hook;assert.equal(hook.phase,'outbound');
  const dir=direction(),hit=a.nearestRay(a.camera.position,dir,CONFIG.maxRange),aim=a.camera.position.clone().addScaledVector(dir,hit.distance);
  assert(hook.direction.dot(aim.sub(hook.position).normalize())>.999999);const position=hook.position.clone(),flight=hook.direction.clone();
  viewport(ht,w);viewport(w,ht);assert(hook.position.distanceTo(position)<1e-12);assert(hook.direction.distanceTo(flight)<1e-12);
 }
 fresh();isolateTarget(.9,2.5,9);h.key('KeyQ');h.frames(16);assert.equal(h.qa.hook.phase,'return');assert.equal(h.qa.hook.travel,0);assert.equal(h.element('hitnotice').textContent,'BLOCKED');
});

test('portrait E retains central targeting, authored impact timing, player range and cover',()=>{
 for(const [w,ht] of [[320,568],[390,844]]){
  fresh(w,ht);const t=isolateTarget();assert.equal(a.meleeHit(3.4).target,t);h.key('KeyE');h.frames(53);h.punch();h.frames(23);assert.equal(h.qa.skills.metrics.powerHits,0);
  viewport(ht,w);viewport(w,ht);h.frames(2);assert.equal(h.qa.skills.metrics.powerHits,1);assert.equal(h.qa.session.score,80);assert(t.knockup);
  fresh(w,ht);isolateTarget(.9,2.5,2);assert.equal(a.meleeHit(3.4).target,null);
  fresh(w,ht);isolateTarget();const cover={min:new THREE.Vector3(.25,1.8,5.9),max:new THREE.Vector3(.65,2.3,6.5)};a.obstacles.push(cover);
  try{assert.equal(a.meleeHit(3.4).target,null);}finally{a.obstacles.splice(a.obstacles.indexOf(cover),1);}
 }
});

test('portrait R retains player-centered range, cover and one timed pulse through resize',()=>{
 for(const [w,ht] of [[320,568],[390,844]]){
  fresh(w,ht);const inside=isolateTarget(0,1.7,3),outside=h.game.data.targets[1];outside.active=true;outside.captured=false;outside.anchor.set(0,1.7,-6);outside.group.position.copy(outside.anchor);outside.amplitude=0;outside.speed=0;
  h.key('KeyR');h.frames(17);assert.equal(h.qa.skills.metrics.discharges,0);viewport(ht,w);viewport(w,ht);h.frames(2);assert.equal(h.qa.skills.metrics.discharges,1);assert.equal(h.qa.skills.metrics.pulseHits,1);assert.equal(inside.active,false);assert.equal(outside.active,true);h.frames(70);assert.equal(h.qa.skills.metrics.discharges,1);
  fresh(w,ht);const blocked=isolateTarget(0,1.7,3),cover={min:new THREE.Vector3(-1,0,4.8),max:new THREE.Vector3(1,4,5.2)};a.obstacles.push(cover);
  try{h.key('KeyR');h.frames(21);assert.equal(blocked.active,true);assert.equal(h.qa.skills.metrics.pulseHits,0);}finally{a.obstacles.splice(a.obstacles.indexOf(cover),1);}
 }
});
