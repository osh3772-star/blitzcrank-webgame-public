import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
async function start(){const writes=[],r=await createGameplayHarness({delta:()=>.05,storage:{getItem:()=>null,setItem:(...args)=>writes.push(args)}});r.element('duelmode').click();r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});r.frames(35);assert(r.qa.duel.active);return{r,writes,d:r.game.data};}
function untilScore(r){for(let i=0;i<20&&r.qa.duel.active;i++)r.frames(1);assert.equal(r.qa.duel.match.history.length,1);}
for(const winner of ['human','bot'])test(`actual ${winner} E awards one point, no pull and finishes knockup during result`,async()=>{
 const {r,d,writes}=await start();d.duelBot.position.set(0,1.7,5);
 const control=d.duel.getSkills(winner);assert(control.castE());r.frames(19);assert.equal(control.status.phase,'E_Hold');assert(control.strikeE());untilScore(r);
 assert.equal(r.qa.duel.match.history[0].winnerId,winner);assert.equal(d.duel.contact.skill,'E');const victim=winner==='human'?d.duelBot.position:d.player;const before={x:victim.x,z:victim.z};
 let peak=victim.y;for(let n=0;n<22;n++){r.frames(1);peak=Math.max(peak,victim.y);assert.equal(victim.x,before.x);assert.equal(victim.z,before.z);assert.equal(r.qa.duel.match.history.length,1);}
 assert(peak>3.7);assert.equal(victim.y,1.7);assert.equal(r.qa.session.score,0);assert.equal(writes.length,0);assert.equal(r.qa.duel.match.phase,'roundReset');r.frames(38);assert.equal(r.qa.duel.match.phase,'countdown');
});
test('actual R score freezes movement/new casts and never pulls opponent',async()=>{
 const {r,d,writes}=await start();d.duelBot.position.set(0,1.7,3);r.key('KeyR');untilScore(r);assert.equal(d.duel.contact.skill,'R');const h=d.player.toArray(),b=d.duelBot.position.toArray();
 r.key('KeyW');r.key('KeyQ');r.key('KeyE');r.key('KeyF');r.punch();r.frames(10);assert.deepEqual(d.player.toArray(),h);assert.deepEqual(d.duelBot.position.toArray(),b);assert.equal(r.qa.duel.match.history.length,1);assert.equal(r.qa.flashAbility.casts,0);assert.equal(writes.length,0);
});
test('actual pending duel R disappears on menu and ordinary solo R still awards 60',async()=>{
 const {r,d}=await start();d.duelBot.position.set(0,1.7,3);r.key('KeyR');r.frames(3);r.game.pause();r.element('mainmenu').click();r.element('practice').click();const s=r.game.data;for(const target of s.targets){target.active=false;target.respawn=Infinity;}
 const target=s.targets[0];target.active=true;target.amplitude=0;target.anchor.set(0,1.7,3);target.group.position.copy(target.anchor);r.frames(10);assert.equal(r.qa.session.score,0);assert.equal(r.qa.duel,null);r.key('KeyR');r.frames(7);assert.equal(r.qa.session.score,60);assert.equal(r.qa.skills.metrics.discharges,1);
});
test('actual W, Flash and basic punch stay available without scoring',async()=>{
 const {r,d,writes}=await start();d.duelBot.position.set(0,1.7,5);r.punch();assert.equal(r.qa.duel.match.history.length,0);r.key('ShiftLeft');assert(r.qa.skills.boost>0);r.key('KeyF');assert.equal(r.qa.flashAbility.casts,1);r.frames(5);assert.equal(r.qa.duel.match.history.length,0);assert.equal(r.qa.session.score,0);assert.equal(writes.length,0);
});
