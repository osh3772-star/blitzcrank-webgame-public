import test from 'node:test';
import assert from 'node:assert/strict';
import {createMouseLook} from '../mouse-look.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';
class Events {
 constructor(){this.events=new Map();}
 addEventListener(name,fn){const list=this.events.get(name)||[];list.push(fn);this.events.set(name,list);}
 removeEventListener(name,fn){this.events.set(name,(this.events.get(name)||[]).filter(f=>f!==fn));}
 dispatch(name,event={}){for(const fn of this.events.get(name)||[])fn(event);}
}
function fixture(){
 const doc=new Events(),canvas=new Events();
 canvas.style={};doc.pointerLockElement=null;
 const q={running:true,losses:0,punches:0,fallbacks:[],requests:[],focuses:0};
 canvas.focus=()=>q.focuses++;
 canvas.requestPointerLock=()=>new Promise((resolve,reject)=>q.requests.push({resolve,reject}));
 const input=createMouseLook({canvas,doc,isRunning:()=>q.running,onLook(){},onPunch:()=>q.punches++,onLockLost:()=>q.losses++,onFallback:reason=>q.fallbacks.push(reason)});
 const grant=()=>{doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');};
 return {doc,canvas,q,input,grant};
}
for(const settlement of ['rejection-first','event-first'])test(`denial ${settlement} eventually permits retry`,async()=>{
 const {doc,q,input,grant}=fixture();input.request();
 if(settlement==='rejection-first'){q.requests[0].reject(Error('denied'));await Promise.resolve();doc.dispatch('pointerlockerror');}
 else {doc.dispatch('pointerlockerror');q.requests[0].reject(Error('denied'));await Promise.resolve();}
 assert.equal(input.pending,false);input.request();assert.equal(q.requests.length,2);grant();q.requests[1].resolve();await Promise.resolve();
 assert.equal(input.mode,'locked');assert.equal(q.losses,0);
});
test('older rejection after newer capture cannot downgrade capture or disable a punch',async()=>{
 const {doc,canvas,q,input,grant}=fixture();input.request();doc.dispatch('pointerlockerror');input.request();
 grant();q.requests[1].resolve();await Promise.resolve();q.requests[0].reject(Error('older denied'));await Promise.resolve();doc.dispatch('pointerlockerror');
 assert.equal(input.mode,'locked');assert.equal(canvas.style.cursor,'none');assert.equal(q.losses,0);
 canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,1);
});
for(const ordering of ['promise-first','event-first'])test(`grant ${ordering} retains capture after pause/resume`,async()=>{
 const {q,input,grant}=fixture();input.request();q.running=false;input.reset();input.refresh();q.running=true;input.refresh();input.request();assert.equal(q.requests.length,1);
 if(ordering==='promise-first'){q.requests[0].resolve();await Promise.resolve();grant();}else{grant();q.requests[0].resolve();await Promise.resolve();}
 assert.equal(input.mode,'locked');assert.equal(q.losses,0);assert.equal(q.focuses,1);
});
for(const action of ['resume','restart'])test(`intentional asynchronous unlock must not re-pause ${action}`,async()=>{
 const h=await createGameplayHarness(),canvas=h.element('game');
 let finishRelease;
 document.exitPointerLock=()=>{finishRelease=()=>{document.pointerLockElement=null;h.docListeners.pointerlockchange();};};
 h.game.begin();await Promise.resolve();h.game.pause();assert.equal(h.qa.state,'paused');
 if(action==='resume')h.game.resume();else h.game.begin();
 assert.equal(h.qa.state,'running');assert.equal(document.pointerLockElement,canvas);
 finishRelease();
 assert.equal(h.qa.state,'running',`${action} was undone by the previous pause's delayed unlock notification`);
});
test('late grant released while paused must not undo a subsequent resume',async()=>{
 const h=await createGameplayHarness(),canvas=h.element('game');
 let finishRelease,resolveCapture;
 canvas.requestPointerLock=()=>new Promise(resolve=>{resolveCapture=resolve;});
 document.exitPointerLock=()=>{finishRelease=()=>{document.pointerLockElement=null;h.docListeners.pointerlockchange();};};
 h.game.begin();h.game.pause();
 document.pointerLockElement=canvas;h.docListeners.pointerlockchange();resolveCapture();await Promise.resolve();
 assert.equal(h.qa.state,'paused');assert.equal(typeof finishRelease,'function');
 h.game.resume();assert.equal(h.qa.state,'running');finishRelease();
 assert.equal(h.qa.state,'running','delayed cleanup of a late grant must not undo resume');
});
for(const action of ['resume','restart'])test(`queued unlock notification must not cancel ${action} while new capture is pending`,async()=>{
 const h=await createGameplayHarness(),canvas=h.element('game');let notifyRelease,resolveCapture,requests=0;
 h.game.begin();await Promise.resolve();
 document.exitPointerLock=()=>{document.pointerLockElement=null;notifyRelease=()=>h.docListeners.pointerlockchange();};
 h.game.pause();
 canvas.requestPointerLock=()=>{requests++;return new Promise(resolve=>{resolveCapture=resolve;});};
 if(action==='resume')h.game.resume();else h.game.begin();
 assert.equal(h.qa.state,'running');notifyRelease();
 assert.equal(h.qa.state,'running',`${action} was cancelled by a queued notification for an earlier intentional release`);
 assert.equal(h.qa.playing,false);assert.equal(h.element('captureprompt').classList.s.has('hidden'),false);
});
