import test from 'node:test';import assert from 'node:assert/strict';
import {createIntegratedTrial} from '../rift-v49-integrated-trial.js';import {createAuditedHookCollider} from '../rift-v49-hook-collider.js';
const pass=()=>({pass:true}),clear=createAuditedHookCollider({auditSegment:pass});
const options={spawn:[0,0],movementAudit:pass,landingAudit:pass,pathAudit:pass,boundaryAudit:pass,bounds:{minX:-20,maxX:20,minZ:-20,maxZ:20},bodyCollider:clear,hookCollider:clear};
test('movement, Flash and the next hook cast use one shared player position',()=>{
 const c=createIntegratedTrial(options);c.step({x:1,z:0},.05);assert.deepEqual(c.snapshot().position,[.25,0]);const f=c.flash({aim:[4.25,0]});assert(f.accepted);const p=c.snapshot().position;
 const cast=c.castPull({aim:[p[0]+4,p[1]]});assert.deepEqual(cast.state.origin,p);assert.equal(c.snapshot().flash.casts,1);
});
test('rejected Flash preserves a flying hook and every shared state field',()=>{
 const c=createIntegratedTrial({...options,pathAudit:()=>({pass:false})});c.castPull({aim:[5,0]});c.step({x:0,z:0},.01);const before=c.snapshot();assert.equal(c.flash({aim:[4,0]}).accepted,false);assert.deepEqual(c.snapshot(),before);
});
test('accepted Flash cancels the old hook and cooldown survives later movement',()=>{
 const c=createIntegratedTrial(options);c.castPull({aim:[5,0]});assert(c.flash({aim:[4,0]}).accepted);assert.equal(c.snapshot().pull.phase,'idle');c.step({x:0,z:1},.05);assert.equal(c.snapshot().flash.remaining,14.95);assert.equal(c.flash({aim:[8,0]}).reason,'cooldown');
});
test('pause cancels skills and freezes movement and cooldown until resume',()=>{
 const c=createIntegratedTrial(options);c.flash({aim:[4,0]});c.castPull({aim:[8,0]});c.pause();const p=c.snapshot();c.step({x:1,z:0},1);assert.deepEqual(c.snapshot(),p);assert.equal(c.castPull({aim:[8,0]}).reason,'paused');c.resume();c.step({x:0,z:0},.05);assert(c.snapshot().flash.remaining<15);
});
test('return follows the moved caster rather than the original launch point',()=>{
 const c=createIntegratedTrial(options);c.castPull({aim:[3,0],targets:[{id:'t',center:[3,0],radius:.7}]});for(let i=0;i<100;i++){const s=c.step({x:0,z:.05},1/60);if(s.pull.phase==='idle'){assert.deepEqual(s.pull.position,s.position);return;}}assert.fail('return did not finish');
});
test('audit failure and invalid dt preserve the shared player/cooldown state',()=>{
 let fail=false;const c=createIntegratedTrial({...options,movementAudit:()=>{if(fail)throw Error('failed');return {pass:true};}});const before=c.snapshot();fail=true;assert.throws(()=>c.step({x:1,z:0},.05));assert.deepEqual(c.snapshot(),before);assert.throws(()=>c.step({x:0,z:0},NaN));
});
test('disposal prevents late input or skill callbacks from restarting the trial',()=>{
 const c=createIntegratedTrial(options);c.castPull({aim:[5,0]});c.dispose();assert.equal(c.snapshot().pull.phase,'idle');for(const f of [()=>c.step({x:0,z:0},.01),()=>c.flash({aim:[4,0]}),()=>c.castPull({aim:[4,0]}),()=>c.resume()])assert.throws(f);
});
