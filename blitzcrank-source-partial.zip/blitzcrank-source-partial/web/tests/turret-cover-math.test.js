import test from 'node:test';
import assert from 'node:assert/strict';
import {sweptSphereBox as hit} from '../turret-view.js';
const min={x:0,y:0,z:0},max={x:1,y:1,z:1},point=(x,y,z)=>({x,y,z});
test('swept sphere exact overlap, tangency, rounded corners and earliest contact',()=>{
let count=0;function check(a,b){count++;assert.equal(a,b);}
check(hit(point(.5,.5,.5),point(.5,.5,.5),min,max,.125),0);
check(hit(point(-.125,.5,.5),point(-.125,.5,.5),min,max,.125),0);
check(hit(point(-.126,.5,.5),point(-.126,.5,.5),min,max,.125),null);
check(hit(point(-.125,.5,.5),point(-1,.5,.5),min,max,.125),0);
check(hit(point(-1,1.375,1.5),point(2,1.375,1.5),min,max,.625),1/3);
check(hit(point(-1,1.375,1.50001),point(2,1.375,1.50001),min,max,.625),null);
check(hit(point(-1,1.1,1.1),point(2,1.1,1.1),min,max,.12),null);
check(hit(point(-1,.5,.5),point(-.125,.5,.5),min,max,.125),1);
check(hit(point(-1,1.125,.5),point(0,1.125,.5),min,max,.125),1);
check(hit(point(0,1.125,.5),point(-1,1.125,.5),min,max,.125),0);
check(hit(point(2,.5,.5),point(-1,.5,.5),min,max,.125),.875/3);
assert.equal(count,11);
});
test('decimal radius tangent retains outward near misses',()=>{
 const r=.12;
 const fraction=hit(point(-.5,1.12,.5),point(1,1.12,.5),min,max,r);
 assert.ok(fraction!==null&&Math.abs(fraction-1/3)<1e-7);
 for(const length of [1,10000])assert.equal(hit(point(-length,1.12+1e-10,.5),point(length,1.12+1e-10,.5),min,max,r),null);
});

import fs from 'node:fs';
// Independent convex-distance oracle cases caught excessive root rechecking.
const regressionCases=JSON.parse(fs.readFileSync(new URL('./fixtures/turret-sweep-oracle-regressions.json',import.meta.url)));
test('217 independently solved contact cases retain earliest roots, including actual projectile radius',()=>{
 assert.equal(regressionCases.length,217);assert(regressionCases.some(c=>c.radius===.12));
 for(const c of regressionCases){const actual=hit(c.from,c.to,c.min,c.max,c.radius);assert.notEqual(actual,null);assert(Math.abs(actual-c.expected)<1e-8,JSON.stringify({actual,expected:c.expected,radius:c.radius}));}
});
