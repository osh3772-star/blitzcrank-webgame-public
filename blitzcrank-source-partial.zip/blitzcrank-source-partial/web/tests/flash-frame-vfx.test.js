import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import * as THREE from '../vendor/three.module.js';
import {FLASH_FRAMES as manifest} from '../flash-frame-manifest.js';
import {validateFlashFrames,loadFlashFrameTexture,createFlashFrameVfx} from '../flash-frame-vfx.js';
const setup=()=>{const scene=new THREE.Scene(),texture=new THREE.Texture();return {scene,texture,vfx:createFlashFrameVfx(THREE,{scene,texture,manifest})};};
test('approved frame atlas matches bytes, source selection and no-audio/arrival boundaries',()=>{
 validateFlashFrames(manifest);const bytes=fs.readFileSync(new URL('../'+manifest.texture.slice(2),import.meta.url));assert.equal(createHash('sha256').update(bytes).digest('hex'),manifest.sha256);assert.equal(bytes.readUInt32BE(16),manifest.cellWidth*manifest.columns);assert.equal(bytes.readUInt32BE(20),manifest.cellHeight*manifest.rows);assert.equal(bytes[25],6);assert.deepEqual(manifest.sourceFrames,[26,27,28,29,30,31]);assert.equal(manifest.fps,10);assert.equal(manifest.completeTail,false);assert.equal(manifest.sourceRgbExact,true);assert.equal(manifest.originalParticleAsset,false);assert.equal(manifest.arrivalAvailable,false);assert.equal(manifest.audioAvailable,false);
});
test('loader uses only the approved atlas and preserves discrete source pixels',async()=>{
 const texture=new THREE.Texture();let path;const loaded=await loadFlashFrameTexture(THREE,manifest,{loader:{async loadAsync(url){path=url;return texture;}}});assert.equal(path,manifest.texture);assert.equal(loaded,texture);assert.equal(texture.colorSpace,THREE.SRGBColorSpace);assert.equal(texture.magFilter,THREE.NearestFilter);assert.equal(texture.minFilter,THREE.NearestFilter);assert.equal(texture.generateMipmaps,false);
 await assert.rejects(loadFlashFrameTexture(THREE,manifest,{loader:{async loadAsync(){throw Error('missing source frame atlas');}}}),/missing source/);
});
test('one fixed source sprite appears only at departure without particles or shader substitutes',()=>{
 const {scene,texture,vfx}=setup();assert.equal(scene.children.length,1);const sprite=scene.children[0];assert(sprite.isSprite);assert.equal(sprite.visible,false);assert.equal(sprite.material.opacity,1);assert.equal(sprite.material.blending,THREE.NormalBlending);assert.equal(sprite.material.depthWrite,false);assert.equal(sprite.material.depthTest,true);assert.equal(sprite.material.toneMapped,false);assert.equal(sprite.material.map,texture);assert.equal(sprite.center.x,.5);assert(Math.abs(sprite.center.y-.45)<1e-12);assert(vfx.play({x:2,y:1.7,z:4}));assert.deepEqual(vfx.inspect().position,[2,.12,4]);assert.equal(vfx.inspect().sourceFrame,26);assert.equal(scene.children.length,1);
});
test('native 10fps stepping holds frames and stops at selected footage boundary without a generated fade',()=>{
 const {texture,vfx}=setup();vfx.play({x:0,y:1.7,z:0});vfx.update(.099);assert.equal(vfx.inspect().sourceFrame,26);assert.equal(texture.offset.x,0);vfx.update(.001);assert.equal(vfx.inspect().sourceFrame,27);assert.equal(texture.offset.x,.1);vfx.update(.4);assert.equal(vfx.inspect().sourceFrame,31);vfx.update(.1);assert.equal(vfx.inspect().active,false);assert.equal(vfx.inspect().frame,-1);
});
test('nonfinite/negative deltas do not advance, and replays reuse only the original sprite',()=>{
 const {scene,vfx}=setup();assert.equal(vfx.play({x:NaN,y:1,z:2}),false);vfx.play({x:0,y:1.7,z:0});const state=vfx.inspect();for(const dt of [0,-1,NaN,Infinity])vfx.update(dt);assert.deepEqual(vfx.inspect(),state);vfx.update(.2);vfx.play({x:3,y:3.7,z:-4});assert.deepEqual(vfx.inspect().position,[3,2.12,-4]);assert.equal(vfx.inspect().sourceFrame,26);assert.equal(scene.children.length,1);vfx.reset();assert.equal(vfx.inspect().active,false);
});
test('dispose releases material/texture exactly once and prevents further playback',()=>{
 const {scene,texture,vfx}=setup();let maps=0,materials=0;texture.addEventListener('dispose',()=>maps++);scene.children[0].material.addEventListener('dispose',()=>materials++);vfx.dispose();vfx.dispose();assert.equal(scene.children.length,0);assert.equal(maps,1);assert.equal(materials,1);assert.equal(vfx.play({x:0,y:1.7,z:0}),false);assert.equal(vfx.inspect().disposed,true);
});
test('malformed atlas metadata and unverified provenance fail closed',()=>{
 for(const replacement of [{sourceRgbExact:false},{originalParticleAsset:true},{arrivalAvailable:true},{audioAvailable:true},{columns:0},{fps:0},{frameCount:99},{anchor:[-1,0]},{texture:'https://example.com/new.png'}])assert.throws(()=>validateFlashFrames({...manifest,...replacement}));assert.throws(()=>createFlashFrameVfx(THREE,{scene:new THREE.Scene(),texture:null,manifest}));
});
