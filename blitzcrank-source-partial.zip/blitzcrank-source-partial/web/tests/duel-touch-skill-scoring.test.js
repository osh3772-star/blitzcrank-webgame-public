import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
for(const view of ['first','third'])for(const skill of ['E','R'])test(`actual touch ${skill} scores once from ${view}-person and freezes repeat input`,async()=>{
 const writes=[],r=await createGameplayHarness({delta:()=>1/60,storage:{getItem:()=>null,setItem:(...a)=>writes.push(a)}});
 r.element('duelmode').click();r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});r.frames(100);
 if(view==='third')r.key('KeyV');
 document.pointerLockElement=null;r.docListeners.pointerdown({pointerType:'touch'});r.frames(1);
 const d=r.game.data;d.duelBot.position.set(0,1.7,5);
 const tap=id=>r.element(id).onpointerdown({pointerType:'touch',button:0,preventDefault(){}});
 if(skill==='E'){tap('skillE');r.frames(60);assert.equal(d.duel.getSkills('human').status.phase,'E_Hold');tap('touchpunch');}
 else tap('skillR');
 for(let i=0;i<40&&d.duel.active;i++)r.frames(1);
 assert.equal(d.duel.contact?.skill,skill);assert.equal(d.duel.state.history.length,1);assert.equal(d.duel.state.history[0].winnerId,'human');
 const casts=r.qa.flashAbility.casts;tap('skillE');tap('skillR');tap('touchpunch');tap('flashbutton');r.frames(5);
 assert.equal(d.duel.state.history.length,1);assert.equal(r.qa.flashAbility.casts,casts);assert.deepEqual(writes,[]);
});
