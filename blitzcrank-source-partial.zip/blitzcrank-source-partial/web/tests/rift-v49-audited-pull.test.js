import test from 'node:test';import assert from 'node:assert/strict';
import {createAuditedPullTrial} from '../rift-v49-audited-pull.js';import {createAuditedHookCollider} from '../rift-v49-hook-collider.js';
const collider=auditSegment=>createAuditedHookCollider({auditSegment}),clear=collider(()=>({pass:true}));
function run(c,hz=60,home=[0,0]){const segments=[];for(let i=0;i<2000;i++){const s=c.step(1/hz,{home});segments.push(...s.segments);if(['idle','blocked'].includes(s.phase))return {...s,segments};}throw Error('Did not terminate');}
test('diagonal pull ends with non-overlapping AABBs and the configured gap',()=>{
 for(const hz of [20,60,120]){const c=createAuditedPullTrial({body:clear,hook:clear});c.cast({origin:[0,0],aim:[4,4],targets:[{id:'t',center:[4,4],radius:.7}]});const s=run(c,hz),[x,z]=s.target.center;assert.equal(s.hit,'t');assert.equal(s.reason,'pulled');assert(Math.hypot(x,z)>=2*Math.hypot(.7,.7)+.15-1e-9);assert(Math.abs(x)>=1.4||Math.abs(z)>=1.4);}
});
test('target body obstacle stops pulling without teleporting through it',()=>{
 const body=collider((a,b)=>({pass:Math.min(a[0],b[0])>=3||Math.max(a[0],b[0])<1,reason:'body-wall'}));
 const c=createAuditedPullTrial({body,hook:clear});c.cast({origin:[0,0],aim:[5,0],targets:[{id:'t',center:[5,0],radius:.7}]});const s=run(c);assert.equal(s.targetBlockedBy,'body-wall');assert(s.target.center[0]>3);assert.equal(s.phase,'idle');
});
test('hook obstruction can independently stop a pulled target',()=>{
 let pulling=false;const hook=collider((a,b)=>({pass:!pulling||Math.min(a[0],b[0])>=3,reason:'hook-wall'}));
 const c=createAuditedPullTrial({body:clear,hook});c.cast({origin:[0,0],aim:[5,0],targets:[{id:'t',center:[5,0],radius:.7}]});while(c.snapshot().phase==='outbound')c.step(1/60);pulling=true;const s=run(c);assert.equal(s.targetBlockedBy,'hook-wall');assert(s.target.center[0]>3);
});
test('moving target contacts continuously and never repels once pulling starts',()=>{
 for(const hz of [20,60,120]){const c=createAuditedPullTrial({body:clear,hook:clear});c.cast({origin:[0,0],aim:[5,0],targets:[{id:'t',center:[5,0],radius:.7,velocity:[0,.5]}]});let prior=Infinity;for(let i=0;i<2000;i++){const s=c.step(1/hz);if(s.phase==='pulling'){const d=Math.hypot(...s.target.center);assert(d<=prior+1e-10);prior=d;}if(s.phase==='idle'){assert.equal(s.hit,'t');break;}}}
});
test('invalid or blocked target does not start a cast; rejected home pauses the step',()=>{
 const body=collider((a,b)=>({pass:a[0]<9&&b[0]<9,reason:'wall'})),c=createAuditedPullTrial({body,hook:clear});assert.equal(c.cast({origin:[0,0],aim:[10,0],targets:[{id:'t',center:[10,0],radius:.7}]}).accepted,false);
 c.cast({origin:[0,0],aim:[5,0],targets:[{id:'t',center:[5,0],radius:.7}]});const before=c.snapshot();assert(c.step(.05,{home:[10,0]}).homeRejected);assert.deepEqual(c.snapshot(),before);c.cancel();assert.equal(c.step(.05).phase,'idle');
});
test('invalid stop distance and excessive target velocity reject',()=>{
 assert.throws(()=>createAuditedPullTrial({body:clear,hook:clear,stopDistance:1}));const c=createAuditedPullTrial({body:clear,hook:clear});assert.throws(()=>c.cast({origin:[0,0],aim:[5,0],targets:[{id:'t',center:[5,0],radius:.7,velocity:[9,0]}]}));
});
test('a target already within the stop gap is never pushed away to create space',()=>{
 const c=createAuditedPullTrial({body:clear,hook:clear});c.cast({origin:[0,0],aim:[1,0],targets:[{id:'t',center:[1,0],radius:.7}]});const s=run(c);assert.deepEqual(s.target.center,[1,0]);assert.equal(s.pulledDistance,0);assert.equal(s.hit,'t');
});
