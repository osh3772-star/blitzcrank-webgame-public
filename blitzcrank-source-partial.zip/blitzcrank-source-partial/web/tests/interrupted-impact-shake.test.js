import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

const root=process.env.DUEL_INTERRUPT_APP_ROOT||fileURLToPath(new URL('../',import.meta.url));
const {createGameplayHarness}=await import(pathToFileURL(path.join(root,'tests/helpers/runtime-harness.js')));
const source=process.env.DUEL_INTERRUPT_SOURCE||path.join(root,'main.js');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'interrupted-impact-shake-'));
const instrumented=path.join(tmp,'main.mjs');
fs.writeFileSync(instrumented,fs.readFileSync(source,'utf8')+'\nwindow.__IMPACT_SHAKE_TEST__={prepareMirrorBody,restoreMirrorBody,fullbodyCableSocket,fullbodyChainSocket,get data(){return{viewmodel,shake};}};\n');
let now=10,delta=.05;
Object.defineProperty(performance,'now',{configurable:true,value:()=>now});
const r=await createGameplayHarness({sourcePath:instrumented,delta:()=>delta});
const extra=globalThis.__IMPACT_SHAKE_TEST__;
const frame=(count=1)=>{for(let i=0;i<count;i++){now+=1000*delta;r.frames(1);}};
const until=p=>{for(let i=0;i<300&&!p();i++)frame();assert(p(),'expected natural transition');};
const points=()=>r.qa.duel.match.scores.map(x=>x.points);
function fresh(view='first'){
 delta=.05;document.hidden=false;r.element('game').listeners.webglcontextrestored();
 r.element('duelmode').click();r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0})});
 if(r.qa.view!==view)r.element('viewtoggle').click();until(()=>r.qa.duel.active);
}
function score(skill='R'){
 r.game.data.duelBot.position.set(0,1.7,5);const previous=r.qa.duel.match.history.length;
 if(skill==='R')r.key('KeyR');else{r.key('KeyE');until(()=>r.qa.skills.phase==='E_Hold');r.punch();}
 until(()=>r.qa.duel.match.history.length===previous+1);
 assert.equal(r.qa.duel.match.history.at(-1).winnerId,'human');
 assert(extra.data.shake>0,'a natural human skill impact supplies the shake');
}
function authoritative(){return structuredClone({match:r.qa.duel.match,hook:r.qa.hook,player:r.qa.player,
 bot:r.qa.duel.bot,skills:r.qa.skills,flash:r.qa.flashAbility,session:r.qa.session,motion:r.qa.motion});}
function freeze(kind){
 if(kind==='pause')r.game.pause();
 if(kind==='blur')r.winListeners.blur();
 if(kind==='hidden'){document.hidden=true;r.docListeners.visibilitychange();}
 if(kind==='capture'){document.pointerLockElement=null;r.docListeners.pointerlockchange();}
 if(kind==='capture-before-event')document.pointerLockElement=null;
 if(kind==='graphics')r.element('game').listeners.webglcontextlost({preventDefault(){}});
 assert.equal(r.qa.playing,false);
}
function resume(kind){
 document.hidden=false;if(kind==='graphics')r.element('game').listeners.webglcontextrestored();
 if(r.qa.state==='paused')r.game.resume();else r.element('mousecapture').click();
 assert.equal(r.qa.playing,true);
}
for(const view of ['first','third'])for(const kind of ['pause','blur','hidden','capture','capture-before-event','graphics'])test(`R scored hold ${view} view freezes FPS impact offset during ${kind}, then resumes once`,()=>{
 fresh(view);score();freeze(kind);const state=authoritative(),position=extra.data.viewmodel.position.toArray(),shake=extra.data.shake;
 for(const elapsed of [1000,10000,30000]){now+=elapsed;r.frames(1);assert.deepEqual(authoritative(),state);assert.equal(extra.data.shake,shake);assert.deepEqual(extra.data.viewmodel.position.toArray(),position,'paused impact must not oscillate from wall time');}
 r.element('viewtoggle').click();r.element('viewtoggle').click();assert.deepEqual(extra.data.viewmodel.position.toArray(),position);
 resume(kind);assert.deepEqual(authoritative(),state);frame();assert(Math.abs(extra.data.shake-(shake-.05))<1e-12);assert(Math.abs(r.qa.duel.match.remainingMs-(state.match.remainingMs-50))<1e-8);
 frame(59);assert.equal(r.qa.duel.match.phase,'countdown');assert.equal(r.qa.duel.match.roundNumber,2);assert.deepEqual(points(),[1,0]);assert.equal(extra.data.shake,0);assert.equal(extra.data.viewmodel.position.x,0);
});
for(const skill of ['E','R'])test(`${skill} zero-time resume refresh freezes impact offset without consuming any hold time`,()=>{
 fresh();score(skill);r.game.pause();const position=extra.data.viewmodel.position.toArray(),state=authoritative(),shake=extra.data.shake;
 delta=0;r.game.resume();for(let i=0;i<3;i++){now+=5000;r.frames(1);assert.deepEqual(authoritative(),state);assert.equal(extra.data.shake,shake);assert.deepEqual(extra.data.viewmodel.position.toArray(),position);}
 delta=.05;frame();assert(Math.abs(r.qa.duel.match.remainingMs-2950)<1e-8);assert.deepEqual(points(),[1,0]);
});
test('uninterrupted positive-time R shake preserves the exact original waveform and decay',()=>{
 fresh();score();let changes=0;
 for(let i=0;i<8;i++){
  const shake=extra.data.shake,before=extra.data.viewmodel.position.x;frame();
  assert.equal(extra.data.viewmodel.position.x,shake?Math.sin(now*.07)*shake*.1:0);
  assert.equal(extra.data.shake,Math.max(0,shake-.05));if(before!==extra.data.viewmodel.position.x)changes++;
 }
 assert(changes>=3);assert.equal(extra.data.shake,0);assert.equal(extra.data.viewmodel.position.x,0);
});
test('third R point freezes the same way and still reaches natural results only after the remaining hold',()=>{
 fresh();for(let n=0;n<2;n++){score();until(()=>r.qa.duel.active);}score();assert.equal(r.qa.duel.match.phase,'matchComplete');
 freeze('blur');const p=extra.data.viewmodel.position.toArray(),s=authoritative();now+=5000;r.frames(3);assert.deepEqual(authoritative(),s);assert.deepEqual(extra.data.viewmodel.position.toArray(),p);
 resume('blur');frame(59);assert.equal(r.qa.state,'running');frame();assert.equal(r.qa.state,'results');assert.deepEqual(points(),[3,0]);const finished=authoritative(),position=extra.data.viewmodel.position.toArray();now+=5000;r.frames(3);assert.deepEqual(authoritative(),finished);assert.deepEqual(extra.data.viewmodel.position.toArray(),position);
 r.element('start').click();assert.equal(r.qa.duel.match.phase,'countdown');assert.deepEqual(points(),[0,0]);
});

for(const view of ['first','third'])test(`natural solo defeat result freezes ${view} FPS root; new game keeps its original live offset formula`,()=>{
 document.hidden=false;r.element('game').listeners.webglcontextrestored();delta=.05;r.game.begin(false);
 if(r.qa.view!==view)r.element('viewtoggle').click();frame();assert.deepEqual(extra.data.viewmodel.position.toArray().slice(1),[-.13,.18]);
 r.game.damagePlayer(100);assert.equal(r.qa.state,'results');assert(extra.data.shake>0);
 const p=extra.data.viewmodel.position.toArray(),shake=extra.data.shake;
 for(let i=0;i<3;i++){now+=5000;r.frames(1);assert.equal(r.qa.state,'results');assert.equal(extra.data.shake,shake);assert.deepEqual(extra.data.viewmodel.position.toArray(),p);}
 r.element('start').click();assert.equal(r.qa.state,'running');frame();assert.equal(extra.data.viewmodel.position.x,Math.sin(now*.07)*shake*.1);assert.equal(extra.data.shake,Math.max(0,shake-.05));assert.deepEqual(extra.data.viewmodel.position.toArray().slice(1),[-.13,.18]);
});
for(const view of ['first','third'])test(`pending human Q ${view} pause preserves projectile, mirror cable and completed-pull scoring`,()=>{
 fresh(view);const d=r.game.data;d.duelBot.position.set(view==='first'?0:d.camera.position.x,1.7,1);r.key('KeyQ');until(()=>!!r.qa.duel.pendingGrab);
 assert.equal(r.qa.duel.match.history.length,0);r.game.pause();const state=authoritative(),rootPosition=extra.data.viewmodel.position.toArray();
 const sceneState=()=>({bodyVisible:d.fullbody.visible,fistVisible:d.fist.visible,ropeVisible:d.rope.visible,ropeStart:d.rope.userData.start.toArray(),ropeEnd:d.rope.userData.end.toArray(),fistPosition:d.fist.position.toArray(),fistQuaternion:d.fist.quaternion.toArray(),player:d.player.toArray(),camera:d.camera.position.toArray()});
 const before=sceneState();now+=30000;r.frames(3);assert.deepEqual(sceneState(),before);assert.deepEqual(extra.data.viewmodel.position.toArray(),rootPosition);assert.deepEqual(authoritative(),state);
 const token=extra.prepareMirrorBody();assert.equal(d.fullbody.visible,true);assert.equal(d.fist.visible,false);
 if(view==='first'){assert.deepEqual(d.rope.userData.start.toArray(),extra.fullbodyCableSocket().toArray());assert.deepEqual(d.rope.userData.end.toArray(),extra.fullbodyChainSocket().toArray());}
 extra.restoreMirrorBody(token);assert.deepEqual(sceneState(),before);assert.deepEqual(authoritative(),state);
 r.game.resume();until(()=>r.qa.duel.match.history.length===1);assert.deepEqual(points(),[1,0]);assert.equal(r.qa.duel.match.remainingMs,3000);frame(60);assert.equal(r.qa.duel.match.phase,'countdown');assert.equal(r.qa.duel.match.history.length,1);
});
