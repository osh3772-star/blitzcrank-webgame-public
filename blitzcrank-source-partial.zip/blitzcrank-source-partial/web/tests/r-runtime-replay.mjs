import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const sourcePath=process.argv[2],h=await createGameplayHarness({sourcePath});
const hash=createHash('sha256');let casts=0;
const fresh=()=>{h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}};
const sample=()=>({player:h.qa.player,session:h.qa.session,skills:h.qa.skills,viewmodel:h.game.data.parts.map(p=>[p.position.toArray(),p.quaternion.toArray(),p.scale.toArray()])});
for(const scenario of ['stationary','moving','blocked','jump','paused','heldE','Q']){
 fresh();if(scenario==='moving'||scenario==='jump'||scenario==='paused'||scenario==='heldE'||scenario==='Q'){h.key('KeyW');h.frames(15);}if(scenario==='blocked'){h.game.data.player.x=23.39;h.key('KeyD');h.frames(30);}if(scenario==='heldE'){h.key('KeyE');h.frames(53);}h.key('KeyR');
 for(let f=0;f<100;f++){if(f===0)assert.equal(h.qa.skills.phase,'R_Cast');if(scenario==='jump'&&f===4)h.key('Space');if(scenario==='paused'&&f===8)h.game.pause();if(scenario==='paused'&&f===18)h.game.resume();if(f===25)h.release('KeyW');if(scenario==='Q'&&f===72)h.key('KeyQ');h.frames(1);if(h.qa.skills.phase==='R_Cast')casts++;hash.update(JSON.stringify(sample()));}
 h.release('KeyW');h.release('KeyD');h.release('Space');
}
console.log(JSON.stringify({digest:hash.digest('hex'),casts}));
