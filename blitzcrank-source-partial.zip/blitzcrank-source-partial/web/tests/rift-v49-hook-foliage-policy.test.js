import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {createHookFoliagePolicy} from '../rift-v49-hook-foliage-policy.mjs';import {MAP_V49,loadV49Inputs} from '../rift-v49-offline-inputs.mjs';import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)),glbBytes=fs.readFileSync(new URL('../'+MAP_V49.glb,import.meta.url)),collisionBytes=fs.readFileSync(new URL('../'+MAP_V49.collision,import.meta.url));
test('exact official flag and node identity produce a one-node exclusion only',()=>{
 const p=createHookFoliagePolicy({glbBytes,collisionBytes});assert.deepEqual(p.excludedMeshNames,['Batched_Grass_And_Reeds']);assert.equal(p.adopted,false);assert.equal(p.evidence.mesh,'Batched_Forest_And_Reeds.001');
});
test('cliffs, unknown geometry and every other foliage name remain blocking',()=>{
 const p=createHookFoliagePolicy({glbBytes,collisionBytes});
 assert.equal(p.blocksSurface({mesh:'Batched_Grass_And_Reeds'}),false);
 for(const mesh of ['Continuous_Cliff_Walls_Layered_v11','Lane_Edge_Grass','Rear_Base_Conifers_And_Shrubs','Unknown','Batched_Grass_And_Reeds.001'])assert(p.blocksSurface({mesh}));
});
test('changed GLB or collision bytes cannot inherit the exception',()=>{
 const changed=Buffer.from(glbBytes);changed[changed.length-1]^=1;
 assert.throws(()=>createHookFoliagePolicy({glbBytes:changed,collisionBytes}));
 assert.throws(()=>createHookFoliagePolicy({glbBytes,collisionBytes:Buffer.concat([collisionBytes,Buffer.from(' ')])}));
});
test('policy cannot mutate either official input',()=>{
 const a=Buffer.from(glbBytes),b=Buffer.from(collisionBytes);const p=createHookFoliagePolicy({glbBytes:a,collisionBytes:b});assert.throws(()=>p.excludedMeshNames.push('cliff'));assert.deepEqual(a,glbBytes);assert.deepEqual(b,collisionBytes);
});
test('official cliff collision remains blocking despite foliage exclusion',()=>{
 const p=createHookFoliagePolicy({glbBytes,collisionBytes}),probe=loadV49Inputs(root).createProbe({radius:.12});assert(p.planarCliffAndBoundaryChecksRequired);assert.equal(probe.probe([0,-12]).blockedBy,'wall_poly_13');assert.equal(probe.probe([100,100]).blockedBy,'map_boundary');
});
