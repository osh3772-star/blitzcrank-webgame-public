import test from 'node:test';
import assert from 'node:assert/strict';
import {createFlashController} from '../flash-controller.js';
const args={playing:true,position:{x:0,y:1.7,z:7},yaw:0};
for(const hz of [30,60,120])test(`Flash controller exact 15s endpoint at ${hz}Hz`,()=>{
 const f=createFlashController();assert(f.cast(args).accepted);
 for(let i=0;i<15*hz;i++)f.step(1/hz);
 const status=f.status,recast=f.cast(args);console.log(JSON.stringify({scope:'controller',hz,frames:15*hz,status,recast:recast.accepted}));
 assert.equal(status.remaining,0);assert.equal(status.ready,true);assert.equal(recast.accepted,true);
});
test('Flash preserves genuine nanosecond delay, invalid dt and strict epsilon boundary',()=>{
 const f=createFlashController();assert(f.cast(args).accepted);f.step(15-1e-9);
 assert(f.status.remaining>9.9e-10);assert.equal(f.cast(args).reason,'cooldown');
 const before=f.status;for(const dt of [0,-1,NaN,Infinity,-Infinity,undefined])f.step(dt);assert.deepEqual(f.status,before);
 f.step(1e-9+1e-14);assert.equal(f.status.remaining,0);assert(f.cast(args).accepted);f.reset();assert.equal(f.status.casts,0);assert(f.status.ready);
 const boundary=createFlashController({cooldown:2e-12});boundary.cast(args);boundary.step(1e-12);assert.equal(boundary.status.remaining,1e-12);assert.equal(boundary.cast(args).reason,'cooldown');boundary.step(5e-13);assert.equal(boundary.status.remaining,0);
});
