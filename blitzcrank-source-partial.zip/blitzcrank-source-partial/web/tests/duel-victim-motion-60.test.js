import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const sourcePath=new URL('../main.js',import.meta.url);
function until(r,p){for(let i=0;i<600&&!p();i++)r.frames(1);assert(p());}
async function start(hz=60,third=false){let delta=1/hz;const r=await createGameplayHarness({sourcePath,delta:()=>delta});r.setDelta=v=>delta=v;r.element('duelmode').click();r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:Math.atan2(r.game.data.player.y-1.7,r.game.data.player.z-r.game.data.duelBot.position.z)})});until(r,()=>r.qa.duel.active);if(third)r.key('KeyV');return r;}
function matrixSnapshot(r){r.game.data.fullbody.updateWorldMatrix(true,true);return [...r.game.data.fullbodyMeshes].map(([name,m])=>[name,m.matrixWorld.toArray()]);}
function soleMin(r,side){const m=r.game.data.fullbodyMeshes.get('BC_FootSole.'+side);m.updateWorldMatrix(true,false);const b=m.geometry.boundingBox;let min=Infinity;for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z])min=Math.min(min,new THREE.Vector3(x,y,z).applyMatrix4(m.matrixWorld).y);return min;}
function geometry(r){for(const [,m]of matrixSnapshot(r))assert(m.every(Number.isFinite));for(const side of ['L','R'])assert(soleMin(r,side)>-.0001,'sole below floor');}
function groundedPose(r){assert.equal(r.qa.player.y,1.7);const j=r.qa.motion.locomotion.jump;assert.equal(j.active,false);assert.equal(j.airborne,false);assert.equal(j.weight,0);for(const side of ['L','R']){assert(Math.abs(soleMin(r,side))<1e-6);assert.deepEqual(r.game.data.fullbodyNodes.get('BC_Pivot_Hip.'+side).quaternion.toArray(),[0,0,0,1]);}geometry(r);}
function beginHit(r,skill,jumping,hz){const d=r.game.data;d.duelBot.position.set(0,1.7,4);if(skill==='Q'){assert(d.duel.cast('bot'));r.frames(Math.floor(.2*hz));if(jumping)r.key('Space');until(r,()=>!!d.duel.pendingGrab);}else{const s=d.duel.getSkills('bot');assert(s.castE());until(r,()=>s.status.phase==='E_Hold');if(jumping)r.key('Space');assert(s.strikeE());until(r,()=>!!r.qa.duel.humanKnockup);}return r.qa.player;}
for(const skill of ['Q','E'])for(const jumping of [false,true])for(const third of [false,true])for(const hz of [60])test(`${skill} ${jumping?'jumping':'grounded'} victim leg response and grounded recovery, ${third?'third':'first'} person ${hz}Hz`,async()=>{
 const r=await start(hz,third),d=r.game.data;const startPosition=beginHit(r,skill,jumping,hz);let airborneSeen=false;const previousHistory=d.duel.state.history.length;let previous=matrixSnapshot(r).filter(([n])=>/^BC_(Knee|Foot)\.[LR]$/.test(n));
 for(let i=0;i<Math.ceil(2*hz);i++){r.frames(1);geometry(r);const current=matrixSnapshot(r).filter(([n])=>/^BC_(Knee|Foot)\.[LR]$/.test(n));for(let j=0;j<current.length;j++)for(let k=0;k<16;k++)assert(Math.abs(current[j][1][k]-previous[j][1][k])<.8,'knee/ankle matrix discontinuity');previous=current;airborneSeen ||= r.qa.motion.locomotion.jump.airborne;if(skill==='E'){assert.equal(d.player.x,startPosition.x);assert.equal(d.player.z,startPosition.z);}assert(d.duel.state.history.length<=1);}
 if(skill==='E'||jumping)assert(airborneSeen,'forced airborne movement must drive leg response');groundedPose(r);assert.equal(d.duel.state.history.length,1);assert.equal(d.duel.state.history.at(-1).winnerId,'bot');
 if(skill==='Q'){assert.equal(d.player.x,0);assert.equal(d.player.z,6.3);assert(previousHistory===0);}
 const endpoint=d.player.toArray();r.frames(Math.floor(.3*hz));assert.deepEqual(d.player.toArray(),endpoint);groundedPose(r);
});
