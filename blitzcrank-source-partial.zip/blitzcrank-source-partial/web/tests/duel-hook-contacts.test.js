import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateHookFrame, COVER_TIE_FRACTION, MAX_COORDINATE } from '../duel-hook-contacts.js';

const point = (x = 0, y = 0, z = 0) => ({ x, y, z });
const clone = (v) => structuredClone(v);
const scope = () => ({ sessionId: 'duel-session', matchId: 'duel-session/match/1', matchNumber: 1, roundId: 'duel-session/match/1/round/1', roundNumber: 1, phaseNumber: 3 });
const box = (id, x, end = x + 1) => ({ obstacleId: id, min: point(x, -2, -2), max: point(end, 2, 2) });
const aabb = (r = 1) => ({ type: 'aabb', min: point(-r, -r, -r), max: point(r, r, r) });
function frame() {
  return {
    scope: scope(), frameId: 'simulation-frame-4', startMs: 100, durationMs: 1000,
    playerIds: ['alice', 'bob'],
    actors: [
      { playerId: 'alice', shape: { type: 'sphere', radius: 1 }, motion: { type: 'linear', from: point(), to: point() } },
      { playerId: 'bob', shape: { type: 'sphere', radius: 1 }, motion: { type: 'linear', from: point(5), to: point(5) } },
    ],
    obstacles: [],
    hook: { hookId: 'alice-hook-1', scope: scope(), attackerId: 'alice', phase: 'outbound', from: point(), to: point(10), travelled: 0, maxRange: 32 },
  };
}
const target = (f) => f.actors.find((a) => a.playerId !== f.hook.attackerId);
const close = (actual, expected, epsilon = 1e-11) => assert.ok(Math.abs(actual - expected) <= epsilon, `${actual} != ${expected}`);
const run = (edit = () => {}) => { const f = frame(); edit(f); const result = evaluateHookFrame(f); assert.equal(result.accepted, true); return result; };
const isDeepFrozen = (v) => !v || typeof v !== 'object' || (Object.isFrozen(v) && Object.values(v).every(isDeepFrozen));

test('point hook hits the supplied sphere, carries original scope and full-frame time', () => {
  const r = run();
  assert.equal(r.kind, 'opponent'); close(r.contact.fraction, .4); close(r.contact.timeMs, 500);
  close(r.contact.distance, 4); assert.deepEqual(r.contact.position, point(4));
  assert.deepEqual(r.source.scope, scope()); assert.equal(r.source.hookId, 'alice-hook-1');
  assert.equal(r.source.opponentId, 'bob'); assert.equal(r.contact.opponentAtSameTime, false);
});

test('local AABB offsets translate with the explicit anchor', () => {
  const r = run((f) => { target(f).shape = { type: 'aabb', min: point(0, -1, -1), max: point(2, 1, 1) }; });
  assert.equal(r.kind, 'opponent'); close(r.contact.fraction, .5);
});

test('attacker collider is never hit, including a huge collider enclosing the hook', () => {
  const r = run((f) => { f.actors[0].shape.radius = 100; target(f).motion.from = target(f).motion.to = point(30); });
  assert.equal(r.kind, 'none'); assert.equal(r.contact, null);
});

for (const shape of ['sphere', 'aabb']) {
  test(`${shape}: moving crossing hit is detected when neither endpoint overlaps`, () => {
    const r = run((f) => { target(f).shape = shape === 'sphere' ? { type: 'sphere', radius: .5 } : aabb(.5); target(f).motion.from = point(5, -5); target(f).motion.to = point(5, 5); });
    assert.equal(r.kind, 'opponent'); close(r.contact.fraction, shape === 'sphere' ? .5 - .5 / Math.sqrt(200) : .45);
  });
  test(`${shape}: crossing the same spatial point at different times is a miss`, () => {
    const r = run((f) => { target(f).shape = shape === 'sphere' ? { type: 'sphere', radius: .5 } : aabb(.5); target(f).motion.from = point(8, -10); target(f).motion.to = point(8, 10); });
    assert.equal(r.kind, 'none');
  });
  test(`${shape}: actor endpoint on old hook path is not a retrospective hit`, () => {
    const r = run((f) => { target(f).shape = shape === 'sphere' ? { type: 'sphere', radius: .2 } : aabb(.2); target(f).motion.from = point(2, 10); target(f).motion.to = point(2); });
    assert.equal(r.kind, 'none');
  });
  test(`${shape}: rising jump and falling actor motion are evaluated in 3D`, () => {
    for (const sign of [-1, 1]) {
      const r = run((f) => { target(f).shape = shape === 'sphere' ? { type: 'sphere', radius: .5 } : aabb(.5); target(f).motion.from = point(5, 3 * sign); target(f).motion.to = point(5, -3 * sign); });
      assert.equal(r.kind, 'opponent'); assert.ok(r.contact.fraction > .4 && r.contact.fraction < .5);
    }
  });
  test(`${shape}: starting inside produces time zero`, () => {
    const r = run((f) => { target(f).shape = shape === 'sphere' ? { type: 'sphere', radius: 1 } : aabb(); target(f).motion.from = point(); target(f).motion.to = point(50); });
    assert.equal(r.kind, 'opponent'); assert.equal(r.contact.fraction, 0);
  });
  test(`${shape}: closed endpoint contact counts`, () => {
    const r = run((f) => { target(f).shape = shape === 'sphere' ? { type: 'sphere', radius: 1 } : aabb(); f.hook.to = point(4); });
    assert.equal(r.kind, 'opponent'); close(r.contact.fraction, 1);
  });
  test(`${shape}: equal hook and target velocity has no relative crossing`, () => {
    const r = run((f) => { target(f).shape = shape === 'sphere' ? { type: 'sphere', radius: 1 } : aabb(); target(f).motion.to = point(15); });
    assert.equal(r.kind, 'none');
  });
  test(`${shape}: zero hook travel still detects opponent crossing a stationary point`, () => {
    const r = run((f) => { f.hook.to = point(); target(f).shape = shape === 'sphere' ? { type: 'sphere', radius: 1 } : aabb(); target(f).motion.from = point(-5); target(f).motion.to = point(5); });
    assert.equal(r.kind, 'opponent'); close(r.contact.fraction, .4); assert.equal(r.contact.distance, 0);
  });
}

test('sphere tangency is a closed contact; clear near tangent miss stays a miss', () => {
  const tangent = run((f) => { target(f).motion.from = target(f).motion.to = point(5, 1); });
  assert.equal(tangent.kind, 'opponent'); close(tangent.contact.fraction, .5);
  assert.equal(run((f) => { target(f).motion.from = target(f).motion.to = point(5, 1.00000001); }).kind, 'none');
});

test('long sweep small-radius off-axis sphere regression does not invent a collision', () => {
  const r = run((f) => { f.hook.from = point(-5e8); f.hook.to = point(5e8); f.hook.maxRange = 1e9; target(f).shape.radius = .1; target(f).motion.from = target(f).motion.to = point(0, 1); });
  assert.equal(r.kind, 'none');
});

test('long sweep retains a real tiny sphere hit and a tangent', () => {
  for (const y of [0, .1]) {
    const r = run((f) => { f.hook.from = point(-5e8); f.hook.to = point(5e8); f.hook.maxRange = 1e9; target(f).shape.radius = .1; target(f).motion.from = target(f).motion.to = point(0, y); });
    assert.equal(r.kind, 'opponent'); close(r.contact.fraction, y === 0 ? .5 - 1e-10 : .5);
  }
});

test('arena-scale almost tangent does not lose the perpendicular gap', () => {
  for (const radius of [.0001, .1, .68]) {
    const r = run((f) => { f.hook.from = point(-16); f.hook.to = point(16); target(f).shape.radius = radius; target(f).motion.from = target(f).motion.to = point(0, radius + 1e-10); });
    assert.equal(r.kind, 'none');
  }
});

test('zero radius and zero-size AABB are explicit point colliders', () => {
  for (const shape of [{ type: 'sphere', radius: 0 }, aabb(0)]) {
    const r = run((f) => { target(f).shape = shape; });
    assert.equal(r.kind, 'opponent'); close(r.contact.fraction, .5);
  }
});

test('subnormal finite coordinates do not cause reciprocal overflow', () => {
  const r = run((f) => { f.hook.from = point(); f.hook.to = point(5e-323); target(f).motion.from = target(f).motion.to = point(2e-323); target(f).shape.radius = 0; });
  assert.equal(r.kind, 'opponent'); assert.ok(Number.isFinite(r.contact.fraction));
});

test('wall before opponent blocks and wall after opponent does not', () => {
  assert.equal(run((f) => { f.obstacles = [box('wall', 2)]; }).kind, 'blocked');
  const r = run((f) => { f.obstacles = [box('wall', 6)]; }); assert.equal(r.kind, 'opponent');
});

test('exact cover/opponent tie blocks for both collider types', () => {
  for (const shape of [{ type: 'sphere', radius: 1 }, aabb()]) {
    const r = run((f) => { target(f).shape = shape; f.obstacles = [box('wall', 4)]; });
    assert.equal(r.kind, 'blocked'); assert.equal(r.contact.opponentAtSameTime, true); close(r.contact.fraction, .4);
  }
});

test('cover numerical tie is conservative; an appreciably later wall cannot block', () => {
  const r = run((f) => { target(f).shape = aabb(); f.obstacles = [box('wall', 4 + 10 * COVER_TIE_FRACTION / 2)]; });
  assert.equal(r.kind, 'blocked'); assert.equal(r.contact.opponentAtSameTime, true);
  assert.equal(run((f) => { f.obstacles = [box('wall', 4.000001)]; }).kind, 'opponent');
});

test('all equally early blockers are retained by ID, including start-inside cover', () => {
  const r = run((f) => { f.obstacles = [box('z', -1, 1), box('a', -2, 1)]; target(f).motion.from = point(); });
  assert.equal(r.kind, 'blocked'); assert.equal(r.contact.fraction, 0); assert.deepEqual(r.contact.blockerIds, ['a', 'z']);
});

test('moving parallel to a box face, touching a corner, and negative directions', () => {
  const face = run((f) => { f.hook.from.y = f.hook.to.y = 1; target(f).shape = aabb(); });
  assert.equal(face.kind, 'opponent'); close(face.contact.fraction, .4);
  const corner = run((f) => { f.hook.from = point(0, -5, -5); f.hook.to = point(10, 5, 5); target(f).shape = aabb(); });
  assert.equal(corner.kind, 'opponent'); close(corner.contact.fraction, .4);
  const outsideCorner = run((f) => { f.hook.from = point(10, 6, 6); f.hook.to = point(); target(f).shape = aabb(); });
  assert.equal(outsideCorner.kind, 'none');
  const reverse = run((f) => { f.hook.from = point(10); f.hook.to = point(); target(f).shape = aabb(); });
  assert.equal(reverse.kind, 'opponent'); close(reverse.contact.fraction, .4);
});

test('range clipping retains original time fraction and endpoint', () => {
  const r = run((f) => { f.hook.travelled = 28; });
  assert.equal(r.kind, 'opponent'); close(r.sweep.throughFraction, .4); close(r.contact.fraction, .4);
  assert.deepEqual(r.sweep.endPosition, point(4)); assert.equal(r.sweep.rangeReached, true); close(r.contact.totalTravelled, 32);
});

test('range clipping does not compress late opponent movement into an early hit', () => {
  const r = run((f) => { f.hook.to = point(20); f.hook.travelled = 27; target(f).shape.radius = .5; target(f).motion.from = point(5, 10); target(f).motion.to = point(5); });
  assert.equal(r.kind, 'none'); close(r.sweep.throughFraction, .25);
});

test('neither opponent nor cover beyond exhausted range can be contacted', () => {
  const r = run((f) => { f.hook.maxRange = 3; f.obstacles = [box('wall', 3.00001)]; });
  assert.equal(r.kind, 'none'); close(r.sweep.throughFraction, .3);
});

test('a moving opponent can be contacted before clipping, at its actual early pose', () => {
  const r = run((f) => { f.hook.maxRange = 3; target(f).shape = aabb(.25); target(f).motion.from = point(2, -2); target(f).motion.to = point(2, 8); });
  assert.equal(r.kind, 'opponent'); close(r.contact.fraction, .175); close(r.contact.timeMs, 275);
});

test('a previously exhausted hook cannot acquire a new starts-inside hit', () => {
  const r = run((f) => { f.hook.travelled = f.hook.maxRange; target(f).motion.from = point(); f.obstacles = [box('wall', -1, 1)]; });
  assert.equal(r.kind, 'none'); assert.equal(r.reason, 'range_exhausted'); assert.equal(r.sweep.throughFraction, 0);
});

test('zero-duration stationary sample checks only initial overlap', () => {
  const noHit = run((f) => { f.durationMs = 0; f.hook.to = point(); });
  assert.equal(noHit.kind, 'none'); assert.equal(noHit.sweep.throughFraction, 0);
  const hit = run((f) => { f.durationMs = 0; f.hook.to = point(); target(f).motion.from = target(f).motion.to = point(); });
  assert.equal(hit.kind, 'opponent'); assert.equal(hit.contact.fraction, 0);
});

test('teleport spanning samples are rejected, never swept', () => {
  const f = frame(); target(f).motion.type = 'teleport'; target(f).motion.from = point(5, -5); target(f).motion.to = point(5, 5);
  const r = evaluateHookFrame(f); assert.equal(r.accepted, false); assert.equal(r.reason, 'discontinuous_motion'); assert.equal(r.contact, null);
});

test('split teleport departure and destination samples do not hit along teleport path', () => {
  for (const y of [-5, 5]) {
    const r = run((f) => { f.durationMs = 0; f.hook.from = f.hook.to = point(5); target(f).motion.from = target(f).motion.to = point(5, y); });
    assert.equal(r.kind, 'none');
  }
});

test('permuting actors, stable players, and obstacle arrays cannot choose a result', () => {
  const f = frame(); target(f).shape = aabb();
  f.obstacles = [box('z', 4), box('a', 4), box('near-tie', 4 + COVER_TIE_FRACTION * 4), box('later', 7)];
  const reference = evaluateHookFrame(f);
  for (const order of [[0, 1, 2, 3], [3, 2, 1, 0], [2, 0, 3, 1], [1, 3, 2, 0]]) {
    const copy = clone(f); copy.actors.reverse(); copy.playerIds.reverse(); copy.obstacles = order.map((i) => copy.obstacles[i]);
    assert.deepEqual(evaluateHookFrame(copy), reference);
  }
});

test('result is detached, deeply frozen, JSON serializable, and repeatable', () => {
  const f = frame(); const before = clone(f); const result = evaluateHookFrame(f);
  assert.deepEqual(f, before); assert.equal(Object.isFrozen(f), false); assert.equal(isDeepFrozen(result), true);
  assert.notEqual(result.source.scope, f.hook.scope); assert.notEqual(result.contact.position, f.hook.from);
  assert.deepEqual(result, JSON.parse(JSON.stringify(result))); assert.deepEqual(result, evaluateHookFrame(clone(f)));
  f.scope.sessionId = 'changed'; f.hook.from.x = 100; target(f).motion.from.x = 50;
  assert.equal(result.source.scope.sessionId, 'duel-session'); assert.equal(result.contact.position.x, 4);
  assert.throws(() => { result.source.scope.phaseNumber += 1; }, TypeError);
});

test('two opposing hook contacts are independent data, without automatic winner/score', () => {
  const f = frame(); f.actors[1].motion.from = f.actors[1].motion.to = point(10);
  const first = evaluateHookFrame(f); const other = clone(f);
  other.hook = { ...other.hook, attackerId: 'bob', hookId: 'bob-hook-1', from: point(10), to: point() };
  const second = evaluateHookFrame(other);
  assert.equal(first.kind, 'opponent'); assert.equal(second.kind, 'opponent'); close(first.contact.fraction, second.contact.fraction);
  assert.equal('winnerId' in first, false); assert.equal('validated' in first, false); assert.equal('score' in first, false);
});

for (const [name, edit, reason] of [
  ['unknown frame flag', (f) => { f.validated = true; }, 'invalid_frame'],
  ['client hook flag', (f) => { f.hook.validated = true; }, 'invalid_hook'],
  ['non-point hook radius', (f) => { f.hook.radius = .5; }, 'invalid_hook'],
  ['NaN point', (f) => { f.hook.from.x = NaN; }, 'invalid_hook_motion'],
  ['Infinity radius', (f) => { target(f).shape.radius = Infinity; }, 'invalid_actor'],
  ['negative radius', (f) => { target(f).shape.radius = -1; }, 'invalid_actor'],
  ['unknown collider', (f) => { target(f).shape.type = 'capsule'; }, 'invalid_actor'],
  ['inverted AABB', (f) => { target(f).shape = aabb(-1); }, 'invalid_actor'],
  ['oversize coordinate', (f) => { f.hook.to.x = MAX_COORDINATE + 1; }, 'invalid_hook_motion'],
  ['negative duration', (f) => { f.durationMs = -1; }, 'invalid_time'],
  ['time overflow', (f) => { f.startMs = Number.MAX_SAFE_INTEGER; }, 'invalid_time'],
  ['zero-time hook motion', (f) => { f.durationMs = 0; }, 'motion_in_zero_time'],
  ['zero-time actor motion', (f) => { f.durationMs = 0; f.hook.to = point(); target(f).motion.to = point(6); }, 'motion_in_zero_time'],
  ['duplicate players', (f) => { f.playerIds[1] = f.playerIds[0]; }, 'invalid_players'],
  ['third actor', (f) => { f.actors.push(clone(f.actors[0])); }, 'invalid_actors'],
  ['duplicate actor identity', (f) => { f.actors[1].playerId = f.actors[0].playerId; }, 'invalid_actor'],
  ['unknown attacker', (f) => { f.hook.attackerId = 'third'; }, 'invalid_hook_identity'],
  ['unknown target', (f) => { f.actors[1].playerId = 'third'; }, 'invalid_actor'],
  ['return phase', (f) => { f.hook.phase = 'return'; }, 'not_outbound'],
  ['windup phase', (f) => { f.hook.phase = 'windup'; }, 'not_outbound'],
  ['missing phase', (f) => { delete f.hook.phase; }, 'invalid_hook'],
  ['range below zero', (f) => { f.hook.maxRange = -1; }, 'invalid_range'],
  ['past range', (f) => { f.hook.travelled = 33; }, 'invalid_range'],
  ['stale phase', (f) => { f.hook.scope.phaseNumber -= 1; }, 'stale_hook_scope'],
  ['stale round', (f) => { f.hook.scope.roundNumber = 2; f.hook.scope.roundId = 'duel-session/match/1/round/2'; }, 'stale_hook_scope'],
  ['invalid scope derivation', (f) => { f.scope.matchId = 'another'; }, 'invalid_scope'],
  ['duplicate obstacle ID', (f) => { f.obstacles = [box('wall', 2), box('wall', 3)]; }, 'invalid_obstacle'],
  ['moving cover claim', (f) => { f.obstacles = [{ ...box('wall', 2), motion: {} }]; }, 'invalid_obstacle'],
  ['unknown motion mode', (f) => { target(f).motion.type = 'cubic'; }, 'invalid_actor_motion'],
  ['empty hook ID', (f) => { f.hook.hookId = ''; }, 'invalid_hook_identity'],
]) {
  test(`invalid input rejected: ${name}`, () => {
    const f = frame(); edit(f); const before = clone(f); const result = evaluateHookFrame(f);
    assert.equal(result.accepted, false); assert.equal(result.reason, reason); assert.equal(result.contact, null);
    assert.equal(result.source, null); assert.equal(isDeepFrozen(result), true); assert.deepEqual(f, before);
  });
}

test('non-record and incomplete data are rejected without ordinary-data exceptions', () => {
  for (const value of [null, undefined, true, 1, 'frame', [], {}, { scope: null }]) assert.equal(evaluateHookFrame(value).accepted, false);
});

// Independent numerical oracle: directly minimize convex squared distance over
// time, then bisect the first overlap. No slab/quadratic solver is reused.
function numericOracle(f) {
  const t = target(f); const h = f.hook;
  const distance = Math.hypot(h.to.x - h.from.x, h.to.y - h.from.y, h.to.z - h.from.z);
  const remaining = h.maxRange - h.travelled;
  const limit = distance === 0 ? 1 : Math.min(1, remaining / distance);
  const value = (u) => {
    let squared = 0;
    for (const axis of ['x', 'y', 'z']) {
      const p = h.from[axis] + u * (h.to[axis] - h.from[axis]) - t.motion.from[axis] - u * (t.motion.to[axis] - t.motion.from[axis]);
      const d = t.shape.type === 'sphere' ? p : p < t.shape.min[axis] ? t.shape.min[axis] - p : p > t.shape.max[axis] ? p - t.shape.max[axis] : 0;
      squared += d * d;
    }
    return squared - (t.shape.type === 'sphere' ? t.shape.radius ** 2 : 0);
  };
  if (value(0) <= 0) return 0;
  let lo = 0, hi = limit, witness = null;
  for (let i = 0; i < 120; i += 1) {
    const a = lo + (hi - lo) / 3, b = hi - (hi - lo) / 3;
    const va = value(a), vb = value(b);
    if (va <= 0) witness = a;
    else if (vb <= 0) witness = b;
    if (va <= vb) hi = b; else lo = a;
  }
  const minimum = (lo + hi) / 2;
  // Closed endpoint can be the only overlap at the clipped boundary.
  if (witness === null && value(minimum) > 0 && value(limit) > 0) return null;
  lo = 0; hi = witness !== null ? witness : value(minimum) <= 0 ? minimum : limit;
  for (let i = 0; i < 90; i += 1) { const mid = (lo + hi) / 2; if (value(mid) <= 0) hi = mid; else lo = mid; }
  return hi;
}

function randomFactory(seed) {
  return () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
}

test('4,000 seeded moving sphere/AABB scenes match an independent numerical oracle', () => {
  const random = randomFactory(0x51a7c0de); const number = (size) => (random() * 2 - 1) * size;
  const position = () => point(number(8), number(8), number(8));
  let hits = 0; let misses = 0;
  for (let i = 0; i < 4000; i += 1) {
    const f = frame(); f.hook.from = position(); f.hook.to = position(); f.hook.maxRange = 2 + random() * 25;
    target(f).motion.from = position(); target(f).motion.to = position();
    target(f).shape = i % 2 ? aabb(.5 + random() * 3) : { type: 'sphere', radius: .5 + random() * 3 };
    const expected = numericOracle(f); const actual = evaluateHookFrame(f);
    assert.equal(actual.accepted, true);
    if (expected === null) { misses += 1; assert.equal(actual.kind, 'none', `scene ${i}`); }
    else { hits += 1; assert.equal(actual.kind, 'opponent', `scene ${i}`); close(actual.contact.fraction, expected, 1e-9); }
  }
  assert.ok(hits > 200 && misses > 200, `${hits} hits, ${misses} misses`);
});

test('500 seeded frame subdivisions preserve continuous contact time and range cutoff', () => {
  const random = randomFactory(0xa123); const lerp = (a, b, u) => point(a.x + (b.x - a.x) * u, a.y + (b.y - a.y) * u, a.z + (b.z - a.z) * u);
  for (let i = 0; i < 500; i += 1) {
    const f = frame(); target(f).motion.from = point(5, random() * 6 - 3); target(f).motion.to = point(5, random() * 6 - 3);
    if (i % 2) target(f).shape = aabb(.7);
    f.hook.maxRange = 1 + random() * 15;
    const full = evaluateHookFrame(f); const split = .1 + .8 * random(); const first = clone(f);
    first.durationMs *= split; first.hook.to = lerp(f.hook.from, f.hook.to, split);
    for (let j = 0; j < 2; j += 1) first.actors[j].motion.to = lerp(f.actors[j].motion.from, f.actors[j].motion.to, split);
    const firstResult = evaluateHookFrame(first);
    if (firstResult.contact) { assert.equal(full.kind, firstResult.kind); close(full.contact.timeMs, firstResult.contact.timeMs, 1e-9); continue; }
    if (firstResult.sweep.rangeReached) { assert.equal(full.kind, 'none'); continue; }
    const second = clone(f); second.startMs += f.durationMs * split; second.durationMs *= 1 - split;
    second.hook.from = first.hook.to; second.hook.travelled = firstResult.sweep.distance;
    for (let j = 0; j < 2; j += 1) second.actors[j].motion.from = first.actors[j].motion.to;
    const secondResult = evaluateHookFrame(second); assert.equal(secondResult.kind, full.kind);
    if (secondResult.contact) close(full.contact.timeMs, secondResult.contact.timeMs, 1e-9);
  }
});
