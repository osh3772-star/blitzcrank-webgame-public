import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const sourcePath=new URL('../main.js',import.meta.url);
function until(r,p){for(let i=0;i<600&&!p();i++)r.frames(1);assert(p());}
async function start(hz=60,third=false){let delta=1/hz;const r=await createGameplayHarness({sourcePath,delta:()=>delta});r.setDelta=v=>delta=v;r.element('duelmode').click();r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:Math.atan2(r.game.data.player.y-1.7,r.game.data.player.z-r.game.data.duelBot.position.z)})});until(r,()=>r.qa.duel.active);if(third)r.key('KeyV');return r;}
function matrixSnapshot(r){r.game.data.fullbody.updateWorldMatrix(true,true);return [...r.game.data.fullbodyMeshes].map(([name,m])=>[name,m.matrixWorld.toArray()]);}
function soleMin(r,side){const m=r.game.data.fullbodyMeshes.get('BC_FootSole.'+side);m.updateWorldMatrix(true,false);const b=m.geometry.boundingBox;let min=Infinity;for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z])min=Math.min(min,new THREE.Vector3(x,y,z).applyMatrix4(m.matrixWorld).y);return min;}
function geometry(r){for(const [,m]of matrixSnapshot(r))assert(m.every(Number.isFinite));for(const side of ['L','R'])assert(soleMin(r,side)>-.0001,'sole below floor');}
function groundedPose(r){assert.equal(r.qa.player.y,1.7);const j=r.qa.motion.locomotion.jump;assert.equal(j.active,false);assert.equal(j.airborne,false);assert.equal(j.weight,0);for(const side of ['L','R']){assert(Math.abs(soleMin(r,side))<1e-6);assert.deepEqual(r.game.data.fullbodyNodes.get('BC_Pivot_Hip.'+side).quaternion.toArray(),[0,0,0,1]);}geometry(r);}
function beginHit(r,skill,jumping,hz){const d=r.game.data;d.duelBot.position.set(0,1.7,4);if(skill==='Q'){assert(d.duel.cast('bot'));r.frames(Math.floor(.2*hz));if(jumping)r.key('Space');until(r,()=>!!d.duel.pendingGrab);}else{const s=d.duel.getSkills('bot');assert(s.castE());until(r,()=>s.status.phase==='E_Hold');if(jumping)r.key('Space');assert(s.strikeE());until(r,()=>!!r.qa.duel.humanKnockup);}return r.qa.player;}
for(const skill of ['Q','E'])test(`${skill} forced victim pose freezes on pause/zero dt and resumes without duplicate motion`,async()=>{
 const r=await start(),d=r.game.data;beginHit(r,skill,true,60);r.frames(3);const frozen={position:r.qa.player,motion:r.qa.motion,matrices:matrixSnapshot(r)};r.game.pause();r.frames(90);assert.deepEqual(r.qa.player,frozen.position);assert.deepEqual(r.qa.motion,frozen.motion);assert.deepEqual(matrixSnapshot(r),frozen.matrices);r.game.resume();r.setDelta(0);r.frames(10);assert.deepEqual(r.qa.player,frozen.position);assert.deepEqual(r.qa.motion,frozen.motion);assert.deepEqual(matrixSnapshot(r),frozen.matrices);r.setDelta(1/60);r.frames(130);groundedPose(r);assert.equal(d.duel.state.history.length,1);
});
for(const skill of ['Q','E'])test(`${skill} third bot win completes victim landing before results and rematch clears pose`,async()=>{
 const r=await start(),d=r.game.data;for(let n=0;n<2;n++){d.duelBot.position.set(0,1.7,4);assert(d.duel.getSkills('bot').castR());until(r,()=>d.duel.state.history.length===n+1);until(r,()=>d.duel.active);}
 beginHit(r,skill,true,60);until(r,()=>d.duel.state.phase==='matchComplete');r.frames(120);assert.equal(r.qa.state,'running');groundedPose(r);until(r,()=>r.qa.state==='results');r.key('KeyR');groundedPose(r);assert.equal(r.qa.duel.match.history.length,0);
});

for(const skill of ['Q','E'])test(`${skill} first impact never double advances the live jump pose`,async()=>{
 const r=await start(),d=r.game.data;d.duelBot.position.set(0,1.7,4);
 if(skill==='Q'){assert(d.duel.cast('bot'));r.frames(12);}else{assert(d.duel.getSkills('bot').castE());until(r,()=>d.duel.getSkills('bot').status.phase==='E_Hold');assert(d.duel.getSkills('bot').strikeE());}
 r.key('Space');let frames=0;
 while(d.duel.active){const before=r.qa.motion.locomotion.jump.airTime;r.frames(1);assert(r.qa.motion.locomotion.jump.airTime-before<=1/60+1e-12);assert(++frames<120);}
 assert(Math.abs(r.qa.motion.locomotion.jump.airTime-frames/60)<1e-10);geometry(r);
});

for(const skill of ['Q','E'])test(`${skill} incoming hit retains human E charge while lower legs land`,async()=>{
 const r=await start(60,true),d=r.game.data;assert(d.duel.getSkills('human').castE());until(r,()=>r.qa.skills.phase==='E_Hold');beginHit(r,skill,true,60);
 for(let i=0;i<120;i++){r.frames(1);geometry(r);assert.equal(r.qa.skills.phase,'E_Hold');
  for(const side of ['L','R']){const sign=side==='L'?1:-1;for(const [a,b,p]of [['BC_Thigh.'+side,'BC_Knee.'+side,[sign*.3872,.5416,-.014303]],['BC_Shin.'+side,'BC_Foot.'+side,[sign*.4576,.146944,-.044303]]]){const x=new THREE.Vector3(...p).sub(new THREE.Vector3(...d.fullbodyMeshes.get(a).userData.skillRestPoint)).applyMatrix4(d.fullbodyMeshes.get(a).matrixWorld),y=new THREE.Vector3(...p).sub(new THREE.Vector3(...d.fullbodyMeshes.get(b).userData.skillRestPoint)).applyMatrix4(d.fullbodyMeshes.get(b).matrixWorld);assert(x.distanceTo(y)<.015,'E lower-body joint seam');}}
 }
 assert.equal(r.qa.motion.locomotion.jump.active,false);assert.equal(r.qa.motion.locomotion.jump.airborne,false);assert.equal(d.player.y,1.7);for(const side of ['L','R'])assert(Math.abs(soleMin(r,side))<1e-5);
 assert.equal(d.duel.state.history.length,1);
});
