import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {createOnlineDuelWorld,ONLINE_INPUT_STALE_TICKS} from '../online-duel-world.js';
import {createOnlineSession,validSnapshot} from '../online-duel-session.js';
import {makeInput,ONLINE_ACTIONS as A,ONLINE_PROTOCOL} from '../online-duel-protocol.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';
const skillClips=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))).models.fullbody.clips,session='input_order_fixture_01234567';
const wire=x=>JSON.parse(JSON.stringify(x));
function fixture(){
 const world=createOnlineDuelWorld({session,skillClips,countdownMs:0,obstacles:[]}),toHost=[],toGuest=[],states=[],statuses=[];let host,guest;
 host=createOnlineSession({role:'host',session,world,send:x=>(toGuest.push(wire(x)),true)});
 guest=createOnlineSession({role:'guest',session,send:x=>(toHost.push(wire(x)),true),onState:x=>states.push(x),onStatus:x=>statuses.push(x)});
 const drain=()=>{let n=0;while(toHost.length||toGuest.length){assert(n++<100);while(toHost.length)host.receive(toHost.shift());while(toGuest.length)guest.receive(toGuest.shift());}};
 const step=()=>{host.step();drain();assert(validSnapshot(guest.snapshot,session));};
 const ready=id=>{const result=id==='human'?host.ready(true):host.receive({type:'ready',protocol:ONLINE_PROTOCOL,session,epoch:world.scope.epoch,ready:true});drain();return result;};
 const input=(id,seq,values={})=>makeInput({...world.scope,seq,yaw:id==='human'?0:Math.PI,...values});
 const deliver=(id,c)=>id==='human'?host.input(c):host.receive(c);
 ready('human');guest.ready(true);drain();return{world,host,guest,drain,step,ready,input,deliver,toHost,toGuest,states,statuses};
}
for(const id of ['human','bot'])for(const actions of [A.Q,A.W|A.Q,A.E|A.JUMP])test(`${id} duplicate ready preserves queued movement and action mask ${actions}`,()=>{
 const normal=fixture(),repeat=fixture();for(const f of [normal,repeat])for(const p of ['human','bot'])assert(f.deliver(p,f.input(p,0,{actions,z:-1})));
 assert(repeat.ready(id));assert(repeat.ready(id));
 for(let i=0;i<75;i++){normal.step();repeat.step();assert.deepEqual(repeat.world.snapshot(),normal.world.snapshot(),'authority frame '+i);assert.deepEqual(repeat.guest.snapshot,normal.guest.snapshot,'guest frame '+i);}
 assert.deepEqual(repeat.statuses,[]);
});
for(const id of ['human','bot'])test(`${id} repeated ready neither extends held-input age nor erases held movement`,()=>{
 const a=fixture(),b=fixture();for(const f of [a,b])assert(f.deliver(id,f.input(id,0,{x:1})));
 for(let i=0;i<ONLINE_INPUT_STALE_TICKS+10;i++){if(i%2===0)b.ready(id);a.step();b.step();assert.deepEqual(b.world.snapshot(),a.world.snapshot(),'stale bound '+i);}
 const before=b.world.snapshot().actors[id].position;b.ready(id);b.step();assert.deepEqual(b.world.snapshot().actors[id].position,before);
});
test('queued simultaneous Q survives duplicate readiness and ties without a spurious point',()=>{
 const f=fixture();for(const id of ['bot','human'])assert(f.deliver(id,f.input(id,0,{actions:A.Q})));f.ready('bot');f.ready('human');
 let tied=false;for(let i=0;i<80;i++){f.step();if(f.world.snapshot().tieRemaining>0){tied=true;break;}}
 assert(tied);assert.deepEqual(f.world.snapshot().match.scores.map(x=>x.points),[0,0]);const old=f.input('bot',100,{actions:A.R});let reset=false;
 for(let i=0;i<250;i++){f.step();if(f.world.scope.epoch!==old.epoch){reset=true;break;}}assert(reset);assert(!f.deliver('bot',old));assert.deepEqual(f.world.snapshot().match.scores.map(x=>x.points),[0,0]);assert.deepEqual(f.statuses,[]);
});
test('pause is still destructive and needs fresh readiness; old-epoch duplicated/reordered actions cannot revive it',()=>{
 const f=fixture(),old=f.input('bot',99,{actions:A.Q|A.W,z:-1});assert(f.deliver('bot',old));f.host.ready(false);f.drain();assert(!f.deliver('bot',old));assert(!f.host.receive({type:'ready',protocol:ONLINE_PROTOCOL,session,epoch:old.epoch,ready:true}));
 assert(f.ready('human'));f.step();assert(f.world.snapshot().paused);assert(f.ready('bot'));f.step();assert(!f.world.snapshot().paused);assert.equal(f.world.snapshot().actors.bot.hook,null);assert.equal(f.world.snapshot().actors.bot.skills.boost,0);assert.equal(f.world.snapshot().actors.bot.position.z,-12);
});
test('newer held directions win while accepted edge requests survive batching; duplicates and reversed old seq are rejected',()=>{
 const f=fixture();for(const id of ['human','bot']){const a=f.input(id,4,{z:-1,actions:A.Q|A.W}),b=f.input(id,6,{x:1}),late=f.input(id,5,{x:-1,actions:A.R});assert(f.deliver(id,a));assert(f.deliver(id,b));assert(!f.deliver(id,a));assert(!f.deliver(id,late));assert(!f.deliver(id,b));}f.step();
 for(const id of ['human','bot']){const a=f.world.snapshot().actors[id];assert.equal(a.hook.phase,'windup');assert(a.skills.boost>0);assert.equal(a.skills.cooldown.R,0);assert(Math.abs(a.position.x)>0);assert.equal(a.position.z,id==='human'?7:-12);}assert.deepEqual(f.statuses,[]);
});
test('ready false still discards input, and disconnect cannot be undone by repeated readiness or old packets',()=>{
 const f=fixture();assert(f.deliver('human',f.input('human',0,{actions:A.Q,z:-1})));assert(f.world.setReady('human',false));assert(f.world.setReady('human',false));assert(f.ready('human'));f.step();assert.equal(f.world.snapshot().actors.human.hook,null);const old=f.input('bot',1,{actions:A.R});f.host.disconnect();f.guest.disconnect();const before=f.world.snapshot();assert(!f.ready('human'));assert(!f.deliver('bot',old));f.step();assert.deepEqual(f.world.snapshot(),before);
});
for(const pattern of ['ordered-delay','asymmetric-delay','duplicates','reverse-burst'])test(pattern+' simulated two-player delivery retains exact authority state with repeated readiness',()=>{
 const make=()=>{const w=createOnlineDuelWorld({session,skillClips,countdownMs:0,obstacles:[]});w.setReady('human',true);w.setReady('bot',true);return w;},a=make(),b=make(),queue=[];let accepted=0,rejected=0,tieFrames=0,scoreFrames=0;
 for(let frame=0;frame<900;frame++){
  for(const [player,id] of ['human','bot'].entries()){
   const phase=frame%300,actions=phase===10?A.W:phase===60?A.Q:phase===150?A.E:phase===180?A.R:phase===200?A.PUNCH:0;
   const c=makeInput({...a.scope,seq:frame,yaw:player?Math.PI:0,z:phase<25?-1:0,actions});
   const delay=pattern==='ordered-delay'?3:pattern==='asymmetric-delay'?player*5:pattern==='reverse-burst'?(3-frame%4):0;
   queue.push({at:frame+delay,id,c});if(pattern==='duplicates')for(const offset of [1,4])queue.push({at:frame+offset,id,c});
  }
  const due=queue.filter(x=>x.at===frame);if(pattern==='reverse-burst')due.reverse();
  for(const {id,c} of due){const expected=a.submit(id,c),actual=b.submit(id,c);assert.equal(actual,expected);expected?accepted++:rejected++;b.setReady(id,true);b.setReady(id,true);}
  for(let i=queue.length-1;i>=0;i--)if(queue[i].at<=frame)queue.splice(i,1);
  assert.equal(b.step(),a.step());assert.deepEqual(b.snapshot(),a.snapshot(),'full state '+frame);const s=a.snapshot();tieFrames+=s.tieRemaining>0;scoreFrames+=s.match.history.length>0;assert(validSnapshot(wire(s),session));a.drainEvents();b.drainEvents();
 }
 assert(accepted>100);if(pattern==='duplicates'||pattern==='reverse-burst')assert(rejected>100);if(pattern==='ordered-delay')assert(tieFrames>0,'equal arrival Q must tie');if(pattern==='asymmetric-delay')assert(scoreFrames>0,'unequal arrival Q must resolve rather than freeze');
});
