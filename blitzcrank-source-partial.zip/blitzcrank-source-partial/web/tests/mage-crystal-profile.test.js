import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';
import {GLTFLoader} from '../vendor/GLTFLoader.js';
import {TARGET_MODEL_FILES,attachCharacterTarget,loadCharacterTargets} from '../target-models.js';
const oldHash='adda0e7dff7aac779b6af9e63bf8a32f5c78d894a9f8e0eb1f82e3ff17c5de94',newHash='768d796854b89a2f608e23c892d2a90cc80c7186aedf64a3c910c1d83076c6f5';
const read=p=>fs.readFileSync(new URL(p,import.meta.url));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const bytes=[oldHash,newHash].map(h=>read('../assets/targets/mage.'+h.slice(0,16)+'.glb'));
const docs=bytes.map(b=>JSON.parse(b.subarray(20,20+b.readUInt32LE(12))));
const scenes=await Promise.all(bytes.map(b=>new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'')));
const geometry=g=>{const out={};g.scene.traverse(n=>{if(n.isMesh){assert(!(n.material.name in out));out[n.material.name]=n.geometry;}});return out;};
const [a,b]=scenes.map(geometry);
const selected=new Map(Object.entries(a).filter(([n])=>n.startsWith('Crystal ')).map(([n,g])=>[n,new Set(Array.from({length:g.attributes.position.count},(_,i)=>i))]));
const vec=(a,i)=>[a.getX(i),a.getY(i),a.getZ(i)];
function bounds(s){s.updateMatrixWorld(true);const box=new THREE.Box3().setFromObject(s);return [box.min.toArray(),box.max.toArray()];}
function triangleKeys(g){const p=g.attributes.position,idx=g.index.array;return Array.from({length:idx.length/3},(_,k)=>[0,1,2].map(j=>JSON.stringify(vec(p,idx[k*3+j]))));}
function topology(g,indices){const p=g.attributes.position,ix=g.index.array,edges=new Map();let triangles=0,volume=0;for(let t=0;t<ix.length;t+=3){const ii=Array.from(ix.slice(t,t+3));if(!ii.some(i=>indices.has(i)))continue;assert(ii.every(i=>indices.has(i)),'selected component must include every incident face');triangles++;const q=ii.map(i=>new THREE.Vector3().fromArray(vec(p,i)));volume+=q[0].dot(q[1].clone().cross(q[2]))/6;assert(q[1].clone().sub(q[0]).cross(q[2].clone().sub(q[0])).length()>1e-10);const keys=ii.map(i=>JSON.stringify(vec(p,i)));for(let j=0;j<3;j++){const u=keys[j],v=keys[(j+1)%3],key=[u,v].sort().join('|');const e=edges.get(key)||{count:0,balance:0};e.count++;e.balance+=u<v?1:-1;edges.set(key,e);}}return{triangles,volume,edgeCounts:[...edges.values()]};}

test('current mage loader and manifest select the new immutable content hash; old asset remains exact',async()=>{
 assert.equal(sha(bytes[0]),oldHash);assert.equal(sha(bytes[1]),newHash);assert.equal(bytes[0].length,207620);assert.equal(bytes[1].length,207620);
 // Historical crystal-profile geometry fixtures remain pinned; active asset may have later material-only refinement.
 const active=read('../assets/targets/'+TARGET_MODEL_FILES.mage);assert.equal(TARGET_MODEL_FILES.mage,'mage.'+sha(active).slice(0,16)+'.glb');const row=JSON.parse(read('../assets/targets/source-manifest.json')).find(x=>x.asset==='mage');
 assert.equal(row.file,TARGET_MODEL_FILES.mage);assert.equal(row.sha256,sha(active));assert.equal(row.bytes,active.length);assert.equal(row.triangles,2548);assert.equal(row.materials,18);
 const requests=[];const loaded=await loadCharacterTargets(async url=>{requests.push(url);const q=read('../'+url.slice(2));return{ok:true,arrayBuffer:async()=>q.buffer.slice(q.byteOffset,q.byteOffset+q.byteLength)};});
 assert.deepEqual(loaded.map(x=>x.id),['mage','guardian','cannon']);assert(requests.includes('./assets/targets/'+TARGET_MODEL_FILES.mage));
});
test('GLB framing, buffer views, accessors and triangle indices are structurally valid and embedded-only',()=>{
 const raw=bytes[1],doc=docs[1];assert.equal(raw.readUInt32LE(0),0x46546c67);assert.equal(raw.readUInt32LE(4),2);assert.equal(raw.readUInt32LE(8),raw.length);const jl=raw.readUInt32LE(12),bo=20+jl;assert.equal(jl%4,0);assert.equal(raw.readUInt32LE(16),0x4e4f534a);assert.equal(raw.readUInt32LE(bo+4),0x004e4942);assert.equal(bo+8+raw.readUInt32LE(bo),raw.length);
 assert.equal(doc.buffers.length,1);assert(!doc.buffers[0].uri);assert(doc.buffers[0].byteLength<=raw.length-bo-8);for(const key of ['animations','skins','images','textures','extensionsRequired'])assert.equal((doc[key]||[]).length,0);
 const sizes={5121:1,5123:2,5125:4,5126:4},types={SCALAR:1,VEC2:2,VEC3:3,VEC4:4};for(const v of doc.bufferViews){assert.equal(v.buffer,0);assert(v.byteOffset>=0);assert(v.byteOffset+v.byteLength<=doc.buffers[0].byteLength);}
 for(const x of doc.accessors){assert(!x.sparse);assert(sizes[x.componentType]&&types[x.type]);const v=doc.bufferViews[x.bufferView],element=sizes[x.componentType]*types[x.type],stride=v.byteStride||element;assert(stride>=element);assert((x.byteOffset||0)+(x.count-1)*stride+element<=v.byteLength);}
 for(const g of Object.values(b)){assert.equal(g.index.count%3,0);for(const i of g.index.array)assert(i>=0&&i<g.attributes.position.count);for(const x of Object.values(g.attributes))assert(Array.from(x.array).every(Number.isFinite));}
});
test('material definitions, nodes, scenes, meshes, buffer layouts and all untouched accessors are exact',()=>{
 for(const key of ['asset','materials','nodes','scenes','scene','meshes','bufferViews','buffers'])assert.deepEqual(docs[1][key],docs[0][key]);
 const pa=new Set(docs[0].meshes[0].primitives.filter(p=>selected.has(docs[0].materials[p.material].name)).map(p=>p.attributes.POSITION));
 docs[0].accessors.forEach((x,i)=>{const y=structuredClone(docs[1].accessors[i]),z=structuredClone(x);if(pa.has(i)){delete y.min;delete y.max;delete z.min;delete z.max;}assert.deepEqual(y,z);});
 assert.equal(docs[1].meshes.length,1);assert.equal(docs[1].meshes[0].primitives.length,18);assert.equal(Object.values(b).reduce((n,g)=>n+g.index.count/3,0),2548);
});
test('every index and UV is unchanged; all fourteen unrelated primitives and every unselected position/normal are exact',()=>{
 let untouched=0,selectedCount=0;assert.deepEqual(Object.keys(b),Object.keys(a));for(const name of Object.keys(a)){const x=a[name],y=b[name],ss=selected.get(name)||new Set();assert.deepEqual(y.index.array,x.index.array);assert.deepEqual(Object.keys(y.attributes),Object.keys(x.attributes));
 for(const k of Object.keys(x.attributes)){const u=x.attributes[k],v=y.attributes[k];assert.equal(v.itemSize,u.itemSize);assert.equal(v.count,u.count);for(let i=0;i<u.count;i++)for(let j=0;j<u.itemSize;j++){if(ss.has(i)&&['position','normal'].includes(k))continue;assert.equal(v.array[i*u.itemSize+j],u.array[i*u.itemSize+j],name+' '+k+' '+i);}}
 if(!ss.size)untouched++;selectedCount+=ss.size;
 }assert.equal(untouched,14);assert.equal(selectedCount,72);
});
test('crystal profile is fitted wider toward the body while base connection, height, depth and left bound stay exact',()=>{
 const base=2.299999713897705,wide=2.7599997520446777,left=-1.2400000095367432;let baseCount=0;
 for(const [name,indices]of selected)for(const i of indices){const p=vec(a[name].attributes.position,i),q=vec(b[name].attributes.position,i),t=Math.max(0,Math.min(1,(p[1]-base)/(wide-base))),w=t*t*(3-2*t);assert(Math.abs(q[0]-(p[0]+.13*(p[0]-left)*w))<1e-7);assert.equal(q[1],p[1]);assert.equal(q[2],p[2]);if(p[1]===base){assert.deepEqual(q,p);baseCount++;}if(p[0]===left)assert.equal(q[0],p[0]);}assert(baseCount>0);
});
test('all 24 crystal facets retain valid winding and unit normals aligned with the new flat face',()=>{
 let faces=0;for(const name of selected.keys()){const g=b[name],ix=g.index.array,p=g.attributes.position,n=g.attributes.normal;for(let j=0;j<ix.length;j+=3){const ids=Array.from(ix.slice(j,j+3)),ps=ids.map(i=>new THREE.Vector3().fromArray(vec(p,i))),cross=ps[1].clone().sub(ps[0]).cross(ps[2].clone().sub(ps[0]));assert(cross.length()>1e-8);cross.normalize();for(const i of ids){const normal=new THREE.Vector3().fromArray(vec(n,i));assert(Math.abs(normal.length()-1)<1e-7);assert(normal.dot(cross)>1-1e-7);}faces++;}}assert.equal(faces,24);
});
test('four material sections remain one closed crystal with exact welded seams and no boundary or reversed edge',()=>{
 const check=geoms=>{const edges=new Map();let volume=0;for(const name of selected.keys()){const g=geoms[name],p=g.attributes.position,ix=g.index.array;for(let j=0;j<ix.length;j+=3){const ps=Array.from(ix.slice(j,j+3)).map(i=>vec(p,i)),vv=ps.map(v=>new THREE.Vector3().fromArray(v));volume+=vv[0].dot(vv[1].clone().cross(vv[2]))/6;const keys=ps.map(p=>JSON.stringify(p));for(let k=0;k<3;k++){const u=keys[k],v=keys[(k+1)%3],key=[u,v].sort().join('|');const e=edges.get(key)||{count:0,balance:0};e.count++;e.balance+=u<v?1:-1;edges.set(key,e);}}}assert([...edges.values()].every(e=>e.count===2&&e.balance===0));return{volume,edges:edges.size};};
 const x=check(a),y=check(b);assert.equal(x.edges,y.edges);assert(x.volume*y.volume>0);const ratio=y.volume/x.volume;assert(ratio>1&&ratio<1.131);
});
test('global model bounds remain bit-exact despite the visible crystal movement',()=>{assert.deepEqual(bounds(scenes[1].scene),bounds(scenes[0].scene));});
test('entire face/body ray intersections below the crystal remain exact from front and rear',()=>{
 let count=0;for(const s of scenes)s.scene.updateMatrixWorld(true);for(const rear of[false,true])for(let iy=0;iy<33;iy++)for(let ix=0;ix<45;ix++){const origin=new THREE.Vector3(-1.5+ix*3/44,.1+iy*2.1/32,rear?-5:5),ray=new THREE.Raycaster(origin,new THREE.Vector3(0,0,rear?1:-1)),probe=s=>ray.intersectObject(s.scene,true).map(h=>({point:h.point.toArray(),distance:h.distance,material:h.object.material.name,faceIndex:h.faceIndex}));assert.deepEqual(probe(scenes[1]),probe(scenes[0]));count++;}assert.equal(count,2970);
});
test('crystal silhouette width grows by the fitted 13 percent and its apex shifts, not only its metadata',()=>{
 const points=g=>[...selected.keys()].flatMap(n=>Array.from({length:g[n].attributes.position.count},(_,i)=>vec(g[n].attributes.position,i)));const ps=points(a),qs=points(b),min=(p,k)=>Math.min(...p.map(x=>x[k])),max=(p,k)=>Math.max(...p.map(x=>x[k]));const ratio=(max(qs,0)-min(qs,0))/(max(ps,0)-min(ps,0));assert(Math.abs(ratio-1.13)<1e-6);assert.equal(min(qs,0),min(ps,0));assert.equal(max(qs,1),max(ps,1));const top=max(ps,1),old=ps.filter(p=>p[1]===top),now=qs.filter(p=>p[1]===top);assert(old.length>0);for(let i=0;i<old.length;i++){const shift=.13*(old[i][0]-min(ps,0));assert(shift>.03);assert(Math.abs(now[i][0]-old[i][0]-shift)<1e-7);}
});
for(const position of[[0,0,0],[12,3,-18],[-9,1.8,4]])test('runtime collider, normalization, hit distances and ring are exact at '+position.join(','),()=>{
 const make=scene=>{const group=new THREE.Group(),ring=new THREE.Group();group.position.fromArray(position);group.add(ring);return attachCharacterTarget({group,ring},{scene,id:'mage',label:'mage'});};const[x,y]=scenes.map(g=>make(g.scene));
 for(const key of['position','scale','quaternion'])assert.deepEqual(y.character[key].toArray(),x.character[key].toArray());assert.deepEqual(y.bounds.min.toArray(),x.bounds.min.toArray());assert.deepEqual(y.bounds.max.toArray(),x.bounds.max.toArray());assert.deepEqual(bounds(y.character),bounds(x.character));assert.deepEqual(y.ring.position.toArray(),x.ring.position.toArray());assert.deepEqual(y.ring.rotation.toArray(),x.ring.rotation.toArray());
 const boxes=[x,y].map(t=>new THREE.Box3(t.bounds.min.clone().add(t.group.position),t.bounds.max.clone().add(t.group.position)));let rays=0;
 for(const view of['first','third'])for(let ix=-5;ix<=5;ix++)for(let iy=-5;iy<=5;iy++){const origin=new THREE.Vector3(position[0]+(view==='third'?.6:0),position[1]+(view==='third'?.5:0),position[2]+6),aim=new THREE.Vector3(position[0]+ix*.22,position[1]+iy*.24,position[2]),ray=new THREE.Ray(origin,aim.sub(origin).normalize()),hit=box=>ray.intersectBox(box,new THREE.Vector3())?.toArray()??null;assert.deepEqual(hit(boxes[1]),hit(boxes[0]));rays++;}assert.equal(rays,242);
 // Multiple target copies still own independent transforms/visibility.
 x.group.position.x+=4;x.character.visible=false;assert.equal(y.character.visible,true);assert.equal(y.group.position.x,position[0]);
});
