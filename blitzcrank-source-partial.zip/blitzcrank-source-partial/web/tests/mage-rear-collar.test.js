import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import * as THREE from '../vendor/three.module.js';import {GLTFLoader} from '../vendor/GLTFLoader.js';import {TARGET_MODEL_FILES} from '../target-models.js';
const load=async path=>{const b=fs.readFileSync(new URL(path,import.meta.url));const json=JSON.parse(b.subarray(20,20+b.readUInt32LE(12)).toString());const g=await new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');g.scene.updateMatrixWorld(true);return{scene:g.scene,json};};
const before=await load('../validation/reference-models-v2424/mage-v2423.glb'),after=await load('../assets/targets/'+TARGET_MODEL_FILES.mage);
// Historical collar-only output stays frozen; current shoulder deltas have their own tests.
const historicalCollar=await load('../validation/recovered-assets/mage.b3e2d52dc5b40951.glb');
const evidence=JSON.parse(fs.readFileSync(new URL('../validation/reference-models-v2424/runtime-evidence.json',import.meta.url)));
const hit=(model,origin,direction)=>new THREE.Raycaster(new THREE.Vector3(...origin),new THREE.Vector3(...direction)).intersectObject(model.scene,true)[0];
for(const side of [0,1])test(`mage rear collar spiral ${side+1} has six visible recessed dark-bronze segments`,()=>{
 for(const row of evidence.rays.slice(side*6,side*6+6)){const a=hit(before,row.origin,row.direction),b=hit(after,row.origin,row.direction);assert.equal(a.object.material.name,'Bronze collar');assert.equal(b.object.material.name,'Collar carved runes');assert(Math.abs(b.point.z-a.point.z-.012)<1e-6);}
});
for(const row of evidence.preservedRays)test(`mage ${row.name} keeps its first surface and material`,()=>{
 const a=hit(before,row.origin,row.direction),b=hit(after,row.origin,row.direction);assert.equal(b.object.material.name,a.object.material.name);assert.equal(b.object.material.name,row.material);
 if(row.name==='collar center ridge')assert(a.point.distanceTo(b.point)<1e-12);else assert.deepEqual(b.point.toArray(),a.point.toArray());
});
test('historical mage 18 material definitions and 16 untouched material geometries remain identical',()=>{
 const after=historicalCollar;
 const materialMap=m=>Object.fromEntries(m.json.materials.map(x=>[x.name,x]));assert.deepEqual(materialMap(after),materialMap(before));assert.deepEqual(after.json.nodes,before.json.nodes);assert.equal(after.json.meshes.length,1);assert.equal(after.json.meshes[0].primitives.length,18);
 const geometries=m=>{const result={};m.scene.traverse(n=>{if(n.isMesh)result[n.material.name]=n.geometry;});return result;};const a=geometries(before),b=geometries(after);let count=0;
 for(const name of Object.keys(a))if(!['Bronze collar','Collar carved runes'].includes(name)){assert.deepEqual(b[name].index.array,a[name].index.array,name);assert.deepEqual(Object.keys(b[name].attributes),Object.keys(a[name].attributes));for(const key of Object.keys(a[name].attributes))assert.deepEqual(b[name].attributes[key].array,a[name].attributes[key].array,name+' '+key);count++;}assert.equal(count,16);
});
test('historical mage rear detail adds only 112 triangles without textures, animations or external resources',()=>{
 const after=historicalCollar;
 const triangles=m=>{let n=0;m.scene.traverse(o=>{if(o.isMesh)n+=o.geometry.index.count/3;});return n;};assert.equal(triangles(before),2400);assert.equal(triangles(after),2512);assert.equal((after.json.animations||[]).length,0);assert.equal((after.json.images||[]).length,0);assert(after.json.buffers.every(b=>!b.uri));
});
