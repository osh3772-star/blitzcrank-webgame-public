import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {buildRuntime, RUNTIME_FILES} from '../build.mjs';
const sha = b => createHash('sha256').update(b).digest('hex');
function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'rocket-build-'));
  t.after(() => fs.rmSync(root, {recursive: true, force: true}));
  for (const name of RUNTIME_FILES) {
    const file = path.join(root, name); fs.mkdirSync(path.dirname(file), {recursive: true});
    fs.writeFileSync(file, 'fixture ' + name);
  }
  return root;
}
test('runtime closure includes all four entrypoints and online/map dependencies', () => {
  assert.equal(RUNTIME_FILES.length, 152); assert.equal(new Set(RUNTIME_FILES).size, 152);
  for (const name of ['index.html', 'online.html', 'online-duel-app.js', 'online-duel-peer.js', 'online-remote-smoothing.js', 'rift-map-test.html', 'rift-map-v36-test.html', 'rift-map-revisions.js', 'rift-map-loader.js', 'assets/map-study-v36/game-probes.json', 'rift-map-flash.js', 'rift-map-pull.js', 'rift-map-hook.js']) assert(RUNTIME_FILES.includes(name), name);
  assert(!RUNTIME_FILES.some(p => p.startsWith('tests/') || p.includes('..') || p.startsWith('/')));
  assert(!RUNTIME_FILES.includes('assets/blitz-fullbody.json'));
});
test('fresh build copies exact bytes and does not rewrite source or repack models', t => {
  const root = fixture(t), result = buildRuntime(root);
  assert.equal(result.files, 152); assert.equal(result.previousBuild, null);
  for (const name of RUNTIME_FILES) {
    const expected = Buffer.from('fixture ' + name);
    assert.deepEqual(fs.readFileSync(path.join(root, name)), expected);
    assert.deepEqual(fs.readFileSync(path.join(root, 'dist', name)), expected);
    assert.equal(result.manifest[name], sha(expected));
  }
});
test('repeat build excludes stale output while preserving the earlier build recoverably', t => {
  const root = fixture(t); buildRuntime(root);
  fs.writeFileSync(path.join(root, 'dist', 'stale.txt'), 'preserve me');
  fs.writeFileSync(path.join(root, 'main.js'), 'updated main');
  const result = buildRuntime(root);
  assert.equal(fs.readFileSync(path.join(root, 'dist', 'main.js'), 'utf8'), 'updated main');
  assert.equal(fs.existsSync(path.join(root, 'dist', 'stale.txt')), false);
  assert.equal(fs.readFileSync(path.join(result.previousBuild, 'stale.txt'), 'utf8'), 'preserve me');
  assert.equal(fs.readFileSync(path.join(result.previousBuild, 'main.js'), 'utf8'), 'fixture main.js');
});
test('missing source fails before changing previous output', t => {
  const root = fixture(t); buildRuntime(root);
  fs.unlinkSync(path.join(root, 'online-duel-app.js'));
  assert.throws(() => buildRuntime(root), /ENOENT/);
  assert.equal(fs.readFileSync(path.join(root, 'dist', 'online-duel-app.js'), 'utf8'), 'fixture online-duel-app.js');
  assert(!fs.readdirSync(root).some(p => p.startsWith('.dist-stage-') || p.startsWith('.dist-backup-')));
});
test('refuses symlink output without changing its target', t => {
  const root = fixture(t), target = path.join(root, 'keep'); fs.mkdirSync(target);
  fs.writeFileSync(path.join(target, 'note'), 'keep'); fs.symlinkSync(target, path.join(root, 'dist'));
  assert.throws(() => buildRuntime(root), /symlink dist/);
  assert.equal(fs.readFileSync(path.join(target, 'note'), 'utf8'), 'keep');
});
test('refuses source symlinks, including parent directories', t => {
  const root = fixture(t), file = path.join(root, 'main.js');
  fs.renameSync(file, path.join(root, 'main-real.js')); fs.symlinkSync('main-real.js', file);
  assert.throws(() => buildRuntime(root), /Runtime symlink rejected/); assert(!fs.existsSync(path.join(root, 'dist')));
  fs.unlinkSync(file); fs.renameSync(path.join(root, 'main-real.js'), file);
  fs.renameSync(path.join(root, 'assets'), path.join(root, 'real-assets')); fs.symlinkSync('real-assets', path.join(root, 'assets'));
  assert.throws(() => buildRuntime(root), /Runtime symlink rejected/); assert(!fs.existsSync(path.join(root, 'dist')));
});
test('npm build invokes only the included builder and needs no absent packing scripts', () => {
  const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url)));
  assert.equal(pkg.scripts.build, 'node build.mjs');
});
test('refuses dangling dist symlinks explicitly before staging', t => {
  const root = fixture(t); fs.symlinkSync('absent-target', path.join(root, 'dist'));
  assert.throws(() => buildRuntime(root), /symlink dist/);
  assert(fs.lstatSync(path.join(root, 'dist')).isSymbolicLink());
  assert(!fs.readdirSync(root).some(p => p.startsWith('.dist-stage-')));
});
test('staging copy failure preserves prior output and removes incomplete staging', t => {
  const root = fixture(t); buildRuntime(root); fs.writeFileSync(path.join(root, 'main.js'), 'new main');
  const write = fs.writeFileSync;
  try {
    fs.writeFileSync = (file, ...args) => {if (String(file).includes('.dist-stage-') && String(file).endsWith('main.js')) throw Error('injected copy failure'); return write(file, ...args);};
    assert.throws(() => buildRuntime(root), /injected copy failure/);
  } finally {fs.writeFileSync = write;}
  assert.equal(fs.readFileSync(path.join(root, 'dist/main.js'), 'utf8'), 'fixture main.js');
  assert(!fs.readdirSync(root).some(p => p.startsWith('.dist-stage-')));
});
test('promotion failure rolls back the prior output and removes incomplete staging', t => {
  const root = fixture(t); buildRuntime(root); fs.writeFileSync(path.join(root, 'main.js'), 'new main');
  const rename = fs.renameSync;
  try {
    fs.renameSync = (from, to) => {if (path.basename(from).startsWith('.dist-stage-')) throw Error('injected promotion failure'); return rename(from, to);};
    assert.throws(() => buildRuntime(root), /injected promotion failure/);
  } finally {fs.renameSync = rename;}
  assert.equal(fs.readFileSync(path.join(root, 'dist/main.js'), 'utf8'), 'fixture main.js');
  assert(!fs.readdirSync(root).some(p => p.startsWith('.dist-stage-')));
});
test('actual source imports, HTML references, and literal asset paths are in the runtime closure', () => {
  const root = new URL('../', import.meta.url), included = new Set(RUNTIME_FILES);
  function requirePath(from, reference) {
    const clean = reference.split(/[?#]/)[0];
    const resolved = path.posix.normalize(path.posix.join(path.posix.dirname(from), clean));
    assert(included.has(resolved), `${from} references omitted ${resolved}`);
  }
  for (const name of RUNTIME_FILES) {
    const local = new URL(name, root); assert(fs.statSync(local).isFile(), name);
    if (!/\.(?:m?js|html|css)$/.test(name) || name.startsWith('vendor/')) continue;
    const source = fs.readFileSync(local, 'utf8');
    for (const [,ref] of source.matchAll(/(?:from\s*|import\s*\()\s*['"](\.[^'"]+)['"]/g)) requirePath(name, ref);
    if (name.endsWith('.html')) for (const [,ref] of source.matchAll(/(?:src|href)=["']([^"']+)["']/g)) if (!/^(?:https?:|data:|#)/.test(ref)) requirePath(name, ref);
    for (const [,ref] of source.matchAll(/["'](\.?\/?assets\/[^"'\s]+)["']/g)) {
      if (ref.endsWith('/')) assert(RUNTIME_FILES.some(p => p.startsWith(ref.replace(/^\.\//,''))), ref);
      else requirePath(name, ref);
    }
  }
});
