import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameAudio} from '../game-audio.js';
const tick=()=>new Promise(r=>setImmediate(r));
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return{promise,resolve,reject};};
function harness(stage='fetch'){
 const gate=deferred(),sources=[],errors=[],requests=[],listeners=new Set();let decodes=0,resumes=0,trusted=false;
 const node=()=>({connect(){},disconnect(){this.disconnected=true;}});
 const ctx={state:'suspended',currentTime:1,destination:{},
  addEventListener(_,f){listeners.add(f);},removeEventListener(_,f){listeners.delete(f);},
  setState(s,notify=true){this.state=s;if(notify)for(const f of listeners)f();},
  resume(){resumes++;if(!trusted)return Promise.reject(Error('gesture required'));this.setState('running');return Promise.resolve();},
  close(){this.setState('closed');return Promise.resolve();},
  createGain(){return{...node(),gain:{cancelScheduledValues(){},setValueAtTime(){}}};},
  createBufferSource(){const s={...node(),start(){s.started=true;},stop(){s.stopped=true;s.onended?.();}};sources.push(s);return s;},
  async decodeAudioData(){decodes++;if(stage==='decode')await gate.promise;return{duration:.5};},
 };
 const audio=createGameAudio({createContext:()=>ctx,cues:{q:{url:'q.wav',group:'q',maxDuration:1,gain:1}},events:{q:'q'},fetchImpl:async u=>{requests.push(u);if(stage==='fetch')await gate.promise;return{ok:true,arrayBuffer:async()=>new ArrayBuffer(1)};},onError:(e,id)=>errors.push({e,id})});
 const gesture=()=>{trusted=true;try{return audio.unlock();}finally{trusted=false;}};
 return{ctx,audio,gate,sources,errors,requests,gesture,get decodes(){return decodes;},get resumes(){return resumes;}};
}
for(const stage of ['fetch','decode'])test(`trusted resume runs synchronously while priority ${stage} is pending`,async()=>{
 const h=harness(stage),first=h.gesture();await tick();assert.equal(h.resumes,1);h.ctx.setState('suspended');h.audio.setPaused(true);assert.equal(h.audio.playEvent('q'),false);
 const second=h.gesture();h.audio.setPaused(false);const resumedImmediately=h.resumes===2&&h.ctx.state==='running';
 h.gate.resolve();const outcomes=await Promise.all([first,second]);
 assert(resumedImmediately,'second trusted gesture must resume before pending load finishes');assert.deepEqual(outcomes,[true,true]);assert.equal(h.requests.length,1);assert.equal(h.decodes,1);assert.equal(h.sources.length,0);assert(h.audio.playEvent('q'));h.audio.dispose();
});
test('pending resume refusal reports false and next trusted gesture retries without duplicate load',async()=>{
 const h=harness(),first=h.gesture();await tick();h.ctx.setState('suspended');
 const refused=h.audio.unlock();await tick();const errors=h.errors.length;
 const retry=h.gesture();h.gate.resolve();const outcomes=await Promise.all([first,refused,retry]);
 assert.equal(errors,1,'pending unlock must attempt and report refused resume');assert.deepEqual(outcomes,[true,false,true]);assert.equal(h.requests.length,1);assert.equal(h.decodes,1);h.audio.dispose();
});
test('pending synchronous resume exception is reported and retryable',async()=>{
 const h=harness(),first=h.gesture();await tick();h.ctx.setState('suspended');const original=h.ctx.resume;
 h.ctx.resume=()=>{throw Error('resume throw');};const failed=h.gesture();await tick();const errors=h.errors.length;h.ctx.resume=original;const retry=h.gesture();h.gate.resolve();
 assert.deepEqual(await Promise.all([first,failed,retry]),[true,false,true]);assert.equal(errors,1);assert.equal(h.requests.length,1);h.audio.dispose();
});
for(const stop of ['pause','mute','dispose'])test(`pending recovery preserves ${stop} and drops stale events`,async()=>{
 const h=harness(),first=h.gesture();await tick();h.ctx.setState('interrupted',false);const second=h.gesture();assert.equal(h.audio.playEvent('q'),false);
 if(stop==='pause')h.audio.setPaused(true);if(stop==='mute')h.audio.setMuted(true);if(stop==='dispose')h.audio.dispose();h.gate.resolve();await Promise.all([first,second]);
 assert.equal(h.audio.playEvent('q'),false);assert.equal(h.sources.length,0);if(stop==='dispose')assert.deepEqual(h.audio.status.ready,[]);else{h.audio.setPaused(false);h.audio.setMuted(false);assert(h.audio.playEvent('q'));h.audio.dispose();}
});
for(const order of ['resume-first','load-first'])test(`delayed resumed promise and preload settle safely: ${order}`,async()=>{
 const h=harness(),first=h.gesture();await tick();h.ctx.setState('suspended');const resume=deferred();let calls=0;
 h.ctx.resume=()=>{calls++;return resume.promise.then(()=>{h.ctx.setState('running');});};const second=h.gesture();
 if(order==='resume-first'){resume.resolve();await tick();h.gate.resolve();}else{h.gate.resolve();await tick();resume.resolve();}
 const outcomes=await Promise.all([first,second]);assert.equal(calls,1);assert.equal(outcomes[1],true);assert.equal(outcomes[0],order==='resume-first');assert.equal(h.requests.length,1);assert.equal(h.sources.length,0);h.audio.dispose();
});
test('a later trusted gesture loads normally even when the original resume rejects late',async()=>{
 const h=harness(),denied=deferred(),original=h.ctx.resume;h.ctx.resume=()=>denied.promise;const first=h.gesture();h.ctx.resume=original;
 const second=h.gesture();await tick();denied.reject(Error('old resume denied'));await tick();h.gate.resolve();
 assert.deepEqual(await Promise.all([first,second]),[false,true]);assert.equal(h.errors.length,1);assert.equal(h.requests.length,1);assert.equal(h.decodes,1);assert(h.audio.playEvent('q'));h.audio.dispose();
});
test('a late rejected second resume stays false even after preload completed',async()=>{
 const h=harness(),first=h.gesture();await tick();h.ctx.setState('suspended');const denied=deferred(),original=h.ctx.resume;h.ctx.resume=()=>denied.promise;const second=h.gesture();h.gate.resolve();await tick();denied.reject(Error('resume denied'));
 assert.deepEqual(await Promise.all([first,second]),[false,false]);assert.equal(h.errors.length,1);h.ctx.resume=original;assert.equal(await h.gesture(),true);assert.equal(h.requests.length,1);assert.equal(h.decodes,1);h.audio.dispose();
});
test('disposal while resume is pending does not load or revive audio',async()=>{
 const h=harness(),resume=deferred();h.ctx.resume=()=>resume.promise;const first=h.gesture(),second=h.gesture();h.audio.dispose();resume.resolve();h.gate.resolve();
 assert.deepEqual(await Promise.all([first,second]),[false,false]);assert.equal(h.requests.length,0);assert.equal(h.sources.length,0);assert.deepEqual(h.audio.status.ready,[]);
});
