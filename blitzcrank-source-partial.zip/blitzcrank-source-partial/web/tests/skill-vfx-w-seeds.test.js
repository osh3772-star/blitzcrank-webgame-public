import {capacityComparableVfxState as vfxState} from './helpers/vfx-capacity-comparison.js';
import test from 'node:test';import assert from 'node:assert/strict';
import {createSkillVfx} from '../skill-vfx.js';
import {createSkillVfx as legacyCreate} from './fixtures/skill-vfx-v0.24.46-baseline.js';
import {createSkillVfxHarness,vfxStatus,uploadVersions} from './helpers/skill-vfx-harness.js';
const position={x:2,y:1.7,z:-3};let comparisons=0;
function pair(){
 const a=createSkillVfxHarness(legacyCreate),b=createSkillVfxHarness(createSkillVfx);
 const identities=[a,b].map(h=>({arrays:[...h.arrays],geometries:[...h.geometries],materials:[...h.materials],textures:[...h.textures]}));
 const same=label=>{assert.deepEqual(vfxState(b),vfxState(a),label);const av=uploadVersions(a),bv=uploadVersions(b),r=a.geometries.indexOf(a.owned.find(o=>o.name==='R_ivory_branched_web').geometry);for(let j=0;j<av.length;j++){if(j!==r)assert.deepEqual(bv[j],av[j],label+' non-R upload versions');else for(const key of Object.keys(av[j])){if(key==='uv')assert.equal(bv[j][key],av[j][key]);else assert(bv[j][key]<=av[j][key],label+' R uploads never increase');}}for(const [i,h] of [a,b].entries())for(const key of Object.keys(identities[i]))assert(h[key].every((value,j)=>value===identities[i][key][j]),key+' stable');comparisons++;};
 same('construction');return{a,b,same,tick(dt,status=vfxStatus(),extra={}){for(const h of [a,b])h.vfx.update(dt,{status,position,yaw:.4,...extra});same(`tick ${dt}`);},event(type,args){for(const h of [a,b])h.vfx.event(type,args);same('event '+type);},reset(){a.vfx.reset();b.vfx.reset();same('reset');},dispose(){a.vfx.dispose();b.vfx.dispose();same('dispose');}};
}
test('active W removes 258 repeated sine evaluations while preserving all animated output',t=>{
 const p=pair(),status=vfxStatus(null,0,{boost:2});
 const count=h=>{let calls=0;const original=Math.sin;Math.sin=function(...args){calls++;return original(...args);};try{h.vfx.update(1/60,{status,position,yaw:.4,moving:true});}finally{Math.sin=original;}return calls;};
 const baseline=count(p.a),candidate=count(p.b);p.same('instrumented boost');
 assert.equal(baseline,301);assert.equal(candidate,43);assert.equal(baseline-candidate,258);
 t.diagnostic(`Active W sine evaluations ${baseline} → ${candidate}; 40 time-varying streak opacity samples and 3 Three.js rotation samples remain.`);p.dispose();
});
test('W onset, direction, moving/standing, frame intervals and view changes are byte-exact',()=>{
 const p=pair(),deltas=[1/120,1/60,1/30,.05,.001,.2];
 for(let i=0;i<48;i++)p.tick(deltas[i%deltas.length],vfxStatus(null,0,{boost:[4,3.99,3.9,3,2,1,.12,.06][i%8]}),{moving:i%3!==0,thirdPerson:i%2===0,position:{x:i*.17,y:1.7+i*.01,z:-i*.2},yaw:i*.13});
 for(const dt of [0,-1,NaN,Infinity,undefined])p.tick(dt,vfxStatus(null,0,{boost:3}));p.dispose();
});
test('tail, time-dependent ground sparks, resets and simultaneous E/R remain byte-exact',()=>{
 const p=pair();
 for(const boost of [4,3,.12,.06,.001,0])p.tick(1/30,vfxStatus(null,0,{boost}),{moving:true});
 for(let i=0;i<15;i++)p.tick(1/30,vfxStatus(null,0,{slow:2-i/30}),{moving:i%2===0});
 p.reset();p.event('static_field_discharge',{position,targets:[position,{x:1,y:2,z:3}]});p.event('power_fist_hit',{position});
 for(let i=0;i<15;i++)p.tick(1/60,vfxStatus('E_Hold',i/60,{boost:2,armed:3}),{moving:true,thirdPerson:i%2===0});
 p.reset();p.tick(.01,vfxStatus(null,0,{boost:4}));p.tick(1000);p.tick(.01);p.dispose();
});
test('fixed W seeds do not share mutable animation state between actors or survive disposal as resources',()=>{
 const p=pair(),other=createSkillVfxHarness(createSkillVfx);
 for(let i=0;i<8;i++){other.vfx.update(.13,{status:vfxStatus('E_Hold',.2,{boost:4-i*.3,armed:3}),position:{x:i,y:2,z:-i},moving:true});p.tick(.017,vfxStatus(null,0,{boost:2}),{moving:i%2===0});if(i===3)other.vfx.reset();}
 other.vfx.dispose();p.tick(.02,vfxStatus(null,0,{boost:2}));p.reset();p.tick(.01,vfxStatus(null,0,{boost:4}));p.dispose();
});
test('capacity-aware state equivalence count is reported without a rendering claim',t=>{
 assert(comparisons>=100);t.diagnostic(`${comparisons} exact capacity-aware VFX snapshots including every retained typed-buffer byte, shader values, visibility, transforms and unchanged non-R upload versions. R geometry reuse may reduce only its dynamic upload counters. CPU-only actual Three; no browser or GPU validation.`);
});
