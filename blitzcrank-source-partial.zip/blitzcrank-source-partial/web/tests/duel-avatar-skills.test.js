import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {rig,THREE} from './helpers/locomotion-rig.js';
import {createDuelAvatarFactory} from '../duel-avatar.js';
import {createFullbodyLocomotion} from '../fullbody-locomotion.js';
import {bindSkillClips,createFullbodyPoseApplicator,createFullbodyELocomotionLayer} from '../skill-animation.js';
const model=JSON.parse(fs.readFileSync(new URL('../assets/skill-animations/skills.9b293d06ddb21614.json',import.meta.url))).models.fullbody;
const state={position:[0,0,0],yaw:0};
function fixture(){const original=rig();const factory=createDuelAvatarFactory(THREE,{...original,createLocomotion:createFullbodyLocomotion});const avatar=factory.create();avatar.configureSkills(model);return {original,factory,avatar};}
function surfaces(a){const out=[];a.object.traverse(o=>{if(o.isMesh)out.push(o);});return out;}
function pose(a){return surfaces(a).map(m=>({matrix:m.matrix.toArray(),world:m.matrixWorld.toArray(),auto:m.matrixAutoUpdate}));}
function near(a,b){assert.equal(a.length,b.length);for(let i=0;i<a.length;i++)assert(Math.abs(a[i]-b[i])<1e-8,`${i}: ${a[i]} != ${b[i]}`);}
for(const name of ['W_Start','W_Loop','W_End','E_Charge','E_Hold','E_Strike','R_Cast'])test(`bot ${name} matches original authored surfaces by name`,()=>{
 const {avatar}=fixture(),ref=rig(),meshes=[...ref.meshes.values()],clip=bindSkillClips(model,meshes).find(c=>c.name===name);
 createFullbodyPoseApplicator(THREE)(clip,.2,meshes);
 avatar.update(0,{...state,skill:{name,time:.2}});
 const actual=new Map(surfaces(avatar).map(m=>[m.name,m]));for(const mesh of meshes)near(actual.get(mesh.name).matrix.elements,mesh.matrix.elements);
 assert.equal(avatar.inspect().skill,name);
});
test('E moving lower layer matches original and retains authored upper body',()=>{
 const {avatar}=fixture(),ref=rig(),meshes=[...ref.meshes.values()],apply=createFullbodyPoseApplicator(THREE),layer=createFullbodyELocomotionLayer(THREE,{...ref,surfaces:meshes,locomotion:ref.motion}),clip=bindSkillClips(model,meshes).find(c=>c.name==='E_Hold');
 for(let i=0;i<20;i++){
  ref.motion.advance(.05,{deltaX:0,deltaZ:.2,yaw:0,grounded:true});ref.motion.restorePose();ref.body.position.set(0,0,0);apply(clip,.2,meshes);layer();
  avatar.update(.05,{...state,locomotion:{deltaZ:.2},skill:{name:'E_Hold',time:.2}});
 }
 const actual=new Map(surfaces(avatar).map(m=>[m.name,m]));for(const mesh of meshes)near(actual.get(mesh.name).matrix.elements,mesh.matrix.elements);
});
test('presentation override, Q priority, reset and disposal clear authored matrices',()=>{
 const {avatar}=fixture();avatar.update(0,{...state,skill:{name:'W_End',time:.1,presentation:{name:'W_Loop',time:.2}}});assert.equal(avatar.inspect().skill,'W_Loop');
 avatar.update(0,{...state,hook:{phase:'windup',phaseTime:.1},skill:{name:'E_Hold',time:.2}});assert.equal(avatar.inspect().skill,null);assert(surfaces(avatar).every(m=>m.matrixAutoUpdate));
 avatar.update(0,{...state,skill:{name:'R_Cast',time:.2}});avatar.reset();assert(surfaces(avatar).every(m=>m.matrixAutoUpdate));assert.equal(avatar.inspect().skill,null);
 avatar.update(0,{...state,skill:{name:'R_Cast',time:.2}});const meshes=surfaces(avatar);avatar.dispose();assert(meshes.every(m=>m.matrixAutoUpdate&&m.position.length()===0));assert.throws(()=>avatar.getSkillHands(),/disposed/);
});
test('invalid snapshots are rejected without animation or transform mutations',()=>{
 const {avatar}=fixture();avatar.update(.05,{...state,skill:{name:'E_Hold',time:.2}});const before=pose(avatar),inspect=avatar.inspect();
 for(const skill of [{name:'absent',time:0},{name:'E_Hold',time:NaN},{name:'E_Hold',time:-1},{name:'E_Hold',time:.2,presentation:{name:'R_Cast',time:Infinity}}]){
  assert.throws(()=>avatar.update(.05,{...state,locomotion:{deltaZ:.2},skill}));assert.deepEqual(pose(avatar),before);assert.deepEqual(avatar.inspect(),inspect);
 }
});
test('actor skill transforms and VFX children never contaminate factory or original resources',()=>{
 const {avatar,factory,original}=fixture(),hands=avatar.getSkillHands();assert.equal(hands.length,2);const extra=new THREE.Group();hands[0].add(extra);
 avatar.update(0,{...state,skill:{name:'R_Cast',time:.2}});const other=factory.create();other.configureSkills(model);assert(!other.getSkillHands()[0].children.length);assert(surfaces(other).every(m=>m.matrixAutoUpdate));
 for(const mesh of surfaces(other)){const source=original.meshes.get(mesh.name);assert.equal(mesh.geometry,source.geometry);assert.equal(mesh.material,source.material);assert(source.matrixAutoUpdate);}
 avatar.dispose();other.update(0,state);assert(other.getSkillHands()[0].geometry.attributes.position.count>0);
});
test('E layer world pose is independent of rigid uniform-scale parent',()=>{
 const {avatar:a,factory}=fixture(),parent=new THREE.Group();parent.position.set(4,2,-3);parent.rotation.set(.2,.4,-.1);parent.scale.setScalar(1.7);
 const b=factory.create({parent});b.configureSkills(model);
 for(let i=0;i<10;i++){const input={position:[2,1,-4],yaw:.6,locomotion:{deltaZ:.2},skill:{name:'E_Hold',time:.2}};a.update(.05,input);b.update(.05,input);}
 const other=new Map(surfaces(b).map(m=>[m.name,m]));for(const mesh of surfaces(a))near(mesh.matrixWorld.elements,other.get(mesh.name).matrixWorld.elements);
});
test('skill exit restores Q sockets and locomotion to an equivalent clean actor',()=>{
 const {avatar:a,factory}=fixture(),b=factory.create();
 for(let i=0;i<10;i++){a.update(.05,{...state,locomotion:{deltaZ:.2},skill:{name:'E_Strike',time:.3}});b.update(.05,{...state,locomotion:{deltaZ:.2}});}
 const input={...state,hook:{phase:'outbound',phaseTime:.1,position:[0,1,-8]}};a.update(0,input);b.update(0,input);
 near(a.getSockets().palm,b.getSockets().palm);near(a.getSockets().homePalm,b.getSockets().homePalm);
 const other=new Map(surfaces(b).map(m=>[m.name,m]));for(const mesh of surfaces(a))near(mesh.matrixWorld.elements,other.get(mesh.name).matrixWorld.elements);
});
