import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const root=fileURLToPath(new URL('../',import.meta.url));
const repro=path.join(root,'validation/duel-cover-pull/duel-cover-pull-repro.mjs');
for(const hz of [20,60,120])for(const kind of ['clear','margin','blocked'])test(`actual legal-input ${hz}Hz ${kind} pull avoids cover and retains point/reset`,()=>{
 const text=execFileSync(process.execPath,['--max-old-space-size=512',repro,root,String(hz),kind,'--expect-safe'],{encoding:'utf8',maxBuffer:1024*1024});
 const r=JSON.parse(text.trim());assert.equal(r.bodyOverlapFrames,0);assert.equal(r.blockedSegments,0);assert.equal(r.endpointBody,false);
 if(kind==='clear')assert.equal(r.endpointAdjustment,0);else assert(r.endpointAdjustment>0&&r.endpointAdjustment<.51);
});
let failureRuntime;
async function failRoute(){
 if(!failureRuntime){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'pull-route-failure-')),source=path.join(dir,'main.js');
  let code=fs.readFileSync(path.join(root,'main.js'),'utf8');
  const match=code.match(/import \{planDuelPullPath,sampleDuelPullPath\} from '([^']+)';/);assert(match);
  code=code.replace(match[0],`import {sampleDuelPullPath} from '${match[1]}'; const planDuelPullPath=()=>({ok:false,code:'TEST_UNSUPPORTED_ROUTE'});`);
  fs.writeFileSync(source,code);try{failureRuntime=await createGameplayHarness({sourcePath:source,delta:()=>.05});}finally{fs.rmSync(dir,{recursive:true,force:true});}
 }
 const r=failureRuntime;r.element('duelmode').click();
 r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0})});
 r.frames(35);r.game.data.duelBot.position.set(0,1.7,1);r.key('KeyQ');
 for(let i=0;i<30&&r.qa.state==='running';i++)r.frames(1);
 assert.equal(r.qa.state,'paused');assert.equal(r.qa.duel.match.history.length,0);assert(r.qa.duel.pendingGrab);
 return r;
}
test('an uncertified route explicitly pauses without clipping or awarding a false point',async()=>{
 const r=await failRoute(),before={bot:r.qa.duel.bot.position,player:r.qa.player,match:r.qa.duel.match,hook:r.qa.hook};
 assert.match(r.element('intro').textContent,/안전하게 계산하지 못해/);assert.match(r.element('start').innerHTML,/새로 시작/);
 r.frames(200);assert.deepEqual({bot:r.qa.duel.bot.position,player:r.qa.player,match:r.qa.duel.match,hook:r.qa.hook},before);
 for(const key of ['KeyQ','KeyE','KeyR','KeyF','ShiftLeft','Space'])r.key(key);
 assert.equal(r.qa.duel.match.history.length,0);assert.equal(r.qa.session.score,0);
});
for(const action of ['enter','start','practice'])test(`explicit ${action} recovery starts a fresh duel, never resumes an uncertified pull`,async()=>{
 const r=await failRoute(),old=r.qa.duel.match.sessionId;
 if(action==='enter')r.key('Enter');else r.element(action).click();
 assert.equal(r.qa.state,'running');assert.equal(r.qa.duel.match.phase,'countdown');assert.notEqual(r.qa.duel.match.sessionId,old);
 assert.deepEqual(r.qa.duel.match.scores.map(x=>x.points),[0,0]);assert.equal(r.qa.duel.pendingGrab,null);assert.equal(r.qa.hook,null);
 assert.deepEqual(r.qa.player,{x:0,y:1.7,z:7,yaw:0,pitch:0});assert.deepEqual(r.qa.duel.bot.position,[0,1.7,-12]);
});
test('route-error main-menu exit restores ordinary training without a pending duel or record',async()=>{
 const r=await failRoute();r.element('mainmenu').click();assert.equal(r.qa.state,'menu');assert.equal(r.qa.duel,null);
 r.element('practice').click();assert.equal(r.qa.state,'running');assert.equal(r.qa.duel,null);assert.equal(r.qa.session.score,0);assert.equal(r.qa.session.practice,true);
});
