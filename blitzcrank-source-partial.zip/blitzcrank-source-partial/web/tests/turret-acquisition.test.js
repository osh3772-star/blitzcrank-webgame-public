import test from 'node:test';
import assert from 'node:assert/strict';
import {createTurretSimulation} from '../turret-core.js';

const make = (options={}) => createTurretSimulation({turrets:[{id:'a',position:{x:0,y:0,z:0}}],...options});
const player = (x=10, alive=true) => ({position:{x,y:1.3,z:0},radius:.5,alive});
const select = (events,type) => events.filter(e=>e.type===type);

test('one acquisition alert, independent of repeated windups and shots',()=>{
 const sim=make(), events=[];
 for(let i=0;i<480;i++) events.push(...sim.step(1/60,player()));
 assert.equal(select(events,'acquired').length,1);
 assert.ok(select(events,'windup').length>=3);
 assert.ok(select(events,'shot').length>=3);
 assert.equal(select(events,'lost').length,0);
 assert.equal(sim.turrets[0].acquired,true);
});

test('range exit/re-entry during cooldown clears and reacquires immediately',()=>{
 const sim=make();sim.step(.75,player());
 assert.equal(sim.turrets[0].state,'cooldown');
 assert.deepEqual(select(sim.step(.1,player(13)),'lost'),[{type:'lost',turretId:'a'}]);
 const events=sim.step(.1,player());
 assert.deepEqual(select(events,'acquired'),[{type:'acquired',turretId:'a'}]);
 assert.equal(select(events,'windup').length,0);
 assert.equal(sim.turrets[0].state,'cooldown');
 assert.equal(select(sim.step(.1,player()),'acquired').length,0);
});

test('cover prevents acquisition and loss/reacquisition are not tied to windup',()=>{
 const sim=make(),cover={isVisible:()=>false};
 assert.equal(select(sim.step(.1,player(),cover),'acquired').length,0);
 sim.step(.75,player());
 assert.equal(select(sim.step(.1,player(),cover),'lost').length,1);
 assert.equal(select(sim.step(.1,player(),cover),'lost').length,0);
 assert.equal(select(sim.step(.1,player()),'acquired').length,1);
});

test('loss during windup cancels shot; a new lock gets a full telegraph',()=>{
 const sim=make();sim.step(.5,player());
 const lost=sim.step(.1,player(13));
 assert.equal(select(lost,'lost').length,1);
 assert.equal(select(lost,'cancel').length,1);
 const acquired=sim.step(.1,player());
 assert.equal(select(acquired,'acquired').length,1);
 assert.equal(select(acquired,'windup').length,1);
 assert.equal(select(acquired,'shot').length,0);
});

test('death loses lock and suppresses impacts, reset clears locks for respawn',()=>{
 const sim=make();sim.step(.75,player());
 const dead=sim.step(.6,player(10,false));
 assert.equal(select(dead,'lost').length,1);
 assert.equal(select(dead,'hit').length,0);
 assert.equal(select(sim.step(.1,player(10,false)),'lost').length,0);
 sim.reset();assert.equal(sim.turrets[0].acquired,false);
 const events=sim.step(.1,player());
 assert.equal(select(events,'acquired').length,1);
 assert.equal(select(events,'hit').length,0);
});

test('each turret owns its lock; zero time and reset never queue stale alerts',()=>{
 const sim=make({turrets:[{id:'a',position:{x:0,y:0,z:0}},{id:'b',position:{x:20,y:0,z:0}}]});
 assert.deepEqual(sim.step(0,player()),[]);
 assert.deepEqual(select(sim.step(.1,player()),'acquired').map(e=>e.turretId),['a','b']);
 const moved=sim.step(.1,player(1));
 assert.deepEqual(select(moved,'lost').map(e=>e.turretId),['b']);
 assert.equal(select(moved,'acquired').length,0);
 sim.reset();assert.deepEqual(sim.events,[]);
 assert.ok(sim.turrets.every(t=>!t.acquired));
});

test('blocked, expired and dead-player shots never become impact events',()=>{
 const blocked=make();blocked.step(.75,player());
 const blockedEvents=blocked.step(1,player(),{obstruction:()=>.1});
 assert.equal(select(blockedEvents,'blocked').length,1);
 assert.equal(select(blockedEvents,'hit').length,0);
 const expired=make();expired.step(.75,player());
 const expiredEvents=expired.step(5,player(100));
 assert.equal(select(expiredEvents,'expired').length,1);
 assert.equal(select(expiredEvents,'hit').length,0);
 const actual=make();actual.step(.75,player());
 assert.equal(select(actual.step(1,player()),'hit').length,1);
 assert.equal(select(actual.step(.1,player()),'hit').length,0);
});
