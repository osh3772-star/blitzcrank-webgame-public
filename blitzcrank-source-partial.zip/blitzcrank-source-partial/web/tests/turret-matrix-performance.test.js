import test from 'node:test';import assert from 'node:assert/strict';
import {createTurretArena} from '../turret-view.js';
import {createTurretArena as legacyCreate} from './fixtures/turret-view-v0.24.47-baseline.js';
import {THREE,turretFixture,turretState} from './helpers/turret-matrix-harness.js';
let comparisons=0;
function pair(resetOn=null){
 const a=turretFixture(legacyCreate,resetOn),b=turretFixture(createTurretArena,resetOn);
 const same=()=>{assert.deepEqual(turretState(b),turretState(a));comparisons++;};same();
 return{a,b,same,step(dt,player,alive=true){assert.deepEqual(b.arena.step(dt,player,alive),a.arena.step(dt,player,alive));
  // Muzzle matrices must be current before the renderer refreshes any meshes.
  for(const id of ['west','east'])assert.deepEqual(b.arena.visuals.get(id).muzzle.matrixWorld.elements,a.arena.visuals.get(id).muzzle.matrixWorld.elements);
  same();
 }};
}
test('turret aiming updates muzzle ancestors without full-root or unrelated descendant passes',t=>{
 const p=pair();
 for(const h of [p.a,p.b])for(const v of h.arena.visuals.values()){const extra=new THREE.Group();extra.name='unrelated test subtree';v.root.add(extra);for(let i=0;i<100;i++)extra.add(new THREE.Group());}
 const measure=h=>{const roots=new Set([...h.arena.visuals.values()].map(v=>v.root)),nodes=new Set();for(const r of roots)r.traverse(n=>nodes.add(n));let passes=0,visits=0;
  const original=THREE.Object3D.prototype.updateWorldMatrix;THREE.Object3D.prototype.updateWorldMatrix=function(parents,children){if(nodes.has(this))visits++;if(roots.has(this)&&children)passes++;return original.call(this,parents,children);};
  try{h.arena.step(1/60,{x:0,y:1.7,z:7});}finally{THREE.Object3D.prototype.updateWorldMatrix=original;}
  return{passes,visits,nodes:nodes.size};
 };
 const old=measure(p.a),current=measure(p.b);assert.equal(old.passes,2);assert.equal(current.passes,0);assert.equal(old.visits-current.visits,old.nodes);p.same();
 t.diagnostic(`Two turrets plus 202 unrelated test nodes: ${old.passes} → ${current.passes} full-root passes; ${old.visits} → ${current.visits} world updates.`);
});
test('real GLB aiming, windup, shots, recoil, bullets and damage remain exact across changing positions and rates',()=>{
 const p=pair(),rates=[1/120,1/60,1/30,.05];
 for(let i=0;i<900;i++){
  const phase=Math.floor(i/150)%4,player=phase===0?{x:-8+Math.sin(i*.013),y:1.7,z:-12}:phase===1?{x:8,y:1.7+Math.sin(i*.07)*.4,z:-23}:phase===2?{x:0,y:1.7,z:7}:{x:-8,y:2.3,z:-12};
  p.step(rates[i%rates.length],player,i<760||i>810);
 }
 assert(p.a.events.some(e=>e[0]==='shot'));assert(p.a.events.some(e=>e[0]==='damage'));assert(p.a.events.some(e=>e[0]==='lost'));
});
test('cover insertion, zero delta, reset, reacquisition and muzzle position changes stay exact',()=>{
 const p=pair(),near={x:-8,y:1.7,z:-12};
 for(let i=0;i<260;i++){
  if(i===50)for(const h of [p.a,p.b])h.obstacles.push({min:new THREE.Vector3(-11,0,-16),max:new THREE.Vector3(-9,10,-13)});
  if(i===110)for(const h of [p.a,p.b])h.obstacles.pop();
  if(i===180)for(const h of [p.a,p.b])h.arena.reset();
  p.step(i%29===0?0:1/30,near);
 }
 assert(p.a.events.some(e=>e[0]==='acquired'));assert(p.a.events.some(e=>e[0]==='lost'));
});
test('transformed parent scenes and externally moved turret roots retain original muzzle and rendered matrices',()=>{
 const p=pair();for(let i=0;i<60;i++){
  for(const h of [p.a,p.b]){h.scene.position.set(i*.01,.1,-.2);h.scene.rotation.set(.02,.1+i*.001,-.03);h.scene.scale.setScalar(1.1);h.arena.visuals.get('west').root.position.x+=.005;}
  p.step(1/60,{x:-8,y:1.7,z:-12});
 }
});
test('callback-triggered reset still cancels stale events and restores model state',()=>{
 for(const event of ['acquired','lost','shot','damage']){const p=pair(event);for(let i=0;i<90;i++)p.step(.1,i<60?{x:-8,y:1.7,z:-12}:{x:0,y:1.7,z:7});}
});
test('equivalence coverage is reported as CPU preparation, not actual GPU rendering',t=>{
 assert(comparisons>1500);t.diagnostic(`${comparisons} exact turret/game/render-ready state snapshots; muzzle matrices are also compared before the normal scene refresh. Actual Three CPU only, no browser/GPU/FPS measurement.`);
});
