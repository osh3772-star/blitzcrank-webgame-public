import test from 'node:test';import assert from 'node:assert/strict';import {createGameplayHarness} from './helpers/runtime-harness.js';
const writes=[];
const h=await createGameplayHarness({storage:{getItem:()=>null,setItem:(...args)=>writes.push(args)}}),ts=h.game.data.targets;
test('off by default and option applies exclusively to fresh free practice',()=>{
 h.game.begin(true);assert.equal(h.qa.irregularPractice,false);h.frames(2);for(const t of ts)assert(Math.abs(t.group.position.x-t.anchor.x-Math.sin(h.qa.session.elapsed*t.speed+t.phase)*t.amplitude)<1e-9);
 h.element('irregularpractice').checked=true;
 for(const args of [[false],[true,true],[true,false,true]]){h.game.begin(...args);assert.equal(h.qa.irregularPractice,false);}
 h.game.begin(true);assert.equal(h.qa.irregularPractice,true);assert.equal(h.element('timerlabel').textContent,'불규칙 자유 연습');
});
test('actual model lanes avoid obstacles and position stays continuous over turns/pause',()=>{
 h.game.begin(true);const previous=ts.map(t=>t.group.position.clone());
 for(let frame=0;frame<600;frame++){h.frames(1);ts.forEach((t,i)=>{assert(Math.abs(t.group.position.x-previous[i].x)<=2.55/60+1e-7);previous[i].copy(t.group.position);for(const o of h.game.data.obstacles){const p=t.group.position,b=t.bounds;assert(p.x+b.max.x<=o.min.x||p.x+b.min.x>=o.max.x||p.y+b.max.y<=o.min.y||p.y+b.min.y>=o.max.y||p.z+b.max.z<=o.min.z||p.z+b.min.z>=o.max.z,'full target overlaps cover');}});}
 h.game.pause();const pos=h.qa.targets.map(t=>t.position);h.frames(120);assert.deepEqual(h.qa.targets.map(t=>t.position),pos);h.game.resume();h.frames(1);ts.forEach((t,i)=>assert(Math.abs(t.group.position.x-pos[i][0])<=2.55/60+1e-7));
});
test('owned targets skipped, respawn/reset clean; option changes never mutate paused run',()=>{
 h.game.begin(true);h.frames(20);const t=ts[0];t.captured=true;const pos=t.group.position.clone();h.frames(20);assert(t.group.position.equals(pos));t.captured=false;t.active=false;t.respawn=h.qa.session.elapsed+.05;h.frames(5);assert(t.active);assert(Math.abs(t.group.position.x-t.anchor.x)<.15);
 h.game.pause();h.element('irregularpractice').checked=false;h.game.resume();assert.equal(h.qa.irregularPractice,true);h.game.pause();h.element('practice').onclick();assert.equal(h.qa.irregularPractice,false);
 h.game.pause();h.element('mainmenu').onclick();assert.equal(h.qa.irregularPractice,false);
});

test('irregular practice completion cannot write challenge or combo records',()=>{
 h.element('irregularpractice').checked=true;h.game.begin(true);h.game.setScore(99999);h.game.finish();assert.equal(writes.length,0);
});
