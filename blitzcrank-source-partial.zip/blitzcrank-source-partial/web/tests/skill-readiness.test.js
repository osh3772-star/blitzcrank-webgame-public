import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const h=await createGameplayHarness(),el=h.element;
function fresh(combo=false){h.game.begin(true,combo);h.frames(1);}
function shown(key,text,disabled){assert.equal(el('skillstate'+key).textContent,text);assert.equal(el('skill'+key).attributes['aria-disabled'],String(disabled));assert.equal(el('skill'+key).disabled,false);}
for(const phase of ['windup','outbound','return','recover'])test('E/R show the real Q lock during '+phase,()=>{
 fresh();h.key('KeyQ');for(let n=0;n<180&&h.qa.hook?.phase!==phase;n++)h.frames(1);assert.equal(h.qa.hook?.phase,phase);
 shown('E','HOOK ACTIVE',true);shown('R','HOOK ACTIVE',true);const before=h.qa.skills;h.key('KeyE');h.key('KeyR');assert.deepEqual(h.qa.skills,before);
 h.frames(180);shown('E','READY',false);shown('R','READY',false);h.key('KeyE');assert.equal(h.qa.skills.phase,'E_Charge');
});
test('R is casting-blocked during E charge/strike but remains available while E is held',()=>{
 fresh();h.key('KeyE');shown('R','CASTING',true);h.key('KeyR');assert.equal(h.qa.skills.phase,'E_Charge');h.frames(53);shown('R','READY',false);
 h.punch();shown('R','CASTING',true);h.key('KeyR');assert.equal(h.qa.skills.phase,'E_Strike');h.frames(90);shown('R','READY',false);h.key('KeyR');assert.equal(h.qa.skills.phase,'R_Cast');
});
test('E cannot be shown enabled after its cooldown expires while the fist is still armed',()=>{
 fresh();h.key('KeyE');h.frames(306);assert.equal(h.qa.skills.cooldown.E,0);assert.equal(h.qa.skills.phase,'E_Hold');assert.match(el('skillstateE').textContent,/^ARMED /);assert.equal(el('skillE').attributes['aria-disabled'],'true');h.key('KeyE');assert.equal(h.qa.skills.phase,'E_Hold');
 h.frames(60);shown('E','READY',false);h.key('KeyE');assert.equal(h.qa.skills.phase,'E_Charge');
});
test('ordinary punch updates E/R immediately and W remains independent',()=>{
 fresh();h.punch();shown('E','PUNCHING',true);shown('R','PUNCHING',true);shown('W','READY',false);h.key('ShiftLeft');assert.equal(h.qa.skills.boost,4);
 h.frames(120);shown('E','READY',false);shown('R','READY',false);
});
test('E held charge still permits an R override and returns to E without new cooldown or damage',()=>{
 fresh();h.key('KeyE');h.frames(53);shown('R','READY',false);h.key('KeyR');assert.equal(h.qa.skills.phase,'R_Cast');h.frames(70);assert.equal(h.qa.skills.phase,'E_Hold');assert.equal(h.qa.skills.metrics.discharges,1);
});
test('combo prerequisites and retry wait match accepted inputs without changing routes',()=>{
 fresh(true);shown('R','E FIRST',true);h.key('KeyR');assert.equal(h.qa.comboPractice.attempts,0);h.key('KeyE');h.frames(53);shown('R','READY',false);
 h.frames(680);assert.equal(h.qa.comboPractice.phase,'failed');shown('E','RETRY WAIT',true);shown('R','RETRY WAIT',true);h.key('KeyE');assert.equal(h.qa.comboPractice.attempts,1);
 h.frames(120);shown('E','READY',false);shown('R','E FIRST',true);h.key('KeyQ');assert.equal(h.qa.comboPractice.route,'qer');
});
test('pause and recapture update W/E/R before another animation tick',()=>{
 fresh();h.game.pause();for(const k of 'WER')shown(k,'PAUSED',true);h.game.resume();for(const k of 'WER')shown(k,'READY',false);
 document.pointerLockElement=null;h.game.updateHud();for(const k of 'WER')shown(k,'CAPTURE MOUSE',true);h.key('KeyE');assert.equal(h.qa.skills.phase,null);
 document.pointerLockElement=el('game');h.docListeners.pointerlockchange();for(const k of 'WER')shown(k,'READY',false);
});
test('readiness queries are pure and cast rejection uses the same controller gate',()=>{
 fresh();const controller=h.game.data.skills,before=controller.status;
 for(let n=0;n<50;n++)for(const k of 'WER')assert.equal(controller.blockReason(k),null);assert.deepEqual(controller.status,before);
 assert.equal(controller.blockReason('E',{busy:true}),'busy');assert.equal(controller.castE({busy:true}),false);assert.deepEqual(controller.status,before);
 h.key('KeyE');assert.equal(controller.blockReason('R'),'casting');assert.equal(controller.castR(),false);
});
test('touch uses compact Korean reasons and keeps native accessible action activation',()=>{
 fresh();h.docListeners.pointerdown({pointerType:'touch'});h.key('KeyQ');shown('E','그랩 중',true);shown('R','그랩 중',true);h.frames(180);
 el('skillE').onclick({detail:0});shown('R','시전 중',true);h.frames(53);shown('R','준비',false);el('skillR').onclick({detail:0});assert.equal(h.qa.skills.phase,'R_Cast');
 fresh(true);shown('R','주먹 먼저',true);h.game.pause();shown('E','일시정지',true);
});
