import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
test('successful menu, running, paused, results, and context recovery never activate fatal retry',async()=>{
 let calls=0;
 const r=await createGameplayHarness({sourcePath:new URL(process.env.STARTUP_SOURCE||'../main.js',import.meta.url)});
 globalThis.location={reload(){calls++;}};
 const button=r.element('startupretry');
 function check(state){assert.equal(r.qa.state,state);assert.equal(button.hidden,true);assert.equal(button.disabled,true);assert.equal(typeof button.onclick,'function');button.onclick();assert.equal(calls,0);}
 check('menu');
 r.element('game').listeners.webglcontextlost({preventDefault(){}});check('menu');r.element('game').listeners.webglcontextrestored();check('menu');
 r.game.begin(true);check('running');r.game.pause();check('paused');r.game.resume();check('running');
 r.element('game').listeners.webglcontextlost({preventDefault(){}});check('paused');r.element('game').listeners.webglcontextrestored();check('paused');
 r.game.resume();check('running');r.game.finish();check('results');
 r.element('mainmenu').onclick();check('menu');r.frames(3);check('menu');
});
