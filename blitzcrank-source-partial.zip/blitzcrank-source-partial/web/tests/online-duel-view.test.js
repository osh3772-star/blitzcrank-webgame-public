import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import * as RealThree from '../vendor/three.module.js';
import {createOnlineView} from '../online-duel-view.js';import {createOnlineDuelWorld} from '../online-duel-world.js';import {makeInput,ONLINE_ACTIONS as A} from '../online-duel-protocol.js';
class Renderer{constructor(){this.shadowMap={};}setPixelRatio(){}setSize(){}render(scene,camera){scene.updateMatrixWorld();camera.updateMatrixWorld();scene.traverse(o=>{assert(o.matrixWorld.elements.every(Number.isFinite),'finite displayed transforms');});Renderer.observe?.(scene,camera);if(Renderer.fail)throw Error('mock render failure');}}
class TextureLoader{async loadAsync(p){assert(fs.existsSync(new URL('../'+p,import.meta.url)));return new RealThree.Texture();}}
globalThis.innerWidth=1280;globalThis.innerHeight=720;globalThis.devicePixelRatio=1;
globalThis.fetch=async p=>({ok:true,arrayBuffer:async()=>{const b=fs.readFileSync(new URL('../'+p,import.meta.url));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);}});
const sounds=[],audioState={paused:true};const audio={unlock:async()=>true,setPaused:v=>audioState.paused=v,playEvent:(name,options)=>{sounds.push({name,options});return true;},playTone:()=>true};
let now=0;
const view=await createOnlineView({}, {now:()=>now,createAudio:()=>audio,THREE:{...RealThree,WebGLRenderer:Renderer,TextureLoader}});
test('actual shared model and eight authored W/E/R clips build two independently posed humans',()=>{const data=view.inspect();assert.equal(data.actorCount,2);assert.equal(data.parts,279);assert.equal(data.clips.length,8);assert.equal(data.obstacles,10);});
test('host uses actual avatar palm sockets, Q pull and skill state produce finite world matrices',()=>{
 const session='online_view_actual_fixture',world=createOnlineDuelWorld({session,skillClips:view.skillClips,obstacles:view.obstacles,socketProvider:(id,a)=>view.socket(id,a),aimMode:'third',countdownMs:0});world.setReady('human',true);world.setReady('bot',true);let seq=0;
 function input(actions=0,z=0){const s=world.snapshot(),a=s.actors.human.position,b=s.actors.bot.position,dx=b.x-a.x,dz=b.z-a.z,d=Math.hypot(dx,dz),yaw=Math.atan2(-dx,-dz)+Math.asin(.9/d),pitch=-Math.asin(.8/Math.sqrt(d*d-.81));assert(world.submit('human',makeInput({...world.scope,seq:seq++,actions,z,yaw,pitch})));}
 for(let i=0;i<30;i++){input(0,-1);world.step();view.show(world.snapshot());world.drainEvents();view.render();}
 input(A.Q);
 let scored=false;for(let i=0;i<260;i++){world.step();const s=world.snapshot();view.show(s);world.drainEvents();view.render();if(s.match.scores[0].points)scored=true;}
 assert(scored,'actual palm launch hits opponent and awards after pull');
 for(let i=0;i<125;i++){input(0,-1);world.step();view.show(world.snapshot());world.drainEvents();}
 input(A.R);for(let i=0;i<80;i++){world.step();view.show(world.snapshot());world.drainEvents();view.render();}
 assert.equal(world.snapshot().match.scores[0].points,2);
});

test('new-room presentation reset clears old event ids and reuses the same model resources',()=>{const session='online_reset_view_fixture',world=createOnlineDuelWorld({session,skillClips:view.skillClips,countdownMs:0});world.setReady('human',true);world.setReady('bot',true);const s=world.snapshot();s.events=[{serial:999,type:'cast',id:'human',skill:'W'}];view.show(s);const before=view.inspect();assert.equal(before.lastEvent,999);view.reset();const after=view.inspect();assert.equal(after.lastEvent,0);assert.equal(after.lastTick,-1);assert.equal(after.parts,before.parts);assert.equal(after.actorCount,2);assert(audioState.paused);s.events=[{serial:1,type:'cast',id:'human',skill:'R'}];view.show(s);assert.equal(view.inspect().lastEvent,1);assert(!audioState.paused);});
test('online R uses the existing recorded staticCast cue once per event, including after new connection',()=>{const world=createOnlineDuelWorld({session:'online_audio_reset_fixture',skillClips:view.skillClips,countdownMs:0});world.setReady('human',true);world.setReady('bot',true);const s=world.snapshot();view.reset();sounds.length=0;s.events=[{serial:1,type:'cast',id:'bot',skill:'R'}];view.show(s);view.show(s);assert.equal(sounds.filter(x=>x.name==='staticCast').length,1);view.reset();view.show(s);assert.equal(sounds.filter(x=>x.name==='staticCast').length,2);assert(sounds.every(x=>x.options?.emitter==='bot'));});

function smoothingState(){const w=createOnlineDuelWorld({session:'smoothing_view_fixture_0001',skillClips:view.skillClips,countdownMs:0});w.setReady('human',true);w.setReady('bot',true);return w.snapshot();}
test('real model render positions smooth a 20 Hz remote walk, but authority and local player remain exact',()=>{
 const compare=[];for(const enabled of [false,true]){view.reset();now=0;let latest=smoothingState(),sceneRef;const rendered=[];
 Renderer.observe=(scene,camera)=>{sceneRef=scene;const remote=scene.getObjectByName('Online visual offset human'),local=scene.getObjectByName('Online visual offset bot');rendered.push({x:remote.children[0].matrixWorld.elements[12],local:local.children[0].matrixWorld.elements.slice(),camera:camera.matrixWorld.elements.slice()});};
 view.show(latest,'bot',{remoteSmoothing:enabled});view.render();
 for(let t=1;t<=60;t++){now=t*1000/60;if(t%3===0){latest=structuredClone(latest);latest.tick=t;latest.actors.human.position.x=t*.1;latest.actors.human.velocity.x=6;view.show(latest,'bot',{remoteSmoothing:enabled});}const before=structuredClone(latest);view.render();assert.deepEqual(latest,before);const wrapper=sceneRef.getObjectByName('Online visual offset human');assert.deepEqual(wrapper.matrix.elements,new RealThree.Matrix4().elements);assert.equal(wrapper.children[0].matrixWorld.elements[12],latest.actors.human.position.x);assert.deepEqual(rendered.at(-1).local,rendered[0].local);assert.deepEqual(rendered.at(-1).camera,rendered[0].camera);}
 const diffs=rendered.slice(1).map((p,i)=>p.x-rendered[i].x);compare.push({max:Math.max(...diffs),zeros:diffs.filter(x=>x===0).length});}
 Renderer.observe=null;assert(compare[0].max>.29);assert(compare[1].max<.111);assert(compare[1].zeros<compare[0].zeros/2);
});
test('render exceptions restore the identity visual parent and authoritative hand sockets',()=>{
 view.reset();now=0;const s=smoothingState();view.show(s,'bot',{remoteSmoothing:true});view.render();s.tick=3;s.actors.human.position.x=.3;now=50;view.show(s,'bot',{remoteSmoothing:true});const before=view.socket('human',s.actors.human);let parent;
 Renderer.observe=scene=>{parent=scene.getObjectByName('Online visual offset human');assert.notDeepEqual(parent.matrix.elements,new RealThree.Matrix4().elements);};Renderer.fail=true;
 try{assert.throws(()=>view.render(),/mock render failure/);}finally{Renderer.fail=false;Renderer.observe=null;}
 assert.deepEqual(parent.matrix.elements,new RealThree.Matrix4().elements);assert.deepEqual(view.socket('human',s.actors.human),before);
});
test('Flash, pause and new-room view boundaries immediately discard the old remote path',()=>{
 view.reset();now=0;const s=smoothingState();view.show(s,'bot',{remoteSmoothing:true});view.render();s.tick=3;s.actors.human.position.x=.3;now=50;view.show(s,'bot',{remoteSmoothing:true});view.render();
 s.tick=4;s.actors.human.position.x=4;s.events=[{serial:5,type:'cast',id:'human',skill:'FLASH'}];now=1000/15;view.show(s,'bot',{remoteSmoothing:true});Renderer.observe=scene=>assert.deepEqual(scene.getObjectByName('Online visual offset human').matrix.elements,new RealThree.Matrix4().elements);view.render();
 s.paused=true;now+=10;view.show(s,'bot',{remoteSmoothing:true});view.render();view.reset();assert.equal(view.inspect().remoteSmoothing.samples,0);Renderer.observe=null;
});

test('both real avatar views render slow W through packet gaps and exact pause without new geometry',()=>{
 view.reset();Renderer.observe=null;const session='slow_W_actual_view_fixture',world=createOnlineDuelWorld({session,skillClips:view.skillClips,obstacles:view.obstacles,socketProvider:(id,a)=>view.socket(id,a),countdownMs:0});world.setReady('human',true);world.setReady('bot',true);
 for(const id of ['human','bot'])assert(world.submit(id,makeInput({...world.scope,seq:0,actions:A.W,yaw:id==='human'?0:Math.PI})));
 const before=view.inspect(),seen=new Set();for(let f=0;f<380;f++){world.step();const state=world.snapshot();if(f%3===0||f===379){view.show(state,'bot',{remoteSmoothing:true});world.drainEvents();view.render();}for(const a of Object.values(state.actors))if(a.skills.animation)seen.add(a.skills.animation.name);if(f===270){world.pause();const frozen=world.snapshot();for(let i=0;i<20;i++){world.step();view.show(world.snapshot());view.render();}assert.deepEqual(world.snapshot(),frozen);world.setReady('human',true);world.setReady('bot',true);}}
 assert.deepEqual([...seen],['W_Start','W_Loop','W_Loop_Slow','W_End']);assert.equal(view.inspect().parts,before.parts);assert.equal(view.inspect().actorCount,2);assert(world.snapshot().actors.human.skills.animation===null);assert(world.snapshot().actors.bot.skills.animation===null);
});

test('online R recovery animates both original arm rigs before the cast ends and freezes while paused',()=>{
 view.reset();Renderer.observe=null;const world=createOnlineDuelWorld({session:'r_recovery_online_fixture',skillClips:view.skillClips,obstacles:view.obstacles,countdownMs:0});world.setReady('human',true);world.setReady('bot',true);
 for(const id of ['human','bot'])assert(world.submit(id,makeInput({...world.scope,seq:0,actions:A.R,z:-1,yaw:id==='human'?0:Math.PI})));
 let seen=false,last;Renderer.observe=scene=>{const a=scene.getObjectByName('Online visual offset human').children[0],b=scene.getObjectByName('Online visual offset bot').children[0];last=[a,b].map(x=>x.getObjectByName('BC_Pivot_Shoulder.R').rotation.x);};
 for(let f=0;f<58;f++){for(const id of ['human','bot'])assert(world.submit(id,makeInput({...world.scope,seq:f+1,z:-1,yaw:id==='human'?0:Math.PI})));world.step();view.show(world.snapshot());world.drainEvents();view.render();if(f>44&&last.every(x=>Math.abs(x)>1e-4))seen=true;}assert(seen);world.pause();const before=last.slice();for(let f=0;f<10;f++){world.step();view.show(world.snapshot());view.render();assert.deepEqual(last,before);}Renderer.observe=null;
});

test('online E strike recovery animates both arms after impact and freezes exactly while paused',()=>{
 view.reset();Renderer.observe=null;const world=createOnlineDuelWorld({session:'e_recovery_online_fixture',skillClips:view.skillClips,obstacles:view.obstacles,countdownMs:0});world.setReady('human',true);world.setReady('bot',true);let last,seen=false;
 Renderer.observe=scene=>{last=['human','bot'].map(id=>scene.getObjectByName('Online visual offset '+id).children[0].getObjectByName('BC_Pivot_Shoulder.R').rotation.toArray().slice(0,3));};
 for(let f=0;f<126;f++){for(const id of ['human','bot'])assert(world.submit(id,makeInput({...world.scope,seq:f,actions:f===0?A.E:f===54?A.PUNCH:0,x:1,yaw:id==='human'?0:Math.PI})));world.step();const s=world.snapshot();view.show(s);world.drainEvents();view.render();if(f>102&&last.every(x=>Math.hypot(...x)>1e-4)){assert.equal(s.actors.human.skills.phase,'E_Strike');assert.equal(s.actors.bot.skills.phase,'E_Strike');seen=true;}}assert(seen);world.pause();const before=last.slice();for(let f=0;f<10;f++){world.step();view.show(world.snapshot());view.render();assert.deepEqual(last,before);}Renderer.observe=null;
});
