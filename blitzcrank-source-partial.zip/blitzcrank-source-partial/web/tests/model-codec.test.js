import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {gzipSync, gunzipSync} from 'node:zlib';
import {encodeModelData, decodeModelBuffer, loadPlayerModel, hasModelMagic} from '../model-codec.js';

function fixture() {
  const pose = {p: [-0, Math.PI, 1e-12], q: [0, 0, 0, 1], s: [1, 1, 1]};
  const part = {name: 'part', sourcePart: 'source', color: [1, .3, .1, 1], material: {name: 'paint', roughness: .53}, vertices: [0, 0, 0, 1.123456789, 0, 0, 0, 1, 0], normals: [0, 0, 1, 0, 0, 1, 0, 0, 1], uvs: [0, 0, 1, 0, 0, 1], triangles: [0, 1, 2]};
  return {source: 'test', parts: [part, {...part, name: 'second'}], nodes: [{name: 'root', parent: null, position: [-0, 1, 2]}], clips: [{name: 'Idle', fps: 30, duration: 1, loop: true, frames: [{poses: [pose, pose]}, {poses: [pose, pose]}]}]};
}
const entry = {raw: '/model.hash.bin', gzip: '/model.hash.bin.gz'};
const response = bytes => new Response(bytes, {status: 200});

test('preserves source metadata, Float32 GPU geometry and exact Float64 poses', () => {
  const source = fixture(), bytes = encodeModelData(source), result = decodeModelBuffer(bytes);
  assert.equal(hasModelMagic(bytes), true); assert.equal(result.source, source.source);
  assert.deepEqual(result.nodes, source.nodes);
  for (let i = 0; i < source.parts.length; i++) {
    assert.equal(result.parts[i].name, source.parts[i].name);
    assert.equal(result.parts[i].sourcePart, source.parts[i].sourcePart);
    assert.deepEqual(result.parts[i].material, source.parts[i].material);
    for (const key of ['vertices', 'normals', 'uvs']) assert.deepEqual(result.parts[i][key], new Float32Array(source.parts[i][key]));
    assert.deepEqual(result.parts[i].triangles, new Uint16Array(source.parts[i].triangles));
  }
  assert.equal(result.parts[0].vertices.buffer, bytes.buffer);
  assert.equal(result.parts[0].vertices, result.parts[1].vertices);
  assert.equal(result.parts[0].triangles, result.parts[1].triangles);
  const pose = result.clips[0].frames[0].poses[0];
  assert.equal(pose, result.clips[0].frames[1].poses[1]);
  assert.equal(Object.is(pose.p[0], -0), true);
  assert.deepEqual(pose.p, new Float64Array(source.clips[0].frames[0].poses[0].p));
});

test('decoder accepts offset typed-array input and rejects invalid/truncated headers', () => {
  const bytes = encodeModelData(fixture()), offset = new Uint8Array(bytes.length + 3); offset.set(bytes, 3);
  assert.equal(decodeModelBuffer(offset.subarray(3)).parts.length, 2);
  assert.throws(() => decodeModelBuffer(new Uint8Array([1, 2, 3])), /header/);
  assert.throws(() => decodeModelBuffer(bytes.subarray(0, bytes.length - 1)), /length/);
  const badVersion = bytes.slice(); new DataView(badVersion.buffer).setUint32(4, 999, true);
  assert.throws(() => decodeModelBuffer(badVersion), /version/);
});

function mutateMetadata(bytes, change) {
  const header = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), length = header.getUint32(8, true), oldBase = Math.ceil((16 + length) / 8) * 8;
  const metadata = JSON.parse(new TextDecoder().decode(bytes.subarray(16, 16 + length))); change(metadata);
  const json = new TextEncoder().encode(JSON.stringify(metadata)), base = Math.ceil((16 + json.length) / 8) * 8, output = new Uint8Array(base + bytes.length - oldBase);
  output.set(bytes.subarray(0, 16)); new DataView(output.buffer).setUint32(8, json.length, true); output.set(json, 16); output.set(bytes.subarray(oldBase), base); return output;
}

test('rejects reference bounds, alignment, wrong attribute types and malformed poses', () => {
  const bytes = encodeModelData(fixture());
  for (const change of [m => {m.model.parts[0].vertices.offset = 2 ** 32;}, m => {m.model.parts[0].vertices.offset = 1;}, m => {m.model.parts[0].vertices.type = 'f64';}, m => {m.model.clips[0].frames[0].poses.length = 1;}, m => {m.poseTable.length = 11;}]) {
    assert.throws(() => decodeModelBuffer(mutateMetadata(bytes, change)), /Player model:/);
  }
});

test('encoder rejects invalid geometry and unsupported pose data instead of truncating', () => {
  const source = fixture(); source.parts[0].triangles[1] = 70000;
  assert.throws(() => encodeModelData(source), /triangle index/);
  const badFloat = fixture(); badFloat.parts[0].vertices[0] = Infinity;
  assert.throws(() => encodeModelData(badFloat), /non-finite/);
  const extraPose = fixture(); extraPose.clips[0].frames[0].poses[0].extra = 'unsupported';
  assert.throws(() => encodeModelData(extraPose), /pose schema/);
});

test('loader uses compressed asset and also accepts server-decoded model magic', async () => {
  const bytes = encodeModelData(fixture());
  for (const body of [gzipSync(bytes), bytes]) {
    let request;
    const model = await loadPlayerModel(entry, {fetchImpl: async (...args) => {request = args; return response(body);}});
    assert.equal(request[0], entry.gzip); assert.equal(request[1].cache, 'force-cache'); assert.equal(model.parts.length, 2);
  }
});

test('loader falls back directly to raw asset where decompression is unsupported', async () => {
  for (const DecompressionStreamImpl of [null, class {constructor() {throw new TypeError('gzip unsupported');}}]) {
    let url;
    const model = await loadPlayerModel(entry, {DecompressionStreamImpl, fetchImpl: async requested => {url = requested; return response(encodeModelData(fixture()));}});
    assert.equal(url, entry.raw); assert.equal(model.parts.length, 2);
  }
});

test('loader reports HTTP, fetch rejection, malformed encoding and decompression errors', async () => {
  await assert.rejects(loadPlayerModel(entry, {fetchImpl: async () => new Response('', {status: 404})}), /HTTP 404/);
  await assert.rejects(loadPlayerModel(entry, {fetchImpl: async () => {throw new Error('network down');}}), /network down/);
  await assert.rejects(loadPlayerModel(entry, {fetchImpl: async () => response(new Uint8Array([1, 2, 3]))}), /encoding/);
  await assert.rejects(loadPlayerModel(entry, {fetchImpl: async () => response(new Uint8Array([31, 139, 0, 0]))}), /decompression/);
  await assert.rejects(loadPlayerModel({...entry, bytes: 10}, {fetchImpl: async () => response(encodeModelData(fixture()))}), /manifest byte length/);
});

test('generated assets exactly match every original geometry and animation value', async () => {
  const {PLAYER_MODELS} = await import('../player-model-manifest.js');
  for (const name of ['viewmodel', 'fullbody']) {
    const source = JSON.parse(fs.readFileSync(new URL(`../assets/blitz-${name}.json`, import.meta.url)));
    const item = PLAYER_MODELS[name], raw = fs.readFileSync(new URL('../' + item.raw.slice(2), import.meta.url));
    const zipped = fs.readFileSync(new URL('../' + item.gzip.slice(2), import.meta.url));
    assert.equal(raw.length, item.bytes); assert.equal(zipped.length, item.gzipBytes); assert.deepEqual(gunzipSync(zipped), raw);
    const model = decodeModelBuffer(raw);
    assert.equal(model.parts.length, source.parts.length); assert.deepEqual(model.nodes, source.nodes);
    for (const key of Object.keys(source).filter(key => key !== 'parts' && key !== 'clips')) assert.deepEqual(model[key], source[key]);
    for (let i = 0; i < source.parts.length; i++) {
      const original = source.parts[i], restored = model.parts[i];
      for (const key of Object.keys(original)) {
        if (['vertices', 'normals', 'uvs'].includes(key)) assert.deepEqual(restored[key], new Float32Array(original[key]));
        else if (key === 'triangles') assert.deepEqual(restored[key], new Uint16Array(original[key]));
        else assert.deepEqual(restored[key], original[key]);
      }
    }
    if (source.clips) for (let c = 0; c < source.clips.length; c++) {
      for (const key of Object.keys(source.clips[c]).filter(key => key !== 'frames')) assert.deepEqual(model.clips[c][key], source.clips[c][key]);
      for (let f = 0; f < source.clips[c].frames.length; f++) for (let p = 0; p < source.parts.length; p++) for (const key of ['p', 'q', 's']) assert.deepEqual(model.clips[c].frames[f].poses[p][key], new Float64Array(source.clips[c].frames[f].poses[p][key]));
    }
  }
});
