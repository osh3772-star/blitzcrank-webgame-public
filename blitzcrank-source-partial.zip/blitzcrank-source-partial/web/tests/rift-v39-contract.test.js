import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {createHash,webcrypto} from 'node:crypto';
import * as THREE from '../vendor/three.module.js';
import {MAP_STUDY,MAP_STUDY_V39,selectMapStudy,assertMapStudy} from '../rift-v39-revisions.js';
import {createMapProbe} from '../rift-v39-study.js';
import {createPlanarTrial} from '../rift-v39-planar.js';import {createMapHookCollider,createMapHookTrial} from '../rift-v39-hook.js';import {createPullBodyCollider,createMapPullTrial} from '../rift-v39-pull.js';import {createMapFlashAdapter} from '../rift-v39-flash.js';
import {createStudyLoader,disposeMapScene} from '../rift-v39-loader.js';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex'),layout=JSON.parse(read(MAP_STUDY.collision)),v39=JSON.parse(read(MAP_STUDY_V39.collision)),opts={study:MAP_STUDY_V39};
test('only exact registered manifests and exact revisions are accepted',()=>{
 assert.equal(selectMapStudy(),MAP_STUDY);assert.equal(selectMapStudy('0.39'),MAP_STUDY_V39);assert(Object.isFrozen(MAP_STUDY_V39));
 for(const bad of ['0.21','0.35','0.37',36,null])assert.throws(()=>selectMapStudy(bad));
 for(const study of [{...MAP_STUDY_V39},{...MAP_STUDY},{revision:'0.39'},null]){assert.throws(()=>assertMapStudy(study));assert.throws(()=>createMapProbe(v39,{study}));}
 for(const create of [createMapProbe,createPlanarTrial,createMapHookCollider,createMapHookTrial,createPullBodyCollider,createMapPullTrial,createMapFlashAdapter]){
  assert.throws(()=>create(v39));assert.throws(()=>create(layout,opts));assert.throws(()=>create(v39,{study:{...MAP_STUDY_V39}}));assert.doesNotThrow(()=>create(v39,opts));
 }
});
test('v39 pins every byte and never relabels the collision or observational record',()=>{
 for(const [path,hash] of [[MAP_STUDY_V39.glb,MAP_STUDY_V39.glbSHA],[MAP_STUDY_V39.collision,MAP_STUDY_V39.collisionSHA],[MAP_STUDY_V39.record,MAP_STUDY_V39.recordSHA]])assert.equal(sha(read(path)),hash);
 const record=JSON.parse(read(MAP_STUDY_V39.record));assert.equal(record.sourceVersion,'0.39');assert.equal(record.gameSource.sourceGameMainSHA,'73636a10f157d5ab3733e7e4ae173747ba7a3e85b1413b345e887cd3b7e2959e');assert.equal(record.gameSource.mainExecuted,false);assert.equal(record.gameSource.executedModuleSHA['online-duel-world.js'],sha(read('online-duel-world.js')));assert.equal(record.gameSource.skillAsset.sha256,sha(read(record.gameSource.skillAsset.path)));assert.match(record.observedAtUTC,/^2026-11-08T/);assert.equal(record.sourceGLBSHA,MAP_STUDY_V39.glbSHA);assert.equal(record.sourceCollisionSHA,MAP_STUDY_V39.collisionSHA);assert.equal(record.summary.spawnProbes[1].studyCollision,'wall_poly_13');assert.equal(record.summary.verticalCollisionNotIntegrated,true);
 assert(record.routes.every(r=>r.points.length===61&&r.surfaceObservations.length===61&&r.surfaceObservations.every((s,i)=>s.tick===i*4&&s.surfaces.length>0)));
 assert.deepEqual({...v39,assetVersion:layout.assetVersion},layout);assert.equal(v39.assetVersion,'sr-study-0.39');
});
test('new GLB has embedded resources only and exact unchanged official geometry counts',()=>{
 const bin=read(MAP_STUDY_V39.glb);assert.equal(bin.length,17997536);assert.equal(bin.readUInt32LE(0),0x46546c67);assert.equal(bin.readUInt32LE(4),2);assert.equal(bin.readUInt32LE(8),bin.length);
 const json=JSON.parse(bin.subarray(20,20+bin.readUInt32LE(12)));let primitives=0,triangles=0;for(const mesh of json.meshes)for(const p of mesh.primitives){primitives++;triangles+=json.accessors[p.indices].count/3;assert.equal(p.mode??4,4);}assert.equal(primitives,47);assert.equal(triangles,232998);assert.equal(json.materials.length,10);assert.equal(json.images.length,5);assert(json.buffers.every(b=>!b.uri));assert(json.images.every(i=>!i.uri&&Number.isInteger(i.bufferView)));assert.equal(json.animations?.length??0,0);assert.equal(json.skins?.length??0,0);
});
test('v39 rejects malformed collision coordinates before running shared kernels',()=>{
 for(const mutate of [l=>l.span=159,l=>l.upAxis='Z',l=>l.assetVersion='sr-study-0.37',l=>l.mapBoundaryXZ[0][0]=Infinity,l=>l.walls[0].pointsXZ[0]=[NaN,0],l=>l.baseWalls[0].minY=NaN,l=>l.propColliders[0].radius=-1,l=>l.propColliders[0].centerXZ=[0],l=>l.walls[0].maxY=-100,l=>l.rearBackdropWalls=null]){const bad=structuredClone(v39);mutate(bad);assert.throws(()=>createMapProbe(bad,opts));}
 const probe=createMapProbe(v39,opts);for(const point of [null,[],[1,2,3],[NaN,0],[0,Infinity]])assert.throws(()=>probe.probe(point));
});
test('v20 and explicit v39 probes and continuous hook/body sweeps match exactly',()=>{
 let seed=17;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/2**32*160-80);
 for(const radius of [.12,.42,.7,2]){const a=createMapProbe(layout,{radius}),b=createMapProbe(v39,{...opts,radius});for(let i=0;i<250;i++){const from=[rand(),rand()],to=[rand(),rand()];assert.deepEqual(a.probe(from,to),b.probe(from,to));}}
 for(const create of [createMapHookCollider,createPullBodyCollider]){const a=create(layout),b=create(v39,opts);for(const [from,to] of [[[-8,0],[8,0]],[[0,6],[0,-20]],[[0,-12],[0,0]],[[75,75],[85,85]],[[-70,0],[70,0]]])assert.deepEqual(a.sweep(from,to),b.sweep(from,to));}
});
test('identical planar paths keep the same clamped movement and blocked segments',()=>{
 for(const spawn of [[-8,0],[8,0],[0,6]]){const a=createPlanarTrial(layout,{spawn}),b=createPlanarTrial(v39,{...opts,spawn});for(let i=0;i<360;i++){const input={x:Math.sin(i*.01),z:-1},dt=i%7===0?100:1/60;assert.deepEqual(a.advance(input,dt),b.advance(input,dt));}assert.deepEqual(a.reset(),b.reset());}
 assert.throws(()=>createPlanarTrial(v39,{...opts,spawn:[0,-12]}),/충돌/);
});
test('identical hook and moving-target pull scenarios retain exact states every tick',()=>{
 for(const create of [createMapHookTrial,createMapPullTrial])for(const target of [[8,0],[0,-15],[0,-12]]){
  const a=create(layout),b=create(v39,opts),input={origin:[-8,0],aim:target,targets:[{id:'marker',center:target,radius:.7,velocity:[0,2]}]};assert.deepEqual(a.cast(input),b.cast(input));
  for(let i=0;i<120;i++)assert.deepEqual(a.step(1/60,{home:[-8,0]}),b.step(1/60,{home:[-8,0]}));assert.deepEqual(a.cancel(),b.cancel());
 }
});
test('both Flash policies retain exact rejection, range and boundary behavior',()=>{
 const a=createMapFlashAdapter(layout),b=createMapFlashAdapter(v39,opts);
 for(const policy of ['clear-path','landing-only','invalid'])for(const origin of [[-8,0],[0,-8],[0,-12],[78,0]])for(const aim of [[0,0],[0,-12],[90,0],[-7.95,0],[NaN,0]])assert.deepEqual(a.resolve({origin,aim,policy}),b.resolve({origin,aim,policy}));
});
test('scene cleanup disposes shared resources and closes each image exactly once',()=>{
 const scene=new THREE.Scene(),geometry=new THREE.BoxGeometry(),image={width:1,height:1,close(){count.image++;}},texture=new THREE.Texture(image),material=new THREE.MeshStandardMaterial({map:texture});const count={geometry:0,material:0,texture:0,image:0};for(const [key,item] of Object.entries({geometry,material,texture}))item.addEventListener('dispose',()=>count[key]++);scene.add(new THREE.Mesh(geometry,material),new THREE.Mesh(geometry,material));disposeMapScene(scene);assert.deepEqual(count,{geometry:1,material:1,texture:1,image:1});
});
function mockLoad({replace=null,digestOverride=false,parse=async()=>({scene:new THREE.Scene()}),fail=null,dispose}={}){
 let fetches=0,parses=0;const cryptoImpl=digestOverride?{subtle:{async digest(_,bytes){const text=new TextDecoder().decode(bytes);const hash=text.startsWith('{')?(text.includes('sourceGLBSHA')?MAP_STUDY_V39.recordSHA:MAP_STUDY_V39.collisionSHA):MAP_STUDY_V39.glbSHA;return Uint8Array.from(Buffer.from(hash,'hex')).buffer;}}}:webcrypto;
 const loader=createStudyLoader({cryptoImpl,dispose,fetchImpl:async url=>{fetches++;if(fail)return{ok:false,status:fail};const path=url.pathname.split('/candidate/')[1];let bytes=read(path);if(replace)bytes=replace(path,bytes);return{ok:true,arrayBuffer:async()=>bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)};},parse:async bytes=>{parses++;return parse(bytes);}});return{loader,get fetches(){return fetches;},get parses(){return parses;}};
}
test('loader enforces revision and coordinates even if a hypothetical digest service claims valid bytes',async()=>{
 for(const mutate of [l=>l.assetVersion='sr-study-0.20',l=>l.upAxis='Z',l=>l.span=80,l=>l.walls[0].pointsXZ=[[0],[1],[2]]]){const f=mockLoad({digestOverride:true,replace:(path,b)=>{if(!path.includes('collision.'))return b;const l=JSON.parse(b);mutate(l);return Buffer.from(JSON.stringify(l));}});await assert.rejects(f.loader.load(MAP_STUDY_V39));assert.equal(f.parses,0);}
 const f=mockLoad({digestOverride:true,replace:(path,b)=>path.includes('game-probes')?Buffer.from(JSON.stringify({...JSON.parse(b),sourceGLBSHA:MAP_STUDY.glbSHA})):b});await assert.rejects(f.loader.load(MAP_STUDY_V39),/provenance/);assert.equal(f.parses,0);
});
test('HTTP failure and parse failure surface explicitly; invalid manifest makes zero requests',async()=>{
 const bad=mockLoad();await assert.rejects(bad.loader.load({...MAP_STUDY_V39}),/Registered/);assert.equal(bad.fetches,0);
 const http=mockLoad({fail:404});await assert.rejects(http.loader.load(MAP_STUDY_V39),/404/);assert.equal(http.parses,0);
 const parse=mockLoad({parse:async()=>{throw Error('parse failed');}});await assert.rejects(parse.loader.load(MAP_STUDY_V39),/parse failed/);await assert.rejects(parse.loader.load(MAP_STUDY_V39),/parse failed/);assert.equal(parse.parses,2);
});
test('late parse is disposed once and cannot replace a later successful load',async()=>{
 let release,started;const entered=new Promise(r=>started=r),gate=new Promise(r=>release=r),old=new THREE.Scene(),fresh=new THREE.Scene(),disposed=[];let calls=0;
 const f=mockLoad({dispose:s=>disposed.push(s),parse:async()=>{if(++calls===1){started();await gate;return{scene:old};}return{scene:fresh};}});
 const first=f.loader.load(MAP_STUDY_V39);await entered;f.loader.cancel();const second=await f.loader.load(MAP_STUDY_V39);release();assert.equal(await first,null);assert.equal(second.gltf.scene,fresh);assert.deepEqual(disposed,[old]);
});
