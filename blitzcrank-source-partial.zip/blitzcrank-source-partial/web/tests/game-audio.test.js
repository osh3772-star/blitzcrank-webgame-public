import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createGameAudio} from '../game-audio.js';
import {AUDIO_CUES, AUDIO_EVENTS} from '../audio-cues.js';

function harness(options = {}) {
  const sources = [], fetched = [], errors = [], gains = [];
  const node = () => ({connect(){},disconnect(){this.disconnected=true;}});
  const context = {
    state: 'suspended', currentTime: 1, destination: {},
    resume(){this.state='running';return Promise.resolve();},
    close(){this.state='closed';return Promise.resolve();},
    createGain(){const result={...node(),gain:{value:1,cancelScheduledValues(){},setValueAtTime(v){this.value=v;}}};gains.push(result);return result;},
    createBufferSource(){const result={...node(),stop(){this.stopped=true;this.onended?.();},start(...args){this.started=args;}};sources.push(result);return result;},
    decodeAudioData(){return Promise.resolve({duration:.57});},
  };
  const audio = createGameAudio({createContext:()=>context,fetchImpl:async url=>{fetched.push(url);return {ok:true,arrayBuffer:async()=>new ArrayBuffer(1)};},onError:(e,id)=>errors.push({e,id}),...options});
  return {audio,context,sources,fetched,errors,gains};
}

test('waits for trusted unlock and drops events before ready', async()=>{
  const h=harness();assert.equal(h.audio.playEvent('hookWindup'),false);assert.equal(h.fetched.length,0);
  assert.equal(await h.audio.unlock(),true);assert.equal(h.audio.status.context,'running');assert.equal(h.audio.status.ready.length,2);
  assert.equal(h.sources.length,0);assert.equal(h.audio.playEvent('hookWindup'),true);
});
test('concurrent unlocks share preload and repeated unlock does not refetch',async()=>{
  const h=harness();await Promise.all([h.audio.unlock(),h.audio.unlock()]);await h.audio.unlock();assert.equal(h.fetched.length,2);
});
test('only exact mapped events can play, never a full Q montage or voice',async()=>{
  const h=harness();await h.audio.unlock();
  for(const event of ['hookHit','hookMiss','capture','punch','punchMiss','voice','start','victory','defeat'])assert.equal(h.audio.playEvent(event),false,event);
  assert.deepEqual(Object.keys(AUDIO_EVENTS).sort(),['hookWindup','punchHit']);
  assert.ok(Object.values(AUDIO_CUES).every(cue=>cue.maxDuration<1.1));
});
test('repeated group playback stops the earlier one, without replay queues',async()=>{
  const h=harness();await h.audio.unlock();h.audio.playEvent('hookWindup');h.audio.playEvent('hookWindup');
  assert.equal(h.sources[0].stopped,true);assert.equal(h.audio.status.active,1);assert.equal(h.sources[1].loop,false);
});
test('different semantic groups can overlap and natural end cleans up',async()=>{
  const h=harness();await h.audio.unlock();h.audio.playEvent('hookWindup');h.audio.playEvent('punchHit');assert.equal(h.audio.status.active,2);
  h.sources[0].onended();assert.equal(h.audio.status.active,1);assert.equal(h.sources[0].disconnected,true);
});
test('mute stops existing audio and unmute does not replay it',async()=>{
  const h=harness();await h.audio.unlock();h.audio.playEvent('punchHit');h.audio.setMuted(true);
  assert.equal(h.audio.status.active,0);assert.equal(h.gains[0].gain.value,0);assert.equal(h.audio.playEvent('punchHit'),false);
  h.audio.setMuted(false);assert.equal(h.audio.status.active,0);assert.equal(h.sources.length,1);
});
test('pause, menu and restart cleanup cannot leave a stale sound running',async()=>{
  const h=harness();await h.audio.unlock();h.audio.playEvent('hookWindup');h.audio.setPaused(true);
  assert.equal(h.audio.status.active,0);assert.equal(h.audio.playEvent('hookWindup'),false);
  h.audio.setPaused(false);assert.equal(h.sources.length,1);assert.equal(h.audio.playEvent('hookWindup'),true);h.audio.stopAll();assert.equal(h.audio.status.active,0);
});
test('volume is finite and clamped',async()=>{
  const h=harness();await h.audio.unlock();h.audio.setVolume(9);assert.equal(h.audio.status.volume,1);h.audio.setVolume(NaN);assert.equal(h.audio.status.volume,0);
});
test('bad fetch fails closed without breaking the game',async()=>{
  const h=harness({fetchImpl:async()=>({ok:false,status:404})});assert.equal(await h.audio.unlock(),true);assert.equal(h.errors.length,2);assert.equal(h.audio.playEvent('hookWindup'),false);
});
test('an accidentally substituted long montage is rejected',async()=>{
  const h=harness();h.context.decodeAudioData=async()=>({duration:20.25});await h.audio.unlock();assert.equal(h.errors.length,2);assert.equal(h.audio.status.ready.length,0);
});
test('unsupported or denied AudioContext reports instead of throwing',async()=>{
  const h=harness({createContext:()=>{throw new Error('unsupported');}});assert.equal(await h.audio.unlock(),false);assert.equal(h.errors.length,1);
});
test('disposed controller stops sources and never starts again',async()=>{
  const h=harness();await h.audio.unlock();h.audio.playEvent('hookWindup');h.audio.dispose();h.audio.dispose();assert.equal(h.context.state,'closed');assert.equal(h.audio.status.active,0);assert.equal(await h.audio.unlock(),false);assert.equal(h.audio.playEvent('hookWindup'),false);
});
test('loading completion after disposal cannot repopulate buffers',async()=>{
  let resolve;const decode=new Promise(r=>resolve=r),h2=harness();h2.context.decodeAudioData=()=>decode;const p2=h2.audio.unlock();await new Promise(r=>setImmediate(r));h2.audio.dispose();resolve({duration:.57});assert.equal(await p2,false);assert.equal(h2.audio.status.ready.length,0);
});
test('resume refusal is retryable without creating a second context',async()=>{
  const h=harness();h.context.resume=()=>Promise.reject(new Error('gesture required'));assert.equal(await h.audio.unlock(),false);assert.equal(h.errors.length,1);
  h.context.resume=function(){this.state='running';return Promise.resolve();};assert.equal(await h.audio.unlock(),true);assert.equal(h.gains.length,1);
});
test('source start failure leaves no active voice',async()=>{
  const h=harness();await h.audio.unlock();const create=h.context.createBufferSource;h.context.createBufferSource=()=>{const source=create();source.start=()=>{throw new Error('start');};return source;};assert.equal(h.audio.playEvent('punchHit'),false);assert.equal(h.audio.status.active,0);
});
test('staged WAV assets have exact expected identity, duration and no clipping',()=>{
  const root=new URL('../',import.meta.url);const records=JSON.parse(fs.readFileSync(new URL('assets/audio/manifest.json',root)));
  for(const r of records){const data=fs.readFileSync(new URL(r.output,root));assert.equal(data.toString('ascii',0,4),'RIFF');assert.equal(createHash('sha256').update(data).digest('hex'),r.outputSha256);assert.ok(r.durationSeconds>0&&r.durationSeconds<1.1);assert.ok(r.peakDbfs<=-5.99);const cue=Object.values(AUDIO_CUES).find(c=>c.url==='./'+r.output);assert(cue,'missing cue for '+r.id);assert(cue.maxDuration>=r.durationSeconds,'playback cap truncates '+r.id);}
});

test('priority events finish first and ordinary audio downloads stay bounded',async()=>{
 const cues={start:{url:'start',group:'voice',maxDuration:1},q:{url:'q',group:'q',maxDuration:1},a:{url:'a',group:'voice',maxDuration:1},b:{url:'b',group:'voice',maxDuration:1},c:{url:'c',group:'voice',maxDuration:1}},events={start:'start',q:'q',a:'a',b:'b',c:'c'},pending=new Map(),requested=[];
 const h=harness({cues,events,priorityEvents:['start','q'],backgroundConcurrency:2,fetchImpl:async url=>{requested.push(url);if(!['start','q'].includes(url))await new Promise(resolve=>pending.set(url,resolve));return{ok:true,arrayBuffer:async()=>new ArrayBuffer(1)};}});
 assert.equal(await h.audio.unlock(),true);await new Promise(r=>setImmediate(r));assert.deepEqual(requested,['start','q','a','b']);assert.deepEqual(h.audio.status.ready.sort(),['q','start']);pending.get('a')();await new Promise(r=>setImmediate(r));assert.deepEqual(requested,['start','q','a','b','c']);pending.get('b')();pending.get('c')();await new Promise(r=>setImmediate(r));assert.equal(h.audio.status.ready.length,5);
});
test('dispose prevents remaining background audio fetches',async()=>{
 const cues={a:{url:'a',group:'v',maxDuration:1},b:{url:'b',group:'v',maxDuration:1},c:{url:'c',group:'v',maxDuration:1}},events={a:'a',b:'b',c:'c'},requests=[];let release;
 const h=harness({cues,events,priorityEvents:[],backgroundConcurrency:1,fetchImpl:async url=>{requests.push(url);await new Promise(r=>release=r);return{ok:true,arrayBuffer:async()=>new ArrayBuffer(1)};}});await h.audio.unlock();await new Promise(r=>setImmediate(r));h.audio.dispose();release();await new Promise(r=>setImmediate(r));assert.deepEqual(requests,['a']);
});


test('actor-scoped copies of the same hook cue share one decoded buffer without cutting each other off',async()=>{
 const h=harness();await h.audio.unlock();const fetched=h.fetched.length;h.audio.playEvent('hookWindup');h.audio.playEvent('hookWindup',{emitter:'duel-bot'});
 assert.equal(h.audio.status.active,2);assert.equal(h.sources[0].stopped,undefined);assert.strictEqual(h.sources[0].buffer,h.sources[1].buffer);assert.equal(h.fetched.length,fetched);assert(h.audio.isGroupPlaying('hook'));
 h.audio.playEvent('hookWindup',{emitter:'duel-bot'});assert.equal(h.sources[1].stopped,true);assert.equal(h.sources[0].stopped,undefined);assert.equal(h.audio.status.active,2);
 h.audio.playEvent('hookWindup');assert.equal(h.sources[0].stopped,true);assert.equal(h.sources[2].stopped,undefined);assert.equal(h.audio.status.active,2);h.audio.stopAll();assert.equal(h.audio.status.active,0);
});
for(const stop of ['mute','pause','dispose'])test(`actor-scoped hook audio obeys ${stop} and never queues a replay`,async()=>{
 const h=harness();await h.audio.unlock();h.audio.playEvent('hookWindup');h.audio.playEvent('hookWindup',{emitter:'duel-bot'});
 if(stop==='mute')h.audio.setMuted(true);else if(stop==='pause')h.audio.setPaused(true);else h.audio.dispose();assert.equal(h.audio.status.active,0);assert(h.sources.every(s=>s.stopped));
 assert.equal(h.audio.playEvent('hookWindup',{emitter:'duel-bot'}),false);h.audio.setMuted(false);h.audio.setPaused(false);assert.equal(h.sources.length,2);
});
test('actor-scoped hook drops before decode and respects the existing global voice bound',async()=>{
 const h=harness({maxVoices:2});assert.equal(h.audio.playEvent('hookWindup',{emitter:'duel-bot'}),false);await h.audio.unlock();assert.equal(h.sources.length,0);
 h.audio.playEvent('hookWindup');h.audio.playEvent('hookWindup',{emitter:'duel-bot'});h.audio.playEvent('punchHit');assert.equal(h.audio.status.active,2);assert.equal(h.sources[0].stopped,true);
 assert.equal(h.audio.playEvent('hookWindup',{emitter:{}}),false);assert.equal(h.audio.status.active,2);
});
