import {capacityComparableVfxState as vfxState} from './helpers/vfx-capacity-comparison.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {createSkillVfxHarness, vfxStatus} from './helpers/skill-vfx-harness.js';

// The fixture is a verbatim copy of the independently preserved, deployed
// v0.24.5 module, not a baseline reconstructed by undoing candidate edits.
const baseline = await import(process.env.SKILL_VFX_BASELINE
  ? pathToFileURL(resolve(process.env.SKILL_VFX_BASELINE)).href
  : new URL('./fixtures/skill-vfx-v0245-baseline.js', import.meta.url).href);
const candidate = await import(process.env.SKILL_VFX_CANDIDATE
  ? pathToFileURL(resolve(process.env.SKILL_VFX_CANDIDATE)).href
  : new URL('../skill-vfx.js', import.meta.url).href);
const player = {x: 2, y: 1.7, z: -3};
let comparisons = 0;
// Preserve the historical fixture unchanged. Permit only the explicitly
// source-measured R stroke palette change; every other buffer byte still matches.
function calibratedBaseline(h){
 const state=vfxState(h),object=state.objects.find(o=>o.name==='R_ivory_branched_web');
 const colors=state.geometries[object.geometry].attributes.color.array;
 const f=hex=>new Float32Array([(hex>>16&255)/255,(hex>>8&255)/255,(hex&255)/255]);
 const replacements=[[f(0xfff5db),f(0xfffee6)],[f(0xbfeaff),f(0xf0ffe8)]];
 for(let i=0;i<colors.length;i+=3)for(const [old,next] of replacements)if(old.every((v,j)=>colors[i+j]===v)){colors.set(next,i);break;}
 return state;
}

function pair() {
  const a = createSkillVfxHarness(baseline.createSkillVfx), b = createSkillVfxHarness(candidate.createSkillVfx);
  const identity = [a, b].map(h => ({arrays: [...h.arrays], geometries: [...h.geometries], materials: [...h.materials], textures: [...h.textures]}));
  function same(label) {
    assert.deepEqual(vfxState(b), calibratedBaseline(a), label);
    for (const [i, h] of [a, b].entries()) {
      for (const key of Object.keys(identity[i])) assert(h[key].every((x, j) => x === identity[i][key][j]), `${label}: ${key} stable`);
      assert(h.geometries.flatMap(g => Object.values(g.attributes).map(attr => attr.array)).every((array, j) => array === identity[i].arrays[j]));
    }
    comparisons++;
  }
  same('construction');
  return {a, b, same,
    tick(dt, status = vfxStatus(), extra = {}) { for (const h of [a, b]) h.vfx.update(dt, {status, position: player, yaw: .4, ...extra}); same(`update ${dt} ${status?.phase}`); },
    event(type, args) { assert.deepEqual(b.vfx.event(type, args), a.vfx.event(type, args)); same(`event ${String(type)}`); },
    reset() { a.vfx.reset(); b.vfx.reset(); same('reset'); },
    dispose() { a.vfx.dispose(); b.vfx.dispose(); same('dispose'); },
  };
}

test('identical idle state, changing positions/yaw, invalid dt and restart', () => {
  const p = pair();
  for (let i = 0; i < 40; i++) p.tick(1 / 60, vfxStatus(), {position: {x: i * .2, y: 1.7, z: -i}, yaw: i * .1, thirdPerson: i % 2 === 0});
  for (const dt of [0, -1, NaN, Infinity, -Infinity, undefined]) p.tick(dt);
  p.tick(1 / 60, {}, {position: {x: NaN, y: 0, z: 0}, yaw: NaN});
  p.tick(100000); p.reset(); p.tick(1 / 60); p.dispose(); p.tick(1); p.event('power_fist_hit', {position: player}); p.reset(); p.dispose();
});

test('identical W onset, sustained boost, tail, ground traces and return to idle', () => {
  const p = pair();
  for (const boost of [4, 3.99, 3.9, 3, 1, .12, .06, .001, 0]) p.tick(1 / 30, vfxStatus(null, 0, {boost}), {moving: boost < 3, thirdPerson: boost < 1});
  for (let i = 0; i < 14; i++) p.tick(1 / 30, vfxStatus(null, 0, {slow: 2 - i / 30}));
  for (const slow of [.2, .18, .12, .01, 0, -1, NaN, Infinity]) p.tick(.1, vfxStatus(null, 0, {slow}));
  p.reset(); p.tick(.01, vfxStatus(null, 0, {boost: 4})); p.tick(1000); p.tick(.01); p.dispose();
});

test('identical E phase changes, Q/R preservation, consumed strikes, hits and misses', () => {
  const p = pair();
  for (const [phase, time, armed] of [['E_Charge', 0, 5], ['E_Charge', .06, 5], ['E_Hold', .8, 4], ['Q_Launch', .2, 3.8], ['R_Cast', .4, 3], ['E_Strike', .39, 0]]) p.tick(.03, vfxStatus(phase, time, {armed}));
  for (const h of [p.a, p.b]) { h.viewHands[1].visible = false; h.detached.visible = true; h.fullbody.visible = false; h.worldHands[0].rotation.set(.2, -.4, .1); }
  p.tick(.01, vfxStatus('Q_Launch', .4, {armed: 2}));
  p.event('power_fist_hit'); p.tick(.01, vfxStatus('E_Strike', .1));
  p.event('power_fist_hit', {position: player}); p.tick(.01, vfxStatus('E_Strike', .2));
  p.tick(.1, vfxStatus('E_Strike', .4)); p.tick(.1, vfxStatus('E_Strike', .5));
  p.tick(.1); p.tick(.01, vfxStatus('E_Strike', .1)); p.tick(.3, vfxStatus('E_Strike', .4)); p.tick(.1);
  p.reset(); p.tick(.1, vfxStatus('E_Charge', .1)); p.dispose();
});

test('identical E same-source-tick strength, cutoff, phase changes, reset, and delayed frames', () => {
  const p = pair();
  p.tick(.001, vfxStatus('E_Charge', 0));
  p.tick(.001, vfxStatus('E_Charge', .06));
  p.tick(.001, vfxStatus('E_Hold', .2, {armed: 3}));
  p.tick(.001, vfxStatus('Q_Launch', .2, {armed: 3}));
  p.tick(.001, vfxStatus('R_Cast', .2, {armed: 3}));
  p.tick(.001, vfxStatus('E_Strike', .2));
  p.event('power_fist_hit', {position: player});
  p.tick(.001, vfxStatus('E_Strike', .21));
  p.tick(.001); p.tick(.001, vfxStatus('E_Hold', .2, {armed: 3}));
  p.tick(.001, vfxStatus('E_Charge', 'invalid'));
  p.tick(.001, vfxStatus('E_Charge', .1));
  p.reset(); p.tick(.001, vfxStatus('E_Charge', .1));
  for (const dt of [1 / 120, 1 / 60, 1 / 30, .0001, 50, .0001]) p.tick(dt, vfxStatus('E_Hold', .3, {armed: 3}));
  p.dispose();
});

test('identical R field frames, flicker gaps, target pool overflow and immediate events', () => {
  const p = pair();
  p.event('static_field_target', {position: player});
  p.tick(.01);
  p.event('static_field_discharge', {position: player, groundY: -.3, targets: Array.from({length: 30}, (_, i) => ({x: i, y: 1, z: 2}))});
  for (let i = 0; i < 30; i++) p.tick(1 / 30);
  for (let i = 0; i < 26; i++) p.event('static_field_target', {position: {x: i, y: .4, z: -4}});
  p.tick(.2); p.event('static_field_discharge', {position: {x: -9, y: 2.7, z: 3}});
  for (const dt of [.5, 1 / 30, 1 / 30, .1, 1 / 30, .1, 1, 1]) p.tick(dt);
  p.dispose();
});

test('identical pause, reset during active effects and event delivery before next update', () => {
  const p = pair();
  p.event('static_field_discharge', {position: player, targets: [player]});
  p.event('power_fist_hit', {position: player});
  p.tick(.01, vfxStatus('E_Charge', .02, {boost: 4, armed: 5}));
  const before = vfxState(p.b);
  for (const dt of [0, -2, NaN, Infinity]) p.tick(dt, vfxStatus());
  assert.deepEqual(vfxState(p.b), before);
  p.event('static_field_target', {position: {x: 4, y: 3, z: 2}});
  p.event('power_fist_hit', {position: {x: 5, y: 1, z: 6}});
  p.event('static_field_discharge', {position: {x: 0, y: 1.7, z: 0}, targets: [player]});
  p.reset(); p.tick(.01); p.event('static_field_discharge', {position: player});
  p.event('power_fist_hit', {position: player}); p.tick(2000); p.tick(.1); p.reset(); p.dispose();
});

test('identical malformed event results and render callback material values', () => {
  const p = pair();
  for (const type of [undefined, null, '', 'no_such_event', 'power_fist_hit', 'static_field_target', 'static_field_discharge']) {
    for (const position of [undefined, {}, {x: NaN, y: 1, z: 0}, {x: 0, y: Infinity, z: 0}, {x: 0, y: 1, z: -Infinity}]) p.event(type, {position, targets: 'invalid', groundY: NaN});
  }
  p.event('static_field_discharge', {position: player, targets: [{}, player, null, {x: 1, y: NaN, z: 2}], groundY: Infinity});
  p.tick(.01, vfxStatus('E_Hold', .2, {armed: 3, boost: 2}));
  for (const renderer of [{getCurrentViewport(out) { out.set(20, 30, 640, 480); }}, {getCurrentViewport(out) { out.set(0, 0, 0, -2); }}, {getDrawingBufferSize(out) { out.set(1920, 1080); }}]) {
    for (const h of [p.a, p.b]) for (const o of h.owned) if (o.isMesh && o.material?.isShaderMaterial) o.onBeforeRender(renderer);
    p.same('onBeforeRender resolution');
  }
  p.reset(); p.tick(.1); p.dispose();
});

test('identical deterministic mixed action trace and resource sharing', () => {
  const p = pair(); let seed = 0x1234abcd;
  const rand = () => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) / 4294967296; };
  const phases = [null, 'E_Charge', 'E_Hold', 'E_Strike', 'Q_Launch', 'R_Cast'];
  for (let i = 0; i < 180; i++) {
    const n = rand();
    if (n < .08) p.reset();
    else if (n < .2) p.event('static_field_discharge', {position: player, targets: [player, {x: -1, y: 1, z: 3}]});
    else if (n < .35) p.event('power_fist_hit', n < .3 ? {position: player} : undefined);
    else if (n < .45) p.event('static_field_target', {position: {x: rand() * 5, y: 1, z: -4}});
    const dt = n < .05 ? 100 : n > .95 ? 0 : rand() * .15;
    p.tick(dt, vfxStatus(phases[Math.floor(rand() * phases.length)], rand(), {boost: n > .4 ? 0 : rand() * 4, slow: n < .7 ? 0 : rand() * 2, armed: n < .3 ? 0 : rand() * 5}), {moving: n < .5, thirdPerson: n > .6, position: {x: rand() * 10, y: 1.7, z: rand() * -5}, yaw: rand() * 6});
  }
  p.dispose();
});

process.on('beforeExit', () => console.log(`# Exact scene-state comparisons: ${comparisons}. Upload-version counters intentionally excluded; historical R stroke colors are translated and only proved-unused capacity suffixes are omitted; all retained buffer bytes and other render values included.`));
