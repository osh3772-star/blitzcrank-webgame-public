import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';import {GLTFLoader} from '../vendor/GLTFLoader.js';import {TARGET_MODEL_FILES,attachCharacterTarget,loadCharacterTargets} from '../target-models.js';
const read=p=>fs.readFileSync(new URL(p,import.meta.url)),fixture=JSON.parse(read('./fixtures/mage-crystal-surface.json')),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const bytes=[fixture.sourceSha256,fixture.expectedSha256].map(h=>read('../assets/targets/mage.'+h.slice(0,16)+'.glb'));
const docs=bytes.map(b=>JSON.parse(b.subarray(20,20+b.readUInt32LE(12)))),bins=bytes.map(b=>b.subarray(28+b.readUInt32LE(12)));
const gltfs=await Promise.all(bytes.map(b=>new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'')));
const meshes=g=>{const out=[];g.scene.traverse(o=>{if(o.isMesh)out.push(o);});return out;},[before,after]=gltfs.map(meshes),selected=new Set(fixture.materials.map(m=>m.name));
test('active immutable mage hash, manifest and loader agree while previous asset remains exact',async()=>{
 assert.equal(sha(bytes[0]),fixture.sourceSha256);assert.equal(sha(bytes[1]),fixture.expectedSha256);assert.equal(TARGET_MODEL_FILES.mage,'mage.'+fixture.expectedSha256.slice(0,16)+'.glb');
 const row=JSON.parse(read('../assets/targets/source-manifest.json')).find(x=>x.asset==='mage');assert.equal(row.file,TARGET_MODEL_FILES.mage);assert.equal(row.sha256,fixture.expectedSha256);assert.equal(row.bytes,bytes[1].length);assert.equal(row.triangles,2548);assert.equal(row.materials,18);
 const req=[];const loaded=await loadCharacterTargets(async url=>{req.push(url);const b=read('../'+url.slice(2));return {ok:true,arrayBuffer:async()=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)};});assert.equal(loaded.length,3);assert.equal(meshes(loaded[0]).length,18);assert.equal(req.filter(x=>x.endsWith(TARGET_MODEL_FILES.mage)).length,1);
});
test('entire embedded binary and every nonmaterial JSON field are byte/value exact',()=>{
 assert.deepEqual(bins[1],bins[0]);const clean=structuredClone(docs[1]);clean.materials=docs[0].materials;assert.deepEqual(clean,docs[0]);
 for(let i=0;i<docs[0].materials.length;i++){const a=docs[0].materials[i],b=docs[1].materials[i];if(!selected.has(a.name)){assert.deepEqual(b,a);continue;}
  const q=structuredClone(b);q.pbrMetallicRoughness.baseColorFactor=a.pbrMetallicRoughness.baseColorFactor;q.pbrMetallicRoughness.metallicFactor=a.pbrMetallicRoughness.metallicFactor;q.pbrMetallicRoughness.roughnessFactor=a.pbrMetallicRoughness.roughnessFactor;q.emissiveFactor=a.emissiveFactor;assert.deepEqual(q,a);
 }assert.equal(selected.size,4);
});
test('valid embedded-only GLB framing, finite bounded factors, no new extensions/textures',()=>{
 const b=bytes[1],d=docs[1],end=20+b.readUInt32LE(12);assert.equal(b.readUInt32LE(0),0x46546c67);assert.equal(b.readUInt32LE(4),2);assert.equal(b.readUInt32LE(8),b.length);assert.equal(b.readUInt32LE(16),0x4e4f534a);assert.equal(b.readUInt32LE(end+4),0x004e4942);assert.equal(end+8+b.readUInt32LE(end),b.length);assert.equal(d.buffers[0].byteLength,bins[1].length);assert(!d.buffers[0].uri);
 for(const k of ['skins','animations','images','textures','extensionsUsed','extensionsRequired'])assert.equal((d[k]||[]).length,0);
 for(const m of d.materials)for(const v of [...m.pbrMetallicRoughness.baseColorFactor,m.pbrMetallicRoughness.metallicFactor,m.pbrMetallicRoughness.roughnessFactor,...(m.emissiveFactor||[])])assert(Number.isFinite(v)&&v>=0&&v<=1);
});
test('actual Three loader factors equal saved Blender socket values for four existing materials',()=>{
 for(let i=0;i<before.length;i++){const a=before[i].material,b=after[i].material;assert.equal(b.name,a.name);assert.equal(b.type,'MeshStandardMaterial');
  for(const k of ['opacity','transparent','side','alphaTest','depthWrite','vertexColors','map','normalMap','roughnessMap','metalnessMap','emissiveMap'])assert.equal(b[k],a[k]);
  const row=fixture.materials.find(x=>x.name===b.name);if(row){const e=row.after;assert.deepEqual(b.color.toArray(),e['Base Color'].slice(0,3));assert.deepEqual(b.emissive.toArray(),e['Emission Color'].slice(0,3));assert.equal(b.metalness,e.Metallic);assert.equal(b.roughness,e.Roughness);assert.equal(b.emissiveIntensity,1);}else {assert.deepEqual(b.color.toArray(),a.color.toArray());assert.deepEqual(b.emissive.toArray(),a.emissive.toArray());assert.equal(b.metalness,a.metalness);assert.equal(b.roughness,a.roughness);}
 }
});
test('crystal retains diffuse response and nonzero blue emission without transparency or new shader class',()=>{
 for(const n of after.filter(n=>selected.has(n.material.name))){const m=n.material;assert(m.metalness<=.650001);assert(1-m.metalness>=.349999);assert(m.emissive.b>=.059999);assert(m.emissive.g>0);assert(m.color.r<.005);assert(m.roughness>=.299999);assert.equal(m.transparent,false);assert.equal(m.opacity,1);}
});
test('all 18 loaded geometry attributes, indices and transforms remain exact',()=>{
 assert.equal(before.length,18);assert.equal(after.length,18);let tri=0;
 for(let i=0;i<before.length;i++){const a=before[i],b=after[i];assert.deepEqual(Object.keys(b.geometry.attributes),Object.keys(a.geometry.attributes));for(const k of Object.keys(a.geometry.attributes))assert.deepEqual(b.geometry.attributes[k].array,a.geometry.attributes[k].array);assert.deepEqual(b.geometry.index.array,a.geometry.index.array);assert.deepEqual(b.matrix.toArray(),a.matrix.toArray());tri+=b.geometry.index.count/3;}assert.equal(tri,2548);
});
test('no extra draw primitive, triangle, buffer, texture request or animation is introduced',()=>{
 assert.equal(docs[1].materials.length,18);assert.equal(docs[1].meshes.length,1);assert.equal(docs[1].meshes[0].primitives.length,18);assert.equal(bytes[0].length,fixture.beforeBytes);assert.equal(bytes[1].length,fixture.afterBytes);assert(Math.abs(bytes[1].length-bytes[0].length)<512);assert.equal(bins[1].length,bins[0].length);
});
for(const position of [[0,0,0],[12,3,-18],[-9,1.8,4]])test('normalization, ring, collider and 242 aim rays are exact at '+position,()=>{
 const targets=gltfs.map(g=>{const group=new THREE.Group(),ring=new THREE.Group();group.position.fromArray(position);group.add(ring);return attachCharacterTarget({group,ring},{scene:g.scene,id:'mage',label:'mage'});});const[a,b]=targets;
 for(const k of ['position','scale','quaternion'])assert.deepEqual(a.character[k].toArray(),b.character[k].toArray());for(const k of ['min','max'])assert.deepEqual(a.bounds[k].toArray(),b.bounds[k].toArray());assert.deepEqual(a.ring.position.toArray(),b.ring.position.toArray());assert.deepEqual(a.ring.rotation.toArray(),b.ring.rotation.toArray());
 const boxes=targets.map(t=>new THREE.Box3(t.bounds.min.clone().add(t.group.position),t.bounds.max.clone().add(t.group.position)));let n=0;for(const third of [false,true])for(let x=-5;x<=5;x++)for(let y=-5;y<=5;y++){const origin=new THREE.Vector3(position[0]+(third?.6:0),position[1]+(third?.5:0),position[2]+6),direction=new THREE.Vector3(position[0]+x*.22,position[1]+y*.24,position[2]).sub(origin).normalize(),ray=new THREE.Ray(origin,direction);assert.deepEqual(ray.intersectBox(boxes[0],new THREE.Vector3())?.toArray(),ray.intersectBox(boxes[1],new THREE.Vector3())?.toArray());n++;}assert.equal(n,242);
});
