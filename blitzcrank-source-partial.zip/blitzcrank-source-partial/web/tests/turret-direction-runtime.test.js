import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const h=await createGameplayHarness(),root=h.element('threatwarning');
function acquire(){h.game.begin(true);h.game.data.player.set(-8,1.7,-12);h.game.aim(Math.PI/.0021,0);h.frames(1);assert(h.game.data.turretArena.sim.events.some(e=>e.type==='acquired'));assert.equal(root.classList.s.has('hidden'),false);}
function cleared(){assert.equal(root.classList.s.has('hidden'),true);}
test('real main feeds real acquired/windup and shot events into directional HUD',()=>{
 acquire();assert.match(root.textContent,/조준/);
 let shot=false;for(let i=0;i<50;i++){h.frames(1);if(h.game.data.turretArena.sim.events.some(e=>e.type==='shot')){shot=true;assert.equal(root.classList.s.has('hidden'),false);assert.match(root.textContent,/발사/);break;}}assert(shot);
});
test('real view switch, muting, capture loss/pause, stale resume, menu and reset',()=>{
 acquire();h.element('viewtoggle').click();h.frames(1);assert.equal(h.qa.view,'third');assert.equal(root.classList.s.has('hidden'),false);
 h.element('viewtoggle').click();h.frames(1);assert.equal(h.qa.view,'first');assert.equal(root.classList.s.has('hidden'),false);
 h.element('sound').click();h.frames(1);assert.equal(root.classList.s.has('hidden'),false);h.element('sound').click();
 document.exitPointerLock();cleared();h.frames(1);cleared();
 h.game.data.player.set(0,1.7,7);h.game.resume();h.frames(1);cleared();
 acquire();h.game.pause();cleared();h.element('mainmenu').click();h.frames(1);cleared();
 acquire();h.game.begin(true);h.frames(1);cleared();
});
test('real cover/lost event, death, combo and duel clear HUD',()=>{
 acquire();h.game.data.obstacles.push({min:h.game.data.player.clone().addScalar(-1),max:h.game.data.player.clone().addScalar(1)});h.frames(1);
 assert(h.game.data.turretArena.sim.events.some(e=>e.type==='lost'));cleared();h.game.data.obstacles.pop();
 acquire();h.game.damagePlayer(200);cleared();assert.equal(h.qa.state,'results');
 acquire();h.game.begin(true,true);h.frames(1);cleared();
 acquire();h.game.begin(false,false,true);h.frames(1);cleared();
});
test('real main restores generic text for on-screen windup and clears stale directional text',()=>{
 h.game.begin(true);h.game.data.player.set(-8,1.7,-12);h.frames(1);
 assert.equal(root.classList.s.has('hidden'),false);assert.equal(root.textContent,'포탑 조준 중 · 이동하거나 엄폐하세요');
 h.game.aim(Math.PI/.0021,0);h.frames(1);assert.match(root.textContent,/^포탑 .*:조준/);
 h.game.aim(-Math.PI/.0021,0);h.frames(1);assert.equal(root.textContent,'포탑 조준 중 · 이동하거나 엄폐하세요');
 h.game.pause();cleared();assert.equal(root.textContent,'포탑 조준 중 · 이동하거나 엄폐하세요');
});
