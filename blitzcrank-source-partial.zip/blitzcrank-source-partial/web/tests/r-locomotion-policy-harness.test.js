import {normalizeERecovery} from './helpers/e-recovery-policy.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {rLocomotionPresentationPolicy,normalizeRForWPresentation,adaptHistoricalRPresentation,rArmClause,rBotArmOption,rArmImport} from './helpers/r-locomotion-policy.js';
import {adaptHistoricalWPresentation,stationaryWPresentationPolicy} from './helpers/w-stationary-policy.js';
const frozen=fs.readFileSync(new URL('./fixtures/main-duel-pose-v0.24.60-baseline.txt',import.meta.url),'utf8'),actualCurrent=normalizeERecovery(fs.readFileSync(new URL('../main.js',import.meta.url),'utf8'));
// Keep the original lower-only parser assertions, plus explicit new-policy tests below.
const current=actualCurrent.replace(rArmClause,"if(skill.name==='R_Cast')applyEWalkLayer();").replace(rBotArmOption,'').replace(rArmImport,'createFullbodyELocomotionLayer,clearFullbodySkillPose');
const clause="if(skill.name==='R_Cast')applyEWalkLayer();",e="if(skill.name.startsWith('E_'))applyEWalkLayer();";
test('R adaptation aligns player and bot without changing final-pose or frozen contracts',()=>{
 assert.equal(createHash('sha256').update(frozen).digest('hex'),'0c657035d53a127e697df4400367b04fe2e1fd8cbc421752405f09aa56bfcfee');
 assert.equal(rLocomotionPresentationPolicy(frozen).enabled,false);assert.equal(rLocomotionPresentationPolicy(current).enabled,true);
 const w=adaptHistoricalWPresentation(frozen,current),both=adaptHistoricalRPresentation(w,current),oldBot=rLocomotionPresentationPolicy(w).botSite;
 assert.equal(both,w.replace(e,e+clause).replace(oldBot,oldBot.slice(0,-2)+',{rLocomotion:true});'));
 assert.equal(rLocomotionPresentationPolicy(both).enabled,true);assert.equal(stationaryWPresentationPolicy(both).enabled,true);assert.equal(normalizeRForWPresentation(current),current.replace(clause,''));
 assert.equal(both.split('syncCamera();animateFullbody(0,walking);updateDuelAvatar(0);').length,2);assert.equal(current.split('if(!playing()||duel.resultReady)animateFullbody(0,walking);').length,2);
 assert.equal(adaptHistoricalRPresentation(frozen,frozen),frozen);assert.throws(()=>adaptHistoricalRPresentation(both,current));
});
test('R normalization fails closed for partial, duplicate, moved and unknown player/bot policies',()=>{
 const bad=[current.replace(clause,''),current.replace(',rLocomotion:true',''),current.replace(clause,clause+clause),current.replace(clause,"if(skill.name==='R_Cast')applyEWalkLayer(.5);"),current.replace(clause,"if(skill.name==='R_Cast')otherLayer();"),current.replace('rLocomotion:true','rLocomotion:false'),current.replace('rLocomotion:true','rLocomotion:true,rLocomotion:true'),current.replace(clause,'')+'\n'+clause,current.replace(e+clause,clause+e),current.replace('function animateFullbody(dt,walking){','function animateFullbody(dt,walking,other){'),current.replace('function updateDuelAvatar(dt,deltaX=0,deltaZ=0){','function other(){'),current.replace('deferWorldMatrices:true,rLocomotion:true','deferWorldMatrices:true,rLocomotion:true,unknown:true'),current+'\n'+rLocomotionPresentationPolicy(current).botSite];
 for(const s of bad){assert.throws(()=>rLocomotionPresentationPolicy(s));assert.throws(()=>normalizeRForWPresentation(s));assert.throws(()=>stationaryWPresentationPolicy(s));assert.throws(()=>adaptHistoricalRPresentation(frozen,s));}
});

test('E/W frozen v81 receives exactly two R policy changes while retaining defer and E/W baseline',()=>{
 const original=fs.readFileSync(new URL('./fixtures/e-w-baseline-v81.js',import.meta.url),'utf8');
 assert.equal(createHash('sha256').update(original).digest('hex'),'2ff83436f549e2cd923fdb1e3a97157012148434d7cdb290568b9b0497d9f516');
 const after=adaptHistoricalRPresentation(original,current);
 assert.equal(after,original.replace(e,e+clause).replace(',{deferWorldMatrices:true});',',{deferWorldMatrices:true,rLocomotion:true});'));
 assert.equal(after.replace(clause,'').replace(',rLocomotion:true',''),original);
 assert(!after.includes('function applyHeldFistWalkPresentation('));
 assert.equal(rLocomotionPresentationPolicy(after).enabled,true);
});

test('new R arm policy adapts exact import/player/bot sites while retaining frozen v60 and v81 comparisons',()=>{
 for(const name of ['main-duel-pose-v0.24.60-baseline.txt','e-w-baseline-v81.js']){const source=fs.readFileSync(new URL('./fixtures/'+name,import.meta.url),'utf8'),before=rLocomotionPresentationPolicy(source),after=adaptHistoricalRPresentation(source,actualCurrent),policy=rLocomotionPresentationPolicy(after);assert(policy.recovery);assert.equal(policy.playerClause,rArmClause);const restored=after.replace(rArmClause,'').replace(rArmImport,'createFullbodyELocomotionLayer,clearFullbodySkillPose').replace(policy.botSite,before.botSite);assert.equal(restored,source);}
 assert.equal(normalizeRForWPresentation(actualCurrent),actualCurrent.replace(rArmClause,''));assert(stationaryWPresentationPolicy(actualCurrent).enabled);
});
test('R arm parser rejects altered guards, durations, imports, duplicate options and unsupported calls',()=>{
 for(const source of [actualCurrent.replace(rArmClause,clause),actualCurrent.replace(rBotArmOption,''),actualCurrent.replace('st.armed||st.boost||st.slow','st.boost||st.slow'),actualCurrent.replace('rRecoveryArmWeight(skill.time,skill.duration)','rRecoveryArmWeight(skill.time,1)'),actualCurrent.replace(rArmImport,'createFullbodyELocomotionLayer,clearFullbodySkillPose'),actualCurrent.replace(rBotArmOption,rBotArmOption+rBotArmOption),actualCurrent.replace(rArmClause,rArmClause+rArmClause)]){assert.throws(()=>rLocomotionPresentationPolicy(source));assert.throws(()=>normalizeRForWPresentation(source));assert.throws(()=>adaptHistoricalRPresentation(frozen,source));}
});
