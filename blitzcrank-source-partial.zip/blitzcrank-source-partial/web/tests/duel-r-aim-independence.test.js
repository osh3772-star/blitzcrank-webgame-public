import test from 'node:test';
import assert from 'node:assert/strict';
import {createDuelBotInputs} from '../duel-bot-inputs.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';

const tuning={playerSpeed:6.4,hookSpeed:42,maxRange:32,cooldown:2.2,windup:.25};
const make=options=>createDuelBotInputs({seed:42,tuning,arena:{min:{x:-30,z:-40},max:{x:30,z:30}},...options});
const observation=(patch={})=>({active:true,dt:1/60,canSeeOpponent:true,
 self:{position:{x:0,y:1.7,z:0},yaw:Math.PI,pitch:0,cooldown:0,
  skills:{phase:null,cooldown:{E:0,R:0},armed:0}},
 opponent:{position:{x:0,y:1.7,z:-4},velocity:{x:0,y:0,z:0}},...patch});

test('radial R uses delayed perception without directional Q/E settlement or facing-ray cover',()=>{
 // The target is visible north, but the bot starts facing a wall to the south.
 const brain=make({obstacles:[{min:{x:-3,y:0,z:1},max:{x:3,y:5,z:2}}]});
 let cast=null;
 for(let frame=0;frame<60;frame++){
  const out=brain.step(observation());
  assert(!out.castQ&&!out.castE&&!out.strikeE,'directional actions still need settled aim');
  if(out.castR){cast={frame,out,state:brain.snapshot()};break;}
 }
 assert(cast,'ready radial attack must not wait to face the target');
 assert(cast.state.time>=cast.state.reactionDelay,'reaction delay remains intact');
 assert(cast.state.freshPerception);
 assert.equal(cast.state.settleTime,0);
 assert(Math.abs(cast.out.yaw)>2.5,'R was selected while still facing away');
});

test('unaligned R still honors visibility, controller restrictions, cooldown, phase and delayed range',()=>{
 for(const patch of [
  {canSeeOpponent:false},
  {self:{...observation().self,canCastR:false}},
  {self:{...observation().self,hookActive:true}},
  ...['E_Charge','E_Strike','R_Cast','E_Hold'].map(phase=>({self:{...observation().self,skills:{phase,cooldown:{E:0,R:0},armed:4}}})),
  {self:{...observation().self,skills:{phase:null,cooldown:{E:0,R:1},armed:0}}},
 ]){
  const brain=make();for(let frame=0;frame<30;frame++)assert(!brain.step(observation(patch)).castR);
 }
 const brain=make();
 for(let frame=0;frame<60;frame++)brain.step(observation({opponent:{position:{x:0,y:1.7,z:-20},velocity:{x:0,y:0,z:0}}}));
 for(let frame=0;frame<13;frame++)assert(!brain.step(observation()).castR,'new actual in-range position cannot bypass delayed perception');
});

test('circling and jumping ends with a legal Q win before any radial R range opportunity',async()=>{
 const hz=60,r=await createGameplayHarness({delta:()=>1/hz});r.element('duelmode').click();
 const d=r.game.data,brain=d.duelBrain,commands=[],observations=[];let frame=0,held=new Set();
 // Observe the real source only; do not alter actions, positions or cooldowns.
 r.game.setBotCommandSource({reset:()=>brain.reset(),step:obs=>{
  const out=brain.step(obs),state=brain.snapshot();const record=structuredClone({frame,obs,out,state});observations.push(record);if(out.castQ||out.castE||out.strikeE||out.castR)commands.push(record);return out;
 }});
 for(frame=0;frame<12*hz&&!d.duel.state.history.length;frame++){
  if(d.duel.active){
   let dx=d.player.x-d.duelBot.position.x,dz=d.player.z-d.duelBot.position.z;
   const distance=Math.hypot(dx,dz);dx/=distance;dz/=distance;
   const radial=Math.max(-2,Math.min(2,(6-distance)*1.3));
   const heading=Math.round(Math.atan2(dz*radial+dx,dx*radial-dz)/(Math.PI/4))*Math.PI/4;
   const x=Math.cos(heading),z=Math.sin(heading),keys=new Set();
   if(x>.3)keys.add('KeyD');if(x<-.3)keys.add('KeyA');if(z>.3)keys.add('KeyS');if(z<-.3)keys.add('KeyW');
   if(frame%45<15)keys.add('Space');
   for(const key of held)if(!keys.has(key))r.release(key);
   for(const key of keys)if(!held.has(key))r.key(key);
   held=keys;
  }
  r.frames(1);
 }
 // The historical R expectation was unreachable: Q wins while even the
 // delayed/predicted radial range preconditions are absent. Preserve that
 // exact input scenario; the paired valid-opportunity test proves actual R.
 assert(observations.length>0);
 let perceivedFrames=0;
 for(const {obs,out,state} of observations){
  assert(!out.castR,'no R edge without a valid range opportunity');
  if(!state.perceived){assert(!state.freshPerception);continue;}
  perceivedFrames++;
  const p=state.perceived,s=obs.self.position;
  const dist=Math.hypot(p.position.x-s.x,p.position.y-s.y,p.position.z-s.z);
  const lead=Math.min(.7,Math.max(0,state.time-p.sampledAt)+Math.min(.35,(.25+dist/42)*.45));
  const aimDistance=Math.hypot(p.position.x+p.velocity.x*lead-s.x,p.position.y+p.velocity.y*lead-s.y,p.position.z+p.velocity.z*lead-s.z);
  assert(!(dist<=6.3&&aimDistance<=7),'this scenario must never acquire both radial R range prerequisites');
 }
 assert(perceivedFrames>0,'the scenario actually exercises delayed perception');
 assert.equal(commands.length,1,'exactly one real attack edge causes the win');
 const cast=commands[0];assert(cast.out.castQ);assert(!cast.out.castE&&!cast.out.strikeE&&!cast.out.castR);
 assert(cast.obs.canSeeOpponent&&cast.obs.self.canCastQ&&!cast.obs.self.hookActive);
 assert(cast.state.freshPerception&&cast.state.time>=cast.state.reactionDelay);
 assert.equal(d.duel.state.history.length,1);
 assert.equal(d.duel.state.history[0].winnerId,'bot');
 assert.equal(d.duel.contact.skill,'Q','shared authority validates the actual Q impact');
 assert.equal(d.duel.contact.kind,'grab');assert.equal(d.duel.contact.attackerId,'bot');assert.equal(d.duel.contact.targetId,'human');
 assert.deepEqual(d.duel.state.scores,[{playerId:'human',points:0},{playerId:'bot',points:1}]);
 assert.equal(r.qa.session.score,0,'duel scoring never leaks into solo points');
});
