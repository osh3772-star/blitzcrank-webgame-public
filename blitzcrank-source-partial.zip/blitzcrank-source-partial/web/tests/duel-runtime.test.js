import test from 'node:test';import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
async function start(){const writes=[],r=await createGameplayHarness({delta:()=>.05,storage:{getItem:()=>null,setItem:(...args)=>writes.push(args)}});r.element('duelmode').click();quiet(r);return {r,writes};}
function quiet(r){r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,jump:false})});}
function active(r){r.frames(35);assert.equal(r.qa.duel.match.phase,'active');}
function scoreHuman(r){r.game.data.duelBot.position.set(0,1.7,1);r.key('KeyQ');for(let i=0;i<25&&r.qa.duel.match.phase==='active';i++)r.frames(1);assert.equal(r.qa.duel.match.history.at(-1)?.winnerId,'human');}
test('actual selectable duel gates countdown, hides solo actors/turret colliders and preserves movement, W, jump and F',async()=>{
 const {r}=await start(),d=r.game.data;assert.equal(r.qa.duel.match.phase,'countdown');assert.equal(r.qa.duel.avatar.visible,true);assert(r.qa.targets.every(t=>!t.visible&&!t.active));assert([...d.turretArena.visuals.values()].every(v=>!v.root.visible&&!v.ring.visible));
 const before=r.qa.player;r.key('KeyW');r.key('KeyQ');r.key('KeyE');r.key('ShiftLeft');r.key('Space');r.key('KeyF');r.punch();assert.equal(r.qa.hook,null);assert.equal(r.qa.flashAbility.casts,0);assert.equal(r.qa.skills.cooldown.W,0);r.frames(5);assert.deepEqual(r.qa.player,before);active(r);
 r.key('KeyW');r.frames(2);r.release('KeyW');assert(r.qa.player.z<before.z);r.key('ShiftLeft');assert(r.qa.skills.boost>0);r.key('Space');r.frames(2);assert(r.qa.player.y>1.7);r.key('KeyF');assert.equal(r.qa.flashAbility.casts,1);assert.equal(r.qa.flashAbility.cooldown,15);assert.equal(r.qa.session.score,0);
});
test('actual human Q scores exactly once from geometry, pulls victim and resets both actors, inputs and all cooldowns',async()=>{
 const {r,writes}=await start();active(r);r.key('ShiftLeft');r.key('KeyF');r.game.data.player.set(0,1.7,7);scoreHuman(r);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[1,0]);const afterPull=r.game.data.duelBot.position.clone();assert(Math.abs(afterPull.z-4.7)<1e-9);r.frames(5);assert.equal(r.game.data.duelBot.position.z,afterPull.z);r.key('KeyQ');assert.equal(r.qa.duel.match.history.length,1);r.frames(60);assert.equal(r.qa.duel.match.roundNumber,2);assert.equal(r.qa.duel.match.phase,'countdown');assert.deepEqual(r.qa.player,{x:0,y:1.7,z:7,yaw:0,pitch:0});assert.deepEqual(r.qa.duel.bot.position,[0,1.7,-12]);assert.equal(r.qa.hook,null);assert.equal(r.qa.duel.bot.hook,null);assert.equal(r.qa.flashAbility.remaining,0);assert.equal(r.qa.skills.cooldown.W,0);assert.equal(r.game.data.keys.size,0);assert.equal(r.game.data.joystick.x,0);assert.equal(r.qa.session.score,0);assert.equal(writes.length,0);
});
test('actual E empowered punch scores one, preserves knockup through reset interval and never pulls',async()=>{
 const {r,writes}=await start();active(r);const bot=r.game.data.duelBot;bot.position.set(0,1.7,5);r.punch();assert.equal(r.qa.duel.match.history.length,0);assert.equal(r.qa.duel.avatar.visible,true);assert.equal(r.qa.session.score,0);r.frames(30);r.key('KeyE');r.frames(20);assert.equal(r.qa.skills.phase,'E_Hold');assert.equal(r.qa.duel.match.history.length,0);r.punch();r.frames(10);assert(bot.knockup);assert(bot.position.y>1.7);assert.equal(r.qa.skills.metrics.powerHits,1);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[1,0]);assert.equal(r.qa.duel.match.phase,'roundReset');assert.equal(bot.position.z,5);const lifted=bot.position.y;r.frames(6);assert.notEqual(bot.position.y,lifted);assert.equal(bot.position.z,5);assert.equal(r.qa.duel.match.history.length,1);assert.equal(r.qa.session.score,0);assert.equal(writes.length,0);r.frames(56);assert.equal(r.qa.duel.match.phase,'countdown');assert.equal(bot.knockup,null);assert.equal(bot.position.y,1.7);
});
test('actual R opponent hit scores once with original feedback, without a Q pull or solo records',async()=>{
 const {r,writes}=await start();active(r);const bot=r.game.data.duelBot;bot.position.set(0,1.7,3);r.key('KeyR');assert.equal(r.qa.duel.match.history.length,0);r.frames(7);assert.equal(r.qa.skills.metrics.discharges,1);assert.equal(r.qa.skills.metrics.pulseHits,1);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[1,0]);assert.equal(r.qa.duel.avatar.visible,true);assert.equal(r.qa.skills.vfx.fieldVisible,true);r.frames(5);assert.equal(bot.position.z,3);assert.equal(r.qa.session.score,0);assert.equal(writes.length,0);assert(r.qa.targets.every(t=>!t.visible));
});
test('actual pause/capture loss freezes countdown and hooks; rematch keys preserve duel; menu restores solo',async()=>{
 const {r,writes}=await start();const phase=r.qa.duel.match.remainingMs;r.game.pause();r.frames(100);assert.equal(r.qa.duel.match.remainingMs,phase);r.game.resume();active(r);r.key('KeyQ');r.frames(6);document.exitPointerLock();assert.equal(r.qa.state,'paused');const h=r.qa.hook,bot=r.qa.duel.bot;r.frames(50);assert.deepEqual(r.qa.hook,h);assert.deepEqual(r.qa.duel.bot,bot);r.game.resume();
 // New match resets any in-flight hook without a stale scoring callback.
 r.element('duelmode').click();quiet(r);const id=r.qa.duel.match.sessionId;active(r);for(let n=0;n<3;n++){scoreHuman(r);r.frames(60);if(n<2)active(r);}assert.equal(r.qa.state,'results');assert.equal(r.qa.duel.match.winnerId,'human');assert.equal(writes.length,0);r.key('KeyR');assert(r.qa.duel.match.sessionId!==id);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[0,0]);assert.equal(r.qa.duel.match.phase,'countdown');r.game.pause();r.element('mainmenu').click();assert.equal(r.qa.state,'menu');assert.equal(r.qa.duel,null);assert.equal(r.game.data.duelAvatar.inspect().visible,false);assert.equal(r.game.data.duelRope.visible,false);assert(r.qa.targets.every(t=>t.visible&&t.active));assert([...r.game.data.turretArena.visuals.values()].every(v=>v.root.visible&&v.ring.visible));r.element('start').click();assert.equal(r.qa.session.practice,false);assert.equal(r.qa.duel,null);
});
test('actual bot can geometrically win 3–0 with no training records and result Enter rematches',async()=>{
 const writes=[],r=await createGameplayHarness({delta:()=>.05,storage:{getItem:()=>null,setItem:(...a)=>writes.push(a)}});r.element('duelmode').click();for(let i=0;i<700&&r.qa.state==='running';i++)r.frames(1);assert.equal(r.qa.state,'results');assert.equal(r.qa.duel.match.winnerId,'bot');assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[0,3]);assert.equal(r.qa.duel.match.history.length,3);assert.equal(writes.length,0);r.key('Enter');assert.equal(r.qa.state,'running');assert.equal(r.qa.duel.match.phase,'countdown');
});
test('actual touch duel has gated actions, independent chain and resettable held pointers',async()=>{
 const r=await createGameplayHarness({delta:()=>.05});r.docListeners.pointerdown({pointerType:'touch'});r.element('duelmode').click();quiet(r);const down=id=>r.element(id).onpointerdown({button:0,pointerType:'touch',preventDefault(){}});down('touchhook');assert.equal(r.qa.hook,null);r.element('joystick').onpointerdown({pointerType:'touch',pointerId:4,clientX:90,clientY:55});assert(r.game.data.joystick.x>0);r.frames(2);assert.equal(r.qa.player.x,0);r.element('joystick').onpointercancel({pointerId:4});assert.equal(r.game.data.joystick.x,0);active(r);r.game.data.duelBot.position.set(0,1.7,1);down('touchhook');r.frames(6);assert.equal(r.qa.hook.phase,'outbound');assert.notEqual(r.game.data.rope.links.geometry,r.game.data.duelRope.links.geometry);r.game.pause();assert.equal(r.game.data.joystick.x,0);r.game.resume();r.frames(80);assert.equal(r.qa.duel.match.scores[0].points,1);assert.equal(r.qa.duel.match.roundNumber,2);
});

test('actual third-person behind-hand aim returns blocked rather than shooting through near-camera opponent',async()=>{
 const {r}=await start();active(r);r.key('KeyV');r.game.data.duelBot.position.set(.9,2.5,9);r.key('KeyQ');r.frames(6);assert.equal(r.qa.hook.phase,'return');assert.equal(r.qa.hook.travel,0);assert.equal(r.qa.duel.match.history.length,0);assert.match(r.element('hitnotice').textContent,/BLOCKED/);r.frames(15);assert.equal(r.qa.duel.match.history.length,0);
});
test('actual two fullbody Q chains follow separate real palms and detach safely on menu',async()=>{
 const {r}=await start();active(r);r.key('KeyV');r.key('KeyQ');r.game.data.duel.cast('bot');r.frames(6);const d=r.game.data;
 assert.equal(r.qa.hook.phase,'outbound');assert.equal(r.qa.duel.bot.hook.phase,'outbound');assert.equal(d.duelRope.visible,true);assert.equal(d.rope.visible,true);const sockets=d.duelAvatar.getSockets(),h=r.qa.duel.bot.hook;
 assert(Math.hypot(...sockets.palm.map((v,i)=>v-h.position[['x','y','z'][i]]))<1e-5);assert(d.duelRope.userData.start.distanceTo({x:sockets.cable[0],y:sockets.cable[1],z:sockets.cable[2]})<1e-5);assert(d.duelRope.userData.end.distanceTo({x:sockets.chain[0],y:sockets.chain[1],z:sockets.chain[2]})<1e-5);assert.notEqual(d.fullbody,d.duelAvatar.object);
 r.game.pause();r.element('mainmenu').click();assert.equal(d.duelAvatar.inspect().phase,null);assert.equal(d.duelRope.links.count,0);assert.equal(r.qa.hook,null);
});
test('actual cover interception and empty-space Q return without point or training writes',async()=>{
 const {r,writes}=await start();active(r);r.game.data.duelBot.position.set(0,1.7,-12);const d=r.game.data;d.obstacles.push({min:d.player.clone().set(-2,0,-2),max:d.player.clone().set(2,4,-1)});r.key('KeyQ');r.frames(10);assert.equal(r.qa.hook.phase,'return');assert.equal(r.qa.duel.match.history.length,0);assert.match(r.element('hitnotice').textContent,/BLOCKED/);r.frames(20);assert.equal(r.qa.session.score,0);assert.equal(writes.length,0);
 d.obstacles.pop();d.duelBot.position.set(12,1.7,-12);r.frames(20);r.key('KeyQ');r.frames(40);assert.equal(r.qa.duel.match.history.length,0);assert.equal(writes.length,0);
});
test('actual five scored rounds close at 3–2 without a sixth and top replay retains duel',async()=>{
 const {r,writes}=await start();active(r);for(const winner of ['human','bot','human','bot','human']){
  if(winner==='human')scoreHuman(r);else{r.game.data.duelBot.position.set(0,1.7,1);r.game.data.duel.cast('bot');for(let i=0;i<25&&r.qa.duel.match.phase==='active';i++)r.frames(1);assert.equal(r.qa.duel.match.history.at(-1)?.winnerId,'bot');}
  r.frames(60);if(r.qa.state!=='results')active(r);
 }
 assert.equal(r.qa.state,'results');assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[3,2]);assert.equal(r.qa.duel.match.roundNumber,5);assert.equal(r.qa.duel.match.history.length,5);r.frames(100);assert.equal(r.qa.duel.match.roundNumber,5);assert.equal(writes.length,0);r.element('pause').click();assert.equal(r.qa.duel.match.phase,'countdown');assert.equal(r.qa.duel.match.history.length,0);
});
test('actual graphics loss gates new duel entry and freezes match until explicit resume',async()=>{
 const {r}=await start();active(r);const old=r.qa.duel.match;r.element('game').listeners.webglcontextlost({preventDefault(){}});assert.equal(r.qa.state,'paused');assert.equal(r.element('duelmode').disabled,true);r.element('duelmode').click();r.frames(100);assert.equal(r.qa.duel.match,old);r.element('game').listeners.webglcontextrestored();assert.equal(r.element('duelmode').disabled,false);assert.equal(r.qa.state,'paused');r.game.resume();r.frames(1);assert.equal(r.qa.state,'running');
});
test('actual touch countdown and round phase remain visible as concise two-line text without keyboard hints',async()=>{
 const r=await createGameplayHarness({delta:()=>.05});r.docListeners.pointerdown({pointerType:'touch'});r.element('duelmode').click();quiet(r);
 const check=()=>{const text=r.element('comborecord').textContent,lines=text.split('\n');assert.equal(lines.length,2);assert(lines.length*18<=40);assert(!r.element('comborecord').classList.s.has('hidden'));assert(!/[QER]|Shift/.test(text));
  // Conservative text-only estimate at the existing 10px touch HUD font:
  // Hangul consumes 1em, ASCII .65em. This is not browser layout validation.
  for(const line of lines)assert([...line].reduce((n,c)=>n+(c.charCodeAt(0)>127?1:.65),0)*10<=90);
  assert.equal(r.element('timer').textContent,'1/5');assert(r.element('timer').textContent.length*24*.65<=84);
 };assert.match(r.element('comborecord').textContent,/준비/);check();active(r);assert.match(r.element('comborecord').textContent,/먼저 3점/);check();scoreHuman(r);assert.match(r.element('comborecord').textContent,/다음 판까지 3초/);check();
});
