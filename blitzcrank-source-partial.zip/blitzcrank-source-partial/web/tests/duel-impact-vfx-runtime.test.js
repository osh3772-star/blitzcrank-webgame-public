import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';

const root = path.resolve(process.env.DUEL_APP_ROOT || fileURLToPath(new URL('../', import.meta.url)));
const worker = fileURLToPath(new URL('./helpers/duel-impact-vfx-case.mjs', import.meta.url));
function check(hz, skill, winner, scenario = 'boundary') {
  const output = execFileSync(process.execPath, ['--max-old-space-size=512',worker, root, String(hz), skill, winner, scenario], {encoding: 'utf8', maxBuffer: 256 * 1024});
  const result = JSON.parse(output.trim());
  assert.equal(result.harnesses, 1);
  assert.equal(result.pauseFrozen, true);
  assert.equal(result.resetAfterSeconds, 3);
}
for (const hz of [20, 60, 120]) for (const winner of ['human', 'bot']) for (const skill of ['E', 'R']) {
  test(`real ${winner} ${skill} at ${hz} Hz aligns first VFX, pauses, resets at 3 s and repeats cleanly`, () => check(hz, skill, winner));
}
for (const winner of ['human', 'bot']) for (const skill of ['E', 'R']) {
  test(`real ${winner} ${skill} uses 30 ms after an impact 20 ms into a 50 ms frame`, () => check(20, skill, winner, 'fractional'));
}
