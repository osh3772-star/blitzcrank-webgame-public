import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {VOICE_CUES,VOICE_EVENTS,RANDOM_VOICE_EVENTS,START_VOICE_EVENT,DEATH_VOICE_EVENT} from '../voice-cues.js';
const base=new URL('../',import.meta.url);
const manifest=JSON.parse(readFileSync(new URL('assets/audio/voice/manifest.json',base)));
test('separate 12 ordinary lines, start and user-confirmed death',()=>{
 assert.equal(RANDOM_VOICE_EVENTS.length,12);assert.equal(new Set(RANDOM_VOICE_EVENTS).size,12);
 assert.ok(!RANDOM_VOICE_EVENTS.includes(START_VOICE_EVENT));assert.equal(DEATH_VOICE_EVENT,'voice:death');assert.ok(!RANDOM_VOICE_EVENTS.includes(DEATH_VOICE_EVENT));
 assert.equal(Object.keys(VOICE_CUES).length,14);assert.equal(Object.keys(VOICE_EVENTS).length,14);
 for(const event of [...RANDOM_VOICE_EVENTS,START_VOICE_EVENT])assert.ok(VOICE_CUES[VOICE_EVENTS[event]]);
});
test('cut ranges exclude all unresolved nonverbal clips',()=>{
 for(const clip of manifest.clips){
  assert.ok(clip.sourceStartSeconds>=0);assert.ok(clip.sourceEndSeconds<=49.296);
  assert.ok(Math.abs(clip.sourceEndSeconds-clip.sourceStartSeconds-clip.durationSeconds)<1e-6);
  for(const ex of manifest.excluded)assert.ok(clip.sourceEndSeconds<=ex.start||clip.sourceStartSeconds>=ex.end);
 }
});
test('actual WAV hashes, format, duration, safety headroom and contract match',()=>{
 for(const clip of manifest.clips){
  const b=readFileSync(new URL(clip.url,base));assert.equal(createHash('sha256').update(b).digest('hex'),clip.sha256);assert.equal(b.length,clip.bytes);
  assert.equal(b.toString('ascii',0,4),'RIFF');assert.equal(b.toString('ascii',8,12),'WAVE');
  let pos=12,fmt,data;
  while(pos+8<=b.length){const tag=b.toString('ascii',pos,pos+4),size=b.readUInt32LE(pos+4);if(tag==='fmt ')fmt=b.subarray(pos+8,pos+8+size);if(tag==='data')data=b.subarray(pos+8,pos+8+size);pos+=8+size+(size%2);}
  assert.ok(fmt&&data);assert.equal(fmt.readUInt16LE(0),1);assert.equal(fmt.readUInt16LE(2),2);assert.equal(fmt.readUInt32LE(4),48000);assert.equal(fmt.readUInt16LE(14),16);
  const duration=data.length/(48000*2*2);assert.ok(Math.abs(duration-clip.durationSeconds)<1/48000);
  let peak=0;for(let p=0;p<data.length;p+=2)peak=Math.max(peak,Math.abs(data.readInt16LE(p))/32768);
  assert.ok(peak>0&&peak<.502);const cue=VOICE_CUES[VOICE_EVENTS['voice:'+clip.id]];
  assert.equal(cue.group,'voice');assert.equal(cue.url,clip.url);assert.ok(cue.maxDuration>=duration);assert.ok(cue.maxDuration-duration<=.03);
 }
});
test('start sentence maps only to requested taunt clip',()=>{
 const x=manifest.clips.find(x=>x.role==='start');assert.equal(x.id,'age-of-man');assert.equal(x.text,'인간 시대의 끝이 도래했다.');assert.equal(x.sourceStartSeconds,46.54);assert.equal(x.sourceEndSeconds,49.25);
});
