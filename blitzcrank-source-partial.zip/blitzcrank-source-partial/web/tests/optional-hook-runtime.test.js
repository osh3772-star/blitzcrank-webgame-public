import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import {MODE_RECORD_KEYS as keys} from '../mode-records.js';

// Actual game logic with CPU scene graph and controlled DOM/storage.
const originalQer=' {"version":1,"mode":"combo","rules":"q-e-r-v1","seconds":0.2} ';
const originalChallenge='{"version":1,"mode":"challenge90","score":700}';
const storage={data:new Map([[keys.combo,originalQer],[keys.challenge,originalChallenge],['rocket-hand-best','legacy-do-not-touch']]),writes:[],getItem(key){return this.data.get(key)??null;},setItem(key,value){this.writes.push([key,value]);this.data.set(key,value);}};
const h=await createGameplayHarness({storage});
const targets=h.game.data.targets;
function until(predicate,max=240,label='condition') {for(let i=0;i<max&&!predicate();i++)h.frames(1);assert(predicate(),label);}
function fresh({third=false,index=0,combo=true,distance=2,practice=true}={}) {
 h.game.begin(practice,combo);if((h.qa.view==='third')!==third)h.key('KeyV');h.frames(1);
 for(const t of targets){t.active=t.group.visible=false;t.respawn=Infinity;}
 const t=targets[index];t.anchor.set(third?.9:0,third?2.5:1.7,h.game.data.player.z-distance);t.group.position.copy(t.anchor);t.amplitude=t.speed=t.phase=0;t.active=t.group.visible=true;t.respawn=0;
 return t;
}
function tap(id){h.element(id).onpointerdown({button:0,pointerType:'touch',preventDefault(){}});}
function empower({touch=false}={}) {
 (touch?()=>tap('skillE'):()=>h.key('KeyE'))();
 assert.equal(h.qa.comboPractice.phase,'e','accepted E from ready starts the no-Q route');assert.equal(h.qa.comboPractice.route,'er');
 until(()=>h.qa.skills.phase==='E_Hold',120,'E must arm');
 (touch?()=>tap('touchpunch'):()=>h.punch())();
 until(()=>h.qa.comboPractice.phase==='r',90,'E must strike a nearby target without Q');
}
function discharge({touch=false}={}) {
 until(()=>!h.qa.skills.phase,120,'E strike completes before R');
 (touch?()=>tap('skillR'):()=>h.key('KeyR'))();
 until(()=>['success','failed'].includes(h.qa.comboPractice.phase),120,'R discharges');
}
for(const third of [false,true])for(const index of [0,1,2])test(`${third?'third':'first'} person target ${index}: E-first knockup, landed retention, then same-target R`,()=>{
 const t=fresh({third,index});const start=h.qa.session.elapsed;
 empower();assert.equal(h.qa.session.shots,0);assert.equal(h.qa.comboPractice.attempts,1);assert.equal(h.qa.comboPractice.target,index);assert(t.active&&t.knockup&&t.group.visible);
 const hitLocation=t.knockup.origin.clone();assert(t.comboHold,'no-Q hit needs its own retained position');
 until(()=>!t.knockup,120,'target lands');h.frames(20);
 assert(t.active&&t.group.visible,'landing never creates an invisible active target');assert(t.group.position.distanceTo(hitLocation)<1e-8,'target remains where E hit it');
 discharge();assert.equal(h.qa.comboPractice.phase,'success');assert.equal(h.qa.comboPractice.successes,1);assert(Math.abs(h.qa.comboPractice.last.elapsed-(h.qa.session.elapsed-start))<1e-8,'ER time starts on E acceptance and ends at R impact');
 assert(!t.active&&!t.group.visible&&!t.comboHold&&!t.knockup);
 until(()=>h.qa.comboPractice.phase==='ready',180,'retry');assert.equal(h.qa.comboPractice.target,null);assert.equal(h.qa.comboPractice.attempts,1);assert.equal(h.qa.skills.cooldown.E,0);assert.equal(h.qa.skills.cooldown.R,0);assert(targets.every(t=>t.active&&t.group.visible&&!t.captured&&!t.comboHold&&!t.knockup));
});
test('ER starts on accepted E, not E impact, and cannot be replaced by repeated E or Q',()=>{
 fresh();h.frames(90);h.key('KeyE');const started=h.qa.session.elapsed;
 assert.equal(h.qa.comboPractice.attempts,1);assert.equal(h.qa.comboPractice.elapsed,0);h.frames(10);const elapsed=h.qa.comboPractice.elapsed;assert(elapsed>0);h.key('KeyE');h.key('KeyQ');assert.equal(h.qa.comboPractice.attempts,1);assert.equal(h.qa.comboPractice.elapsed,elapsed);assert.equal(h.qa.hook,null);
 until(()=>h.qa.skills.phase==='E_Hold');h.key('KeyQ');assert.equal(h.qa.hook,null);assert.equal(h.qa.session.shots,0);h.frames(30);h.punch();until(()=>h.qa.comboPractice.phase==='r');discharge();assert.equal(h.qa.comboPractice.phase,'success');assert(Math.abs(h.qa.comboPractice.last.elapsed-(h.qa.session.elapsed-started))<1e-8);
});
test('blocked E, bare R, and unpowered punch do not create an ER attempt',()=>{
 fresh();h.game.pause();h.game.castE();assert.equal(h.qa.comboPractice.attempts,0);h.game.resume();
 h.key('KeyR');h.punch();assert.equal(h.qa.comboPractice.phase,'ready');assert.equal(h.qa.comboPractice.attempts,0);
 // Create a genuine controller block independent of combo mode. E must be accepted before beginning the route.
 assert(h.game.data.skills.castE());h.game.castE();assert.equal(h.qa.comboPractice.attempts,0);assert.equal(h.qa.comboPractice.phase,'ready');
});
test('ER pause freezes elapsed, cooldowns, and retained airborne target',()=>{
 const t=fresh();empower();const before=h.qa.comboPractice,pos=t.group.position.clone(),skill=h.qa.skills;h.game.pause();h.frames(300);assert.deepEqual(h.qa.comboPractice,before);assert(t.group.position.equals(pos));assert.deepEqual(h.qa.skills,skill);h.game.resume();discharge();assert.equal(h.qa.comboPractice.phase,'success');
});
test('ER miss and early R fail and never save a successful record',()=>{
 for(const path of ['miss','early']){fresh({distance:path==='miss'?25:2});const count=storage.writes.length;h.key('KeyE');until(()=>h.qa.skills.phase==='E_Hold');if(path==='miss')h.punch();else h.key('KeyR');until(()=>h.qa.comboPractice.phase==='failed');assert.equal(h.qa.comboPractice.successes,0);assert.equal(h.qa.comboPractice.last.success,false);assert.equal(storage.writes.length,count);until(()=>h.qa.comboPractice.phase==='ready',180);assert(targets.every(t=>!t.comboHold&&!t.knockup&&!t.captured));}
});
test('R hitting a different target cannot finish the ER route',()=>{
 const a=fresh();empower();until(()=>!h.qa.skills.phase);a.comboHold.set(30,1.7,0);a.group.position.copy(a.comboHold);const b=targets[1];b.anchor.set(0,1.7,5);b.group.position.copy(b.anchor);b.amplitude=b.speed=b.phase=0;b.active=b.group.visible=true;b.respawn=0;
 const writes=storage.writes.length;discharge();assert.equal(h.qa.comboPractice.phase,'failed');assert.equal(h.qa.comboPractice.successes,0);assert.equal(b.active,false,'R really hit the other target');assert.equal(storage.writes.length,writes);
});
test('expired E can re-arm without restarting its clock, and a fresh route does not display the last success',()=>{
 fresh();h.key('KeyE');until(()=>h.qa.skills.phase==='E_Hold');until(()=>!h.qa.skills.phase,400,'E charge expires');
 const elapsed=h.qa.comboPractice.elapsed;assert(elapsed>5);assert.equal(h.qa.comboPractice.phase,'e');h.key('KeyE');assert.equal(h.qa.comboPractice.attempts,1);assert.equal(h.qa.comboPractice.elapsed,elapsed);
 until(()=>h.qa.skills.phase==='E_Hold');h.punch();until(()=>h.qa.comboPractice.phase==='r');discharge();assert.equal(h.qa.comboPractice.phase,'success');
 until(()=>h.qa.comboPractice.phase==='ready',180);h.key('KeyQ');assert.equal(h.qa.comboPractice.route,'qer');assert.equal(h.qa.comboPractice.bests.qer,null);assert(h.qa.comboPractice.bests.er>5);assert(!h.element('comborecord').textContent.includes('성공'),'running Q route must not relabel old ER success');assert.match(h.element('comborecord').textContent,/Q → E/);
});
test('touch E/punch/R succeeds without touching Q and displays both paths in ready help',()=>{
 fresh();const ready=h.element('combo').textContent+' '+h.element('comborecord').textContent;assert.match(ready,/E|강철 주먹/);empower({touch:true});discharge({touch:true});assert.equal(h.qa.comboPractice.phase,'success');assert.equal(h.qa.session.shots,0);assert.equal(h.element('comborecord').textContent.split('\n').length,2);
});
test('ER result is isolated from exact legacy QER record, challenge record, and mixed legacy key',()=>{
 fresh();empower();discharge();assert.equal(h.qa.comboPractice.phase,'success');assert.equal(storage.data.get(keys.combo),originalQer);assert.equal(storage.data.get(keys.challenge),originalChallenge);assert.equal(storage.data.get('rocket-hand-best'),'legacy-do-not-touch');
 const otherKeys=[keys.comboER];assert.equal(new Set([keys.combo,keys.comboER,keys.comboFlash,keys.comboERFlash]).size,4,'distinct route and assisted record keys');const raw=storage.data.get(otherKeys[0]);assert(raw,'successful ER has a saved record');const saved=JSON.parse(raw);assert(saved.seconds>0);assert.equal(saved.rules,'e-r-v1');
 const menu=h.element('combobest').textContent+' '+h.element('erbest').textContent+' '+h.element('comboerbest').textContent;assert.match(menu,/Q.*E.*R|그랩 연계/,'menu labels the QER clock');assert.match(menu,/E.*R|주먹 연계/,'menu labels the ER clock');
});
for(const practice of [false,true])test(`${practice?'free practice':'90-second challenge'} retains original no-Q E behavior`,()=>{
 const t=fresh({combo:false,practice});h.key('KeyE');until(()=>h.qa.skills.phase==='E_Hold');h.punch();until(()=>t.knockup);assert.equal(h.qa.comboPractice.enabled,false);assert.equal(t.active,false);assert.equal(t.comboHold,null);until(()=>!t.knockup,120);assert.equal(t.group.visible,false);assert.equal(h.qa.comboPractice.attempts,0);
});
