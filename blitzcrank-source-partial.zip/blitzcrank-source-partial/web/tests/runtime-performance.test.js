import test from 'node:test';
import assert from 'node:assert/strict';
import {CONFIG,formatTime} from '../core.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';

const h=await createGameplayHarness(),el=h.element;
function assertHud(){
 const {session,skills,health,hook,shotCooldown}=h.game.data,st=skills.status;
 assert.equal(el('health').textContent,String(health));
 assert.equal(el('healthbar').style.width,health+'%');
 assert.equal(el('healthblock').classList.s.has('critical'),health<=36);
 assert.equal(el('score').textContent,String(session.score).padStart(5,'0'));
 assert.equal(el('caught').textContent,String(session.catches).padStart(2,'0'));
 assert.equal(el('combo').textContent,session.combo>1?`COMBO ×${Math.min(session.combo,5)} / ${session.combo} IN A ROW`:'READY TO CONNECT');
 assert.equal(el('timer').textContent,session.practice?'∞':formatTime(CONFIG.duration-session.elapsed));
 assert.equal(el('timer').parentElement.classList.s.has('urgent'),!session.practice&&CONFIG.duration-session.elapsed<15);
 assert.equal(el('hookstate').textContent,hook?(hook.phase==='windup'?'WINDUP':hook.phase==='recover'?'REATTACH':hook.returning?'RETURNING':'IN FLIGHT'):shotCooldown>0?`${shotCooldown.toFixed(1)}s RECHARGING`:skills.blocksAttack?'CASTING':'READY');
 assert.equal(el('cooldown').style.width,`${(1-shotCooldown/CONFIG.cooldown)*100}%`);
 for(const key of ['W','E','R']){
  const label=key==='W'?(st.boost>0?'BOOST '+st.boost.toFixed(1)+'s':st.slow>0?'SLOW '+st.slow.toFixed(1)+'s':''):key==='E'?(st.phase==='E_Hold'?'ARMED '+st.armed.toFixed(1)+'s':st.phase?.startsWith('E_')?'CASTING':''):st.phase==='R_Cast'?'CASTING':'';
  const hookBusy=key!=='W'&&!!hook,phaseBusy=(key==='E'&&!!st.phase)||(key==='R'&&['E_Charge','E_Strike','R_Cast'].includes(st.phase));
  const readyText=hookBusy?'HOOK ACTIVE':st.cooldown[key]>0?st.cooldown[key].toFixed(1)+'s':phaseBusy?'CASTING':'READY';
  assert.equal(el('skillstate'+key).textContent,label||readyText,key);
  assert.equal(el('skill'+key).classList.s.has('active'),!!label,key);
  assert.equal(el('skill'+key).classList.s.has('cooling'),!label&&st.cooldown[key]>0,key);
  assert.equal(el('skill'+key).attributes['aria-disabled'],String(hookBusy||st.cooldown[key]>0||phaseBusy),key);
 }
}
const checkedFrames=count=>{for(let i=0;i<count;i++){h.frames(1);assertHud();}};

test('unchanged HUD does not repeat DOM writes or lookups',()=>{
 h.game.begin(true);h.game.updateHud();h.resetMetrics();
 for(let i=0;i<120;i++)h.game.updateHud();
 assert.equal(h.metrics.writes,0);assert.equal(h.metrics.lookups,0);assertHud();
});
test('normal running frame updates HUD once after simulation',()=>{
 h.game.begin(true);h.resetMetrics();h.frames(60);
 assert.equal(h.metrics.hudCalls,60);assertHud();
});
test('health, score, captures and combo changes are immediate and reset cleanly',()=>{
 h.game.begin(true);h.game.setHealth(36);h.game.setScore(12345);h.game.setCombo(7);h.game.data.session.catches=12;h.game.updateHud();assertHud();
 h.game.damagePlayer(6);assertHud();h.game.begin(true);assertHud();
 assert.equal(el('health').textContent,'100');assert.equal(el('score').textContent,'00000');assert.equal(el('caught').textContent,'00');
});
test('timer cache preserves ceil display and independent urgent threshold',()=>{
 h.game.begin(false);
 for(const elapsed of [0,.001,.999,1,74.999,75,75.001,89.999,90]){h.game.setElapsed(elapsed);h.game.updateHud();assertHud();}
 assert.equal(el('timer').textContent,'00:00');h.game.begin(true);assertHud();assert.equal(el('timer').textContent,'∞');
 h.game.begin(false);assertHud();assert.equal(el('timer').textContent,'01:30');
});
test('cooldown width keeps full precision even while rounded text is unchanged',()=>{
 h.game.begin(true);h.game.setCooldown(2.1);h.game.updateHud();const text=el('hookstate').textContent,width=el('cooldown').style.width;
 h.game.setCooldown(2.09);h.game.updateHud();assertHud();assert.equal(el('hookstate').textContent,text);assert.notEqual(el('cooldown').style.width,width);
 h.game.setCooldown(0);h.game.updateHud();assertHud();assert.equal(el('hookstate').textContent,'READY');
});
test('Q windup, flight, capture, return and recovery display current end-of-frame state',()=>{
 h.game.begin(true);h.key('KeyQ');assertHud();const phases=new Set();
 for(let i=0;i<180;i++){h.frames(1);if(h.qa.hook)phases.add(h.qa.hook.phase);assertHud();}
 for(const phase of ['windup','outbound','return','recover'])assert(phases.has(phase),phase);
 assert.equal(h.qa.session.catches,1);assert.equal(el('score').textContent,'00100');
});
test('W E R labels, cooldown classes and ARIA states remain exact on every frame',()=>{
 h.game.begin(true);h.key('ShiftLeft');assertHud();checkedFrames(270);assert(el('skillstateW').textContent.startsWith('SLOW'));
 h.key('KeyE');assertHud();checkedFrames(53);assert(el('skillstateE').textContent.startsWith('ARMED'));
 h.punch();checkedFrames(100);h.key('KeyR');assertHud();checkedFrames(800);
 for(const key of ['W','E','R'])assert.equal(el('skillstate'+key).textContent,'READY');
});
test('pause leaves HUD frozen and resume/restart does not retain stale cached values',()=>{
 h.game.begin(false);h.key('ShiftLeft');checkedFrames(10);h.game.pause();const label=el('skillstateW').textContent;
 h.resetMetrics();h.frames(120);assert.equal(h.metrics.hudCalls,0);assert.equal(el('skillstateW').textContent,label);
 h.game.resume();checkedFrames(1);h.game.begin(true);assertHud();assert.equal(el('skillstateW').textContent,'READY');
});
