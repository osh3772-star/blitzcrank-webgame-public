import test from 'node:test';
import assert from 'node:assert/strict';
import {app,peers} from './helpers/online-touch-harness.js';

// Executes the actual app/session/world with simulated DOM, clock, capture and
// transport. This is not real browser, touchscreen, WebRTC or two-device QA.
async function pair(){
 peers.length=0;const h=await app(),g=await app();await h.click('host');g.element('incoming').value='offer';await g.click('join');h.element('incoming').value='answer';await h.click('accept');
 await h.click('ready','touch');await g.click('ready','touch');for(let i=0;i<110;i++){h.frames(1);g.frames(1);}assert(h.api.getState().active);return {h,g};
}
const down=(h,id,pointerId=1)=>h.pointer(id,'pointerdown',{pointerId,clientX:50,clientY:12});
const move=(h,id,pointerId=1)=>h.pointer(id,'pointermove',{pointerId,clientX:70,clientY:12});
for(const id of ['arena','pad'])for(const mode of ['throw','refuse'])test(`${id}: capture ${mode} is inert and a fresh press recovers`,async()=>{
 const {g}=await pair(),el=g.element(id),capture=el.setPointerCapture.bind(el),before=g.api.getInput();
 el.setPointerCapture=()=>{if(mode==='throw')throw Error('inactive pointer');};
 assert.doesNotThrow(()=>down(g,id));move(g,id);const after=g.api.getInput();assert.equal(after.yaw,before.yaw);assert.equal(after.moveZ,0);assert.equal(after.drag,null);assert.equal(after.padId,null);
 el.setPointerCapture=capture;down(g,id,2);move(g,id,2);assert(id==='arena'?g.api.getInput().yaw!==before.yaw:g.api.getInput().moveZ===-1);
});
for(const id of ['arena','pad'])test(`${id}: silent capture loss discards stale coordinates and permits a new owner`,async()=>{
 const {g}=await pair();down(g,id,1);const before=g.api.getInput();g.element(id).releasePointerCapture(1);move(g,id,1);const after=g.api.getInput();assert.equal(after.yaw,before.yaw);assert.equal(after.moveZ,0);assert.equal(after.drag,null);assert.equal(after.padId,null);
 down(g,id,2);for(const type of ['lostpointercapture','pointerup','pointercancel'])g.pointer(id,type,{pointerId:1});move(g,id,2);assert(id==='arena'?g.api.getInput().yaw!==before.yaw:g.api.getInput().moveZ===-1);
});
test('silent stick capture loss stops transmitted movement without another pointer event',async()=>{
 const{h,g}=await pair(),packets=[],send=peers[1].send;peers[1].send=x=>{if(x.type==='input')packets.push(x);return send(x);};
 down(g,'pad',1);g.frames(2);assert.equal(packets.at(-1).z,-1);g.element('pad').releasePointerCapture(1);g.frames(2);assert.equal(packets.at(-1).z,0);h.frames(2);assert.equal(g.api.getInput().padId,null);
});
for(const id of ['arena','pad'])test(`${id}: replacement before delayed old capture loss is not blocked`,async()=>{
 const{g}=await pair();down(g,id,1);g.element(id).releasePointerCapture(1);down(g,id,2);g.pointer(id,'lostpointercapture',{pointerId:1});move(g,id,2);assert(id==='arena'?g.api.getInput().drag?.id===2:g.api.getInput().padId===2);
});
for(const kind of ['pause','blur','hidden','resize','leave','new-room'])test(`${kind}: stale contacts cannot resume movement or look`,async()=>{
 const{g}=await pair();down(g,'pad',1);down(g,'arena',2);
 if(['pause','leave','new-room'].includes(kind))await g.click(kind);if(kind==='blur')g.listeners.blur();if(kind==='hidden'){g.document.hidden=true;g.docListeners.visibilitychange();}if(kind==='resize')g.listeners.resize();
 const before=g.api.getInput();move(g,'arena',2);move(g,'pad',1);g.frames(2);const after=g.api.getInput();assert.equal(after.yaw,before.yaw);assert.equal(after.moveZ,0);assert.equal(after.drag,null);assert.equal(after.padId,null);assert(!g.element('arena').hasPointerCapture(2));assert(!g.element('pad').hasPointerCapture(1));
});
for(const kind of ['blur','new-room'])test(`${kind}: capture release failure cannot abort pause or room cleanup`,async()=>{
 const{h,g}=await pair();down(g,'arena',2);g.element('arena').releasePointerCapture=()=>{throw Error('inactive pointer');};
 if(kind==='blur'){assert.doesNotThrow(()=>g.listeners.blur());assert(h.api.getState().paused);assert(g.fakeView.pauseCount>0);}else{await assert.doesNotReject(()=>g.click('new-room'));assert(peers[1].closed);assert.equal(g.api.getState(),null);assert(g.element('hud').hidden);}
 assert(!g.api.getControl());assert.equal(g.api.getInput().drag,null);
});
test('touch then mouse ready uses pointer lock again, including a new room',async()=>{
 const{g}=await pair();g.listeners.blur();let calls=0;const canvas=g.element('arena'),lock=canvas.requestPointerLock.bind(canvas);canvas.requestPointerLock=()=>{calls++;return lock();};
 await g.click('resume','mouse');assert.equal(calls,1);assert.equal(g.document.pointerLockElement,canvas);assert(g.api.getControl());await g.click('new-room','mouse');assert.equal(g.document.pointerLockElement,null);
});
for(const id of ['pad','action-R'])test(`${id}: secondary mouse button is not a movement or skill press`,async()=>{
 const{g}=await pair();g.pointer(id,'pointerdown',{pointerType:'mouse',button:2,clientY:12});assert.equal(g.api.getInput().actions,0);assert.equal(g.api.getInput().moveZ,0);assert.equal(g.api.getInput().padId,null);
});
test('multiple touches remain independent and a non-owner cannot cancel a live contact',async()=>{
 const{g}=await pair();down(g,'pad',1);down(g,'arena',2);down(g,'pad',3);down(g,'arena',4);g.pointer('arena','pointercancel',{pointerId:4});g.pointer('pad','pointercancel',{pointerId:3});move(g,'arena',2);assert.equal(g.api.getInput().padId,1);assert.equal(g.api.getInput().drag.id,2);assert.equal(g.api.getInput().moveZ,-1);assert.equal(g.api.getInput().yaw,Math.PI-.042);
});
