import test from 'node:test';import assert from 'node:assert/strict';
import {createIrregularTargets} from '../irregular-targets.js';
const target=()=>({anchor:{x:0,y:2,z:0},amplitude:4,active:true,bounds:{min:{x:-1.2,y:-1,z:-.8},max:{x:1.2,y:1,z:.8}}});
test('seed replay, diverse speeds/directions, no discontinuities and lane bounds',()=>{
 const a=createIrregularTargets(),b=createIrregularTargets(),t=target(),u=target();let last=0;const speeds=new Set(),signs=new Set();
 for(let i=0;i<4000;i++){const x=a.step(t,0,1/60);assert.equal(x,b.step(u,0,1/60));assert(Math.abs(x)<=4);assert(Math.abs(x-last)<=2.55/60+1e-9);speeds.add(Math.abs(x-last).toFixed(4));signs.add(Math.sign(x-last));last=x;}
 assert(speeds.size>20);assert(signs.has(-1)&&signs.has(1));a.reset();assert.equal(a.step(t,0,1/60),createIrregularTargets().step(u,0,1/60));
});
test('full model bounds and hover envelope keep motion clear of cover',()=>{
 const c=createIrregularTargets(),t=target(),o=[{min:{x:2,y:0,z:.7},max:{x:5,y:4,z:3}}];
 for(let i=0;i<4000;i++){const x=c.step(t,0,1/60,o);assert(x+1.2<=1.94+1e-9);assert(x>=-4);}
});
test('pause, lifecycle ownership, respawn, zero and tiny lanes, invalid dt',()=>{
 const c=createIrregularTargets(),t=target();const first=c.step(t,0,1/60);
 for(const flag of ['captured','knockup','comboHold']){t[flag]=true;assert.equal(c.step(t,0,1/60),first);t[flag]=null;}
 t.active=false;assert.equal(c.step(t,0,1/60),first);t.active=true;
 for(const dt of [0,-1,NaN,Infinity])assert.equal(c.step(t,0,dt),first);
 c.resetTarget(t);assert.equal(c.step(t,0,1/60),first);
 for(const width of [0,1e-7]){t.amplitude=width;c.reset();for(let i=0;i<100;i++)assert(Math.abs(c.step(t,0,.1))<=width+1e-12);}
});
