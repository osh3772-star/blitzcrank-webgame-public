import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {auditSpawn} from '../rift-v39-spawn-audit.js';
import {createMapProbe} from '../rift-v39-study.js';
import {MAP_STUDY_V39} from '../rift-v39-revisions.js';
const layout=JSON.parse(fs.readFileSync(new URL('../'+MAP_STUDY_V39.collision,import.meta.url)));
const probe=createMapProbe(layout,{radius:.7,study:MAP_STUDY_V39});
test('blocked guest yields deterministic bounded planar suggestions without claiming support',()=>{
 const input={origin:[0,-12],occupied:[{position:[0,7],radius:.7}]};
 const a=auditSpawn(layout,input),b=auditSpawn(layout,input);
 assert.deepEqual(a,b);assert.equal(a.originalBlockedBy,'wall_poly_13');assert(a.selected);
 for(const c of a.candidates){assert.equal(probe.probe(c.position).blockedBy,null);assert(c.distance<=8);assert(Math.hypot(c.position[0],c.position[1]-7)>1.4);}
 assert.equal(a.verticalSupportVerified,false);assert.equal(a.gameplayChanged,false);assert.equal(a.adopted,false);
});
test('clear origin is retained at distance zero, not arbitrarily displaced',()=>{
 const a=auditSpawn(layout,{origin:[-8,0],limit:1});assert.equal(a.selected.distance,0);assert.deepEqual(a.selected.position,[-8,0]);
});
test('zero search radius reports blocked origin without fallback teleport',()=>{
 const a=auditSpawn(layout,{origin:[0,-12],maxDistance:0});assert.equal(a.selected,null);assert.equal(a.searchStatus,'no-candidate-in-grid');assert.equal(a.examined,1);
});
test('occupied bodies reject overlapping and exactly touching candidates',()=>{
 for(const position of [[-8,0],[-6.6,0]])assert.equal(auditSpawn(layout,{origin:[-8,0],maxDistance:0,occupied:[{position,radius:.7}]}).selected,null);
});
test('optional straight corridor is swept with full actor radius',()=>{
 const a=auditSpawn(layout,{origin:[0,-12],corridorTo:[-8,0],maxDistance:12});assert(a.selected);
 for(const c of a.candidates)assert.equal(probe.probe(c.position,[-8,0]).blockedBy,null);
});
test('boundary and blocked corridor are rejected',()=>{
 assert.equal(auditSpawn(layout,{origin:[100,100],maxDistance:0}).selected,null);
 assert.equal(auditSpawn(layout,{origin:[-8,0],maxDistance:0,corridorTo:[0,-12]}).selected,null);
});
test('human spawn also overlaps wall 18 at the wider diagnostic radius',()=>{
 assert.equal(probe.probe([0,7]).blockedBy,'wall_poly_18');
 const a=auditSpawn(layout,{origin:[0,-12],corridorTo:[0,7]});assert.equal(a.selected,null);
});
test('malformed inputs and excessive sample counts fail before scanning',()=>{
 for(const opts of [{origin:[NaN,0]},{origin:[0]},{origin:[0,0],step:0},{origin:[0,0],maxDistance:Infinity},{origin:[0,0],step:.05,maxDistance:32},{origin:[0,0],radius:0},{origin:[0,0],limit:0},{origin:[0,0],occupied:[{position:[1,2],radius:-1}]},{origin:[0,0],corridorTo:[0,Infinity]}])assert.throws(()=>auditSpawn(layout,opts));
});
test('caller layout, origin and occupied bodies remain unchanged',()=>{
 const l=structuredClone(layout),opts={origin:[0,-12],occupied:[{position:[0,7],radius:.7}]},before=JSON.stringify([l,opts]);auditSpawn(l,opts);assert.equal(JSON.stringify([l,opts]),before);
});
test('empty-box fixture has an independently known nearest valid grid point and stable tie-break',()=>{
 const empty={...structuredClone(layout),walls:[],baseWalls:[],rearBackdropWalls:[],propColliders:[],mapBoundaryXZ:[[-20,-20],[20,-20],[20,20],[-20,20]]};
 const a=auditSpawn(empty,{origin:[0,0],step:.5,maxDistance:3,occupied:[{position:[0,0],radius:.7}],limit:1});
 // sqrt(2) at [1,1] is the first lattice radius strictly above 1.4.
 assert.deepEqual(a.selected.position,[-1,-1]);assert.equal(a.selected.distance,Math.SQRT2);
});
test('conservative circular envelope covers all four current AABB corners',()=>{
 const radius=Math.hypot(.7,.7),a=auditSpawn(layout,{origin:[0,-12],radius,limit:1});
 const conservative=createMapProbe(layout,{radius,study:MAP_STUDY_V39});
 assert(a.selected);assert.equal(conservative.probe(a.selected.position).blockedBy,null);
 assert.deepEqual(a.selected.position,[1,-13.25]);
});
