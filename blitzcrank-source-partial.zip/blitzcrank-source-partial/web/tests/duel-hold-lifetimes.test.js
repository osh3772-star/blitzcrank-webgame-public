import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const sourcePath=new URL('../main.js',import.meta.url);
const until=(r,p)=>{for(let i=0;i<600&&!p();i++)r.frames(1);assert(p());};
async function start({third=false,hz=60}={}){const r=await createGameplayHarness({sourcePath,delta:()=>1/hz});r.element('duelmode').click();r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:Math.atan2(r.game.data.player.y-r.game.data.duelBot.position.y,r.game.data.player.z-r.game.data.duelBot.position.z)})});until(r,()=>r.qa.duel.active);if(third)r.key('KeyV');return r;}
function score(r,winner='human',{jump=true,flash=false}={}){const d=r.game.data,n=d.duel.state.history.length;d.duelBot.position.set(0,1.7,5);if(jump)r.key('Space');assert(d.duel.getSkills(winner).castR());if(flash){r.frames(14);r.key('KeyF');assert(r.qa.flashFrames.active);}until(r,()=>d.duel.state.history.length===n+1);assert.equal(d.duel.state.history.at(-1).winnerId,winner);}
for(const third of [false,true])for(const winner of ['human','bot'])test(`jump lands through ${winner} R hold in ${third?'third':'first'} person with XZ/input locked`,async()=>{
 const r=await start({third});score(r,winner);const d=r.game.data,from=r.qa.player;assert(from.y>2.7);const n=d.duel.state.history.length;const frames=[];
 r.key('KeyD');r.key('Space');r.key('KeyQ');r.key('KeyR');r.key('KeyF');r.punch();
 for(let i=0;i<70;i++){r.frames(1);frames.push(r.qa.player.y);assert.equal(d.player.x,from.x);assert.equal(d.player.z,from.z);assert.equal(d.duel.state.history.length,n);}
 assert.equal(d.player.y,1.7);assert(frames.some(y=>y<from.y));assert.equal(r.qa.duel.match.phase,'roundReset');assert.equal(r.qa.flashAbility.casts,0);assert.equal(r.qa.motion.locomotion.jump.active,false);
});
for(const hz of [20,10,5])test(`jump lands on low-FPS ${hz}Hz scored hold slices`,async()=>{
 const r=await start({hz});score(r);assert(r.qa.player.y>1.7);r.frames(hz);assert.equal(r.qa.player.y,1.7);assert.equal(r.qa.duel.match.phase,'roundReset');
});
for(const third of [false,true])test(`Flash departure expires through score while pause/capture freeze it, ${third?'third':'first'} person`,async()=>{
 const r=await start({third});score(r,'human',{flash:true});const frozen=r.qa.flashFrames;assert(frozen.active);assert.equal(frozen.fpsReplay,!third);const from=r.qa.player,remaining=r.qa.flashAbility.remaining;
 r.game.pause();r.frames(120);assert.deepEqual(r.qa.flashFrames,frozen);assert.deepEqual(r.qa.player,from);r.game.resume();
 document.pointerLockElement=null;r.frames(60);assert.deepEqual(r.qa.flashFrames,frozen);assert.deepEqual(r.qa.player,from);r.element('mousecapture').click();
 r.frames(40);assert.equal(r.qa.flashFrames.active,false);assert.equal(r.qa.flashFrames.fpsReplay,false);assert.equal(r.qa.player.y,1.7);assert.equal(r.qa.flashAbility.remaining,remaining);assert.equal(r.qa.duel.match.history.length,1);
});
test('final R win lands and Flash expires before results, rematch resets all',async()=>{
 const r=await start();for(let n=0;n<2;n++){score(r,'human',{jump:false});until(r,()=>r.qa.duel.active);}
 score(r,'human',{flash:true});assert.equal(r.qa.duel.match.phase,'matchComplete');assert(r.qa.player.y>1.7);r.frames(65);assert.equal(r.qa.state,'running');assert.equal(r.qa.player.y,1.7);assert.equal(r.qa.flashFrames.active,false);until(r,()=>r.qa.state==='results');r.key('KeyR');assert.equal(r.qa.duel.match.history.length,0);assert.equal(r.qa.player.y,1.7);assert.equal(r.qa.flashFrames.active,false);assert.equal(r.qa.flashAbility.casts,0);
});
test('menu and restart discard airborne scored-hold effects without later replay',async()=>{
 for(const exit of ['menu','restart']){const r=await start();score(r,'bot',{flash:true});if(exit==='menu'){r.game.pause();r.element('mainmenu').click();r.element('duelmode').click();}else r.game.begin(true,false,true);assert.equal(r.qa.player.y,1.7);assert.equal(r.qa.flashFrames.active,false);assert.equal(r.qa.flashAbility.casts,0);assert.equal(r.qa.duel.match.history.length,0);r.frames(20);assert.equal(r.qa.player.y,1.7);assert.equal(r.qa.duel.match.history.length,0);}
});
for(const winner of ['human','bot'])test(`${winner} E knockup remains exclusively reaction-driven during landing hold`,async()=>{
 const r=await start(),d=r.game.data;d.duelBot.position.set(0,1.7,5);const s=d.duel.getSkills(winner);assert(s.castE());until(r,()=>s.status.phase==='E_Hold');r.key('Space');if(winner==='human')r.game.aim(0,240);assert(s.strikeE());until(r,()=>!d.duel.active);assert.equal(d.duel.state.history.at(-1).winnerId,winner);
 while((winner==='human'?r.qa.duel.bot.knockup:r.qa.duel.humanKnockup)!==null){r.frames(1);const k=winner==='human'?d.duelBot.knockup:null;if(k){const u=Math.min(1,Math.max(0,k.time)/1.1);assert(Math.abs(d.duelBot.position.y-(k.originY+(1.7-k.originY)*u*u*(3-2*u)+Math.sin(u*Math.PI)*2.2))<1e-9);}}
 r.frames(20);assert.equal(d.player.y,1.7);assert.equal(d.duelBot.position.y,1.7);assert.equal(d.duel.state.history.length,1);
});
test('Q pull path retains frozen airborne attacker until award then lands without moving endpoints horizontally',async()=>{
 const r=await start(),d=r.game.data;d.duelBot.position.set(0,1.7,4);r.key('KeyQ');r.frames(13);r.key('Space');until(r,()=>!!d.duel.pendingGrab);const atContact=r.qa.player;assert(atContact.y>1.7);let steps=0;
 while(d.duel.pendingGrab){r.frames(1);assert.deepEqual(r.qa.player,atContact);assert(++steps<100);}assert.equal(d.duel.contact.skill,'Q');const bot=d.duelBot.position.toArray();r.frames(70);assert.equal(d.player.y,1.7);assert.equal(d.player.x,atContact.x);assert.equal(d.player.z,atContact.z);assert.deepEqual(d.duelBot.position.toArray(),bot);
});
test('Q airborne human victim follows pull only and does not resume stale jump after bot score',async()=>{
 const r=await start(),d=r.game.data;d.duelBot.position.set(0,1.7,4);assert(d.duel.cast('bot'));r.frames(13);r.key('Space');until(r,()=>!!d.duel.pendingGrab);assert.equal(d.duel.pendingGrab.targetId,'human');let steps=0;
 while(d.duel.pendingGrab){assert.equal(d.duel.state.history.length,0);r.frames(1);assert(++steps<100);}
 assert.equal(d.duel.state.history.at(-1).winnerId,'bot');assert.equal(d.player.y,1.7);const endpoint=d.player.toArray();r.frames(90);assert.deepEqual(d.player.toArray(),endpoint);assert.equal(d.duel.state.history.length,1);
});
