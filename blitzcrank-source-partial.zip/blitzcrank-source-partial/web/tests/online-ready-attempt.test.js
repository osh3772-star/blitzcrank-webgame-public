import test from 'node:test';import assert from 'node:assert/strict';
import {app,peers} from './helpers/online-touch-harness.js';
async function pair(){peers.length=0;const h=await app(),g=await app();await h.click('host');g.element('incoming').value='offer';await g.click('join');h.element('incoming').value='answer';await h.click('accept');return{h,g};}
function deferred(){let resolve,reject;const promise=new Promise((r,j)=>{resolve=r;reject=j;});return{resolve,reject,promise};}
async function drain(){for(let i=0;i<4;i++)await Promise.resolve();}
for(const kind of ['pause','blur','pagehide','hidden'])test(`${kind}: old ready rejection cannot cancel a new same-room request`,async()=>{
 const{h}=await pair(),q=[];h.element('arena').requestPointerLock=()=>{const d=deferred();q.push(d);return d.promise;};await h.click('ready');
 if(kind==='pause')await h.click('pause');else if(kind==='hidden'){h.document.hidden=true;h.docListeners.visibilitychange();h.document.hidden=false;}else h.listeners[kind]();
 await h.click('resume');assert(h.api.getPending());q[0].reject(Error('old denial'));h.docListeners.pointerlockerror();await drain();assert(h.api.getPending());h.document.pointerLockElement=h.element('arena');h.docListeners.pointerlockchange();q[1].resolve();await drain();assert(h.api.getControl());
});
for(const kind of ['leave','new-room'])test(`${kind}: late capture results do not reopen readiness`,async()=>{
 const{h}=await pair(),d=deferred();h.element('arena').requestPointerLock=()=>d.promise;await h.click('ready');await h.click(kind);h.docListeners.pointerlockerror();d.reject(Error('old request'));await drain();assert(h.element('resume').hidden);assert(!h.api.getControl());assert(!h.api.getPending());
 h.document.pointerLockElement=h.element('arena');h.docListeners.pointerlockchange();assert.equal(h.document.pointerLockElement,null);assert(!h.api.getControl());
});
test('a current Promise rejection still pauses with a visible retry',async()=>{
 const{h}=await pair(),d=deferred();h.element('arena').requestPointerLock=()=>d.promise;await h.click('ready');h.docListeners.pointerlockerror();assert(h.api.getPending());d.reject(Error('current denial'));await drain();assert(!h.api.getPending());assert(!h.api.getControl());assert(!h.element('resume').hidden);assert(h.api.getState().paused);
});
test('legacy non-Promise capture error still pauses with a visible retry',async()=>{
 const{h}=await pair();h.element('arena').requestPointerLock=()=>undefined;await h.click('ready');assert(h.api.getPending());h.docListeners.pointerlockerror();assert(!h.api.getPending());assert(!h.element('resume').hidden);assert(!h.api.getControl());
});
test('synchronous lock then rejected Promise is handled without reversing successful readiness',async()=>{
 const{h}=await pair();h.element('arena').requestPointerLock=()=>{h.document.pointerLockElement=h.element('arena');h.docListeners.pointerlockchange();return Promise.reject(Error('late rejection'));};await h.click('ready');await drain();assert(h.api.getControl());assert.equal(h.document.pointerLockElement,h.element('arena'));
});
test('current capture throw is contained and repeated ready only creates one pending request',async()=>{
 const{h}=await pair();h.element('arena').requestPointerLock=()=>{throw Error('blocked');};await h.click('ready');assert(!h.api.getPending());assert(!h.element('resume').hidden);
 let calls=0;h.element('arena').requestPointerLock=()=>{calls++;return new Promise(()=>{});};await h.click('resume');await h.click('resume');assert.equal(calls,1);assert(h.api.getPending());
});
test('stale mouse request cannot pause active touch or retain a late lock grant',async()=>{
 const{h,g}=await pair(),d=deferred();h.element('arena').requestPointerLock=()=>d.promise;await h.click('ready');await h.click('pause');await h.click('resume','touch');await g.click('ready','touch');assert(!h.api.getState().paused);
 h.docListeners.pointerlockerror();d.reject(Error('old desktop request'));await drain();assert(h.api.getControl());assert(!h.api.getState().paused);
 h.document.pointerLockElement=h.element('arena');h.docListeners.pointerlockchange();assert.equal(h.document.pointerLockElement,null);assert(h.api.getControl());assert(!h.api.getState().paused);
});
test('touching UI cannot bypass lock loss for a mouse-ready session',async()=>{
 const{h,g}=await pair();await h.click('ready','mouse');await g.click('ready','touch');assert(!h.api.getState().paused);h.docListeners.pointerdown({pointerType:'touch'});h.document.pointerLockElement=null;h.docListeners.pointerlockchange();assert(!h.api.getControl());assert(h.api.getState().paused);
});
test('pagehide discards active contacts and actions and requires explicit ready again',async()=>{
 const{h,g}=await pair();await h.click('ready','touch');await g.click('ready','touch');h.pointer('pad','pointerdown',{pointerId:2,clientY:12});h.pointer('action-R','pointerdown');h.listeners.pagehide();assert(!h.api.getControl());assert(h.api.getState().paused);assert.equal(h.api.getInput().moveZ,0);assert.equal(h.api.getInput().actions,0);assert.equal(h.api.getInput().padId,null);h.frames(3);assert(!h.api.getControl());
});
test('stale errors after a new connected room do not change its pending Promise request',async()=>{
 const{h}=await pair(),old=deferred();h.element('arena').requestPointerLock=()=>old.promise;await h.click('ready');await h.click('new-room');await h.click('host');const newGuest=await app();newGuest.element('incoming').value='offer';await newGuest.click('join');h.element('incoming').value='answer';await h.click('accept');const fresh=deferred();h.element('arena').requestPointerLock=()=>fresh.promise;await h.click('ready');old.reject(Error('old room'));h.docListeners.pointerlockerror();await drain();assert(h.api.getPending());h.document.pointerLockElement=h.element('arena');h.docListeners.pointerlockchange();fresh.resolve();await drain();assert(h.api.getControl());
});
test('resume waits for intentional unlock completion and a fresh explicit mouse gesture',async()=>{
 const{h,g}=await pair();await h.click('ready','mouse');await g.click('ready','touch');let finishUnlock;
 h.document.exitPointerLock=()=>{finishUnlock=()=>{h.document.pointerLockElement=null;h.docListeners.pointerlockchange();};};await h.click('pause');assert(h.api.getState().paused);const canvas=h.element('arena'),lock=canvas.requestPointerLock.bind(canvas);let requests=0;canvas.requestPointerLock=()=>{requests++;return lock();};
 await h.click('resume','mouse');assert(!h.api.getControl());assert(!h.api.getPending());assert.equal(requests,0);finishUnlock();assert(!h.api.getControl());await h.click('resume','mouse');assert.equal(requests,1);assert(h.api.getControl());assert(h.api.getState().paused,'other player still needs fresh ready');await g.click('resume','touch');assert(!h.api.getState().paused);
});
test('mouse activity does not change the active touch session mode',async()=>{
 const{h,g}=await pair();await h.click('ready','touch');await g.click('ready','touch');h.docListeners.pointerdown({pointerType:'mouse',button:0});h.docListeners.pointerlockchange();assert(h.api.getControl());assert(!h.api.getState().paused);
});
test('pagehide and stale capture errors in a new lobby do not expose dead resume UI',async()=>{
 const h=await app();h.listeners.pagehide();h.docListeners.pointerlockerror();assert(h.element('resume').hidden);assert(!h.api.getControl());assert.equal(h.api.getState(),undefined);
});
