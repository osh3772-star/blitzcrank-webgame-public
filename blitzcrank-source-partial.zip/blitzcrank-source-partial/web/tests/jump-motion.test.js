import test from 'node:test';
import assert from 'node:assert/strict';
import {rig,THREE,minY,fingerMinimum} from './helpers/locomotion-rig.js';
import {createFullbodyLocomotion as baselineMotion} from './fixtures/fullbody-locomotion-v2413.js';
function pose(r){r.motion.restorePose();r.body.position.y=r.motion.applyPose();r.body.updateMatrixWorld(true);}
function exact(a,b){for(const [name,node]of a.nodes){const other=b.nodes.get(name);assert.deepEqual(node.position.toArray(),other.position.toArray(),name);assert.deepEqual(node.quaternion.toArray(),other.quaternion.toArray(),name);}assert.equal(a.body.position.y,b.body.position.y);}

test('grounded non-jump locomotion remains bit-identical to the preserved baseline',()=>{
 const a=rig(),b=rig({createMotion:baselineMotion});
 for(let f=0;f<1800;f++){
  const speed=f<300?0:f<600?1.6:f<1200?6.4:f<1500?9.92:0,angle=Math.floor(f/90)*.47;
  const input={deltaX:-Math.sin(angle)*speed/120,deltaZ:-Math.cos(angle)*speed/120,yaw:Math.sin(f/300),grounded:true,height:0,velocityY:0};
  a.motion.advance(1/120,input);b.motion.advance(1/120,input);pose(a);pose(b);exact(a,b);
 }
});

test('zero-dt refresh cannot advance, retarget, or accumulate any active jump pose',()=>{
 const r=rig();r.motion.advance(1/60,{grounded:false,height:.11,velocityY:6.66});pose(r);const snapshot=r.motion.inspect(),joints=[...r.nodes.values()].map(n=>n.matrixWorld.toArray()),y=r.body.position.y;
 for(let i=0;i<200;i++){r.motion.advance(0,{grounded:true,height:0,velocityY:0,deltaZ:-10});pose(r);assert.deepEqual(r.motion.inspect(),snapshot);assert.equal(r.body.position.y,y);assert.deepEqual([...r.nodes.values()].map(n=>n.matrixWorld.toArray()),joints);}
 r.motion.reset();pose(r);assert.equal(r.motion.inspect().jump.active,false);assert.equal(r.body.position.y,0);
});

const metrics={minSole:Infinity,minFinger:Infinity,maxLocalFootStep:0,maxTuck:0,clamps:0,samples:0};
test('actual rig remains finite and clear through 30/60/120 Hz and capped dt jumps from 16 gait phases',()=>{
 for(const dt of [1/120,1/60,1/30,.05])for(const warmup of Array.from({length:16},(_,i)=>i*3))for(const speed of [0,6.4]){
  const r=rig();let height=0,v=7,air=true,last=null;
  for(let i=0;i<warmup;i++){r.motion.advance(dt,{deltaZ:-speed*dt,grounded:true,height:0,velocityY:0});pose(r);}
  for(let frame=0;frame<Math.ceil(1.3/dt);frame++){
   if(air){v-=20*dt;height+=v*dt;if(height<=0){height=0;v=0;air=false;}}
   const angle=frame*dt>.55?.7:0;
   r.motion.advance(dt,{deltaX:-Math.sin(angle)*speed*dt,deltaZ:-Math.cos(angle)*speed*dt,grounded:!air,height,velocityY:v});pose(r);r.body.position.y+=height;r.body.updateMatrixWorld(true);
   const diagnostic=r.motion.inspect();metrics.maxTuck=Math.max(metrics.maxTuck,diagnostic.jump.tuck);metrics.samples++;
   for(const leg of diagnostic.legs){metrics.clamps+=+leg.clamped;const sole=minY(r.meshes.get('BC_FootSole.'+leg.side));metrics.minSole=Math.min(metrics.minSole,sole);assert(sole>-.00001);}
   metrics.minFinger=Math.min(metrics.minFinger,fingerMinimum(r.fingers));
   const point=r.nodes.get('BC_Pivot_Ankle.L').getWorldPosition(new THREE.Vector3());point.y-=height;
   if(last)metrics.maxLocalFootStep=Math.max(metrics.maxLocalFootStep,point.distanceTo(last));last=point;
   for(const n of r.nodes.values())assert(n.matrixWorld.elements.every(Number.isFinite));
  }
  assert.equal(r.motion.inspect().jump.active,false);
 }
 assert.equal(metrics.clamps,0);assert(metrics.minFinger>0);assert(metrics.maxLocalFootStep<.32);assert.equal(metrics.maxTuck,1);console.log('JUMP_FRAME_RATE_GEOMETRY '+JSON.stringify(metrics));
});

test('a second jump during landing recovery continues from its current pose and resets cleanly',()=>{
 const r=rig();let max=0,previous=null;
 for(let repeat=0;repeat<5;repeat++){
  let height=0,v=7,air=true;
  for(let f=0;f<47;f++){
   if(air){v-=20/60;height+=v/60;if(height<=0){height=0;v=0;air=false;}}
   r.motion.advance(1/60,{grounded:!air,height,velocityY:v});pose(r);const p=r.nodes.get('BC_Pivot_Ankle.L').getWorldPosition(new THREE.Vector3());if(previous)max=Math.max(max,p.distanceTo(previous));previous=p;
  }
 }
 assert(max<.08,'local repeated-jump foot step '+max);r.motion.reset();pose(r);assert.equal(r.motion.inspect().jump.active,false);for(const side of ['L','R'])assert(Math.abs(minY(r.meshes.get('BC_FootSole.'+side)))<1e-6);
});

import fs from 'node:fs';
import {SKILL_ASSET} from '../skill-animation-manifest.js';
import {bindSkillClips,createFullbodyPoseApplicator,createFullbodyELocomotionLayer} from '../skill-animation.js';
test('E jump lower-layer seams stay bounded at 30/60/120 Hz and the maximum frame step',()=>{
 const asset=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))),apply=createFullbodyPoseApplicator(THREE);let maxSeam=0,minimum=Infinity;
 for(const dt of [1/120,1/60,1/30,.05])for(const speed of [0,6.4])for(const warm of [0,5,13,20]){
  const r=rig(),surfaces=[...r.meshes.values()],clips=Object.fromEntries(bindSkillClips(asset.models.fullbody,surfaces).map(c=>[c.name,c])),layer=createFullbodyELocomotionLayer(THREE,{body:r.body,nodes:r.nodes,surfaces,locomotion:r.motion});
  for(let i=0;i<warm;i++)r.motion.advance(dt,{deltaZ:-speed*dt,grounded:true,height:0,velocityY:0});
  let height=0,v=7,air=true;
  for(let frame=0;frame<Math.ceil(1.1/dt);frame++){
   if(air){v-=20*dt;height+=v*dt;if(height<=0){height=0;v=0;air=false;}}
   r.motion.advance(dt,{deltaZ:-speed*dt,grounded:!air,height,velocityY:v});r.motion.restorePose();r.body.position.y=height;apply(clips.E_Hold,frame*dt,surfaces);layer();r.body.updateMatrixWorld(true);
   const point=(name,p)=>{const m=r.meshes.get(name);return new THREE.Vector3(...p).sub(new THREE.Vector3(...m.userData.skillRestPoint)).applyMatrix4(m.matrixWorld)};
   for(const side of ['L','R']){const sign=side==='L'?1:-1;minimum=Math.min(minimum,minY(r.meshes.get('BC_FootSole.'+side)));for(const [a,b,p]of [['BC_Pelvis','BC_Hip.'+side,[sign*.35,.9226,-.014303]],['BC_Thigh.'+side,'BC_Knee.'+side,[sign*.3872,.5416,-.014303]],['BC_Shin.'+side,'BC_Foot.'+side,[sign*.4576,.146944,-.044303]]])maxSeam=Math.max(maxSeam,point(a,p).distanceTo(point(b,p)));}
  }
 }
 console.log('E_JUMP_MULTIRATE_GEOMETRY '+JSON.stringify({maxSeam,minimum}));assert(maxSeam<.015,'E multirate joint gap '+maxSeam);assert(minimum>-.00001);
});
