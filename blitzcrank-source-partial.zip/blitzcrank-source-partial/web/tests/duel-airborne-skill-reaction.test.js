import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
for(const hz of [60,120])test(`actual bot E lands an airborne human continuously at ${hz}Hz without pull`,async()=>{
 const r=await createGameplayHarness({delta:()=>1/hz});r.element('duelmode').click();const d=r.game.data;
 r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:Math.atan2(d.player.y-d.duelBot.position.y,d.player.z-d.duelBot.position.z),castQ:false,castE:false,strikeE:false,castR:false})});
 r.frames(Math.ceil(1.7*hz));d.duelBot.position.set(0,1.7,5);assert(d.duel.getSkills('bot').castE());r.frames(hz);r.key('Space');assert(d.duel.getSkills('bot').strikeE());
 for(let i=0;i<hz&&d.duel.active;i++)r.frames(1);
 assert.equal(d.duel.state.history[0]?.winnerId,'bot');assert(d.player.y>2.7,'impact occurred during jump');const x=d.player.x,z=d.player.z,originY=d.player.y;
 let previous=originY,peak=originY,maxStep=0;
 while(r.qa.duel.humanKnockup!==null){r.frames(1);const y=d.player.y;peak=Math.max(peak,y);maxStep=Math.max(maxStep,Math.abs(y-previous));assert.equal(d.player.x,x);assert.equal(d.player.z,z);assert.equal(r.qa.duel.match.phase,'roundReset');previous=y;}
 assert(peak>originY+1);assert(maxStep<.18*(60/hz),`landing must be continuous, largest frame change was ${maxStep}`);assert.equal(d.player.y,1.7);assert.equal(d.duel.state.history.length,1);assert.equal(r.qa.session.score,0);
});
for(const hz of [60,120])test(`actual grounded E retains the original sine reaction at ${hz}Hz`,async()=>{
 const r=await createGameplayHarness({delta:()=>1/hz});r.element('duelmode').click();const d=r.game.data;
 r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false})});r.frames(Math.ceil(1.7*hz));d.duelBot.position.set(0,1.7,5);r.key('KeyE');r.frames(hz);r.punch();for(let i=0;i<hz&&d.duel.active;i++)r.frames(1);
 while(d.duelBot.knockup){const k=d.duelBot.knockup;assert(Math.abs(d.duelBot.position.y-(1.7+Math.sin(Math.min(1,Math.max(0,k.time)/1.1)*Math.PI)*2.2))<1e-10);assert.equal(d.duelBot.position.z,5);r.frames(1);}
 assert.equal(d.duelBot.position.y,1.7);assert.equal(d.duel.state.history[0].winnerId,'human');
});
