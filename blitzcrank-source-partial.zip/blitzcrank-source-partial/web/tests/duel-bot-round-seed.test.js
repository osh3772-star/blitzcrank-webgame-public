import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

test('real round preparation changes bot pattern seed while clearing tactics and preserving reset positions',async()=>{
 const r=await createGameplayHarness({delta:()=>.05});r.element('duelmode').click();
 const brain=r.game.data.duelBrain, first=brain.snapshot(),seeds=[];
 r.game.setBotCommandSource({reset(options){seeds.push(options.seed);brain.reset(options);},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false,jump:false})});
 for(let round=1;round<=2;round++){
  r.frames(35);assert.equal(r.qa.duel.match.phase,'active');r.game.data.duelBot.position.set(0,1.7,1);r.key('KeyQ');r.release('KeyQ');
  for(let i=0;i<35&&r.qa.duel.match.phase==='active';i++)r.frames(1);
  assert.equal(r.qa.duel.match.history.at(-1).winnerId,'human');r.frames(60);assert.equal(r.qa.duel.match.roundNumber,round+1);
  assert.equal(brain.snapshot().time,0);assert.equal(brain.snapshot().tactics,undefined);assert.notEqual(brain.snapshot().seed,first.seed);
  assert.deepEqual(r.qa.duel.bot.position,[0,1.7,-12]);assert.deepEqual(r.qa.player,{x:0,y:1.7,z:7,yaw:0,pitch:0});
 }
 assert.equal(new Set(seeds).size,2);assert.match(seeds[0],/round\/2\//);assert.match(seeds[1],/round\/3\//);
 r.element('duelmode').click();assert.notEqual(r.game.data.duelBrain.snapshot().seed,first.seed);
});

test('real bot tactics and movement freeze on pause and continue only after explicit resume',async()=>{
 const r=await createGameplayHarness({delta:()=>.05});r.element('duelmode').click();r.frames(45);
 const before=r.game.data.duelBrain.snapshot();assert.ok(before.tactics);r.game.pause();r.frames(120);
 assert.deepEqual(r.game.data.duelBrain.snapshot(),before);r.game.resume();r.frames(1);assert.ok(r.game.data.duelBrain.snapshot().time>before.time);
});
