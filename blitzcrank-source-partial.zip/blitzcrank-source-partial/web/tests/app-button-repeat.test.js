import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// Runs real main.js in the CPU harness. These explicit native-default models
// do not claim physical/browser key dispatch, focus, rendering or audio QA.
const h=await createGameplayHarness(process.env.CONTROL_REPEAT_SOURCE?{sourcePath:process.env.CONTROL_REPEAT_SOURCE}:{});
const controls=['pause','viewtoggle','sound','start','practice','combopractice','duelmode','mainmenu','mousecapture','capturestart'];
const toggles=['pause','viewtoggle','sound'];
const otherControls=controls.filter(id=>!toggles.includes(id));
const actions=['touchhook','touchpunch','touchjump','skillW','skillE','skillR','flashbutton'];
const canvas=h.element('game'),requestPointerLock=canvas.requestPointerLock;
canvas.tagName='CANVAS';canvas.focus=()=>{document.activeElement=canvas;};
function button(id){const b=h.element(id);b.id=id;b.tagName='BUTTON';return b;}
function key(target,code='Enter',repeat=false){let prevented=false;h.dispatchKey({target,code,repeat,preventDefault(){prevented=true;}});return prevented;}
function enter(target,repeat=false){const prevented=key(target,'Enter',repeat);if(!prevented&&!target.disabled)target.onclick?.({detail:0,preventDefault(){}});return prevented;}
function reset(){h.element('mainmenu').onclick();canvas.requestPointerLock=requestPointerLock;document.pointerLockElement=null;h.docListeners.pointerlockchange();document.activeElement=null;}
function opposite(view){return view==='first'?'third':'first';}

test('visible menu camera changes once on initial Enter, not on held repeats',()=>{
 reset();const b=button('viewtoggle'),before=h.qa.view;document.activeElement=b;
 assert.equal(enter(document.activeElement),false);const once=h.qa.view;assert.equal(once,opposite(before));
 for(let i=0;i<5;i++){enter(document.activeElement,true);assert.equal(h.qa.view,once);}
 assert.equal(document.activeElement,b);h.release('Enter');enter(b);assert.equal(h.qa.view,before);
});

for(const capture of ['pending','denied'])test(`visible pause stays paused when held Enter would resume while pointer capture is ${capture}`,async()=>{
 reset();h.game.begin(true);const b=button('pause');document.activeElement=b;
 // A denied/pending capture does not focus the canvas. Never manufacture a
 // held button target after a successful pointer capture focuses the canvas.
 canvas.requestPointerLock=capture==='pending'?()=>new Promise(()=>{}):()=>Promise.reject(new Error('modeled denial'));
 assert.equal(enter(document.activeElement),false);assert.equal(h.qa.state,'paused');
 for(let i=0;i<5;i++){enter(document.activeElement,true);await Promise.resolve();assert.equal(h.qa.state,'paused');}
 assert.equal(document.activeElement,b);h.release('Enter');enter(b);assert.equal(h.qa.state,'running');
});

test('visible menu sound changes once on initial Enter, not on held repeats',()=>{
 reset();const b=button('sound'),before=String(h.qa.audio.muted);
 enter(b);const once=b.attributes['aria-pressed'];assert.notEqual(once,before);
 for(let i=0;i<5;i++){enter(b,true);assert.equal(b.attributes['aria-pressed'],once);}
 h.release('Enter');enter(b);assert.equal(b.attributes['aria-pressed'],before);
});

test('repeat default cancellation covers action buttons and the three persistent toggles only',()=>{
 reset();
 for(const id of [...toggles,...actions])assert.equal(key(button(id),'Enter',true),true,id);
 for(const id of otherControls)assert.equal(key(button(id),'Enter',true),false,id);
 for(const target of [{tagName:'BUTTON',id:'unrelated'},{tagName:'BUTTON'},{tagName:'A',id:'outside-link'}])assert.equal(key(target,'Enter',true),false);
});

test('a deliberate pause resume refocuses canvas after successful capture; later repeats cannot reactivate pause',()=>{
 reset();h.game.begin(true);const b=button('pause');document.activeElement=b;
 enter(document.activeElement);assert.equal(h.qa.state,'paused');assert.equal(document.activeElement,b);
 h.release('Enter');enter(document.activeElement);assert.equal(h.qa.state,'running');assert.equal(document.activeElement,canvas);
 for(let i=0;i<5;i++){enter(document.activeElement,true);assert.equal(h.qa.state,'running');assert.equal(document.activeElement,canvas);}
});

test('every app command keeps the initial native Enter default',()=>{
 reset();for(const id of [...controls,...actions])assert.equal(key(button(id)),false,id);
});

test('native Space repeats do not activate; Space release still activates once',()=>{
 reset();
 for(const id of [...controls,...actions])for(const repeat of [false,true])assert.equal(key(button(id),'Space',repeat),false,id);
 const b=button('viewtoggle'),before=h.qa.view;
 for(let i=0;i<5;i++){key(b,'Space',i>0);assert.equal(h.qa.view,before);}
 h.release('Space');b.onclick({detail:0});assert.equal(h.qa.view,opposite(before));
});

test('pointer clicks and assistive zero-detail clicks still activate app controls',()=>{
 for(const detail of [1,0]){
  reset();const view=h.qa.view;button('viewtoggle').onclick({detail});assert.equal(h.qa.view,opposite(view));
  const sound=button('sound'),muted=sound.attributes['aria-pressed'];sound.onclick({detail});assert.notEqual(sound.attributes['aria-pressed'],muted);
  h.game.begin(true);button('pause').onclick({detail});assert.equal(h.qa.state,'paused');button('pause').onclick({detail});assert.equal(h.qa.state,'running');
 }
});

test('initial Enter still starts the selected menu mode',()=>{
 for(const [id,practice,combo,duel] of [['start',false,false,false],['practice',true,false,false],['combopractice',true,true,false],['duelmode',true,false,true]]){
  reset();assert.equal(enter(button(id)),false);assert.equal(h.qa.state,'running',id);assert.equal(h.qa.session.practice,practice,id);assert.equal(h.qa.comboPractice.enabled,combo,id);assert.equal(!!h.qa.duel,duel,id);
 }
});

test('slider editing, repeat arrows and contenteditable keys remain untouched',()=>{
 reset();const slider=h.element('sensitivity');slider.id='sensitivity';slider.tagName='INPUT';slider.type='range';
 for(const target of [slider,{tagName:'SELECT'},{tagName:'TEXTAREA'},{tagName:'BUTTON',id:'pause',isContentEditable:true}])for(const code of ['ArrowLeft','ArrowRight','Enter','Space'])for(const repeat of [false,true])assert.equal(key(target,code,repeat),false);
 slider.oninput({target:{value:'1.5'}});const yaw=h.qa.player.yaw;h.game.aim(10,0);assert(Math.abs(h.qa.player.yaw-(yaw-10*.0021*1.5))<1e-12);slider.oninput({target:{value:'1'}});
});

test('global hotkeys remain edge-triggered and ordinary new presses work',()=>{
 reset();h.game.begin(true);const before=h.qa.view;
 assert.equal(key(canvas,'KeyV',true),false);assert.equal(h.qa.view,before);key(canvas,'KeyV');assert.equal(h.qa.view,opposite(before));
 key(canvas,'Escape');assert.equal(h.qa.state,'paused');assert.equal(key(canvas,'Enter',true),false);assert.equal(h.qa.state,'paused');key(canvas,'Enter');assert.equal(h.qa.state,'running');
});
