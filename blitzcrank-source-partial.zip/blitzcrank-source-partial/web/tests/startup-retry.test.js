import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from '../vendor/three.module.js';
import * as core from '../core.js';
import * as irregularTargets from '../irregular-targets.js';
import * as turretDirection from '../turret-direction.js';
import * as comboPractice from '../combo-practice.js';
import * as modeRecords from '../mode-records.js';
import * as flashController from '../flash-controller.js';
import * as duelAvatar from '../duel-avatar.js';
import * as duelSimulation from '../duel-simulation.js';
import * as duelBotInputs from '../duel-bot-inputs.js';
import * as duelPullPath from '../duel-pull-path.js';

const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const flush=()=>new Promise(resolve=>setImmediate(resolve));
let instance=0;
async function startup(kind, reload=()=>{}){
 const jobs=Object.fromEntries(['viewmodel','fullbody','characters','turret','skills','flash','textures'].map(k=>[k,deferred()]));
 // Some jobs are deliberately not requested at the natural menu boundary.
 // Observe fixture-owned rejections without changing the promise returned to production.
 for(const job of Object.values(jobs))job.promise.catch(()=>{});
 const elements=new Map(),errors=[],winListeners={},canvasListeners={};let frame,renderCalls=0;
 const element=id=>{if(!elements.has(id))elements.set(id,{style:{},textContent:'',disabled:['start','practice','combopractice','duelmode'].includes(id),classList:{add(){},remove(){},toggle(){}},addEventListener(name,fn){canvasListeners[name]=fn;},setAttribute(){},firstElementChild:{style:{}}});return elements.get(id);};
 class Renderer{constructor(){if(kind==='graphics')throw new Error('TEST: WebGL context creation failed');this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}clearDepth(){}render(){renderCalls++;}}
 const deps={
  './irregular-targets.js':irregularTargets,'./turret-direction.js':turretDirection,
  './vendor/three.module.js':{...THREE,WebGLRenderer:Renderer},
  './model-codec.js':{loadPlayerModel:entry=>jobs[entry].promise},
  './player-model-manifest.js':{PLAYER_MODELS:{viewmodel:'viewmodel',fullbody:'fullbody'}},
  './skill-animation.js':{validateSkillSourceParts(){},bindSkillClips(){},createFullbodyPoseApplicator:()=>()=>{},clearFullbodySkillPose(){},loadSkillAsset:()=>jobs.skills.promise},
  './skill-vfx.js':{createSkillVfx(){}},'./skill-audio.js':{createSkillAudio:()=>({}),SKILL_AUDIO_CUES:{},SKILL_AUDIO_EVENTS:{}},
  './w-stationary-layer.js':{createFullbodyWStationaryLayer:()=>()=>{}},
  './fullbody-locomotion.js':{createFullbodyLocomotion(){}},
  './skill-controller.js':{createSkillController(){},SKILL_TUNING:{}},'./skill-animation-manifest.js':{SKILL_ASSET:{}},
  './flash-frame-vfx.js':{loadFlashFrameTexture:()=>jobs.flash.promise,createFlashFrameVfx(){}},'./flash-frame-manifest.js':{FLASH_FRAMES:{}},
  './duel-avatar.js':duelAvatar,'./duel-simulation.js':duelSimulation,'./duel-bot-inputs.js':duelBotInputs,'./duel-pull-path.js':duelPullPath,
  './combo-practice.js':comboPractice,'./mode-records.js':modeRecords,'./flash-controller.js':flashController,'./flash-audio.js':{FLASH_AUDIO_CUES:{},FLASH_AUDIO_EVENTS:{}},
  './core.js':core,'./mouse-look.js':{createMouseLook:()=>({mode:'test',reset(){},refresh(){},request(){}})},
  './hook-chain.js':{createHookChain:()=>new THREE.Group()},'./training-mirror.js':{createTrainingMirror:()=>new THREE.Group()},
  './game-audio.js':{createGameAudio:()=>({})},'./audio-cues.js':{AUDIO_CUES:{},AUDIO_EVENTS:{}},
  './voice-cues.js':{VOICE_CUES:{},VOICE_EVENTS:{},RANDOM_VOICE_EVENTS:[],START_VOICE_EVENT:'start',DEATH_VOICE_EVENT:'death'},
  './voice-schedule.js':{createVoiceSchedule:()=>({})},
  './blitz-materials.js':{createBlitzMaterial(){},blitzMaterialKey(){},loadBlitzTextures:()=>jobs.textures.promise,attachBlitzUV(){}},
  './target-models.js':{loadCharacterTargets:()=>jobs.characters.promise,attachCharacterTarget(){}},
  './turret-view.js':{loadTurretModel:()=>jobs.turret.promise,createTurretArena(){}},
 };
 Object.assign(globalThis,{__startupDeps:deps,document:{getElementById:element,querySelector:element,addEventListener(){},pointerLockElement:null},window:{location:{reload}},localStorage:{getItem:()=>null,setItem(){throw Error('unexpected storage write')},clear(){throw Error('unexpected storage clear')},removeItem(){throw Error('unexpected storage delete')}},matchMedia:()=>({matches:false}),addEventListener:(name,fn)=>winListeners[name]=fn,requestAnimationFrame:f=>frame=f,devicePixelRatio:1,innerWidth:1280,innerHeight:720});
 let source=fs.readFileSync(new URL(process.env.STARTUP_SOURCE||'../main.js',import.meta.url),'utf8');
 source=source.replace(/import \* as (\w+) from '([^']+)';/g,(_,name,path)=>`const ${name}=globalThis.__startupDeps[${JSON.stringify(path.split('?')[0])}];`).replace(/import (\{[^}]+\}) from '([^']+)';/g,(_,names,path)=>`const ${names}=globalThis.__startupDeps[${JSON.stringify(path.split('?')[0])}];`);
 const originalError=console.error;console.error=e=>errors.push(e?.message||String(e));
 try{
  const run=import('data:text/javascript;base64,'+Buffer.from(source+'\n// '+kind+(++instance)).toString('base64'));
  if(kind==='network')jobs.fullbody.reject(new Error('TEST: HTTP 503'));
  if(kind==='decode')jobs.fullbody.reject(new Error('TEST: Invalid model header'));
  if(kind==='scene')for(const job of Object.values(jobs))job.resolve({});
  if(kind==='loading')await flush();else await run;
  return {run,element,jobs,winListeners,canvasListeners,errors,qa:window.__HOOK_ARENA__,render:()=>{frame?.();return renderCalls;}};
 }finally{console.error=originalError;}
}

for(const kind of ['graphics','network','decode','scene'])test(`fatal ${kind}: explicit one-shot retry survives late requests`,async()=>{
 let calls=0;const r=await startup(kind,function(){assert.equal(this,window.location);assert.equal(arguments.length,0);calls++;});
 const button=r.element('startupretry'),status=r.element('loadstatus').textContent,intro=r.element('intro').textContent;
 assert.equal(r.qa.state,'error');assert.equal(button.hidden,false);assert.equal(button.disabled,false);assert.equal(calls,0);
 for(const [key,job]of Object.entries(r.jobs)){if(key==='turret')job.reject(Error('late failure'));else job.resolve({});}
 await flush();await flush();
 assert.equal(r.element('loadstatus').textContent,status);assert.equal(r.element('intro').textContent,intro);
 button.onclick();button.onclick();assert.equal(calls,1);assert.equal(button.disabled,true);assert.equal(r.qa.state,'error');
 assert.match(r.element('startupretrystatus').textContent,/ブラウザ|브라우저/);
 let prevented=0;r.winListeners.keydown({target:{tagName:'BUTTON',id:'startupretry'},code:'Enter',repeat:true,preventDefault(){prevented++;}});
 assert.equal(prevented,1);button.onclick();assert.equal(calls,1);
 // Graphics loss/restoration cannot replace the fatal diagnosis or revive play.
 r.canvasListeners.webglcontextlost({preventDefault(){}});r.canvasListeners.webglcontextrestored();
 assert.equal(r.element('loadstatus').textContent,status);assert.equal(r.element('intro').textContent,intro);
 for(const id of ['start','practice','combopractice','duelmode'])assert.equal(r.element(id).disabled,true);
 assert.equal(r.render(),0);assert.equal(r.errors.length,1);
});
for(const failure of ['throw','missing','missing-location'])test(`synchronous reload ${failure} leaves explicit retry available`,async()=>{
 let calls=0;const r=await startup('graphics',()=>{calls++;throw new DOMException('Blocked navigation','SecurityError');});
 if(failure==='missing')window.location.reload=undefined;
 if(failure==='missing-location')window.location=undefined;
 const button=r.element('startupretry'),original=r.element('loadstatus').textContent;
 assert.doesNotThrow(()=>button.onclick());assert.equal(button.disabled,false);assert.equal(button.hidden,false);assert.equal(button.textContent,'다시 불러오기');
 assert.match(r.element('startupretrystatus').textContent,/브라우저.*새로고침/);assert.equal(r.element('loadstatus').textContent,original);
 let prevented=0;r.winListeners.keydown({target:{tagName:'BUTTON',id:'startupretry'},code:'Enter',repeat:true,preventDefault(){prevented++;}});assert.equal(prevented,1);
 window.location={reload(){calls++;}};const before=calls;button.onclick();button.onclick();assert.equal(calls,before+1);assert.equal(button.disabled,true);
});
test('native keyboard first activation and Space are preserved, global Enter does not retry',async()=>{
 let calls=0;const r=await startup('graphics',()=>calls++);
 for(const code of ['Enter','Space']){let prevented=0;r.winListeners.keydown({target:{tagName:'BUTTON',id:'startupretry'},code,repeat:false,preventDefault(){prevented++;}});assert.equal(prevented,0);assert.equal(calls,0);}
 r.winListeners.keydown({code:'Enter',repeat:false,preventDefault(){}});assert.equal(calls,0);
 r.element('startupretry').onclick({detail:0});assert.equal(calls,1);
});
test('retry is a hidden native menu button with contained touch styling and status',()=>{
 const html=fs.readFileSync(new URL(process.env.STARTUP_HTML||'../index.html',import.meta.url),'utf8');
 const css=fs.readFileSync(new URL(process.env.STARTUP_CSS||'../style.css',import.meta.url),'utf8');
 assert.match(html,/<button id="startupretry" type="button" class="primary" aria-describedby="loadstatus startupretrystatus" hidden disabled>다시 불러오기<\/button>/);
 assert(html.indexOf('id="startupretry"')>html.indexOf('class="menu-panel"'));
 assert(html.indexOf('id="startupretry"')<html.indexOf('class="menu-actions"'));
 assert.match(html,/<p id="startupretrystatus" role="status" aria-live="polite"><\/p>/);
 assert.match(css,/#startupretry\{[^}]*width:100%;max-width:100%;min-height:44px/);
 assert.match(css,/#startupretry\[hidden\]\{display:none!important\}/);
 assert.match(css,/button:focus-visible/);
 assert.match(css,/#startupretry:not\(\[hidden\]\)\) #loadstatus\{height:auto;min-height:15px;line-height:1.6;overflow-wrap:anywhere\}/);
});

test('menu model completion keeps retry hidden while required showcase textures remain pending',async()=>{
 let calls=0;const r=await startup('loading',()=>calls++),button=r.element('startupretry');
 assert.equal(r.qa.state,'loading');assert.equal(button.hidden,true);assert.equal(button.disabled,true);const loadingStatus=r.element('loadstatus').textContent;
 button.onclick();assert.equal(calls,0);r.jobs.fullbody.resolve({});await flush();
 assert.equal(r.qa.state,'loading');assert.equal(r.element('loadstatus').textContent,loadingStatus);assert.equal(button.hidden,true);button.onclick();assert.equal(calls,0);
 const originalError=console.error;console.error=()=>{};try{r.jobs.textures.reject(Error('cleanup'));await r.run;}finally{console.error=originalError;}
});
test('late asset progress cannot replace a pending retry status',async()=>{
 let calls=0;const r=await startup('network',()=>calls++),button=r.element('startupretry');
 button.onclick();const status=r.element('startupretrystatus').textContent,diagnosis=r.element('loadstatus').textContent;
 for(const [key,job]of Object.entries(r.jobs)){if(key==='turret')job.reject(Error('late failure'));else job.resolve({});}
 await flush();await flush();assert.equal(button.hidden,false);assert.equal(button.disabled,true);
 assert.equal(r.element('startupretrystatus').textContent,status);assert.equal(r.element('loadstatus').textContent,diagnosis);button.onclick();assert.equal(calls,1);
});
