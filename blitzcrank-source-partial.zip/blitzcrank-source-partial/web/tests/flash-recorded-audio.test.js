import test from 'node:test';import {createHash} from 'node:crypto';import {FLASH_AUDIO_CUES,FLASH_AUDIO_EVENTS} from '../flash-audio.js';import {rayBox} from '../core.js';import assert from 'node:assert/strict';import fs from 'node:fs';import * as RealThree from '../vendor/three.module.js';
// CPU-only smoke harness. It runs the actual game module and Three.js scene graph,
// but deliberately does not claim GPU rendering or physical-browser input coverage.
class Classes{constructor(){this.s=new Set();}toggle(x,force){if(force===undefined)force=!this.s.has(x);force?this.s.add(x):this.s.delete(x);}add(x){this.s.add(x);}remove(x){this.s.delete(x);}}
class Element{constructor(){this.style={};this.classList=new Classes();this.firstElementChild={style:{}};this.parentElement={classList:new Classes()};this.value='1';this.disabled=false;this.listeners={};this.textContent='';this.innerHTML='';}addEventListener(k,f){const previous=this.listeners[k];this.listeners[k]=e=>{previous?.(e);f(e);};}setAttribute(k,v){this.attributes??={};this.attributes[k]=String(v);}querySelector(){return new Element();}getBoundingClientRect(){return{left:0,top:0,width:110,height:110};}setPointerCapture(){}requestPointerLock(){document.pointerLockElement=this;docListeners.pointerlockchange?.();return Promise.resolve();}click(){this.onclick?.();}getContext(){return{fillRect(){},fillText(){},fillStyle:'',textAlign:'',font:''};}}
const elements=new Map(),docListeners={},winListeners={};let callback;
const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
globalThis.document={getElementById:element,querySelector:element,createElement:()=>new Element(),addEventListener:(n,f)=>docListeners[n]=f,pointerLockElement:null,exitPointerLock(){this.pointerLockElement=null;docListeners.pointerlockchange?.();}};globalThis.window=globalThis;globalThis.innerWidth=1280;globalThis.innerHeight=720;globalThis.devicePixelRatio=1;globalThis.matchMedia=()=>({matches:false});globalThis.localStorage={getItem:()=>null,setItem(){}};globalThis.addEventListener=(n,f)=>winListeners[n]=f;globalThis.requestAnimationFrame=f=>{callback=f;};globalThis.fetch=async(path)=>({ok:true,arrayBuffer:async()=>{const b=fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);},json:async()=>JSON.parse(fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url)))});
class Renderer{constructor(){this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}render(){}clearDepth(){}}
class Clock{getDelta(){return 1/60;}}
const sampleSources=[],synthSources=[],audioContexts=[];
class AudioContextMock{
 constructor(){this.state='suspended';this.currentTime=1;this.destination={};this.oscillators=[];this.listeners=new Set();audioContexts.push(this);}
 addEventListener(type,listener){if(type==='statechange')this.listeners.add(listener);}
 removeEventListener(type,listener){if(type==='statechange')this.listeners.delete(listener);}
 setState(state){this.state=state;for(const listener of this.listeners)listener();}
 advance(seconds){if(this.state!=='running')return;this.currentTime+=seconds;for(const o of this.oscillators)if(o.started&&!o.ended&&this.currentTime>=o.stopAt)o.end();}
 resume(){if(this.resumeGate)return this.resumeGate.then(()=>this.setState('running'));this.setState('running');return Promise.resolve();}
 createGain(){return{connect(){},disconnect(){},gain:{cancelScheduledValues(){},setValueAtTime(){},exponentialRampToValueAtTime(){}}};}
 decodeAudioData(data){const b=Buffer.from(data);let rate=0,size=0;for(let o=12;o+8<=b.length;){const n=b.readUInt32LE(o+4),kind=b.toString('ascii',o,o+4);if(kind==='fmt ')rate=b.readUInt32LE(o+16);if(kind==='data')size=n;o+=8+n+(n%2);}return Promise.resolve({duration:size&&rate?size/rate:(data.byteLength>120000?.73:.57),byteLength:data.byteLength});}
 createBufferSource(){const o={connect(){},disconnect(){},start(){o.started=true;},stop(){o.stopped=true;o.onended?.();}};sampleSources.push(o);return o;}
 createOscillator(){const ctx=this,o={context:ctx,stopAt:Infinity,connect(){},disconnect(){o.disconnected=true;},start(){o.started=true;},stop(when=ctx.currentTime){o.stopAt=when;if(when<=ctx.currentTime)o.end();},end(){if(o.ended)return;o.ended=true;o.onended?.();},get audible(){return Boolean(ctx.state==='running'&&o.started&&!o.ended&&!o.disconnected);},frequency:{setValueAtTime(v){o.freq=v;},exponentialRampToValueAtTime(){}}};this.oscillators.push(o);synthSources.push(o);return o;}
}
globalThis.AudioContext=AudioContextMock;
class TextureLoader{async loadAsync(path){assert(fs.existsSync(new URL('../'+path.replace('./',''),import.meta.url)));return new RealThree.Texture();}}
globalThis.testThree={...RealThree,WebGLRenderer:Renderer,Clock,TextureLoader};
let source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8').replace("import * as THREE from './vendor/three.module.js';",'const THREE = globalThis.testThree;').replace("from './hook-chain.js'",`from '${new URL('../hook-chain.js',import.meta.url).href}'`).replace("from './training-mirror.js'",`from '${new URL('../training-mirror.js',import.meta.url).href}'`).replace("from './game-audio.js'",`from '${new URL('../game-audio.js',import.meta.url).href}'`).replace("from './audio-cues.js'",`from '${new URL('../audio-cues.js',import.meta.url).href}'`).replace("from './voice-cues.js'",`from '${new URL('../voice-cues.js',import.meta.url).href}'`).replace("from './voice-schedule.js'",`from '${new URL('../voice-schedule.js',import.meta.url).href}'`).replace("from './blitz-materials.js'",`from '${new URL('../blitz-materials.js',import.meta.url).href}'`).replace("from './core.js'",`from '${new URL('../core.js',import.meta.url).href}'`).replace("from './mouse-look.js'",`from '${new URL('../mouse-look.js',import.meta.url).href}'`).replace("from './target-models.js'",`from '${new URL('../target-models.js',import.meta.url).href}'`).replace("from './turret-view.js'",`from '${new URL('../turret-view.js',import.meta.url).href}'`);
source+=`\nwindow.__MOTION__={get data(){return{hook,fist,rope,parts,projectileParts,camera,viewCamera,viewmodel,targets,obstacles,fullbodySocket,player,turretArena,fullbodyNodes,fullbodyMeshes}},prepareMirrorBody,restoreMirrorBody,fullbodyCableSocket,fullbodyChainSocket,get mirror(){return trainingMirror},handPoint,cableSocket,chainHandSocket,nearestRay,begin,pause,resume,finish,damagePlayer,castFlash,audio,gameAudio,setDuelBotSource(source){duelBrain=source}};`;
source=source.replace("from './model-codec.js'",`from '${new URL('../model-codec.js',import.meta.url).href}'`).replace("from './player-model-manifest.js'",`from '${new URL('../player-model-manifest.js',import.meta.url).href}'`);
source=source.replace(/from '\.\/([^']+)'/g,(_,path)=>`from '${new URL('../'+path,import.meta.url).href}'`);
// This fixture exercises initialized gameplay, not the natural first selection.
source+='\nif(typeof ensureGameplayAssets==="function")await ensureGameplayAssets();';
await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const punch=()=>element('game').listeners.pointerdown({pointerType:'mouse',button:0,preventDefault(){}});
const key=code=>winListeners.keydown({code,repeat:false,preventDefault(){}}),release=code=>winListeners.keyup({code});const frames=n=>{for(let i=0;i<n;i++){for(const ctx of audioContexts)ctx.advance(1/60);callback();}};

const qa=window.__HOOK_ARENA__,motion=window.__MOTION__;
function fresh(third=false){motion.begin(true);if((qa.view==='third')!==third)key('KeyV');frames(1);}
function launch(){key('KeyQ');frames(16);assert.equal(motion.data.hook.phase,'outbound');}

async function ready(){fresh();await motion.gameAudio.unlock();await motion.gameAudio.preload();frames(1);motion.gameAudio.stopAll();sampleSources.length=0;synthSources.length=0;}

const flashBytes=fs.readFileSync(new URL('../assets/audio/flash/flash-cast.wav',import.meta.url));
const flashSamples=()=>sampleSources.filter(s=>s.buffer?.byteLength===flashBytes.length);
test('Flash excerpt is the exact selected file and does not claim official identity, listening or game-use license',()=>{
 const m=JSON.parse(fs.readFileSync(new URL('../assets/audio/flash/source-manifest.json',import.meta.url)));
 assert.equal(createHash('sha256').update(flashBytes).digest('hex'),m.runtime.sha256);
 assert.equal(flashBytes.toString('ascii',0,4),'RIFF');assert.equal(flashBytes.toString('ascii',8,12),'WAVE');
 assert.equal(m.selection.start,.18);assert.equal(m.selection.end,1.99);assert.equal(m.runtime.duration,1.81);
 assert.equal(m.audioAuditioned,false);assert.equal(m.gameUseLicenseEstablished,false);assert.equal(m.officialSource,false);
 assert.equal(m.video.url,'https://www.youtube.com/watch?v=hqsq7IPt7J0');assert.equal(m.runtime.synthesisUsed,false);
 assert.equal(FLASH_AUDIO_CUES.flashCast.maxDuration,1.81);assert.equal(FLASH_AUDIO_EVENTS.flashCast,'flashCast');
});
test('accepted actual-game Flash starts the selected local sample once and preserves movement',async()=>{
 await ready();const z=motion.data.player.z;assert.equal(motion.castFlash(),true);assert.equal(flashSamples().length,1);
 assert.equal(flashSamples()[0].buffer.duration,1.81);assert(Math.abs(motion.data.player.z-(z-4))<1e-6);assert.equal(qa.flashAbility.casts,1);
 assert.equal(motion.castFlash(),false);key('KeyF');frames(2);assert.equal(flashSamples().length,1);assert.equal(synthSources.length,0);
});
test('blocked Flash rejects audio and cooldown consumption',async()=>{
 await ready();const p=motion.data.player;const wall={min:new RealThree.Vector3(p.x-1,0,p.z-5),max:new RealThree.Vector3(p.x+1,5,p.z-.42)};motion.data.obstacles.push(wall);
 try{assert.equal(motion.castFlash(),false);assert.equal(qa.flashAbility.casts,0);assert.equal(flashSamples().length,0);assert.equal(synthSources.length,0);}finally{motion.data.obstacles.pop();}
});
test('muted accepted Flash moves but never replays on unmute',async()=>{
 await ready();element('sound').onclick();try{assert.equal(motion.castFlash(),true);assert.equal(flashSamples().length,0);}finally{element('sound').onclick();}
 frames(2);assert.equal(flashSamples().length,0);assert.equal(synthSources.length,0);
});
for(const action of ['mute','pause','menu','restart','blur','hidden','capture loss','finish'])test(`Flash sample stops on ${action} without stale replay`,async()=>{
 await ready();motion.castFlash();const sample=flashSamples()[0];assert(sample?.started);
 try{
  if(action==='mute')element('sound').onclick();if(action==='pause')motion.pause();if(action==='menu'){motion.pause();element('mainmenu').onclick();}
  if(action==='restart')motion.begin(true);if(action==='blur')winListeners.blur();if(action==='hidden'){document.hidden=true;docListeners.visibilitychange();}
  if(action==='capture loss')document.exitPointerLock();if(action==='finish')motion.finish();
  assert.equal(sample.stopped,true);const count=flashSamples().length;frames(2);assert.equal(flashSamples().length,count);
 }finally{if(qa.audio.muted)element('sound').onclick();document.hidden=false;}
});
test('audio-only interruption stops Flash without replay when context resumes',async()=>{
 await ready();motion.castFlash();const sample=flashSamples()[0],ctx=audioContexts.at(-1);ctx.setState('interrupted');assert(sample.stopped);ctx.setState('running');frames(2);assert.equal(flashSamples().length,1);assert.equal(qa.audio.active,0);
});
test('failed or pending Flash playback cannot create a synthetic substitute or late sample',async()=>{
 await ready();const original=motion.gameAudio.playEvent,events=[];motion.gameAudio.playEvent=event=>{events.push(event);return false;};
 try{assert.equal(motion.castFlash(),true);assert.deepEqual(events,['flashCast']);assert.equal(flashSamples().length,0);assert.equal(synthSources.length,0);}finally{motion.gameAudio.playEvent=original;}
 frames(2);assert.equal(flashSamples().length,0);
});
test('keyboard auto-repeat and follow-up synthetic click cannot double Flash audio',async()=>{
 await ready();winListeners.keydown({code:'KeyF',repeat:true,preventDefault(){}});assert.equal(flashSamples().length,0);
 const b=element('flashbutton');b.onpointerdown({button:0,pointerType:'touch',preventDefault(){}});b.onclick({detail:1});assert.equal(flashSamples().length,1);
});
test('paused, results and duel countdown cannot play Flash audio',async()=>{
 await ready();motion.pause();assert.equal(motion.castFlash(),false);assert.equal(flashSamples().length,0);
 motion.resume();motion.finish();assert.equal(motion.castFlash(),false);assert.equal(flashSamples().length,0);
 motion.begin(true,false,true);sampleSources.length=0;assert.equal(motion.castFlash(),false);assert.equal(flashSamples().length,0);
});

test('desktop and touch labels describe selected recording and still disclose missing arrival effect',async()=>{
 const markup=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
 assert(markup.includes('출발 영상 프레임과 선택 녹음 사용, 도착 효과 미연결'));
 assert(!markup.includes('도착 효과와 음향 미연결'));
 document.pointerLockElement=null;docListeners.pointerdown({pointerType:'touch'});
 assert.match(element('flashbutton').attributes['aria-label'],/선택 녹음 사용, 도착 효과 미연결/);
});
test('runtime Flash audio status reports decoded availability, not direct listening',async()=>{
 await ready();assert.equal(qa.flashAbility.audio,'recorded-ready');assert(qa.audio.ready.includes('flashCast'));
});
