import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {createHookChain} from '../hook-chain.js';
const v=(x=0,y=2,z=0)=>new THREE.Vector3(x,y,z);
function matrix(chain,i){const m=new THREE.Matrix4();chain.links.getMatrixAt(i,m);return m;}
function center(chain,i){return new THREE.Vector3().setFromMatrixPosition(matrix(chain,i));}
function check(chain,start,end){
  assert(chain.userData.start.equals(start));assert(chain.userData.end.equals(end));
  assert.equal(chain.links.count,chain.userData.linkCount);
  if(chain.links.count){assert(center(chain,0).distanceTo(start)<2e-5);assert(center(chain,chain.links.count-1).distanceTo(end)<2e-5);}
  for(let i=0;i<chain.links.count;i++){
    const m=matrix(chain,i);assert(m.elements.every(Number.isFinite));assert(Math.abs(m.determinant()-1)<1e-5);
    for(let j=0;j<3;j++)assert(Math.abs(new THREE.Vector3().setFromMatrixColumn(m,j).length()-1)<1e-6);
  }
}
test('one instanced mesh uses fixed metal oval geometry with outward triangle winding',()=>{
  const chain=createHookChain(THREE);assert.equal(chain.children.length,1);assert(chain.links.isInstancedMesh);
  assert.equal(chain.links.instanceMatrix.usage,THREE.DynamicDrawUsage);assert.equal(chain.links.frustumCulled,false);
  const geo=chain.links.geometry;geo.computeBoundingBox();const size=geo.boundingBox.getSize(v());
  assert(Math.abs(size.x-.14)<1e-6);assert(Math.abs(size.y-.25)<1e-6);assert(size.z>.03);
  const positions=geo.attributes.position,normals=geo.attributes.normal,index=geo.index;
  for(let i=0;i<index.count;i+=3){const a=new THREE.Vector3().fromBufferAttribute(positions,index.getX(i)),b=new THREE.Vector3().fromBufferAttribute(positions,index.getX(i+1)),c=new THREE.Vector3().fromBufferAttribute(positions,index.getX(i+2));const n=new THREE.Vector3().fromBufferAttribute(normals,index.getX(i));assert(b.sub(a).cross(c.sub(a)).dot(n)>0);}
  assert(chain.links.material.metalness>.7);assert.equal(chain.links.material.emissive.getHex(),0);
});
test('finite orthonormal alternating link planes and exact endpoint centers in all directions',()=>{
  const chain=createHookChain(THREE);
  for(const end of [v(12,3,0),v(0,15,0),v(0,-5,0),v(-7,4,-9),v(0,2,12)]){
    const start=v();chain.update(start,end,{time:.6,phaseTime:.1});check(chain,start,end);
    for(let i=1;i<chain.links.count;i++){
      const a=new THREE.Vector3().setFromMatrixColumn(matrix(chain,i-1),2),b=new THREE.Vector3().setFromMatrixColumn(matrix(chain,i),2);assert(Math.abs(a.dot(b))<.08);
    }
  }
});
test('links retain spatial size and pitch while count changes at sleeve, including reversal',()=>{
  const chain=createHookChain(THREE);let previousNormal;
  for(const length of [2,2.03,2.07,2.11,2.2,2.4,2.2,2.11,2.03,2]){
    chain.update(v(),v(length),{phaseTime:2});check(chain,v(),v(length));
    for(let i=2;i<chain.links.count;i++)assert(Math.abs(center(chain,i).distanceTo(center(chain,i-1))-.17)<.001);
    const n=new THREE.Vector3().setFromMatrixColumn(matrix(chain,chain.links.count-1),2);
    if(previousNormal)assert(n.dot(previousNormal)>.999);previousNormal=n;
  }
});
test('zero, tiny, short, and capacity-limited chain remain finite and reusable',()=>{
  const chain=createHookChain(THREE);
  for(const length of [0,1e-9,.0001,.06,.17,25,1000,0,12]){
    chain.update(v(),v(length));check(chain,v(),v(length));assert(chain.links.count<=256);
    if(length<1e-7)assert.equal(chain.links.count,0);
    if(length===1000)assert.equal(chain.links.count,256);
  }
});
test('return starts continuously then damps to a tauter chain; gravity cannot dip below floor clearance',()=>{
  const chain=createHookChain(THREE),start=v(),end=v(14);
  chain.update(start,end,{phase:'outbound',phaseTime:.3,time:.7});const before=chain.links.instanceMatrix.array.slice(),sag=chain.userData.sag;
  chain.update(start,end,{phase:'return',phaseTime:0,time:.7});assert.deepEqual(chain.links.instanceMatrix.array,before);
  chain.update(start,end,{phase:'return',phaseTime:.3,time:1});assert(chain.userData.sag<sag*.3);check(chain,start,end);
  chain.update(v(0,.1),v(20,.1),{phase:'outbound'});
  for(let i=0;i<chain.links.count;i++)assert(center(chain,i).y>=.07999);
});
test('same inputs are deterministic and update does not replace GPU resources or caller lifecycle',()=>{
  const chain=createHookChain(THREE),geometry=chain.links.geometry,material=chain.links.material,buffer=chain.links.instanceMatrix;
  chain.visible=false;const args=[v(1,3,4),v(12,2,-2),{phase:'outbound',phaseTime:.1,time:.3}];chain.update(...args);const first=buffer.array.slice();chain.update(...args);
  assert.deepEqual(buffer.array,first);assert.equal(chain.visible,false);assert.equal(chain.links.geometry,geometry);assert.equal(chain.links.material,material);assert.equal(chain.links.instanceMatrix,buffer);
});
