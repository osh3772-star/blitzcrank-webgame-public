import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';import {GLTFLoader} from '../vendor/GLTFLoader.js';import {TARGET_MODEL_FILES,attachCharacterTarget,loadCharacterTargets} from '../target-models.js';
const read=p=>fs.readFileSync(new URL(p,import.meta.url)),fixture=JSON.parse(read('./fixtures/cannon-wheel-colors.json')),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const bytes=[fixture.sourceSha256,fixture.expectedSha256].map(h=>read('../assets/targets/cannon.'+h.slice(0,16)+'.glb'));
const docs=bytes.map(b=>JSON.parse(b.subarray(20,20+b.readUInt32LE(12)))),bins=bytes.map(b=>b.subarray(28+b.readUInt32LE(12)));
const gltfs=await Promise.all(bytes.map(b=>new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'')));
function meshes(g){const out=[];g.scene.traverse(o=>{if(o.isMesh)out.push(o);});return out;}
const [before,after]=gltfs.map(meshes),key=p=>p.map(x=>Number(x.toFixed(6))).join(','),expected=new Map(fixture.rows.map(r=>[r.material+'|'+key(r.positionLocalGLTF),r.rgba]));
test('current loader names the exact immutable wheel asset and preserves the previous asset',async()=>{
 assert.equal(sha(bytes[0]),fixture.sourceSha256);assert.equal(sha(bytes[1]),fixture.expectedSha256);assert.equal(TARGET_MODEL_FILES.cannon,'cannon.'+fixture.expectedSha256.slice(0,16)+'.glb');
 const row=JSON.parse(read('../assets/targets/source-manifest.json')).find(x=>x.asset==='cannon');assert.equal(row.sha256,fixture.expectedSha256);assert.equal(row.bytes,bytes[1].length);assert.equal(row.triangles,9998);assert.equal(row.materials,7);
 const loaded=await loadCharacterTargets(async url=>{const b=read('../'+url.slice(2));return{ok:true,arrayBuffer:async()=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)};});assert.equal(loaded.length,3);assert.equal(meshes(loaded[2]).length,7);
});
test('every original binary byte and accessor is exact, with only appended colour buffers',()=>{
 assert.deepEqual(bins[1].subarray(0,bins[0].length),bins[0]);assert.deepEqual(docs[1].accessors.slice(0,docs[0].accessors.length),docs[0].accessors);assert.deepEqual(docs[1].bufferViews.slice(0,docs[0].bufferViews.length),docs[0].bufferViews);
 for(const field of ['asset','nodes','materials','scenes','scene'])assert.deepEqual(docs[1][field],docs[0][field]);
 const clean=structuredClone(docs[1].meshes);for(const p of clean[0].primitives)delete p.attributes.COLOR_0;assert.deepEqual(clean,docs[0].meshes);assert.equal(docs[1].accessors.length-docs[0].accessors.length,2);
});
test('GLB chunks, all attributes, index limits and embedded resource bounds are valid',()=>{
 const b=bytes[1],d=docs[1];assert.equal(b.readUInt32LE(0),0x46546c67);assert.equal(b.readUInt32LE(4),2);assert.equal(b.readUInt32LE(8),b.length);assert.equal(b.readUInt32LE(16),0x4e4f534a);const end=20+b.readUInt32LE(12);assert.equal(b.readUInt32LE(end+4),0x004e4942);assert.equal(end+8+b.readUInt32LE(end),b.length);assert.equal(d.buffers[0].byteLength,bins[1].length);assert(!d.buffers[0].uri);
 for(const k of ['skins','animations','images','textures','extensionsRequired'])assert.equal((d[k]||[]).length,0);
 const sizes={5121:1,5123:2,5125:4,5126:4},width={SCALAR:1,VEC2:2,VEC3:3,VEC4:4};for(const a of d.accessors){const v=d.bufferViews[a.bufferView],size=sizes[a.componentType]*width[a.type];assert(size);assert(!a.sparse);assert(v.byteOffset+v.byteLength<=bins[1].length);assert((a.byteOffset||0)+(a.count-1)*(v.byteStride||size)+size<=v.byteLength);}
 for(const m of after){for(const a of Object.values(m.geometry.attributes))assert(Array.from(a.array).every(Number.isFinite));for(const i of m.geometry.index.array)assert(i>=0&&i<m.geometry.attributes.position.count);}
});
test('Three geometry, normals, UVs, indices and transforms are exact for all seven primitives',()=>{
 assert.equal(before.length,7);assert.equal(after.length,7);let triangles=0;
 for(let i=0;i<before.length;i++){const a=before[i],b=after[i];assert.equal(b.material.name,a.material.name);for(const k of Object.keys(a.geometry.attributes))assert.deepEqual(b.geometry.attributes[k].array,a.geometry.attributes[k].array);assert.deepEqual(b.geometry.index.array,a.geometry.index.array);assert.deepEqual(b.matrix.toArray(),a.matrix.toArray());triangles+=b.geometry.index.count/3;}
 assert.equal(triangles,9998);
});
test('only the eight selected wheel components change colour; every unrelated vertex is white or untouched',()=>{
 let changed=0,unselected=0,attributes=0;const seen=new Set();for(let j=0;j<after.length;j++){const m=after[j],g=m.geometry,c=g.attributes.color,p=g.attributes.position;if(c){attributes++;assert(m.material.vertexColors);assert.equal(c.normalized,true);assert.equal(c.itemSize,4);assert.equal(c.count,p.count);}else assert(!m.material.vertexColors);
  for(let i=0;i<p.count;i++){const k=m.material.name+'|'+key([p.getX(i),p.getY(i),p.getZ(i)]),e=expected.get(k);if(e){assert(c,k);assert.deepEqual(Array.from(c.array.slice(i*4,i*4+4)),e);seen.add(k);changed++;}else{unselected++;if(c)assert.deepEqual(Array.from(c.array.slice(i*4,i*4+4)),[255,255,255,255]);}}
 }assert.equal(attributes,2);assert.equal(changed,3816);assert.equal(seen.size,expected.size);assert(unselected>6000);
});
test('no new material, texture, draw primitive, triangle or animation is introduced',()=>{
 assert.equal(docs[1].materials.length,7);assert.equal(docs[1].meshes.length,1);assert.equal(docs[1].meshes[0].primitives.length,7);assert.equal(bytes[1].length-bytes[0].length,43824);assert.equal(bins[1].length-bins[0].length,43496);
});
for(const position of [[0,0,0],[12,3,-18],[-9,1.8,4]])test('normalization, ring, collider and 242 aim rays are exact at '+position,()=>{
 const targets=gltfs.map(g=>{const group=new THREE.Group(),ring=new THREE.Group();group.position.fromArray(position);group.add(ring);return attachCharacterTarget({group,ring},{scene:g.scene,id:'cannon',label:'cannon'});});const[a,b]=targets;
 for(const k of ['position','scale','quaternion'])assert.deepEqual(a.character[k].toArray(),b.character[k].toArray());for(const k of ['min','max'])assert.deepEqual(a.bounds[k].toArray(),b.bounds[k].toArray());assert.deepEqual(a.ring.position.toArray(),b.ring.position.toArray());assert.deepEqual(a.ring.rotation.toArray(),b.ring.rotation.toArray());
 const boxes=targets.map(t=>new THREE.Box3(t.bounds.min.clone().add(t.group.position),t.bounds.max.clone().add(t.group.position)));let n=0;for(const third of [false,true])for(let x=-5;x<=5;x++)for(let y=-5;y<=5;y++){const origin=new THREE.Vector3(position[0]+(third?.6:0),position[1]+(third?.5:0),position[2]+6),direction=new THREE.Vector3(position[0]+x*.22,position[1]+y*.24,position[2]).sub(origin).normalize(),ray=new THREE.Ray(origin,direction);assert.deepEqual(ray.intersectBox(boxes[0],new THREE.Vector3())?.toArray(),ray.intersectBox(boxes[1],new THREE.Vector3())?.toArray());n++;}assert.equal(n,242);
});
