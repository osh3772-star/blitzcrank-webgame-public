import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {TARGET_TYPES,TARGET_MODEL_FILES,loadCharacterTargets} from '../target-models.js';
const file=path=>fileURLToPath(new URL(path,import.meta.url));
const expected='eca6d8f038e90aa41b1b5ad9162f10919d86b07c11dc154ce9533d70126ddcd6';
test('historical guardian fitted face remains immutable and current loader still decodes the same material/triangle contract',async()=>{
 const historical='guardian.'+expected.slice(0,16)+'.glb';
 const bytes=fs.readFileSync(file('../assets/targets/'+historical));
 assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),expected);assert.equal(bytes.length,353080);
 const row=JSON.parse(fs.readFileSync(file('../assets/targets/source-manifest.json'))).find(x=>x.asset==='guardian');
 assert.equal(row.file,TARGET_MODEL_FILES.guardian);assert.equal(row.sha256,crypto.createHash('sha256').update(fs.readFileSync(file('../assets/targets/'+TARGET_MODEL_FILES.guardian))).digest('hex'));assert.equal(row.bytes,353080);assert.equal(row.triangles,4636);assert.equal(row.materials,9);assert.equal(row.draw_primitives,9);
 const requested=[],allowed=TARGET_TYPES.map(type=>'./assets/targets/'+TARGET_MODEL_FILES[type.id]);
 const assets=await loadCharacterTargets(async url=>{
  assert(allowed.includes(url));requested.push(url);const data=fs.readFileSync(file('../'+url.slice(2)));
  const json=JSON.parse(data.subarray(20,20+data.readUInt32LE(12)));assert(json.buffers.every(buffer=>!buffer.uri));assert.equal((json.images||[]).length,0);
  return{ok:true,arrayBuffer:async()=>data.buffer.slice(data.byteOffset,data.byteOffset+data.byteLength)};
 });
 assert.deepEqual(requested,allowed);assert.deepEqual(assets.map(x=>x.id),TARGET_TYPES.map(x=>x.id));
 let triangles=0;assets.find(x=>x.id==='guardian').scene.traverse(o=>{if(o.isMesh)triangles+=o.geometry.index.count/3;});assert.equal(triangles,4636);
});
test('historical guardian face preserves exact bounded geometry, rear and unaffected front hits, palette and collider',()=>{
 const report=JSON.parse(execFileSync(process.execPath,['--max-old-space-size=128',file('../validation/guardian-face-v2475/regression.mjs'),'--baseline',file('../validation/recovered-assets/guardian.638195a23537033b.glb'),'--candidate',file('../assets/targets/guardian.'+expected.slice(0,16)+'.glb'),'--three',file('../vendor/three.module.js'),'--loader',file('../vendor/GLTFLoader.js'),'--target-models',file('../target-models.js')],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024}));
 assert.equal(report.pass,true);assert.equal(report.inputs.candidate.sha256,expected);
 assert.equal(report.materialDefinitionsExact,true);assert.equal(report.nodesExact,true);assert.equal(report.runtimeEnvelopeExact,true);assert.equal(report.noAnimationsSkinsTexturesOrExternalAssets,true);
 assert.equal(report.unaffectedFrontRaysExact,9925);assert.equal(report.rearRaysExact,10201);assert.equal(report.faceProbes,7200);assert.deepEqual(report.darkFirstHits,{baseline:2578,candidate:584});
 assert.equal(report.eyeFirstHits.length,2);assert(report.eyeFirstHits.every(hit=>hit.material==='Eye cavity'));assert.equal(report.bridgeFirstHits.length,3);assert(report.bridgeFirstHits.every(hit=>hit.material==='Frost blue mask'));
 assert.equal(report.triangleDeltas.filter(x=>!x.removed&&!x.added).length,6);
 assert.deepEqual(report.triangleDeltas.filter(x=>x.removed||x.added).map(x=>[x.material,x.removed,x.added]),[['Armor edges',88,0],['Frost blue mask',144,34],['Eye cavity',24,24]]);
 assert.equal(report.networkCalls,0);assert.equal(report.externalCalls,0);
});
