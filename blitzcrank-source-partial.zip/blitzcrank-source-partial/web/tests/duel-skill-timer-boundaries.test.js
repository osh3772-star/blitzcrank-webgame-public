import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createDuelSimulation,DUEL_SHAPE} from '../duel-simulation.js';
import {CONFIG} from '../core.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';
const clips=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))).models.fullbody.clips;
const ids=['human','bot'],point=(x,y=1.7,z=0)=>({x,y,z});
function fixture(hz){
 const sim=createDuelSimulation({sessionId:'timer-boundaries',config:CONFIG,countdownMs:100,skillClips:clips});
 const frame={actors:ids.map((playerId,i)=>({playerId,shape:DUEL_SHAPE,motion:{type:'linear',from:point(i*40),to:point(i*40)}})),obstacles:[],sockets:Object.fromEntries(ids.map((id,i)=>[id,{origin:point(i*40),home:point(i*40),direction:point(i?-1:1,0)}]))};
 assert.equal(sim.state.phase,'preparing');assert(sim.prepare());assert.equal(sim.state.phase,'countdown');
 for(const id of ids){assert.equal(sim.getSkills(id).blockReason('W'),'round');assert.equal(sim.getSkills(id).castW(),false);}
 for(let n=0;n<hz&&!sim.active;n++)assert(sim.step(1/hz,frame));
 assert(sim.active);assert.equal(sim.state.phase,'active');
 const step=(n=1)=>{for(let i=0;i<n;i++)assert(sim.step(1/hz,frame));assert(sim.active);assert.equal(sim.state.history.length,0);assert.deepEqual(sim.state.scores.map(s=>s.points),[0,0]);};
 return {sim,step};
}
for(const hz of [30,60,120])for(const id of ids){
 for(const skill of ['W','E','R'])test(`duel ${id} ${skill} exact cooldown permits recast at ${hz} Hz`,()=>{
  const {sim,step}=fixture(hz),c=sim.getSkills(id);assert(c['cast'+skill]());
  if(skill==='E'){step(hz);assert.equal(c.status.phase,'E_Hold');assert(c.strikeE());step(4*hz-1);}else step(12*hz-1);
  assert(c.status.cooldown[skill]>0);assert.equal(c.blockReason(skill),'cooldown');assert.equal(c['cast'+skill](),false);
  step();assert.equal(c.status.cooldown[skill],0);assert.equal(c.blockReason(skill),null);assert(c['cast'+skill]());
  const impacts=sim.drainEvents().filter(e=>e.type==='skill-impact');
  if(skill!=='W'){assert.equal(impacts.length,1);assert.equal(impacts[0].hit,false);}
  assert.equal(sim.getSkills(id==='human'?'bot':'human').status.cooldown[skill],0);
 });
 test(`duel ${id} W boost changes movement and attack at four seconds at ${hz} Hz`,()=>{
  const {sim,step}=fixture(hz),c=sim.getSkills(id);assert(c.castW());step(4*hz-1);assert.equal(c.moveMultiplier,1.55);assert.equal(c.attackMultiplier,1.5);
  step();assert.equal(c.status.boost,0);assert.equal(c.status.slow,2);assert.equal(c.moveMultiplier,.65);assert.equal(c.attackMultiplier,1);assert.equal(c.animation.name,'W_Loop_Slow');
  step(2*hz);assert.equal(c.status.slow,0);assert.equal(c.moveMultiplier,1);
 });
 test(`duel ${id} W slow expires two seconds after its actual start at ${hz} Hz`,()=>{
  const {sim,step}=fixture(hz),c=sim.getSkills(id);assert(c.castW());let frames=0;while(c.status.boost>0&&frames++<=4*hz+1)step();
  assert.equal(c.status.boost,0);assert.equal(c.status.slow,2);step(2*hz-1);assert(c.status.slow>0);assert.equal(c.moveMultiplier,.65);
  step();assert.equal(c.status.slow,0);assert.equal(c.moveMultiplier,1);
 });
}
