import {createRRuntimeOracle} from './helpers/r-runtime-composition-oracle.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as THREE from '../vendor/three.module.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import {rig} from './helpers/locomotion-rig.js';
import {bindSkillClips,createFullbodyPoseApplicator} from '../skill-animation.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'jump-runtime-'));
const instrumented=path.join(temporary,'main.js');
fs.writeFileSync(instrumented,fs.readFileSync(new URL('../main.js',import.meta.url),'utf8')+`\nwindow.__JUMP_EXTRA__={animateFullbody,updateFullbodyHand,cableSocket,chainHandSocket,prepareMirrorBody,restoreMirrorBody,get data(){return{fullbody,fullbodySocket,hook,rope,fist,velocityY,grounded}}};`);
const h=await createGameplayHarness({sourcePath:instrumented}).finally(()=>fs.rmSync(temporary,{recursive:true,force:true})),extra=globalThis.__JUMP_EXTRA__;
const motion=()=>h.qa.motion.locomotion;
const jump=()=>motion().jump;
function key(k){h.key(k);h.release(k);}
function fresh(third=false,practice=true){h.game.begin(practice);if((h.qa.view==='third')!==third)key('KeyV');h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}}
function matrices(relative=false){return [...h.game.data.fullbodyMeshes].map(([name,m])=>{m.updateWorldMatrix(true,false);const a=m.matrixWorld.toArray();if(relative){a[12]-=h.qa.player.x;a[13]-=h.qa.player.y-1.7;a[14]-=h.qa.player.z;}return [name,a];});}
function nearMatrices(a,b,tolerance=1e-10){assert.equal(a.length,b.length);for(let i=0;i<a.length;i++){assert.equal(a[i][0],b[i][0]);for(let k=0;k<16;k++)assert(Math.abs(a[i][1][k]-b[i][1][k])<tolerance,`${a[i][0]} matrix[${k}]`);}}
function point(name,p){const m=h.game.data.fullbodyMeshes.get(name);m.updateWorldMatrix(true,false);return new THREE.Vector3(...p).sub(new THREE.Vector3(...m.userData.skillRestPoint)).applyMatrix4(m.matrixWorld);}
function minY(name){const m=h.game.data.fullbodyMeshes.get(name),v=new THREE.Vector3(),p=m.geometry.attributes.position;m.updateWorldMatrix(true,false);let y=Infinity;for(let i=0;i<p.count;i++)y=Math.min(y,v.fromBufferAttribute(p,i).applyMatrix4(m.matrixWorld).y);return y;}
const diagnostics={minSole:Infinity,minFinger:Infinity,maxSeam:0,maxFrameFootTravel:0};
let geometryContext=null;
function geometry(){for(const [name] of h.game.data.fullbodyMeshes)if(/Finger|Thumb/.test(name)){const y=minY(name);diagnostics.minFinger=Math.min(diagnostics.minFinger,y);assert(y>0,'finger below floor '+name+' '+y);}for(const [,a]of matrices())assert(a.every(Number.isFinite));for(const s of ['L','R']){const y=minY('BC_FootSole.'+s);diagnostics.minSole=Math.min(diagnostics.minSole,y);assert(y>-.0001,'sole below floor '+y);const sign=s==='L'?1:-1;for(const [a,b,p]of [['BC_Pelvis','BC_Hip.'+s,[sign*.35,.9226,-.014303]],['BC_Thigh.'+s,'BC_Knee.'+s,[sign*.3872,.5416,-.014303]],['BC_Shin.'+s,'BC_Foot.'+s,[sign*.4576,.146944,-.044303]]]){const gap=point(a,p).distanceTo(point(b,p));if(gap>diagnostics.maxSeam){diagnostics.maxSeam=gap;diagnostics.seamContext={...geometryContext,a,b,jump:jump()};}}}}

test('jump preserves exact existing vertical physics and cannot double jump',()=>{
 fresh();key('Space');let y=1.7,v=7;for(let f=0;f<90;f++){if(f===9)key('Space');v-=20*(1/60);y+=v*(1/60);if(y<=1.7){y=1.7;v=0;}h.frames(1);assert.equal(h.qa.player.y,y);assert.equal(extra.data.velocityY,v);assert.equal(extra.data.grounded,y===1.7);}assert.equal(jump().active,false);
});

test('stationary, moving and E jumps retain finite joined legs, ground clearance and bounded continuity',()=>{
 for(const moving of [false,true])for(const e of [false,true]){fresh();if(e){key('KeyE');h.frames(53);}if(moving){h.key('KeyW');h.frames(20);}key('Space');let peakTuck=0,previous=null;for(let f=0;f<115;f++){h.frames(1);geometryContext={moving,e,frame:f};try{geometry();}catch(error){error.message+=` moving=${moving} E=${e} frame=${f} jump=${JSON.stringify(jump())}`;throw new Error(error.message,{cause:error});}peakTuck=Math.max(peakTuck,jump().tuck);const p=point('BC_Foot.L',[.4576,.146944,-.044303]);if(previous){const d=p.distanceTo(previous);diagnostics.maxFrameFootTravel=Math.max(diagnostics.maxFrameFootTravel,d);assert(d<.28,'foot discontinuity '+d);}previous=p;if(f===45)h.release('KeyW');}assert(peakTuck>.01,'visible jump tuck');assert.equal(jump().active,false);for(const s of ['L','R'])assert(Math.abs(minY('BC_FootSole.'+s))<1e-6);}
});

test('pause and zero-dt view refresh freeze ascent apex descent and landing',()=>{
 for(const frame of [5,20,32,44])for(const e of [false,true]){fresh();if(e){key('KeyE');h.frames(53);}key('Space');h.frames(frame);h.game.pause();const state=motion(),before=matrices(),player=h.qa.player;h.frames(90);for(let i=0;i<4;i++)h.element('viewtoggle').onclick();assert.deepEqual(motion(),state);assert.deepEqual(h.qa.player,player);nearMatrices(matrices(),before);h.game.resume();h.frames(100);assert.equal(jump().active,false);}
});

test('R jump composes exact authored upper and anchored lower poses through recovery and exit',()=>{
 const oracle=createRRuntimeOracle();
 for(const moving of [false,true])for(const airborne of [false,true]){
  fresh();oracle.reset();
  if(moving){h.key('KeyW');for(let f=0;f<20;f++)oracle.step(h);}
  if(airborne){key('Space');oracle.jump();}
  h.game.castR();assert.equal(h.qa.skills.phase,'R_Cast');oracle.cast();
  for(let f=1;f<=70;f++){oracle.step(h);if([2,12,25,41,42,43,55,67,68,70].includes(f))oracle.check(h,`R jump moving=${moving} air=${airborne} frame=${f}`);}
  h.release('KeyW');
 }
 const report=oracle.summary();assert.equal(report.surfaces,279);assert(report.upperAuthored>0&&report.recovery>0&&report.exit>0);console.log('R_JUMP_COMPOSITION '+JSON.stringify(report));
});

test('airborne E upper body is authored only plus common root translation',()=>{
 for(const phase of ['E_Charge','E_Hold','E_Strike']){const setup=()=>{key('KeyE');if(phase!=='E_Charge')h.frames(53);if(phase==='E_Strike')h.punch();};fresh();setup();h.frames(12);const expected=matrices(true),root=extra.data.fullbody.position.y-(h.qa.player.y-1.7);fresh();setup();key('Space');h.frames(12);const offset=extra.data.fullbody.position.y-(h.qa.player.y-1.7)-root,actual=matrices(true);for(let i=0;i<actual.length;i++){let n=h.game.data.fullbodyMeshes.get(actual[i][0]),upper=false;for(;n;n=n.parent)if(n===h.game.data.fullbodyNodes.get('BC_Torso'))upper=true;if(upper){actual[i][1][13]-=offset;nearMatrices([actual[i]],[expected[i]]);}}for(const s of ['L','R'])assert.deepEqual(h.game.data.fullbodyNodes.get('BC_Pivot_Shoulder.'+s).quaternion.toArray(),[0,0,0,1]);}
});

test('Q detached palm and chain endpoints track correctly during jump in both views',()=>{
 for(const third of [false,true]){fresh(third);key('Space');key('KeyQ');let detached=0;for(let f=0;f<210;f++){h.frames(1);const d=extra.data;if(d.hook&&['outbound','return'].includes(d.hook.phase)){detached++;const palm=h.game.data.fullbodyMeshes.get('BC_Palm.R');palm.updateWorldMatrix(true,false);const p=palm.localToWorld(palm.geometry.boundingBox.getCenter(new THREE.Vector3()));assert(p.distanceTo(d.hook.position)<1e-9);assert(d.rope.userData.start.distanceTo(extra.cableSocket())<1e-9);assert(d.rope.userData.end.distanceTo(extra.chainHandSocket())<1e-9);const token=extra.prepareMirrorBody();extra.restoreMirrorBody(token);assert.equal(d.fullbody.visible,third);}if(d.hook)assert.equal(h.game.data.fullbodyNodes.get('BC_Pivot_Shoulder.R').rotation.z,0);}assert(detached>0);assert.equal(h.qa.hook,null);}
});

test('death timeout menu and restart clear jump pose and remain frozen without stale Q',()=>{
 for(const third of [false,true])for(const ending of ['death','timeout','menu','restart'])for(const q of [false,true]){fresh(third,ending!=='timeout');key('Space');if(q)key('KeyQ');h.frames(15);assert(jump().active);if(ending==='death')h.game.damagePlayer(100);if(ending==='timeout'){h.game.setElapsed(89.99);h.frames(1);}if(ending==='menu'){h.game.pause();h.element('mainmenu').onclick();}if(ending==='restart')h.game.begin(true);assert.equal(jump().active,false);assert.equal(jump().weight,0);assert.equal(h.qa.hook,null);for(const s of ['L','R']){const n=h.game.data.fullbodyNodes.get('BC_Knee.'+s);assert.deepEqual(n.position.toArray(),n.userData.base);assert.deepEqual(n.quaternion.toArray(),[0,0,0,1]);}const before=matrices();if(ending!=='restart'){h.frames(40);nearMatrices(matrices(),before);}fresh(third);h.frames(80);assert.equal(jump().active,false);geometry();}
});

test('jump geometry diagnostics and bounded seams',()=>{console.log('JUMP_RUNTIME_GEOMETRY '+JSON.stringify(diagnostics));assert(diagnostics.maxSeam<.015,'maximum joint seam '+diagnostics.maxSeam);});

const authoredRig=rig(),authoredSurfaces=[...authoredRig.meshes.values()],authoredClips=Object.fromEntries(bindSkillClips(JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))).models.fullbody,authoredSurfaces).map(c=>[c.name,c])),applyAuthored=createFullbodyPoseApplicator(THREE);
function lower(name){for(let n=h.game.data.fullbodyMeshes.get(name);n;n=n.parent)if(n.name.startsWith('BC_Pivot_Hip.'))return true;return false;}
function exactAuthoredW(){const status=h.qa.skills.animation,p=status.presentation||status;assert(p.name.startsWith('W_'));applyAuthored(authoredClips[p.name],p.time,authoredSurfaces);authoredRig.body.position.copy(h.game.data.fullbody.position);authoredRig.body.quaternion.copy(h.game.data.fullbody.quaternion);authoredRig.body.updateMatrixWorld(true);for(const [name,reference]of authoredRig.meshes){const actual=h.game.data.fullbodyMeshes.get(name);actual.updateWorldMatrix(true,false);for(let k=0;k<16;k++)assert(Math.abs(actual.matrixWorld.elements[k]-reference.matrixWorld.elements[k])<1e-10,name+' must retain authored moving/airborne W');}}

test('W jump preserves every authored upper pose and restores the full authored pose after the stationary fade',()=>{
 for(const elapsed of [2,8,12,25]){
  fresh();h.game.castW();h.frames(elapsed);const expected=matrices(true);fresh();key('Space');h.game.castW();h.frames(elapsed);assert.equal(extra.data.grounded,false);const actual=matrices(true);assert.equal(actual.length,expected.length);
  for(let i=0;i<actual.length;i++){assert.equal(actual[i][0],expected[i][0]);if(!lower(actual[i][0]))nearMatrices([actual[i]],[expected[i]]);else assert(actual[i][1].every(Number.isFinite));}
  for(const side of ['L','R'])assert(minY('BC_FootSole.'+side)-(h.qa.player.y-1.7)>-.000001,'W airborne sole must not go below its root-relative floor');
  if(elapsed/60>=.12)exactAuthoredW();
 }
});
