import test from 'node:test';import assert from 'node:assert/strict';
import {validateSkillSourceParts,validateSkillAsset,loadSkillAsset} from '../skill-animation.js';
import {validateSkillAsset as original} from './fixtures/skill-animation-v0.24.54-baseline.js';
const pose=()=>({p:[0,0,0],q:[0,0,0,1],s:[1,1,1]});
const model=()=>({sourceParts:['palm'],clips:[{name:'E',fps:1,duration:1,loop:false,events:[{type:'impact',time:.5}],frames:[{poses:[pose()]},{poses:[pose()]}]}]});
const data=()=>({version:1,models:{viewmodel:model(),fullbody:model()}});
function outcome(fn,d,e){try{return {same:fn(d,e)===d};}catch(error){return {name:error.name,message:error.message};}}
test('source-only check preserves return identity, input and name-set bindings',()=>{
 const d=data(),before=structuredClone(d);assert.equal(validateSkillSourceParts(d,{viewmodel:['palm'],fullbody:['palm']}),d);assert.deepEqual(d,before);
 for(const type of ['viewmodel','fullbody']){d.models[type].sourceParts.push('wrist');assert.equal(validateSkillSourceParts(d,{[type]:['wrist','palm']}),d);assert.throws(()=>validateSkillSourceParts(d,{[type]:['palm']}),new RegExp('mismatch: '+type));}
});
test('source-only check rejects missing, empty, duplicate and invalid part names',()=>{
 for(const d of [null,undefined,{}, {version:2}, {version:1,models:{}}, {version:1,models:{viewmodel:null}}])assert.throws(()=>validateSkillSourceParts(d));
 for(const type of ['viewmodel','fullbody'])for(const value of [undefined,null,{},[],['a','a'],[1],['']]){const d=data();d.models[type].sourceParts=value;assert.throws(()=>validateSkillSourceParts(d));}
});
test('binding check deliberately does not read clips and is not a schema cache',()=>{
 const d=data();for(const m of Object.values(d.models))Object.defineProperty(m,'clips',{get(){throw Error('clips accessed');}});
 assert.equal(validateSkillSourceParts(d),d);assert.throws(()=>validateSkillAsset(d),/clips accessed/);
 const mutable=data();validateSkillAsset(mutable);mutable.models.fullbody.clips[0].frames[0].poses[0].s[0]=0;assert.throws(()=>validateSkillAsset(mutable),/quaternion\/scale/);
});
test('full validator retains source access and failure order against original API',()=>{
 function run(fn,mode){const d=data(),trace=[];for(const type of ['viewmodel','fullbody']){const m=d.models[type],parts=m.sourceParts,clips=m.clips;Object.defineProperty(m,'sourceParts',{get(){trace.push(type+'.sourceParts');return mode==='badfull'&&type==='fullbody'?[]:parts;}});Object.defineProperty(m,'clips',{get(){trace.push(type+'.clips');return mode==='badfull'&&type==='viewmodel'?[]:clips;}});}
 const models=d.models;Object.defineProperty(d,'version',{get(){trace.push('version');return 1;}});Object.defineProperty(d,'models',{get(){trace.push('models');return models;}});const e={};for(const type of ['viewmodel','fullbody'])Object.defineProperty(e,type,{get(){trace.push('expected.'+type);return ['palm'];}});
 return {outcome:outcome(fn,d,e),trace};}
 for(const mode of ['good','badfull'])assert.deepEqual(run(validateSkillAsset,mode),run(original,mode));
 const d=data();d.models.viewmodel.clips=[];d.models.fullbody.sourceParts=[];assert.throws(()=>validateSkillAsset(d),/^Error: No skill clips$/);assert.deepEqual(outcome(validateSkillAsset,data(),null),outcome(original,data(),null));
});
test('real loader still fully rejects malformed JSON at the correct byte length',async()=>{
 for(const mutate of [d=>d.version=2,d=>d.models.viewmodel.sourceParts=[],d=>d.models.fullbody.sourceParts=['x','x'],d=>d.models.viewmodel.clips[0].duration=3,d=>d.models.fullbody.clips[0].events[0].time=2,d=>d.models.viewmodel.clips[0].frames[0].poses[0].p[0]='bad',d=>d.models.fullbody.clips[0].frames[1].poses[0].q=[0,0,0,0],d=>d.models.fullbody.clips[0].frames[0].poses[0].s[1]=0]){
  const d=data();mutate(d);const bytes=new TextEncoder().encode(JSON.stringify(d));await assert.rejects(loadSkillAsset({raw:'local',bytes:bytes.length},{DecompressionStreamImpl:null,fetchImpl:async()=>({ok:true,arrayBuffer:async()=>bytes.buffer})}));
 }
});
test('source-only check removes pose reads while loader/full validator retain them',()=>{
 function measure(fn){const d=data();let reads=0;for(const m of Object.values(d.models))for(const f of m.clips[0].frames){const values=f.poses[0];for(const k of ['p','q','s']){const v=values[k];Object.defineProperty(values,k,{get(){reads++;return v;}});}}fn(d,{viewmodel:['palm'],fullbody:['palm']});return reads;}
 assert.equal(measure(validateSkillSourceParts),0);assert(measure(validateSkillAsset)>0);
});
