import test from 'node:test';import {rayBox} from '../core.js';import assert from 'node:assert/strict';import fs from 'node:fs';import * as RealThree from '../vendor/three.module.js';
// CPU-only smoke harness. It runs the actual game module and Three.js scene graph,
// but deliberately does not claim GPU rendering or physical-browser input coverage.
class Classes{constructor(){this.s=new Set();}toggle(x,force){if(force===undefined)force=!this.s.has(x);force?this.s.add(x):this.s.delete(x);}add(x){this.s.add(x);}remove(x){this.s.delete(x);}}
class Element{constructor(){this.style={};this.classList=new Classes();this.firstElementChild={style:{}};this.parentElement={classList:new Classes()};this.value='1';this.disabled=false;this.listeners={};this.textContent='';this.innerHTML='';}addEventListener(k,f){const previous=this.listeners[k];this.listeners[k]=e=>{previous?.(e);f(e);};}setAttribute(){}querySelector(){return new Element();}getBoundingClientRect(){return{left:0,top:0,width:110,height:110};}setPointerCapture(){}requestPointerLock(){document.pointerLockElement=this;docListeners.pointerlockchange?.();return Promise.resolve();}click(){this.onclick?.();}getContext(){return{fillRect(){},fillText(){},fillStyle:'',textAlign:'',font:''};}}
const elements=new Map(),docListeners={},winListeners={};let callback;
const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
globalThis.document={getElementById:element,querySelector:element,createElement:()=>new Element(),addEventListener:(n,f)=>docListeners[n]=f,pointerLockElement:null,exitPointerLock(){this.pointerLockElement=null;docListeners.pointerlockchange?.();}};globalThis.window=globalThis;globalThis.innerWidth=1280;globalThis.innerHeight=720;globalThis.devicePixelRatio=1;globalThis.matchMedia=()=>({matches:false});globalThis.localStorage={getItem:()=>null,setItem(){}};globalThis.addEventListener=(n,f)=>winListeners[n]=f;globalThis.requestAnimationFrame=f=>{callback=f;};globalThis.fetch=async(path)=>({ok:true,arrayBuffer:async()=>{const b=fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);},json:async()=>JSON.parse(fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url)))});
class Renderer{constructor(){this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}render(){}clearDepth(){}}
class Clock{getDelta(){return 1/60;}}
class TextureLoader{async loadAsync(path){assert(fs.existsSync(new URL('../'+path.replace('./',''),import.meta.url)));return new RealThree.Texture();}}
globalThis.testThree={...RealThree,WebGLRenderer:Renderer,Clock,TextureLoader};
let source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8').replace("import * as THREE from './vendor/three.module.js';",'const THREE = globalThis.testThree;').replace("from './hook-chain.js'",`from '${new URL('../hook-chain.js',import.meta.url).href}'`).replace("from './training-mirror.js'",`from '${new URL('../training-mirror.js',import.meta.url).href}'`).replace("from './game-audio.js'",`from '${new URL('../game-audio.js',import.meta.url).href}'`).replace("from './audio-cues.js'",`from '${new URL('../audio-cues.js',import.meta.url).href}'`).replace("from './voice-cues.js'",`from '${new URL('../voice-cues.js',import.meta.url).href}'`).replace("from './voice-schedule.js'",`from '${new URL('../voice-schedule.js',import.meta.url).href}'`).replace("from './blitz-materials.js'",`from '${new URL('../blitz-materials.js',import.meta.url).href}'`).replace("from './core.js'",`from '${new URL('../core.js',import.meta.url).href}'`).replace("from './mouse-look.js'",`from '${new URL('../mouse-look.js',import.meta.url).href}'`).replace("from './target-models.js'",`from '${new URL('../target-models.js',import.meta.url).href}'`).replace("from './turret-view.js'",`from '${new URL('../turret-view.js',import.meta.url).href}'`);
source+=`\nwindow.__MOTION__={get data(){return{hook,fist,rope,parts,projectileParts,camera,viewCamera,viewmodel,targets,obstacles,fullbodySocket,player,turretArena,fullbodyNodes,fullbodyMeshes}},prepareMirrorBody,restoreMirrorBody,fullbodyCableSocket,fullbodyChainSocket,get mirror(){return trainingMirror},handPoint,cableSocket,chainHandSocket,nearestRay,begin,pause,resume,damagePlayer};`;
source=source.replace("from './model-codec.js'",`from '${new URL('../model-codec.js',import.meta.url).href}'`).replace("from './player-model-manifest.js'",`from '${new URL('../player-model-manifest.js',import.meta.url).href}'`);
source=source.replace(/from '\.\/([^']+)'/g,(_,path)=>`from '${new URL('../'+path,import.meta.url).href}'`);
// This fixture exercises initialized gameplay, not the natural first selection.
source+='\nif(typeof ensureGameplayAssets==="function")await ensureGameplayAssets();';
await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const punch=()=>element('game').listeners.pointerdown({pointerType:'mouse',button:0,preventDefault(){}});
const key=code=>winListeners.keydown({code,repeat:false,preventDefault(){}}),release=code=>winListeners.keyup({code});const frames=n=>{for(let i=0;i<n;i++)callback();};

const qa=window.__HOOK_ARENA__,motion=window.__MOTION__;
function fresh(third=false){motion.begin(true);if((qa.view==='third')!==third)key('KeyV');frames(1);}
function launch(){key('KeyQ');frames(16);assert.equal(motion.data.hook.phase,'outbound');}
test('windup keeps attached geometry; release uses one complete right arm assembly',()=>{fresh();key('KeyQ');frames(10);let d=motion.data;assert.equal(d.hook.phase,'windup');assert.equal(d.fist.visible,false);assert(d.projectileParts.every(p=>p.visible));frames(6);d=motion.data;assert.equal(d.hook.phase,'outbound');assert(d.fist.visible);assert(d.projectileParts.every(p=>!p.visible));assert.equal(d.projectileParts.length,d.fist.children.length);for(const name of ['VM_KnucklePlate1.R','VM_Wrist.R','VM_Forearm.R','VM_ElbowForearmLink.R'])assert(d.projectileParts.some(p=>p.name===name));});
test('release projects original and detached parts to identical screen positions and sizes',()=>{fresh();launch();const d=motion.data;d.viewmodel.updateMatrixWorld(true);d.fist.updateMatrixWorld(true);d.camera.updateMatrixWorld(true);d.viewCamera.updateMatrixWorld(true);for(let i=0;i<d.projectileParts.length;i++){const p=d.projectileParts[i],clone=d.fist.children[i],v=p.geometry.boundingBox.getCenter(new RealThree.Vector3());const a=v.clone().applyMatrix4(p.matrixWorld).project(d.viewCamera),b=v.clone().applyMatrix4(clone.matrixWorld).project(d.camera);assert(Math.abs(a.x-b.x)<1e-6,p.name+' x');assert(Math.abs(a.y-b.y)<1e-6,p.name+' y');}});
test('return attaches at actual socket before geometry is restored, then recovers',()=>{fresh();launch();let sawReturn=false,sawRecovery=false;for(let i=0;i<180&&qa.hook;i++){frames(1);const d=motion.data;if(d.hook?.phase==='return'){sawReturn=true;assert(d.projectileParts.every(p=>!p.visible));}if(d.hook?.phase==='recover'&&!sawRecovery){sawRecovery=true;assert(d.hook.position.distanceTo(motion.handPoint())<1e-6);assert(d.projectileParts.every(p=>p.visible));assert.equal(d.fist.visible,false);}}assert(sawReturn);assert(sawRecovery);assert.equal(qa.hook,null);assert.equal(qa.session.catches,1);});
test('hook pauses without motion, survives view switch, and restart restores all hand meshes',()=>{fresh();launch();frames(10);motion.pause();const at=motion.data.hook.position.clone();frames(30);assert.equal(motion.data.hook.position.distanceTo(at),0);motion.resume();key('KeyV');frames(1);assert.equal(motion.data.fist.visible,false);frames(20);key('KeyV');frames(1);for(const m of motion.data.fist.children)assert(m.matrix.elements.every(Number.isFinite));motion.begin();assert.equal(qa.hook,null);assert(motion.data.projectileParts.every(p=>p.visible));assert.equal(motion.data.fist.visible,false);});
test('mouse aim updates camera immediately and launch trajectory converges on centered camera ray',()=>{fresh();docListeners.mousemove({target:element('game'),movementX:75,movementY:-20});const d=motion.data;assert.equal(d.camera.rotation.y,qa.player.yaw);assert.equal(d.camera.rotation.x,qa.player.pitch);launch();const h=motion.data.hook,dir=d.camera.getWorldDirection(new RealThree.Vector3()),far=d.camera.position.clone().addScaledVector(dir,32),toward=far.sub(h.position).normalize();assert(h.direction.dot(toward)>.999999);});
test('capture denial freezes desktop timer and actions, shows prompt, keeps cursor visible',()=>{fresh();motion.pause();const game=element('game'),request=game.requestPointerLock;game.requestPointerLock=()=>Promise.resolve();motion.resume();assert.equal(qa.playing,false);assert.equal(game.style.cursor,'');assert.equal(element('captureprompt').classList.s.has('hidden'),false);const elapsed=qa.session.elapsed;frames(60);key('KeyQ');assert.equal(qa.session.elapsed,elapsed);assert.equal(qa.hook,null);docListeners.pointerlockerror();game.requestPointerLock=request;element('capturestart').onclick();assert.equal(qa.playing,true);assert.equal(game.style.cursor,'none');assert.equal(element('captureprompt').classList.s.has('hidden'),true);motion.pause();assert.equal(game.style.cursor,'');});

test('return completes while continuously sprinting away from the hook',()=>{fresh();launch();key('KeyS');key('ShiftLeft');frames(240);release('KeyS');release('ShiftLeft');assert.equal(qa.hook,null);assert(motion.data.projectileParts.every(p=>p.visible));});

test('release frame initializes cable and moving/portrait return matches source screen geometry',()=>{fresh();launch();let d=motion.data;assert(d.rope.userData.start.distanceTo(motion.cableSocket())<1e-6);assert(d.rope.userData.end.distanceTo(motion.chainHandSocket())<1e-6);innerWidth=600;innerHeight=900;winListeners.resize();let checked=false;for(let i=0;i<180&&qa.hook;i++){docListeners.mousemove({target:element('game'),movementX:1,movementY:.1});frames(1);d=motion.data;if(d.hook?.phase==='recover'){d.fist.updateMatrixWorld(true);d.viewmodel.updateMatrixWorld(true);d.camera.updateMatrixWorld(true);d.viewCamera.updateMatrixWorld(true);for(let j=0;j<d.projectileParts.length;j++){const p=d.projectileParts[j],v=p.geometry.boundingBox.getCenter(new RealThree.Vector3()),a=v.clone().applyMatrix4(p.matrixWorld).project(d.viewCamera),b=v.clone().applyMatrix4(d.fist.children[j].matrixWorld).project(d.camera);assert(Math.abs(a.x-b.x)<1e-6,p.name+' x return');assert(Math.abs(a.y-b.y)<1e-6,p.name+' y return');}checked=true;break;}}assert(checked);innerWidth=1280;innerHeight=720;winListeners.resize();});

test('all three character types are visible targets and can be hooked, captured and scored',()=>{assert.deepEqual(qa.assets.targetTypes,['mage','guardian','cannon']);assert.equal(qa.assets.targetCount,8);for(const type of qa.assets.targetTypes){fresh();const all=motion.data.targets;for(const t of all){t.active=false;t.group.visible=false;}const target=all.find(t=>t.type===type);target.active=true;target.group.visible=true;target.anchor.set(0,1.8,-8);target.group.position.copy(target.anchor);target.amplitude=0;target.speed=0;key('KeyQ');frames(150);assert.equal(qa.hook,null);assert.equal(qa.session.catches,1,type);assert.equal(qa.session.score,100,type);assert.equal(target.group.visible,false,type);assert(target.character);}});

test('actual game turret damages player, pauses safely, and defeat/restart restores HP and capture',()=>{fresh();assert.equal(qa.health,100);assert.equal(qa.turrets.count,2);motion.data.player.set(-8,1.7,-12);frames(100);assert(qa.health<100);assert(qa.health>0);motion.pause();const health=qa.health,bullets=qa.turrets.bullets;frames(100);assert.equal(qa.health,health);assert.equal(qa.turrets.bullets,bullets);motion.resume();frames(1200);assert.equal(qa.state,'results');assert.equal(qa.health,0);assert.equal(qa.turrets.bullets,0);assert.equal(qa.turrets.warning,false);assert.equal(element('threatwarning').classList.s.has('hidden'),true);assert.equal(element('game').style.cursor,'');element('start').onclick();assert.equal(qa.health,100);assert.equal(qa.state,'running');assert.equal(qa.turrets.bullets,0);assert.equal(element('game').style.cursor,'none');});

test('hook cannot travel through the solid arena floor or rear wall',()=>{fresh();for(const t of motion.data.targets)t.active=false;docListeners.mousemove({target:element('game'),movementX:0,movementY:250});docListeners.mousemove({target:element('game'),movementX:0,movementY:100});launch();let lowest=Infinity;for(let i=0;i<90&&qa.hook;i++){frames(1);if(motion.data.hook)lowest=Math.min(lowest,motion.data.hook.position.y);}assert(lowest>=-.031,'hook passed below floor: '+lowest);fresh();for(const t of motion.data.targets)t.active=false;motion.data.player.set(0,1.7,-42);frames(1);launch();let farthest=Infinity;for(let i=0;i<90&&qa.hook;i++){frames(1);if(motion.data.hook)farthest=Math.min(farthest,motion.data.hook.position.z);}assert(farthest>=-45.501,'hook passed rear wall: '+farthest);});

test('graphics context loss pauses timers/attacks and restoration requires deliberate resume',()=>{fresh();motion.data.player.set(-8,1.7,-12);frames(20);const game=element('game');let prevented=false;game.listeners.webglcontextlost({preventDefault(){prevented=true;}});assert(prevented);assert.equal(qa.state,'paused');assert.equal(qa.playing,false);assert.equal(game.style.cursor,'');assert.equal(element('start').disabled,true);const time=qa.session.elapsed,health=qa.health;frames(90);assert.equal(qa.session.elapsed,time);assert.equal(qa.health,health);element('start').onclick();assert.equal(qa.state,'paused');game.listeners.webglcontextrestored({});assert.equal(qa.state,'paused');assert.equal(element('start').disabled,false);frames(30);assert.equal(qa.session.elapsed,time);element('start').onclick();assert.equal(qa.state,'running');frames(1);assert(qa.session.elapsed>time);});


test('third-person hook lifts toward aim pitch and returns to the idle shoulder pose',()=>{
 for(const movementY of [-120,120]){fresh(true);docListeners.mousemove({target:element('game'),movementX:0,movementY});launch();const shoulder=motion.data.fullbodyNodes.get('BC_Pivot_Shoulder.R');assert(Math.abs(shoulder.rotation.x+Math.PI/2+qa.player.pitch)<1e-9);const d=motion.data,elbow=d.fullbodyMeshes.get('BC_Elbow.R'),origin=shoulder.getWorldPosition(new RealThree.Vector3()),direction=elbow.getWorldPosition(new RealThree.Vector3()).sub(origin);assert(Math.abs(Math.atan2(direction.y,-direction.z)-qa.player.pitch)<1e-6,'upper arm must follow vertical aim');frames(180);assert.equal(qa.hook,null);assert(Math.abs(shoulder.rotation.x)<1e-9);}
});

test('over-shoulder view preserves centered hook convergence and camera cover clearance',()=>{
 fresh(true);let d=motion.data;assert(Math.abs(d.camera.position.x-d.player.x-.9)<1e-9);docListeners.mousemove({target:element('game'),movementX:60,movementY:-30});launch();d=motion.data;const direction=d.camera.getWorldDirection(new RealThree.Vector3()),aimed=motion.nearestRay(d.camera.position,direction,32),aim=d.camera.position.clone().addScaledVector(direction,aimed.distance),toAim=aim.sub(d.hook.position).normalize();assert(d.hook.direction.dot(toAim)>.999999,'hook must converge on the reticle ray');fresh(true);d=motion.data;d.player.set(-9,1.7,-12);frames(1);const offset=d.camera.position.clone().sub(d.player),distance=offset.length(),dir=offset.normalize();assert(distance<new RealThree.Vector3(.9,.8,4.6).length(),'camera must shorten before the cover behind player');for(const o of d.obstacles){const hit=rayBox(d.player,dir,o.min,o.max,distance);assert(hit===null,'camera crossed solid cover');}
});

function isolatedMeleeTarget(type,x,y,z){const all=motion.data.targets;for(const t of all){t.active=false;t.group.visible=false;}const target=all.find(t=>t.type===type);target.active=true;target.group.visible=true;target.group.position.set(x,y,z);return target;}
test('first/third-person melee hits all close character types under the centered reticle',()=>{
 for(const third of [false,true])for(const type of ['mage','guardian','cannon']){fresh(third);const d=motion.data,target=isolatedMeleeTarget(type,d.camera.position.x,d.camera.position.y,5),direction=d.camera.getWorldDirection(new RealThree.Vector3());assert.equal(motion.nearestRay(d.camera.position,direction,32).target,target);punch();assert.equal(qa.session.score,40,`${third?'third':'first'} ${type}`);assert.equal(target.active,false);}
});
test('third-person melee keeps player reach, cover blocking, and forward-only hits',()=>{
 fresh(true);let d=motion.data;isolatedMeleeTarget('mage',.9,2.5,2);punch();assert.equal(qa.session.score,0,'reticle highlight must not extend3m reach');fresh(true);d=motion.data;const target=isolatedMeleeTarget('mage',.9,2.5,5),cover={min:new RealThree.Vector3(.25,1.8,5.9),max:new RealThree.Vector3(.65,2.3,6.5)};d.obstacles.push(cover);try{assert.equal(motion.nearestRay(d.camera.position,d.camera.getWorldDirection(new RealThree.Vector3()),32).target,target);punch();assert.equal(qa.session.score,0,'player-to-target cover must block even if camera sees over it');}finally{d.obstacles.splice(d.obstacles.indexOf(cover),1);}fresh(true);d=motion.data;const behind=isolatedMeleeTarget('mage',.9,2.5,9);assert.equal(motion.nearestRay(d.camera.position,d.camera.getWorldDirection(new RealThree.Vector3()),32).target,behind);punch();assert.equal(qa.session.score,0,'cannot punch behind the player via the rear camera');
});


function detachedPalmState(){const d=motion.data,palm=d.fullbodyMeshes.get('BC_Palm.R');palm.updateWorldMatrix(true,false);return{orientation:palm.getWorldQuaternion(new RealThree.Quaternion()),center:palm.localToWorld(palm.geometry.boundingBox.getCenter(new RealThree.Vector3()))};}
test('detached third-person hand keeps launch orientation while body turns and view switches',()=>{
 for(const third of [false,true]){fresh(third);for(const t of motion.data.targets)t.active=false;launch();frames(4);const before=detachedPalmState(),direction=motion.data.hook.direction.clone();docListeners.mousemove({target:element('game'),movementX:Math.PI/2/.0021,movementY:-Math.PI/6/.0021});if(!third)key('KeyV');frames(1);const after=detachedPalmState();assert.equal(qa.hook.phase,'outbound');assert(after.orientation.angleTo(before.orientation)<1e-6,'detached hand inherited body rotation');assert(after.center.distanceTo(motion.data.hook.position)<1e-6,'rotation moved palm off hook');assert(direction.distanceTo(motion.data.hook.direction)<1e-12);}
});
test('turning throughout third-person return ends at the attached socket and orientation',()=>{
 fresh(true);for(const t of motion.data.targets)t.active=false;launch();let returned=false;for(let i=0;i<180&&qa.hook;i++){docListeners.mousemove({target:element('game'),movementX:6,movementY:.4});frames(1);const d=motion.data;if(d.hook&&['outbound','return'].includes(d.hook.phase)){assert(detachedPalmState().center.distanceTo(d.hook.position)<1e-6,'flying palm anchor drifted');}if(d.hook?.phase==='recover'){const q=d.fullbodyNodes.get('BC_QLaunch.R');assert(q.quaternion.angleTo(new RealThree.Quaternion())<1e-6,'return left a wrist orientation snap');assert(q.position.distanceTo(new RealThree.Vector3().fromArray(q.userData.base))<1e-6);assert(detachedPalmState().center.distanceTo(d.hook.position)<1e-6);returned=true;break;}}assert(returned);frames(20);assert.equal(qa.hook,null);
});

test('third-person mouse orbit holds actor framing and FPS returns to the unchanged eye',()=>{
 fresh(true);const d=motion.data;d.camera.updateMatrixWorld(true);const start=d.player.clone().applyMatrix4(d.camera.matrixWorld.clone().invert()),position=d.camera.position.clone();docListeners.mousemove({target:element('game'),movementX:95,movementY:-120});d.camera.updateMatrixWorld(true);const after=d.player.clone().applyMatrix4(d.camera.matrixWorld.clone().invert());assert(start.distanceTo(after)<1e-9,'body slid off frame when aiming');assert(d.camera.position.distanceTo(position)>.5);assert.equal(d.camera.rotation.x,qa.player.pitch);assert.equal(d.camera.rotation.y,qa.player.yaw);const look=d.camera.getWorldDirection(new RealThree.Vector3());key('KeyV');assert.equal(qa.view,'first');assert(d.camera.position.distanceTo(d.player)<1e-12);assert(d.camera.getWorldDirection(new RealThree.Vector3()).distanceTo(look)<1e-12);
});
test('orbit camera keeps floor clearance and restores the shoulder frame across pitch changes',()=>{
 fresh(true);const d=motion.data;for(let i=0;i<3;i++)docListeners.mousemove({target:element('game'),movementX:0,movementY:-250});frames(1);assert(d.camera.position.y>=.15-1e-8);for(let i=0;i<3;i++)docListeners.mousemove({target:element('game'),movementX:0,movementY:250});docListeners.mousemove({target:element('game'),movementX:0,movementY:-.275/.0021});d.camera.updateMatrixWorld(true);const local=d.camera.position.clone().sub(d.player).applyQuaternion(d.camera.quaternion.clone().invert());assert(local.distanceTo(new RealThree.Vector3(.9,.8,4.6))<1e-8);
});
test('third-person near aim behind the hand blocks instead of launching backward',()=>{
 fresh(true);const d=motion.data,target=isolatedMeleeTarget('mage',.9,2.5,9);target.anchor.copy(target.group.position);target.amplitude=0;target.speed=0;key('KeyQ');frames(16);assert.equal(qa.hook.phase,'return');const h=motion.data.hook;assert.equal(h.travel,0);assert(h.direction.dot(d.camera.getWorldDirection(new RealThree.Vector3()))>.999999);assert.equal(element('hitnotice').textContent,'BLOCKED');frames(45);assert.equal(qa.hook,null);assert.equal(qa.session.catches,0);
});


test('third-person pitch stops before the actor fills the lens, while FPS retains full range',()=>{
 fresh(true);let d=motion.data;for(let i=0;i<4;i++)docListeners.mousemove({target:element('game'),movementX:0,movementY:-250});assert.equal(qa.player.pitch,.5);assert(Math.abs(d.camera.position.distanceTo(d.player)-new RealThree.Vector3(.9,.8,4.6).length())<1e-8);for(let i=0;i<4;i++)docListeners.mousemove({target:element('game'),movementX:0,movementY:250});assert.equal(qa.player.pitch,-1.15);key('KeyV');for(let i=0;i<2;i++)docListeners.mousemove({target:element('game'),movementX:0,movementY:250});assert.equal(qa.player.pitch,-1.3);for(let i=0;i<6;i++)docListeners.mousemove({target:element('game'),movementX:0,movementY:-250});assert.equal(qa.player.pitch,1.3);key('KeyV');assert.equal(qa.player.pitch,.5);
});

test('chain follows actual elbow and rear hand connectors through launch, aim, view swap and return',()=>{
 for(const third of [false,true]){
  fresh(third);for(const t of motion.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}launch();let checked=0;
  for(let i=0;i<240&&qa.hook;i++){
   if(i===12)key('KeyV');
   docListeners.mousemove({target:element('game'),movementX:.8,movementY:.15});frames(1);
   const d=motion.data;
   if(d.hook&&['outbound','return'].includes(d.hook.phase)){
    assert(d.rope.visible);assert(d.rope.userData.start.distanceTo(motion.cableSocket())<1e-6);
    assert(d.rope.userData.end.distanceTo(motion.chainHandSocket())<1e-6);
    assert(d.rope.userData.end.distanceTo(d.hook.position)>.05,'chain must end at rear connector, not cut through palm');
    assert(d.rope.links.count<=256);checked++;
   }
   if(d.hook?.phase==='recover')assert.equal(d.rope.visible,false);
  }
  assert(checked>10);assert.equal(qa.hook,null);assert.equal(motion.data.rope.visible,false);
 }
});
test('paused chain stays still and view toggling reconnects the paused visual safely',()=>{
 fresh();launch();frames(8);motion.pause();const rope=motion.data.rope,a=rope.userData.start.clone(),b=rope.userData.end.clone();frames(20);
 assert(rope.userData.start.distanceTo(a)<1e-12);assert(rope.userData.end.distanceTo(b)<1e-12);
 element('viewtoggle').onclick();assert(rope.userData.start.distanceTo(motion.cableSocket())<1e-6);assert(rope.userData.end.distanceTo(motion.chainHandSocket())<1e-6);
 motion.begin(true);assert.equal(rope.visible,false);
});

test('mirror uses the complete body in FPS, only one flying hand, and restores chain sockets',()=>{
 fresh();for(const t of motion.data.targets){t.active=false;t.respawn=Infinity;}launch();frames(7);const d=motion.data,body=d.fullbodyNodes.get('BC_QLaunch.R');
 let root=body;while(root.parent&&!root.parent.isScene)root=root.parent;
 assert.equal(root.visible,false);assert.equal(d.fist.visible,true);
 const start=d.rope.userData.start.clone(),end=d.rope.userData.end.clone(),count=d.rope.links.count,matrix=d.rope.links.instanceMatrix.array.slice(0,count*16);
 const token=motion.prepareMirrorBody();
 assert.equal(root.visible,true);assert.equal(d.fist.visible,false);
 assert(d.rope.userData.start.distanceTo(motion.fullbodyCableSocket())<1e-8);
 assert(d.rope.userData.end.distanceTo(motion.fullbodyChainSocket())<1e-8);
 motion.restoreMirrorBody(token);
 assert.equal(root.visible,false);assert.equal(d.fist.visible,true);
 assert(d.rope.userData.start.distanceTo(start)<1e-12);assert(d.rope.userData.end.distanceTo(end)<1e-12);
 assert.equal(d.rope.links.count,count);assert.deepEqual(d.rope.links.instanceMatrix.array.slice(0,count*16),matrix);
 key('KeyV');const thirdToken=motion.prepareMirrorBody();motion.restoreMirrorBody(thirdToken);assert.equal(root.visible,true);assert.equal(d.fist.visible,false);
});
test('back-wall mirror replaces sign at the photographed location and blocks hook rays',()=>{
 fresh();const mirror=motion.mirror;assert(mirror.isReflector);assert.equal(mirror.position.x,0);assert.equal(mirror.position.z,-45.08);assert.equal(mirror.geometry.parameters.width,9);assert.equal(mirror.geometry.parameters.height,7);
 const obstacle=motion.data.obstacles.find(o=>o.mirrorSurface);assert(obstacle);const hit=rayBox(new RealThree.Vector3(0,1.7,-40),new RealThree.Vector3(0,0,-1),obstacle.min,obstacle.max,10);assert(Math.abs(hit-5.05)<1e-9);
});

test('FPS meshes share equivalent materials instead of creating one per part',()=>{const meshes=window.__MOTION__.data.parts;assert(new Set(meshes.map(p=>p.material)).size<meshes.length/4);});
