import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {TURRET_AUDIO_CUES as cues} from '../audio-cues.js';
const dir=new URL('../assets/audio/turrets/',import.meta.url);
const manifest=JSON.parse(fs.readFileSync(new URL('source-manifest.json',dir)));
const row=manifest.find(r=>r.id==='turret-target');
function read(name){
 const bytes=fs.readFileSync(new URL(name,dir));let pcm;
 for(let i=12;i+8<=bytes.length;){const length=bytes.readUInt32LE(i+4);if(bytes.toString('ascii',i,i+4)==='data')pcm=bytes.subarray(i+8,i+8+length);i+=8+length+(length%2);}
 assert(pcm);return {bytes,pcm,values:Array.from({length:pcm.length/2},(_,i)=>pcm.readInt16LE(i*2))};
}
const original=read('turret-target.wav'),continued=read('turret-target-extended.wav'),single=read('turret-target-single-044.wav');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function rmsDbWindows(values){const result=[];for(let i=0;i<values.length;i+=960){let sum=0;for(let j=i;j<i+960;j++)sum+=(values[j]/32768)**2;result.push(20*Math.log10(Math.max(1e-12,Math.sqrt(sum/960))));}return result;}
function dominant(values,lo,hi){let bestHz=lo,best=-Infinity;for(let hz=lo;hz<=hi;hz+=2){const k=2*Math.cos(2*Math.PI*hz/48000);let a=0,b=0;for(let n=0;n<values.length;n++){const c=values[n]*(.5-.5*Math.cos(2*Math.PI*n/(values.length-1)))+k*a-b;b=a;a=c;}const power=a*a+b*b-k*a*b;if(power>best){best=power;bestHz=hz;}}return bestHz;}

test('active warning uses processed single source, not the following recorded repeat',()=>{
 assert(cues.turretTarget.url.endsWith('/turret-target-single-044.wav'));assert.equal(cues.turretTarget.maxDuration,.44);
 assert.equal(row.file,'turret-target-single-044.wav');assert.equal(row.duration_seconds,.44);assert.equal(row.source_start_seconds,9.63);assert.equal(row.source_end_seconds,9.87);
 assert.equal(row.processing_input_file,'turret-target.wav');assert.equal(row.processing_input_sha256,sha(original.bytes));assert.equal(row.time_stretch,true);assert.equal(row.pitch_scale,1);assert.equal(row.tempo_scale,6/11);assert.equal(row.recorded_following_repeat_used,false);assert.equal(row.direct_listening_verified,false);
 assert.equal(row.sha256,sha(single.bytes));
});

test('both previous source files stay byte-identical and the processed duration adds exactly .2s',()=>{
 assert.equal(sha(original.bytes),'82301eeb88ba08592ce6d25b97303d2e109af7fb0c5240fc0f7b80ea51fe7012');assert.equal(sha(continued.bytes),'c90fe9d641b64c18e5c73bcb46c632f54aa168c31be951bea5495bad673bf234');
 assert.equal(original.values.length,11520);assert.equal(single.values.length,21120);assert.equal(single.values.length-original.values.length,9600);
 assert.equal(single.values[0],0);assert.equal(single.values.at(-1),0);assert(single.values.slice(11520).filter(Boolean).length>9500);assert(Math.max(...single.values.map(Math.abs))<16425);
});

test('processed envelope removes the second large warning onset from the added interval',()=>{
 const before=rmsDbWindows(continued.values),after=rmsDbWindows(single.values);
 const rise=a=>Math.max(...a.slice(11).map((v,i)=>v-a[i+10]));
 assert(rise(before)>6,'control must expose the repeated warning rise');assert(rise(after)<2,'processed tail must not regain a large warning onset');
 assert(after.at(-1)<-35,'tail should decay to silence');
});

test('dominant alert frequency bands remain near the original after pitch-preserving processing',()=>{
 for(const [lo,hi] of [[800,950],[1320,1480]]){
  const a=dominant(original.values,lo,hi),b=dominant(single.values,lo,hi);assert(Math.abs(a-b)<=10,`spectral peak shifted ${a}Hz → ${b}Hz`);
 }
});
