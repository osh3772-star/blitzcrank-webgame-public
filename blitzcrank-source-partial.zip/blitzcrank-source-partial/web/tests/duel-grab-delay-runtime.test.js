import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const quiet=r=>r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});
function until(r,predicate,limit,label){for(let i=0;i<limit&&!predicate();i++)r.frames(1);assert(predicate(),label);}
async function start(hz){const writes=[],r=await createGameplayHarness({delta:()=>1/hz,storage:{getItem:()=>null,setItem:(...args)=>writes.push(args)}});r.element('duelmode').click();quiet(r);until(r,()=>r.qa.duel.active,hz*2,'countdown ends');return {r,d:r.game.data,writes};}
function contact(r,d,hz,winner){d.duelBot.position.set(0,1.7,1);if(winner==='human')r.key('KeyQ');else assert(d.duel.cast('bot'));until(r,()=>d.duel.contact?.kind==='grab',hz*2,'geometric Q contacts');}
const points=r=>r.qa.duel.match.scores.map(s=>s.points);
for(const hz of [20,30,60,120])for(const winner of ['human','bot'])test(`${winner} Q at ${hz} Hz scores only on completed pull, then resets exactly 3 s later`,async()=>{
 const {r,d,writes}=await start(hz);contact(r,d,hz,winner);
 assert.deepEqual(points(r),[0,0]);assert.equal(r.qa.duel.match.history.length,0);assert.equal(r.qa.duel.active,false);assert.equal(d.duel.getHook(winner).phase,'return');
 const attacker=winner==='human'?d.player:d.duelBot.position,victim=winner==='human'?d.duelBot.position:d.player,attackerStart=attacker.toArray();let previous=attacker.distanceTo(victim),pullFrames=0;
 r.key('KeyW');r.key('ShiftLeft');r.key('KeyE');r.key('KeyR');r.key('KeyF');r.key('Space');r.punch();assert.equal(d.duel.cast(winner==='human'?'bot':'human'),false);
 while(r.qa.duel.match.history.length===0&&pullFrames++<hz*2){r.frames(1);assert.deepEqual(attacker.toArray(),attackerStart);const distance=attacker.distanceTo(victim);assert(distance<=previous+1e-8);previous=distance;if(d.duel.getHook(winner)?.phase==='return')assert.deepEqual(points(r),[0,0]);}
 assert(pullFrames>1);assert.equal(r.qa.duel.match.history.length,1);assert.equal(d.duel.getHook(winner).phase,'recover');assert(Math.abs(previous-2.3)<1e-8);assert.deepEqual(points(r),winner==='human'?[1,0]:[0,1]);assert.equal(r.qa.duel.match.phase,'roundReset');assert.equal(r.qa.duel.match.remainingMs,3000);assert.equal(r.qa.flashAbility.casts,0);
 const h=d.player.toArray(),b=d.duelBot.position.toArray();r.frames(hz*3-1);assert.equal(r.qa.duel.match.roundNumber,1);assert.equal(r.qa.duel.match.phase,'roundReset');assert.deepEqual(d.player.toArray(),h);assert.deepEqual(d.duelBot.position.toArray(),b);r.frames(1);
 assert.equal(r.qa.duel.match.roundNumber,2);assert.equal(r.qa.duel.match.phase,'countdown');assert.deepEqual(d.player.toArray(),[0,1.7,7]);assert.deepEqual(d.duelBot.position.toArray(),[0,1.7,-12]);assert.equal(r.qa.hook,null);assert.equal(r.qa.duel.bot.hook,null);assert.deepEqual([...d.keys],['KeyW'],'held movement survives, but blocked action keys do not');r.release('KeyW');assert.equal(d.keys.size,0,'keyup during countdown clears movement');assert.equal(writes.length,0);
});
for(const hz of [20,30,60,120])test(`third Q point at ${hz} Hz waits 3 s in matchComplete and requires explicit rematch`,async()=>{
 const {r,d}=await start(hz);
 for(let point=1;point<=3;point++){contact(r,d,hz,'human');assert.equal(r.qa.duel.match.scores[0].points,point-1);until(r,()=>r.qa.duel.match.scores[0].points===point,hz*2,'pull completes and awards');if(point<3){r.frames(hz*3);until(r,()=>r.qa.duel.active,hz*2,'next round starts');}}
 assert.equal(r.qa.duel.match.phase,'matchComplete');assert.equal(r.qa.state,'running');const h=d.player.toArray(),b=d.duelBot.position.toArray();r.key('KeyQ');r.key('KeyR');r.key('Enter');r.frames(hz*3-1);assert.equal(r.qa.state,'running');assert.equal(r.qa.duel.match.phase,'matchComplete');r.frames(1);assert.equal(r.qa.state,'results');r.frames(hz*5);assert.equal(r.qa.state,'results');assert.equal(r.qa.duel.match.roundNumber,3);assert.deepEqual(points(r),[3,0]);assert.deepEqual(d.player.toArray(),h);assert.deepEqual(d.duelBot.position.toArray(),b);
 r.key('Enter');assert.equal(r.qa.state,'running');assert.equal(r.qa.duel.match.phase,'countdown');assert.deepEqual(points(r),[0,0]);assert.deepEqual(d.player.toArray(),[0,1.7,7]);assert.deepEqual(d.duelBot.position.toArray(),[0,1.7,-12]);
});
for(const stage of ['pull','award'])for(const action of ['resume','restart','menu'])test(`${action} during Q ${stage} freezes or clears deferred state`,async()=>{
 const hz=60,{r,d}=await start(hz);contact(r,d,hz,'human');if(stage==='award')until(r,()=>r.qa.duel.match.history.length===1,hz*2,'award');r.game.pause();const match=r.qa.duel.match,hook=r.qa.hook,h=d.player.toArray(),b=d.duelBot.position.toArray();r.frames(hz*5);assert.deepEqual(r.qa.duel.match,match);assert.deepEqual(r.qa.hook,hook);assert.deepEqual(d.player.toArray(),h);assert.deepEqual(d.duelBot.position.toArray(),b);
 if(action==='resume'){r.game.resume();if(stage==='pull')until(r,()=>r.qa.duel.match.history.length===1,hz*2,'resumed pull awards once');r.frames(hz*3);assert.equal(r.qa.duel.match.roundNumber,2);assert.equal(r.qa.duel.match.history.length,1);}
 if(action==='restart'){r.element('duelmode').click();quiet(r);assert.equal(r.qa.hook,null);assert.equal(d.duel.contact,null);r.frames(hz*5);assert.deepEqual(points(r),[0,0]);assert.equal(r.qa.duel.match.history.length,0);assert.equal(r.qa.duel.match.roundNumber,1);}
 if(action==='menu'){r.element('mainmenu').click();assert.equal(r.qa.duel,null);assert.equal(r.qa.hook,null);assert.equal(d.duelRope.visible,false);r.element('practice').click();r.frames(hz*5);assert.equal(r.qa.duel,null);assert.equal(r.qa.session.score,0);assert.equal(r.qa.hook,null);}
});
