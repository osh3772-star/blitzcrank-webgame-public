import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {rig, THREE} from './helpers/locomotion-rig.js';
import {createDuelAvatarFactory} from '../duel-avatar.js';
import {createFullbodyLocomotion} from '../fullbody-locomotion.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const skills = JSON.parse(fs.readFileSync(new URL('../assets/skill-animations/skills.9b293d06ddb21614.json', import.meta.url))).models.fullbody;
function fixture() {
 const original = rig(), factory = createDuelAvatarFactory(THREE, {...original, createLocomotion:createFullbodyLocomotion});
 const world = new THREE.Group(), parent = new THREE.Group(); world.add(parent);
 const avatar = factory.create({parent}); avatar.configureSkills(skills);
 return {avatar, factory, parent, world};
}
function legacySockets(avatar) { avatar.object.updateWorldMatrix(true, true); return avatar.getSockets(); }
function sameAsLegacy(avatar) {
 const actual = avatar.getSockets();
 assert.deepEqual(actual, legacySockets(avatar));
 for (const values of Object.values(actual)) assert(values.every(Number.isFinite));
 return actual;
}
test('socket lookup refreshes only socket ancestors, never unrelated or VFX descendants', t => {
 const {avatar, factory} = fixture();
 const unrelated = new THREE.Group(), vfx = new THREE.Group();
 avatar.object.add(unrelated); avatar.getSkillHands()[1].add(vfx);
 for(let i=0;i<100;i++) { unrelated.add(new THREE.Group()); vfx.add(new THREE.Group()); }
 let all = 0, descendantPasses = 0, unrelatedVisits = 0;
 const previous = THREE.Object3D.prototype.updateWorldMatrix;
 THREE.Object3D.prototype.updateWorldMatrix = function(parents, children) {
  all++; if(children) descendantPasses++;
  if(this === unrelated || this === vfx || this.parent === unrelated || this.parent === vfx) unrelatedVisits++;
  return previous.call(this, parents, children);
 };
 try { avatar.getSockets(); } finally { THREE.Object3D.prototype.updateWorldMatrix = previous; }
 assert.equal(descendantPasses, 0); assert.equal(unrelatedVisits, 0);
 assert(all <= 60, `expected ancestor-only work, got ${all} world updates`);
 t.diagnostic(`Socket ancestor updates with two external parents and 202 extra descendants: ${all}`);
 avatar.dispose(); factory.dispose();
});
test('sockets exactly match legacy refresh after ancestor and local root mutation across all Q phases', () => {
 const {avatar, factory, world, parent} = fixture();
 for(const phase of [null, 'windup', 'outbound', 'return', 'recover']) for(let i=0;i<12;i++) {
  world.position.set(i*.03, -.1, .3); world.rotation.set(.1, i*.02, -.05); world.scale.setScalar(1.1);
  parent.position.set(1, .2, -2); parent.rotation.set(-.1, .25, .07); parent.scale.setScalar(1.7);
  const hook = phase ? {phase, phaseTime:i*.02, position:[1+i*.1, 2, -4], returnDuration:.3, bodyOrientation:[0,.2,0,.98]} : null;
  avatar.update(1/60, {position:[2, i*.05, -3], yaw:i*.09, pitch:-.2, locomotion:{deltaX:.04, deltaZ:.03, grounded:false, height:i*.05, velocityY:1}, hook});
  // Mutate after update without manually refreshing either world matrix.
  world.position.x += .17; parent.rotation.y += .06; parent.scale.multiplyScalar(1.01);
  avatar.object.position.z += .11; avatar.object.rotation.y -= .03;
  sameAsLegacy(avatar);
 }
 avatar.dispose(); factory.dispose();
});
test('authored W/E/R matrices, Q interruption, landing, reset and hiding retain legacy sockets', () => {
 const {avatar, factory, parent} = fixture();
 let checks = 0;
 for(const name of ['W_Start','W_Loop','W_End','E_Charge','E_Hold','E_Strike','R_Cast']) {
  for(let i=0;i<12;i++) {
   avatar.update(1/60, {position:[i*.03, i<6?.3:0, -2], yaw:i*.1, locomotion:{deltaZ:.05, grounded:i>=6, height:i<6?.3:0, velocityY:i<6?-1:0}, skill:{name, time:i*.03}});
   parent.position.x += .02; parent.rotation.z += .003;
   sameAsLegacy(avatar); checks++;
  }
  avatar.update(1/60, {position:[1,0,-2], yaw:.4, hook:{phase:'outbound',phaseTime:.1,position:[2,1,-6]}}); sameAsLegacy(avatar); checks++;
  avatar.update(1/60, {position:[1,0,-2], yaw:.4}); sameAsLegacy(avatar); checks++;
  avatar.reset({position:[1,.1,-2], yaw:.2}); avatar.hide(); sameAsLegacy(avatar); avatar.show(); checks++;
 }
 assert.equal(checks,105);
 const saved = avatar.getSockets(), expected = structuredClone(saved);
 avatar.update(1/60, {position:[8,0,4], yaw:2}); avatar.getSockets(); assert.deepEqual(saved,expected);
 avatar.dispose(); assert.throws(()=>avatar.getSockets(),/disposed/); factory.dispose();
});
test('actual duel chain endpoints match sockets through repeated Q, pause, view switch and restart', async t => {
 const r = await createGameplayHarness();
 const quiet = () => r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,jump:false})});
 const phases = new Set(); let comparisons=0, chainChecks=0;
 for(let cycle=0;cycle<2;cycle++) {
  r.element('duelmode').click(); quiet(); r.frames(150); assert.equal(r.qa.duel.match.phase,'active');
  r.game.data.duelBot.position.set(8,1.7,-12); r.game.data.duel.cast('bot'); r.key('KeyQ'); r.release('KeyQ');
  for(let frame=0;frame<150;frame++) {
   if(frame===14) { r.game.pause(); const saved=r.game.data.duelAvatar.getSockets(); r.frames(10); assert.deepEqual(r.game.data.duelAvatar.getSockets(),saved); r.game.resume(); }
   if(frame===22 || frame===71) {r.key('KeyV');r.release('KeyV');}
   r.frames(1); const {duelAvatar:a,duelRope} = r.game.data, sockets=sameAsLegacy(a);
   comparisons++; phases.add(a.inspect().phase);
   if(duelRope.visible) {
    for(const [field, point] of [['start',sockets.cable], ['end',sockets.chain]])
     assert(duelRope.userData[field].distanceTo(new THREE.Vector3(...point)) < 1e-8);
    chainChecks++;
   }
  }
 }
 for(const phase of [null,'windup','outbound','return','recover'])assert(phases.has(phase),String(phase));
 assert(chainChecks>0); t.diagnostic(`${comparisons} exact runtime comparisons, ${chainChecks} visible chain checks`);
 r.game.pause(); r.element('mainmenu').click(); assert.equal(r.game.data.duelRope.visible,false);
});
