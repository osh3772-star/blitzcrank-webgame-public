import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/mobile-runtime-harness.js';

// Executes actual main.js and Three.js, controlled DOM/clock, no browser/GPU/device.
// Models a permitted resize ordering without a preceding pointercancel.
const sourcePath=new URL('../main.js',import.meta.url);
const h=await createGameplayHarness({sourcePath});
const event=(pointerId,clientX,clientY)=>({pointerId,clientX,clientY,pointerType:'touch',button:0,preventDefault(){}});
function fresh(){h.resize(390,844);h.docEvent('pointerdown',event(1,0,0));h.game.begin(true);}
function activeStick(){const stick=h.element('joystick');stick.getBoundingClientRect=()=>({left:18,top:656,width:96,height:96});stick.onpointerdown(event(5,66,666));return stick;}

test('resize cancels stale joystick input until a new press',()=>{
 fresh();const stick=activeStick();h.frames(1);assert.equal(h.game.data.joystick.y,-1);
 const z=h.qa.player.z;h.resize(844,390);h.frames(30);
 assert.equal(h.qa.player.z,z,'player must not keep walking from old-layout input');
 stick.onpointermove(event(5,66,666));h.frames(1);
 assert.equal(h.qa.player.z,z,'old captured finger must not restore cancelled movement');
 stick.onpointerup(event(5,66,666));
 stick.getBoundingClientRect=()=>({left:18,top:290,width:88,height:88});
 stick.onpointerdown(event(7,62,296));h.frames(1);
 assert(h.qa.player.z<z,'fresh post-resize touch remains functional');
});

test('resize discards the old look coordinate reference',()=>{
 fresh();h.canvasEvent('pointerdown',event(6,300,400));const before=h.qa.player;
 h.resize(844,390);
 h.canvasEvent('pointermove',event(6,650,185));
 assert.equal(h.qa.player.yaw,before.yaw,'old-layout coordinate must not rotate yaw');
 assert.equal(h.qa.player.pitch,before.pitch,'old-layout coordinate must not rotate pitch');
 h.canvasEvent('pointerup',event(6,650,185));
 h.canvasEvent('pointerdown',event(8,650,185));
 h.canvasEvent('pointermove',event(8,660,185));
 assert(Math.abs(h.qa.player.yaw-(before.yaw-.021))<1e-10,'fresh look uses only its new delta');
});

test('resize with no active touches preserves held keyboard movement',()=>{
 fresh();h.key('KeyW');const z=h.qa.player.z;h.resize(844,390);h.frames(1);
 assert(h.qa.player.z<z);h.release('KeyW');
});

test('regular pointercancel still stops both contacts before resize',()=>{
 fresh();const stick=activeStick();h.canvasEvent('pointerdown',event(6,300,400));
 stick.onpointercancel(event(5,66,666));h.canvasEvent('pointercancel',event(6,300,400));
 const before=h.qa.player;h.resize(844,390);h.frames(30);
 h.canvasEvent('pointermove',event(6,650,185));
 assert.equal(h.qa.player.z,before.z);assert.equal(h.qa.player.yaw,before.yaw);assert.equal(h.qa.player.pitch,before.pitch);
});

test('same-size resize notification preserves both active touches',()=>{
 fresh();activeStick();h.canvasEvent('pointerdown',event(6,300,400));const before=h.qa.player;
 h.resize(390,844);h.frames(1);h.canvasEvent('pointermove',event(6,310,400));
 assert(h.qa.player.z<before.z);assert.equal(h.game.data.joystick.y,-1);
 assert(Math.abs(h.qa.player.yaw-(before.yaw-.021))<1e-10);
});

test('changed viewport cancels touch but retains concurrent held keyboard input',()=>{
 fresh();activeStick();h.key('KeyD');const before=h.qa.player;
 h.resize(844,390);h.frames(1);
 assert.equal(h.game.data.joystick.y,0);assert.equal(h.qa.player.z,before.z);
 assert(h.qa.player.x>before.x,'held D must still move right after touch reset');h.release('KeyD');
});

test('changed viewport preserves pointer lock, running state, session and skills',()=>{
 fresh();activeStick();h.acquirePointer();h.game.castW();h.game.castE();h.frames(1);
 const before={state:h.qa.state,session:h.qa.session,skills:h.qa.skills,locked:document.pointerLockElement};
 h.resize(844,390);
 assert.equal(h.qa.state,before.state);assert.deepEqual(h.qa.session,before.session);
 assert.deepEqual(h.qa.skills,before.skills);assert.equal(document.pointerLockElement,before.locked);
 assert(h.qa.playing);assert.equal(h.game.data.joystick.y,0);
});

test('invalid transient viewport dimensions do not cancel active input',()=>{
 fresh();activeStick();const before=h.qa.player;h.resize(0,0);h.frames(1);
 assert(h.qa.player.z<before.z);assert.equal(h.game.data.joystick.y,-1);
 // Return to the original valid dimensions, not a real layout change.
 h.resize(390,844);assert.equal(h.game.data.joystick.y,-1);
});
