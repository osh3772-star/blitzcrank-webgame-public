import {eRecoveryPolicy,eArmClause,eOldClause} from './helpers/e-recovery-policy.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {deserialize} from 'node:v8';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import * as THREE from '../vendor/three.module.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8'),call=eRecoveryPolicy(source).enabled?eArmClause:eOldClause;
assert(source.includes(call),'Instrument real E layer call for baseline comparison');
function fresh(h){h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}}
function sample(h){return {player:h.qa.player,session:h.qa.session,skill:{phase:h.qa.skills.phase,armed:h.qa.skills.armed,cooldown:h.qa.skills.cooldown,boost:h.qa.skills.boost,slow:h.qa.skills.slow,metrics:h.qa.skills.metrics},viewmodel:h.game.data.parts.map(p=>[p.position.toArray(),p.quaternion.toArray(),p.scale.toArray()])};}
function replay(h){fresh(h);const a=[];for(let i=0;i<430;i++){if(i===0)h.key('KeyW');if(i===10)h.key('KeyE');if(i===100)h.punch();if(i===130)h.release('KeyW');if(i===210)h.key('KeyR');if(i===310)h.key('ShiftLeft');h.frames(1);a.push(sample(h));}return a;}
const runner=fileURLToPath(new URL('./helpers/e-walk-baseline-case.mjs',import.meta.url));
const baseline=deserialize(execFileSync(process.execPath,['--expose-gc','--max-old-space-size=128','--max-semi-space-size=4',runner],{maxBuffer:16*1024*1024}));
global.gc?.();
const h=await createGameplayHarness(),actual=replay(h);
const motion=()=>h.qa.motion.locomotion;
function sole(side){const m=h.game.data.fullbodyMeshes.get('BC_FootSole.'+side),p=m.geometry.attributes.position,v=new THREE.Vector3();m.updateWorldMatrix(true,false);let min=Infinity;for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i).applyMatrix4(m.matrixWorld);min=Math.min(min,v.y);}return min;}
function relativeSole(side){const m=h.game.data.fullbodyMeshes.get('BC_FootSole.'+side);m.updateWorldMatrix(true,false);return m.geometry.boundingBox.getCenter(new THREE.Vector3()).applyMatrix4(m.matrixWorld).sub(h.game.data.player);}
function matrices(){return [...h.game.data.fullbodyMeshes.values()].map(m=>{m.updateWorldMatrix(true,false);return m.matrixWorld.toArray();});}
function finite(){for(const m of h.game.data.fullbodyMeshes.values()){m.updateWorldMatrix(true,false);assert(m.matrixWorld.elements.every(Number.isFinite));}}

test('actual first-person poses, game movement, cooldowns, scores and E timing are unchanged frame-for-frame',()=>{assert.equal(actual.length,baseline.length);for(let frame=0;frame<actual.length;frame++)assert.deepEqual(actual[frame],baseline[frame],'Gameplay replay frame '+frame);console.log('E_GAMEPLAY_REPLAY_SHA256 '+createHash('sha256').update(JSON.stringify(actual)).digest('hex'));});
test('actual E Charge Hold Strike have moving feet instead of a frozen glide, including the hidden mirror body',()=>{
 for(const third of [false,true])for(const phase of ['E_Charge','E_Hold','E_Strike']){fresh(h);if((h.qa.view==='third')!==third)h.key('KeyV');h.key('KeyE');if(phase!=='E_Charge')h.frames(53);if(phase==='E_Strike')h.punch();h.key('KeyW');const positions=[],knees=[];for(let f=0;f<20;f++){h.frames(1);assert.equal(h.qa.skills.phase,phase);positions.push(relativeSole('L'));knees.push(h.game.data.fullbodyNodes.get('BC_Knee.L').quaternion.toArray());for(const l of motion().legs)assert.equal(l.clamped,false);for(const s of ['L','R'])assert(sole(s)>-1e-5);}h.release('KeyW');assert(positions.some(p=>p.distanceTo(positions[0])>.1));assert(knees.some(q=>JSON.stringify(q)!==JSON.stringify(knees[0])));}
});
test('E while already walking, movement beginning mid-strike and released movement keep upper shoulders clean',()=>{
 fresh(h);h.key('KeyD');h.frames(20);h.key('KeyE');h.frames(20);for(const side of ['L','R'])assert.deepEqual(h.game.data.fullbodyNodes.get('BC_Pivot_Shoulder.'+side).quaternion.toArray(),[0,0,0,1]);h.release('KeyD');h.frames(90);assert.equal(motion().blend,0);for(const s of ['L','R'])assert(Math.abs(sole(s))<1e-6);
 fresh(h);h.key('KeyE');h.frames(53);h.punch();h.frames(12);h.key('KeyA');h.frames(10);h.release('KeyA');h.frames(90);assert.equal(motion().blend,0);finite();
});
test('blocked E movement does not step; airborne E stops the gait phase and lands safely',()=>{
 fresh(h);h.key('KeyE');h.frames(53);h.game.data.player.x=23.39;h.key('KeyD');h.frames(45);h.release('KeyD');assert.equal(motion().moving,false);assert.equal(motion().phase,0);assert.equal(motion().blend,0);for(const s of ['L','R'])assert(Math.abs(sole(s))<1e-6);
 fresh(h);h.key('KeyE');h.frames(53);h.key('KeyW');h.frames(15);h.key('Space');const phase=motion().phase;h.frames(20);assert(h.qa.player.y>1.7);assert.equal(motion().phase,phase);assert.equal(motion().moving,false);h.release('Space');h.release('KeyW');h.frames(90);for(const s of ['L','R'])assert(Math.abs(sole(s))<1e-6);
});
test('E pause and first/third-person view refreshes reapply without advancing or accumulating matrix offsets',()=>{
 fresh(h);h.key('KeyE');h.frames(53);h.key('KeyW');h.frames(20);h.game.pause();const state=motion(),before=matrices();h.frames(80);assert.deepEqual(motion(),state);for(let i=0;i<4;i++)h.element('viewtoggle').onclick();assert.deepEqual(motion(),state);const after=matrices();for(let i=0;i<before.length;i++)for(let k=0;k<16;k++)assert(Math.abs(before[i][k]-after[i][k])<1e-11);h.game.resume();h.frames(1);finite();
});
test('Q and R override E without stale lower matrices; return restores held E and its gait',()=>{
 for(const key of ['KeyQ','KeyR']){fresh(h);h.key('KeyE');h.frames(53);h.key('KeyD');h.frames(20);h.key(key);h.frames(10);assert(key==='KeyQ'?!!h.qa.hook:h.qa.skills.phase==='R_Cast');if(key==='KeyQ')for(const m of h.game.data.fullbodyMeshes.values())assert(m.matrixAutoUpdate);for(let f=0;f<160;f++){h.frames(1);finite();}assert.equal(h.qa.hook,null);assert.equal(h.qa.skills.phase,'E_Hold');assert(motion().blend>.9);const a=relativeSole('L');h.frames(5);assert(a.distanceTo(relativeSole('L'))>.02);h.release('KeyD');}
});
test('E armed expiry clears surface matrices and returns to ordinary locomotion',()=>{
 fresh(h);h.key('KeyE');h.frames(53);h.key('KeyD');h.frames(305);assert.equal(h.qa.skills.phase,null);for(const m of h.game.data.fullbodyMeshes.values())assert(m.matrixAutoUpdate);h.release('KeyD');h.frames(90);for(const s of ['L','R'])assert(Math.abs(sole(s))<1e-6);
});
test('moving E hit still fires once at authored 0.4s, including pause and reset interruption',()=>{
 fresh(h);h.key('KeyE');h.frames(53);h.key('KeyW');h.frames(10);h.release('KeyW');const t=h.game.data.targets[0];t.active=true;t.captured=false;t.group.visible=true;t.anchor.set(h.qa.player.x,1.7,h.qa.player.z-2);t.amplitude=0;t.group.position.copy(t.anchor);h.punch();h.frames(23);assert.equal(h.qa.skills.metrics.powerHits,0);h.game.pause();h.frames(90);assert.equal(h.qa.skills.metrics.powerHits,0);h.game.resume();h.frames(2);assert.equal(h.qa.skills.metrics.powerHits,1);assert.equal(h.qa.session.score,80);h.frames(60);assert.equal(h.qa.skills.metrics.powerHits,1);
 for(const end of ['finish','damage','menu','restart']){fresh(h);h.key('KeyE');h.frames(53);h.key('KeyW');h.frames(10);h.punch();h.frames(12);if(end==='finish')h.game.finish();if(end==='damage')h.game.damagePlayer(100);if(end==='menu'){h.game.pause();h.element('mainmenu').onclick();}if(end==='restart')h.game.begin(true);h.frames(90);assert.equal(h.qa.skills.metrics.powerHits,0);assert.equal(h.qa.skills.phase,null);assert.equal(motion().blend,0);for(const m of h.game.data.fullbodyMeshes.values())assert(m.matrixAutoUpdate);for(const s of ['L','R'])assert(Math.abs(sole(s))<1e-6);}
});
