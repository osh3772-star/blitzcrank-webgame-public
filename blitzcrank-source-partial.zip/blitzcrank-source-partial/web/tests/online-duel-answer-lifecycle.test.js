import test from 'node:test';
import assert from 'node:assert/strict';
import {createManualPeer,encodeSignal} from '../online-duel-peer.js';
class Channel{constructor(){this.label='rocket-hand-v1';this.ordered=true;this.readyState='connecting';this.bufferedAmount=0;}send(){}open(){this.readyState='open';this.onopen?.();}close(){this.readyState='closed';}}
class PC{
 static instances=[];
 constructor(){PC.instances.push(this);this.iceGatheringState='complete';this.remoteCalls=0;this.closed=false;}
 createDataChannel(){return this.channel=new Channel();}
 async createOffer(){return {type:'offer',sdp:'a=fingerprint:test'};}
 async setLocalDescription(d){this.localDescription=d;}
 async setRemoteDescription(d){this.remoteCalls++;if(this.remoteCalls>1)throw Error('InvalidStateError: answer already applied');this.remoteDescription=d;await this.pendingRemote;}
 close(){this.closed=true;this.channel?.close();}
}
function fixture(){const statuses=[],timers=new Map();let id=0;const clock={now:()=>0,setTimeout:(fn,ms)=>{timers.set(++id,{fn,ms});return id;},clearTimeout:i=>timers.delete(i),setInterval:(fn,ms)=>{timers.set(++id,{fn,ms,interval:true});return id;},clearInterval:i=>timers.delete(i)};const peer=createManualPeer({PeerConnection:PC,clock,onStatus:s=>statuses.push(s)});return {peer,statuses,timers,get pc(){return PC.instances.at(-1);}};}
const answer=p=>encodeSignal({session:p.session,description:{type:'answer',sdp:'a=fingerprint:test'}});
test('double acceptance cannot close the first valid in-flight answer',async()=>{
 const f=fixture();await f.peer.host();let resolve;f.pc.pendingRemote=new Promise(r=>resolve=r);const first=f.peer.accept(answer(f.peer));await assert.rejects(f.peer.accept(answer(f.peer)));assert.equal(f.pc.remoteCalls,1,'second click must not call native SDP installation');assert(!f.pc.closed,'the accepted first attempt must stay usable');resolve();await first;f.pc.channel.open();assert(f.peer.connected);f.peer.close();
});
test('a second answer after a successful acceptance is rejected without ending the connection',async()=>{
 const f=fixture();await f.peer.host();await f.peer.accept(answer(f.peer));f.pc.channel.open();assert(f.peer.connected);await assert.rejects(f.peer.accept(answer(f.peer)));assert(f.peer.connected);assert.equal(f.pc.remoteCalls,1);f.peer.close();
});
test('invalid answer remains correctable before any SDP installation',async()=>{
 const f=fixture();await f.peer.host();await assert.rejects(f.peer.accept('bad'));assert.equal(f.pc.remoteCalls,0);assert(!f.pc.closed);await f.peer.accept(answer(f.peer));assert.equal(f.pc.remoteCalls,1);f.pc.channel.open();assert(f.peer.connected);f.peer.close();
});
test('channel opening during answer installation does not regress status to connecting or restore a deadline',async()=>{
 const f=fixture();await f.peer.host();let resolve;f.pc.pendingRemote=new Promise(r=>resolve=r);const work=f.peer.accept(answer(f.peer));f.pc.channel.open();resolve();await work;assert.equal(f.statuses.at(-1).state,'connected');assert([...f.timers.values()].every(x=>x.interval));f.peer.close();assert.equal(f.timers.size,0);
});
test('closing an in-flight answer cannot reopen it, emit connecting, or leave timers',async()=>{
 const f=fixture();await f.peer.host();let resolve;f.pc.pendingRemote=new Promise(r=>resolve=r);const work=f.peer.accept(answer(f.peer));f.peer.close('left');resolve();await assert.rejects(work);assert(!f.peer.connected);assert.equal(f.statuses.at(-1).detail,'left');assert.equal(f.timers.size,0);assert.equal(f.statuses.filter(x=>x.state==='closed').length,1);
});
