import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {thirdPersonCameraPosition,rayBox} from '../core.js';
const offset=new THREE.Vector3(.9,.8,4.6),pivot=new THREE.Vector3(0,1.7,7);
const vector=p=>new THREE.Vector3(p.x,p.y,p.z);
const expanded=o=>({min:vector(o.min).addScalar(-.18),max:vector(o.max).addScalar(.18)});
test('shoulder orbit uses the same yaw and pitch as camera optics',()=>{
 for(const yaw of [-Math.PI,-1,0,1,Math.PI])for(const pitch of [-1.3,-.7,0,.7,1.3]){const q=new THREE.Quaternion().setFromEuler(new THREE.Euler(pitch,yaw,0,'YXZ')),position=thirdPersonCameraPosition(pivot,yaw,pitch),expected=offset.clone().applyQuaternion(q).add(pivot);assert(vector(position).distanceTo(expected)<1e-12);const local=vector(position).sub(pivot).applyQuaternion(q.clone().invert());assert(local.distanceTo(offset)<1e-12,'player framing changed when rotating');}
});
test('vertical orbit changes camera position while keeping boom distance',()=>{
 const level=thirdPersonCameraPosition(pivot,0,0),up=thirdPersonCameraPosition(pivot,0,.3),down=thirdPersonCameraPosition(pivot,0,-.3);assert(up.y<level.y);assert(down.y>level.y);assert(Math.abs(up.distance-level.distance)<1e-12);assert(Math.abs(down.distance-level.distance)<1e-12);
});
test('camera radius remains above solid floor through steep upward aim',()=>{
 const floor={min:{x:-26,y:-.33,z:-48},max:{x:26,y:-.03,z:22}};
 for(const yaw of [-3,-1,0,1,3])for(const pitch of [.1,.6,1,1.3]){const position=thirdPersonCameraPosition(pivot,yaw,pitch,[floor]);assert(position.y>=.15-1e-9,'lens penetrated floor');assert(position.distance>0);assert(Object.values(position).every(Number.isFinite));}
});
test('radius sweep catches grazing cover that a point boom misses',()=>{
 const direction=offset.clone().normalize(),center=pivot.clone().addScaledVector(direction,2).add(new THREE.Vector3(.13,0,0)),cover={min:center.clone().add(new THREE.Vector3(-.03,-.3,-.1)),max:center.clone().add(new THREE.Vector3(.03,.3,.1))};assert.equal(rayBox(pivot,direction,cover.min,cover.max,offset.length()),null);const position=thirdPersonCameraPosition(pivot,0,0,[cover]),inflated=expanded(cover);assert(position.distance<offset.length());assert.equal(rayBox(pivot,direction,inflated.min,inflated.max,position.distance),null);
});
test('near cover never forces the camera through a minimum-distance barrier',()=>{
 const direction=offset.clone().normalize(),center=pivot.clone().addScaledVector(direction,.35),cover={min:center.clone().addScalar(-.03),max:center.clone().addScalar(.03)},position=thirdPersonCameraPosition(pivot,0,0,[cover]),inflated=expanded(cover);assert(position.distance>=0&&position.distance<.4);assert.equal(rayBox(pivot,direction,inflated.min,inflated.max,position.distance),null);
});
test('arena limits shorten the boom without skewing its shoulder angle',()=>{
 for(const yaw of [-Math.PI,-Math.PI/2,0,Math.PI/2]){const actor=new THREE.Vector3(23.4,1.7,15.5),position=thirdPersonCameraPosition(actor,yaw,0),actual=vector(position).sub(actor),desired=offset.clone().applyAxisAngle(new THREE.Vector3(0,1,0),yaw);assert(position.x>=-24.7-1e-9&&position.x<=24.7+1e-9);assert(position.z>=-44.7-1e-9&&position.z<=20.5+1e-9);assert(actual.clone().cross(desired).length()<1e-10);}
});
