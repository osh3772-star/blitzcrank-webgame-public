import test from 'node:test';
import assert from 'node:assert/strict';
import {createSkillVfx} from '../skill-vfx.js';
import {createSkillVfxHarness,vfxState,vfxStatus} from './helpers/skill-vfx-harness.js';
const p={x:2,y:1.7,z:-3},settings={position:p,status:vfxStatus('E_Hold',.3,{armed:4,boost:2}),moving:true};
const make=()=>createSkillVfxHarness(createSkillVfx);
const object=(h,name)=>h.owned.find(o=>o.name===name);
const impact=h=>object(h,'E_reference_warm_contact_flash').children.find(o=>o.isSprite).material.opacity;
const targets=h=>object(h,'R_target_violet_coronas').children.filter(o=>o.name==='R_target_corona');
const core=(h,n=0)=>targets(h)[n].children[1].material.opacity;
const close=(a,b)=>assert(Math.abs(a-b)<1e-12,`${a} != ${b}`);
const hit=(h,frameOffset=0)=>h.vfx.event('power_fist_hit',{position:p,frameOffset});
const discharge=(h,frameOffset=0)=>h.vfx.event('static_field_discharge',{position:p,targets:[p],frameOffset});

test('exact end-of-frame E and R impacts preserve the full first flash and target corona',()=>{
 const h=make();hit(h,.05);discharge(h,.05);h.vfx.update(.05,settings);
 close(impact(h),1);close(h.vfx.inspect().fieldAge,0);close(core(h),1);
 assert(h.vfx.inspect().impactVisible&&h.vfx.inspect().fieldVisible);close(h.vfx.inspect().time,.05);
 h.vfx.update(.01,settings);close(impact(h),(1-.01/.24)**1.4);close(h.vfx.inspect().fieldAge,.01);close(core(h),(1-.01/.65)**1.5);h.vfx.dispose();
});
test('partial-frame offsets age E, R and R target effects only by the remaining time',()=>{
 const h=make();hit(h,.02);discharge(h,.02);h.vfx.update(.05,settings);
 close(impact(h),(1-.03/.24)**1.4);close(h.vfx.inspect().fieldAge,.03);close(core(h),(1-.03/.65)**1.5);
 h.vfx.update(.05,settings);close(h.vfx.inspect().fieldAge,.08);close(core(h),(1-.08/.65)**1.5);h.vfx.dispose();
});
test('pending offsets survive zero, invalid updates and event-time target refreshes',()=>{
 const h=make();hit(h,.04);discharge(h,.04);const before=vfxState(h);
 for(const dt of [0,-1,NaN,Infinity,undefined]){h.vfx.update(dt,settings);assert.deepEqual(vfxState(h),before);}
 h.vfx.update(.01,settings);close(impact(h),1);close(h.vfx.inspect().fieldAge,0);close(core(h),1);
 h.vfx.update(.04,settings);close(h.vfx.inspect().fieldAge,.01);close(impact(h),(1-.01/.24)**1.4);close(core(h),(1-.01/.65)**1.5);h.vfx.dispose();
});
test('existing effects and W retain full elapsed time when another impact starts late',()=>{
 const h=make(),control=make();for(const v of [h,control]){discharge(v);v.vfx.update(.1,settings);}
 hit(h,.04);h.vfx.update(.05,settings);control.vfx.update(.05,settings);
 close(h.vfx.inspect().fieldAge,.15);close(core(h),(1-.15/.65)**1.5);close(impact(h),(1-.01/.24)**1.4);close(h.vfx.inspect().time,control.vfx.inspect().time);
 for(const name of ['W_pale_gold_and_white_streaks','W_FPS_speed_streaks','W_late_yellow_ground_sparks']){
  const a=object(h,name),b=object(control,name);for(const key of Object.keys(a.geometry.attributes))assert.deepEqual(a.geometry.attributes[key].array,b.geometry.attributes[key].array);assert.deepEqual(a.geometry.drawRange,b.geometry.drawRange);close(a.material.uniforms.uOpacity.value,b.material.uniforms.uOpacity.value);
 }
 h.vfx.dispose();control.vfx.dispose();
});
test('separate R target events, overlapping targets and pool reuse retain per-target offsets',()=>{
 const h=make();h.vfx.event('static_field_target',{position:p});h.vfx.update(.1,settings);
 h.vfx.event('static_field_target',{position:p,frameOffset:.02});h.vfx.update(.05,settings);close(core(h,0),(1-.15/.65)**1.5);close(core(h,1),(1-.03/.65)**1.5);
 for(let i=0;i<11;i++)h.vfx.event('static_field_target',{position:p,frameOffset:.05});h.vfx.update(.05,settings);close(core(h,0),1);h.vfx.dispose();
});
test('reset, recast, missed E, malformed offset and dispose cannot leak an old delay',()=>{
 const h=make();hit(h,.05);discharge(h,.05);h.vfx.reset();hit(h);discharge(h);h.vfx.update(.02,settings);close(impact(h),(1-.02/.24)**1.4);close(h.vfx.inspect().fieldAge,.02);close(core(h),(1-.02/.65)**1.5);
 hit(h,.05);hit(h);discharge(h,.05);discharge(h);h.vfx.update(.01,settings);close(impact(h),(1-.01/.24)**1.4);close(h.vfx.inspect().fieldAge,.01);
 h.vfx.event('power_fist_hit',{frameOffset:.05});h.vfx.update(.01,settings);close(impact(h),(1-.02/.24)**1.4);
 for(const frameOffset of [-1,NaN,Infinity,'0.05']){discharge(h,frameOffset);h.vfx.update(.01,settings);close(h.vfx.inspect().fieldAge,.01);}
 h.vfx.dispose();const dead=vfxState(h);hit(h,.05);discharge(h,.05);h.vfx.update(.1,settings);h.vfx.reset();assert.deepEqual(vfxState(h),dead);
});
test('omitted and explicit zero offsets remain exact with unchanged resource identities',()=>{
 const a=make(),b=make(),arrays=b.arrays.slice(),geometries=b.geometries.slice(),materials=b.materials.slice();
 for(let round=0;round<3;round++){
  for(const kind of ['power_fist_hit','static_field_discharge','static_field_target']){
   a.vfx.event(kind,{position:p,targets:[p]});b.vfx.event(kind,{position:p,targets:[p],frameOffset:0});assert.deepEqual(vfxState(a),vfxState(b));
   for(const dt of [.003,.05,.15,.3,.5]){a.vfx.update(dt,settings);b.vfx.update(dt,settings);assert.deepEqual(vfxState(a),vfxState(b));}
  }
  a.vfx.reset();b.vfx.reset();assert.deepEqual(vfxState(a),vfxState(b));
 }
 for(const [old,current] of [[arrays,b.arrays],[geometries,b.geometries],[materials,b.materials]])assert(old.every((x,i)=>x===current[i]));a.vfx.dispose();b.vfx.dispose();
});
