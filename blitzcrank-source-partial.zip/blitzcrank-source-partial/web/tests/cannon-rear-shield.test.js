import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from '../vendor/three.module.js';
import {GLTFLoader} from '../vendor/GLTFLoader.js';
import {TARGET_MODEL_FILES,attachCharacterTarget} from '../target-models.js';
const read=async path=>{const b=fs.readFileSync(new URL(path,import.meta.url)),json=JSON.parse(b.subarray(20,20+b.readUInt32LE(12)));const {scene}=await new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');scene.updateMatrixWorld(true);const primitives={};scene.traverse(n=>{if(n.isMesh)primitives[n.material.name]=n.geometry;});return{json,scene,primitives};};
const before=await read('../validation/reference-models-v2430/cannon-v2429.glb');
const after=await read('../assets/targets/'+TARGET_MODEL_FILES.cannon);
// Preserve the original rear-shield-only contract; the current helmet delta has separate tests.
const historicalShield=await read('../validation/recovered-assets/cannon.ea1159ec02004cd1.glb');
const regions={
 'Beveled silver steel':{min:[-.36000001430511475,.7450000047683716,-1.2912501096725464],max:[.36000001430511475,1.2350000143051147,-1.1712501049041748]},
 'Forged charcoal metal':{min:[-.2849999964237213,.8199999928474426,-1.318750023841858],max:[.2849999964237213,1.159999966621399,-1.283750057220459]}
};
function triangles(g){const attributes=Object.keys(g.attributes).sort(),items=new Map();for(let i=0;i<g.index.count;i+=3){const ids=[0,1,2].map(k=>g.index.array[i+k]);const vertices=ids.map(id=>JSON.stringify(attributes.map(name=>Array.from(g.attributes[name].array.slice(id*g.attributes[name].itemSize,(id+1)*g.attributes[name].itemSize)))));const key=[0,1,2].map(k=>[vertices[k],vertices[(k+1)%3],vertices[(k+2)%3]].join('|')).sort()[0];const item=items.get(key)||{count:0,points:ids.map(id=>[g.attributes.position.getX(id),g.attributes.position.getY(id),g.attributes.position.getZ(id)])};item.count++;items.set(key,item);}return items;}
function difference(a,b){const out=[];for(const [key,item]of a){const count=item.count-(b.get(key)?.count||0);for(let i=0;i<count;i++)out.push(item.points);}return out;}
test('historical rear shield changes keep embedded assets, exact materials, seven primitives and bounded triangle cost',()=>{
 const after=historicalShield;
 assert.deepEqual(after.json.materials,before.json.materials);assert.deepEqual(after.json.nodes,before.json.nodes);assert.equal(after.json.meshes.length,1);assert.equal(after.json.meshes[0].primitives.length,7);assert(!(after.json.images||[]).length);assert((after.json.buffers||[]).every(b=>!b.uri));
 const count=a=>Object.values(a.primitives).reduce((sum,g)=>sum+g.index.count/3,0);assert.equal(count(before),9922);assert.equal(count(after),9970);
});
test('historical five unaffected material primitives, including all blue muzzle accents, remain exactly decoded',()=>{
 const after=historicalShield;
 let count=0;for(const [name,a]of Object.entries(before.primitives)){if(regions[name])continue;const b=after.primitives[name];assert.deepEqual(b.index.array,a.index.array,name);assert.deepEqual(Object.keys(b.attributes),Object.keys(a.attributes));for(const attr of Object.keys(a.attributes))assert.deepEqual(b.attributes[attr].array,a.attributes[attr].array,name+' '+attr);count++;}assert.equal(count,5);
});
for(const [name,box]of Object.entries(regions))test(name+' historical shield changes only triangles inside the original rear-plate region',()=>{
 const after=historicalShield;
 const a=before.primitives[name],b=after.primitives[name];assert.equal(b.attributes.position.count-a.attributes.position.count,64);
 const old=triangles(a),updated=triangles(b),removed=difference(old,updated),added=difference(updated,old);assert.equal(removed.length,108);assert.equal(added.length,132);
 for(const tri of [...removed,...added])for(const point of tri)for(let axis=0;axis<3;axis++)assert(point[axis]>=box.min[axis]-1e-7&&point[axis]<=box.max[axis]+1e-7,name+' outside rear region');
});
test('rear clipped corners reveal the deeper carriage while center frame and inset remain visible',()=>{
 const hit=(asset,x,y)=>new THREE.Raycaster(new THREE.Vector3(x,y,-3),new THREE.Vector3(0,0,1)).intersectObject(asset.scene,true)[0];
 for(const x of [-.32,.32]){const old=hit(before,x,1.2),now=hit(after,x,1.2);assert.equal(old.object.material.name,'Beveled silver steel');assert(now.distance>old.distance+.05);}
 assert.equal(hit(after,0,1.2).object.material.name,'Beveled silver steel');assert.equal(hit(after,0,.95).object.material.name,'Forged charcoal metal');
});
test('actual target normalization, three world placements, ring and collider envelope remain exact',()=>{
 for(const p of [[0,0,0],[12,3,-18],[-9,1.8,4]]){const attach=asset=>{const group=new THREE.Group(),ring=new THREE.Group();group.position.fromArray(p);group.add(ring);return attachCharacterTarget({group,ring},{scene:asset.scene,id:'cannon',label:'cannon'});};const a=attach(before),b=attach(after);assert.deepEqual(b.character.scale.toArray(),a.character.scale.toArray());assert.deepEqual(b.character.position.toArray(),a.character.position.toArray());assert.deepEqual(b.bounds.min.toArray(),a.bounds.min.toArray());assert.deepEqual(b.bounds.max.toArray(),a.bounds.max.toArray());assert.deepEqual(b.ring.position.toArray(),a.ring.position.toArray());}
});
