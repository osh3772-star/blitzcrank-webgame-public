import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as THREE from '../vendor/three.module.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// Real game/Three.js execution with the existing CPU harness. Test-only exports
// expose poses and turret state without changing the shipping module or harness.
const directory=fs.mkdtempSync(path.join(os.tmpdir(),'hook-interruption-'));
const sourcePath=path.join(directory,'instrumented-main.js');
const original=process.env.HOOK_INTERRUPTION_SOURCE || new URL('../main.js',import.meta.url);
fs.writeFileSync(sourcePath,fs.readFileSync(original,'utf8')+`
window.__HOOK_INTERRUPTION__={get data(){return{fist,rope,projectileParts,fullbody,fullbodySocket,clips,clipName,clipTime,oneShot,turretArena}},prepareMirrorBody,restoreMirrorBody};`);
let h;
try {h=await createGameplayHarness({sourcePath});}
finally {fs.rmSync(directory,{recursive:true,force:true});}
const extra=window.__HOOK_INTERRUPTION__;
const phases=['windup','outbound','return','recover'];
function fresh(third=false,practice=true){
 h.game.begin(practice);
 if((h.qa.view==='third')!==third)h.key('KeyV');
 h.frames(1);
}
function seekPhase(phase){
 h.key('KeyQ');
 for(let i=0;i<180&&h.qa.hook?.phase!==phase;i++)h.frames(1);
 assert.equal(h.qa.hook?.phase,phase);
 h.frames(phase==='windup'?8:phase==='outbound'?4:3);
 assert.equal(h.qa.hook?.phase,phase);
 if(phase==='return')assert.equal(h.game.data.hook.target?.captured,true);
 if(phase==='recover')assert.equal(h.qa.session.catches,1);
}
function near(actual,expected,label,tolerance=1e-10){assert(Math.abs(actual-expected)<tolerance,`${label}: ${actual} != ${expected}`);}
function poses(){return{
 parts:h.game.data.parts.map(p=>[p.visible,...p.position.toArray(),...p.quaternion.toArray(),...p.scale.toArray()]),
 nodes:[...h.game.data.fullbodyNodes].map(([name,n])=>[name,...n.position.toArray(),...n.quaternion.toArray()]),
 targetStates:h.qa.targets,
 hook:h.qa.hook,
 fist:extra.data.fist.visible,
 rope:extra.data.rope.visible
};}
function assertRestored(){
 const d=extra.data;
 assert.equal(h.qa.hook,null);
 assert.equal(d.fist.visible,false);assert.equal(d.rope.visible,false);
 assert.equal(d.projectileParts.length,68);
 assert(d.projectileParts.every(p=>p.visible),'the attached FPS projectile surfaces must all be visible');
 assert.equal(d.clipName,'Idle');assert.equal(d.clipTime,0);assert.equal(d.oneShot,0);
 const expected=d.clips.Idle.frames[0].poses;
 for(let i=0;i<h.game.data.parts.length;i++){
  const part=h.game.data.parts[i],pose=expected[i];
  const position=[pose.p[0],pose.p[1],-pose.p[2]];
  part.position.toArray().forEach((v,k)=>near(v,position[k],part.name+' idle position'));
  part.scale.toArray().forEach((v,k)=>near(v,pose.s[k],part.name+' idle scale'));
  const q=new THREE.Quaternion(-pose.q[0],-pose.q[1],pose.q[2],pose.q[3]);
  part.quaternion.toArray().forEach((v,k)=>near(v,q.toArray()[k],part.name+' idle rotation'));
  part.updateWorldMatrix(true,false);assert(part.matrixWorld.elements.every(Number.isFinite));
 }
 const q=h.game.data.fullbodyNodes.get('BC_QLaunch.R');
 assert.deepEqual(q.position.toArray(),q.userData.base);
 assert.deepEqual(q.quaternion.toArray(),[0,0,0,1]);
 const shoulder=h.game.data.fullbodyNodes.get('BC_Pivot_Shoulder.R');
 assert.deepEqual(shoulder.quaternion.toArray(),[0,0,0,1]);
 const palm=h.game.data.fullbodyMeshes.get('BC_Palm.R');
 palm.updateWorldMatrix(true,false);
 const center=palm.localToWorld(palm.geometry.boundingBox.getCenter(new THREE.Vector3()));
 near(center.distanceTo(d.fullbodySocket),0,'restored full-body socket');
 for(const mesh of h.game.data.fullbodyMeshes.values()){mesh.updateWorldMatrix(true,false);assert(mesh.matrixWorld.elements.every(Number.isFinite));}
 assert(h.qa.targets.every(t=>!t.captured),'no target can remain owned by a canceled hook');
 const token=extra.prepareMirrorBody();assert.equal(token.body.visible,true);assert.equal(d.fist.visible,false);
 extra.restoreMirrorBody(token);assert.equal(d.fullbody.visible,h.qa.view==='third');assert.equal(d.fist.visible,false);
}
function scoreState(){const s=h.qa.session;return{score:s.score,catches:s.catches,hits:s.hits,punches:s.punches,combo:s.combo};}

for(const third of [false,true])for(const ending of ['death','timeout'])for(const phase of phases){
 test(`${third?'third-person':'FPS'} ${ending} during Q ${phase} restores both rigs without extra capture`,()=>{
  fresh(third,ending!=='timeout');seekPhase(phase);
  const before=scoreState(),target=h.game.data.hook.target;
  if(ending==='death')h.game.damagePlayer(100);
  else {h.game.setElapsed(89.99);h.frames(1);assert.equal(h.qa.session.elapsed,90);}
  assert.equal(h.qa.state,'results');assert.equal(h.qa.health,ending==='death'?0:100);
  assertRestored();assert.deepEqual(scoreState(),before);
  if(target)assert.equal(target.captured,false);
  if(phase==='return'){assert.equal(target.active,true);assert.equal(target.group.visible,true);}
  if(phase==='recover'){assert.equal(target.active,false);assert.equal(target.group.visible,false);}
  const after=poses();h.frames(120);assert.deepEqual(poses(),after);assert.deepEqual(scoreState(),before);
 });
}

for(const third of [false,true])for(const phase of phases){
 test(`${third?'third-person':'FPS'} pause freezes Q ${phase}; resume completes once`,()=>{
  fresh(third);seekPhase(phase);const current=h.game.data.hook,position=current.position.toArray(),before=poses(),elapsed=h.qa.session.elapsed;
  h.game.pause();h.frames(90);
  assert.equal(h.game.data.hook,current);assert.deepEqual(current.position.toArray(),position);
  assert.deepEqual(poses(),before);assert.equal(h.qa.session.elapsed,elapsed);
  h.game.resume();h.frames(180);assert.equal(h.qa.hook,null);
  assert.equal(h.qa.session.catches,1);assert.equal(h.qa.session.score,100);
  assert(extra.data.projectileParts.every(p=>p.visible));
 });
}

for(const third of [false,true]){
 test(`${third?'third-person':'FPS'} ordinary Q finishes and scores exactly once`,()=>{
  fresh(third);h.key('KeyQ');h.frames(150);
  assert.equal(h.qa.hook,null);assert.equal(h.qa.session.catches,1);assert.equal(h.qa.session.score,100);
  assert(extra.data.projectileParts.every(p=>p.visible));assert.equal(extra.data.fist.visible,false);assert.equal(extra.data.rope.visible,false);
  h.frames(180);assert.equal(h.qa.session.catches,1);assert.equal(h.qa.session.score,100);
 });
 test(`${third?'third-person':'FPS'} restart after canceled capture permits a new normal Q`,()=>{
  fresh(third);seekPhase('return');h.game.damagePlayer(100);assertRestored();
  h.game.begin(true);h.frames(1);assert.equal(h.qa.health,100);assert.equal(h.qa.session.score,0);assert(h.qa.targets.every(t=>!t.captured&&t.active&&t.visible));
  h.key('KeyQ');h.frames(150);assert.equal(h.qa.hook,null);assert.equal(h.qa.session.catches,1);assert.equal(h.qa.session.score,100);
 });
 test(`${third?'third-person':'FPS'} menu and begin still reset an interrupted capture`,()=>{
  fresh(third);seekPhase('return');h.game.pause();h.element('mainmenu').onclick();h.frames(1);
  assert.equal(h.qa.state,'menu');assert.equal(h.qa.hook,null);assert(h.qa.targets.every(t=>!t.captured&&t.active&&t.visible));
  assert(extra.data.projectileParts.every(p=>p.visible));
  h.game.begin(true);h.frames(1);h.key('KeyQ');h.frames(150);assert.equal(h.qa.session.catches,1);assert.equal(h.qa.session.score,100);
 });
 test(`${third?'third-person':'FPS'} lethal turret callback mid-tick cancels Q without later stale work`,()=>{
  fresh(third);seekPhase('return');const before=scoreState();h.game.setHealth(18);
  const sim=extra.data.turretArena.sim,player=h.game.data.player;
  // Actual turret simulation emits two queued hits; the real view callback's
  // generation guard must stop dispatch after the first lethal hit resets it.
  for(const id of [9001,9002])sim.bullets.push({id,turretId:'west',position:{x:player.x,y:player.y-.55,z:player.z},velocity:{x:0,y:0,z:0},age:0,active:true});
  h.frames(1);assert.equal(h.qa.state,'results');assert.equal(h.qa.health,0);assertRestored();
  assert.equal(sim.bullets.length,0);assert.equal(h.qa.turrets.warning,false);assert.deepEqual(scoreState(),before);
  const after=poses();h.frames(90);assert.deepEqual(poses(),after);assert.deepEqual(scoreState(),before);
 });
}
