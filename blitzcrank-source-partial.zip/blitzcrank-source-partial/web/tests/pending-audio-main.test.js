import test from 'node:test';import {rayBox} from '../core.js';import assert from 'node:assert/strict';import fs from 'node:fs';import * as RealThree from '../vendor/three.module.js';
// CPU-only smoke harness. It runs the actual game module and Three.js scene graph,
// but deliberately does not claim GPU rendering or physical-browser input coverage.
class Classes{constructor(){this.s=new Set();}toggle(x,force){if(force===undefined)force=!this.s.has(x);force?this.s.add(x):this.s.delete(x);}add(x){this.s.add(x);}remove(x){this.s.delete(x);}}
class Element{constructor(){this.style={};this.classList=new Classes();this.firstElementChild={style:{}};this.parentElement={classList:new Classes()};this.value='1';this.disabled=false;this.listeners={};this.textContent='';this.innerHTML='';}addEventListener(k,f){const previous=this.listeners[k];this.listeners[k]=e=>{previous?.(e);f(e);};}setAttribute(){}querySelector(){return new Element();}getBoundingClientRect(){return{left:0,top:0,width:110,height:110};}setPointerCapture(){}requestPointerLock(){document.pointerLockElement=this;docListeners.pointerlockchange?.();return Promise.resolve();}click(){this.onclick?.();}getContext(){return{fillRect(){},fillText(){},fillStyle:'',textAlign:'',font:''};}}
const elements=new Map(),docListeners={},winListeners={};let callback;
const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
globalThis.document={getElementById:element,querySelector:element,createElement:()=>new Element(),addEventListener:(n,f)=>docListeners[n]=f,pointerLockElement:null,exitPointerLock(){this.pointerLockElement=null;docListeners.pointerlockchange?.();}};globalThis.window=globalThis;globalThis.innerWidth=1280;globalThis.innerHeight=720;globalThis.devicePixelRatio=1;globalThis.matchMedia=()=>({matches:false});globalThis.localStorage={getItem:()=>null,setItem(){}};globalThis.addEventListener=(n,f)=>winListeners[n]=f;globalThis.requestAnimationFrame=f=>{callback=f;};globalThis.fetch=async(path)=>({ok:true,arrayBuffer:async()=>{const b=fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);},json:async()=>JSON.parse(fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url)))});
class Renderer{constructor(){this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}render(){}clearDepth(){}}
class Clock{getDelta(){return 1/60;}}
const sampleSources=[],synthSources=[],audioContexts=[];
class AudioContextMock{
 constructor(){this.state='suspended';this.currentTime=1;this.destination={};this.oscillators=[];this.listeners=new Set();audioContexts.push(this);}
 addEventListener(type,listener){if(type==='statechange')this.listeners.add(listener);}
 removeEventListener(type,listener){if(type==='statechange')this.listeners.delete(listener);}
 setState(state){this.state=state;for(const listener of this.listeners)listener();}
 advance(seconds){if(this.state!=='running')return;this.currentTime+=seconds;for(const o of this.oscillators)if(o.started&&!o.ended&&this.currentTime>=o.stopAt)o.end();}
 resume(){if(this.resumeGate)return this.resumeGate.then(()=>this.setState('running'));this.setState('running');return Promise.resolve();}
 createGain(){return{connect(){},disconnect(){},gain:{cancelScheduledValues(){},setValueAtTime(){},exponentialRampToValueAtTime(){}}};}
 decodeAudioData(data){const b=Buffer.from(data);let rate=0,size=0;for(let o=12;o+8<=b.length;){const n=b.readUInt32LE(o+4),kind=b.toString('ascii',o,o+4);if(kind==='fmt ')rate=b.readUInt32LE(o+16);if(kind==='data')size=n;o+=8+n+(n%2);}return Promise.resolve({duration:size&&rate?size/rate:(data.byteLength>120000?.73:.57),byteLength:data.byteLength});}
 createBufferSource(){const o={connect(){},disconnect(){},start(){o.started=true;},stop(){o.stopped=true;o.onended?.();}};sampleSources.push(o);return o;}
 createOscillator(){const ctx=this,o={context:ctx,stopAt:Infinity,connect(){},disconnect(){o.disconnected=true;},start(){o.started=true;},stop(when=ctx.currentTime){o.stopAt=when;if(when<=ctx.currentTime)o.end();},end(){if(o.ended)return;o.ended=true;o.onended?.();},get audible(){return Boolean(ctx.state==='running'&&o.started&&!o.ended&&!o.disconnected);},frequency:{setValueAtTime(v){o.freq=v;},exponentialRampToValueAtTime(){}}};this.oscillators.push(o);synthSources.push(o);return o;}
}
globalThis.AudioContext=AudioContextMock;
class TextureLoader{async loadAsync(path){assert(fs.existsSync(new URL('../'+path.replace('./',''),import.meta.url)));return new RealThree.Texture();}}
globalThis.testThree={...RealThree,WebGLRenderer:Renderer,Clock,TextureLoader};
const nativeFetch=globalThis.fetch,audioRequests=[];let releaseAudio,holdingAudio=true;
const audioGate=new Promise(resolve=>releaseAudio=()=>{holdingAudio=false;resolve();});
globalThis.fetch=async path=>{if(path.includes('assets/audio/')){audioRequests.push(path);if(holdingAudio)await audioGate;}return nativeFetch(path);};
let trustedGesture=false,resumeCalls=0;
const originalResume=AudioContextMock.prototype.resume;
AudioContextMock.prototype.resume=function(){resumeCalls++;if(!trustedGesture)return Promise.reject(Error('gesture required'));return originalResume.call(this);};
const gesture=fn=>{trustedGesture=true;try{return fn();}finally{trustedGesture=false;}};
let source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8').replace("import * as THREE from './vendor/three.module.js';",'const THREE = globalThis.testThree;').replace("from './hook-chain.js'",`from '${new URL('../hook-chain.js',import.meta.url).href}'`).replace("from './training-mirror.js'",`from '${new URL('../training-mirror.js',import.meta.url).href}'`).replace("from './game-audio.js'",`from '${new URL('../game-audio.js',import.meta.url).href}'`).replace("from './audio-cues.js'",`from '${new URL('../audio-cues.js',import.meta.url).href}'`).replace("from './voice-cues.js'",`from '${new URL('../voice-cues.js',import.meta.url).href}'`).replace("from './voice-schedule.js'",`from '${new URL('../voice-schedule.js',import.meta.url).href}'`).replace("from './blitz-materials.js'",`from '${new URL('../blitz-materials.js',import.meta.url).href}'`).replace("from './core.js'",`from '${new URL('../core.js',import.meta.url).href}'`).replace("from './mouse-look.js'",`from '${new URL('../mouse-look.js',import.meta.url).href}'`).replace("from './target-models.js'",`from '${new URL('../target-models.js',import.meta.url).href}'`).replace("from './turret-view.js'",`from '${new URL('../turret-view.js',import.meta.url).href}'`);
source+=`\nwindow.__MOTION__={get data(){return{hook,fist,rope,parts,projectileParts,camera,viewCamera,viewmodel,targets,obstacles,fullbodySocket,player,turretArena,fullbodyNodes,fullbodyMeshes}},prepareMirrorBody,restoreMirrorBody,fullbodyCableSocket,fullbodyChainSocket,get mirror(){return trainingMirror},handPoint,cableSocket,chainHandSocket,nearestRay,begin,pause,resume,finish,damagePlayer,audio,gameAudio,setDuelBotSource(source){duelBrain=source}};`;
source=source.replace("from './model-codec.js'",`from '${new URL('../model-codec.js',import.meta.url).href}'`).replace("from './player-model-manifest.js'",`from '${new URL('../player-model-manifest.js',import.meta.url).href}'`);
source=source.replace(/from '\.\/([^']+)'/g,(_,path)=>`from '${new URL('../'+path,import.meta.url).href}'`);
// This fixture exercises initialized gameplay, not the natural first selection.
source+='\nif(typeof ensureGameplayAssets==="function")await ensureGameplayAssets();';
await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const punch=()=>element('game').listeners.pointerdown({pointerType:'mouse',button:0,preventDefault(){}});
const key=code=>winListeners.keydown({code,repeat:false,preventDefault(){}}),release=code=>winListeners.keyup({code});const frames=n=>{for(let i=0;i<n;i++){for(const ctx of audioContexts)ctx.advance(1/60);callback();}};

const qa=window.__HOOK_ARENA__,motion=window.__MOTION__;
function fresh(third=false){motion.begin(true);if((qa.view==='third')!==third)key('KeyV');frames(1);}
function launch(){key('KeyQ');frames(16);assert.equal(motion.data.hook.phase,'outbound');}

async function ready(){fresh();await motion.gameAudio.unlock();await motion.gameAudio.preload();frames(1);motion.gameAudio.stopAll();sampleSources.length=0;synthSources.length=0;}
test('actual main start, blur and explicit resume recover while original priority fetch is pending',async()=>{
 gesture(()=>element('practice').onclick());await new Promise(r=>setImmediate(r));
 assert.equal(qa.state,'running');assert.equal(audioContexts.length,1);const ctx=audioContexts[0];assert.equal(resumeCalls,1);assert(audioRequests.length>0);assert.equal(qa.audio.ready.length,0);
 ctx.setState('suspended');winListeners.blur();assert.equal(qa.state,'paused');assert.equal(qa.audio.active,0);assert.equal(qa.audio.activeTones,0);
 gesture(()=>element('start').onclick());const immediateCalls=resumeCalls,immediateState=ctx.state;
 assert.equal(qa.state,'running');key('KeyQ');const count=sampleSources.length;assert.equal(count,0,'preload-time Q must be dropped');
 releaseAudio();await motion.gameAudio.preload();await new Promise(r=>setImmediate(r));frames(1);
 assert.equal(immediateCalls,2,'actual resume handler must call context.resume in trusted stack despite pending preload');assert.equal(immediateState,'running');assert.equal(ctx.state,'running');
 assert.equal(sampleSources.length,count,'old start voice and Q must not replay');assert.equal(qa.voice.pendingStart,false);assert.equal(new Set(audioRequests).size,audioRequests.length,'each audio asset fetched once');
 gesture(()=>motion.begin(true));sampleSources.length=0;key('KeyQ');assert.equal(sampleSources.length,1,'fresh accepted Q plays after recovery');
 motion.pause();assert.equal(qa.audio.active,0);assert.equal(qa.audio.activeTones,0);motion.gameAudio.dispose();
});
