import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createSkillController,SKILL_TUNING} from '../skill-controller.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';

const clips=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))).models.fullbody.clips;
const duration=name=>clips.find(clip=>clip.name===name).duration;
const impactTypes=events=>events.filter(event=>['power_fist_hit','static_field_discharge','static_field_end'].includes(event.type)).map(event=>event.type);
function charged(){const events=[],controller=createSkillController(clips,{onEvent:event=>events.push(event)});assert(controller.castE());controller.step(duration('E_Charge'));assert.equal(controller.status.armed,SKILL_TUNING.eArmedDuration);return {controller,events};}
function frames(controller,count,hz){for(let i=0;i<count;i++)controller.step(1/hz);}

for(const hz of [20,30,50,60,100,120,144,165]){
 test(`E expires at its five-second endpoint without R at ${hz} Hz`,()=>{
  const {controller:c,events}=charged();frames(c,SKILL_TUNING.eArmedDuration*hz-1,hz);
  assert.equal(c.status.phase,'E_Hold');assert(c.status.armed>0);
  c.step(1/hz);
  assert.equal(c.status.armed,0);assert.equal(c.status.phase,null);assert.equal(c.animation,null);
  assert.equal(c.strikeE(),false);c.step(2);assert.deepEqual(impactTypes(events),[]);
 });
 test(`R ending at E expiry does not revive an expired empowered punch at ${hz} Hz`,()=>{
  const {controller:c,events}=charged(),castFrames=Math.ceil(duration('R_Cast')*hz);
  frames(c,SKILL_TUNING.eArmedDuration*hz-castFrames,hz);assert(c.castR());
  frames(c,castFrames-1,hz);assert(c.status.armed>0);assert.equal(c.status.phase,'R_Cast');
  c.step(1/hz);
  assert.equal(c.status.armed,0);assert.equal(c.status.phase,null);assert.equal(c.animation,null);
  assert.equal(c.strikeE(),false);c.step(2);
  assert.deepEqual(impactTypes(events),['static_field_discharge','static_field_end']);
 });
}

test('E expiry during R does not cancel R or its once-only authored events',()=>{
 const {controller:c,events}=charged();frames(c,282,60);assert(c.castR());frames(c,18,60);
 assert.equal(c.status.armed,0);assert.equal(c.status.phase,'R_Cast');assert.equal(c.blocksAttack,true);
 assert.equal(c.strikeE(),false);assert.deepEqual(impactTypes(events),['static_field_discharge']);
 frames(c,50,60);assert.equal(c.status.phase,null);assert.equal(c.blocksAttack,false);
 assert.deepEqual(impactTypes(events),['static_field_discharge','static_field_end']);
});

test('a genuinely remaining nanosecond survives R completion and can still be struck',()=>{
 for(const remaining of [1e-9,1e-8,.001]){
  const {controller:c,events}=charged();c.step(SKILL_TUNING.eArmedDuration-duration('R_Cast')-remaining);
  assert(c.castR());c.step(duration('R_Cast'));
  assert.equal(c.status.phase,'E_Hold');assert(c.status.armed>remaining*.99);
  assert(c.strikeE());c.step(.4);
  assert.deepEqual(impactTypes(events),['static_field_discharge','static_field_end','power_fist_hit']);
 }
});

test('R ending before expiry preserves the remaining charge and pause/invalid steps do not age it',()=>{
 const {controller:c,events}=charged();frames(c,180,60);assert(c.castR());frames(c,68,60);
 assert.equal(c.status.phase,'E_Hold');assert(Math.abs(c.status.armed-(2-duration('R_Cast')))<1e-12);
 const before=c.status;for(const dt of [0,-1,NaN,Infinity])c.step(dt);assert.deepEqual(c.status,before);
 assert(c.strikeE());frames(c,24,60);assert.deepEqual(impactTypes(events),['static_field_discharge','static_field_end','power_fist_hit']);
});

test('expired charge cannot survive reset or prevent a fresh E cast',()=>{
 const {controller:c,events}=charged();frames(c,232,60);assert(c.castR());frames(c,68,60);
 assert.equal(c.strikeE(),false);assert.equal(c.blockReason('E'),null);assert(c.castE());
 assert.equal(c.status.phase,'E_Charge');c.reset();c.step(10);
 assert.equal(c.status.phase,null);assert.equal(c.status.armed,0);assert.equal(c.animation,null);
 assert.deepEqual(impactTypes(events),['static_field_discharge','static_field_end']);
});
