import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {PLAYER_MODELS} from '../player-model-manifest.js';
import {decodeModelBuffer} from '../model-codec.js';
const baseline=JSON.parse(fs.readFileSync(new URL('../validation/head-ui-v2415/baseline-signatures.json',import.meta.url)));
const source=JSON.parse(fs.readFileSync(new URL('../assets/blitz-fullbody.json',import.meta.url)));
const hash=x=>crypto.createHash('sha256').update(JSON.stringify(x)).digest('hex');
test('head correction preserves all 290 runtime node transforms, height, materials and shell',()=>{
 assert.deepEqual(Object.keys(source),baseline.schema);
 for(const [key,value] of Object.entries(baseline.metadata))assert.equal(hash(source[key]),value,key);
 const shell=source.parts.find(p=>p.name==='BC_Head');assert.equal(hash(shell),baseline.parts.find(p=>p.name==='BC_Head').hash);
});
test('head correction changes exactly eleven permitted surfaces and preserves all bindings',()=>{
 assert.equal(source.parts.length,279);const changed=[];
 for(let i=0;i<source.parts.length;i++){const p=source.parts[i],b=baseline.parts[i];assert.equal(p.name,b.name);assert.equal(p.sourcePart,b.sourcePart);if(hash(p)!==b.hash)changed.push(p.name);}
 assert.deepEqual(changed,baseline.changed);assert.equal(279-changed.length,268);
});
test('corrected immutable player binary resolves to manifest and contains valid bounded geometry',()=>{
 const file=new URL('../'+PLAYER_MODELS.fullbody.raw.slice(2),import.meta.url),raw=fs.readFileSync(file);assert.equal(crypto.createHash('sha256').update(raw).digest('hex'),PLAYER_MODELS.fullbody.sha256);
 assert(PLAYER_MODELS.fullbody.raw.includes(PLAYER_MODELS.fullbody.sha256.slice(0,16)));
 const decoded=decodeModelBuffer(raw);assert.equal(decoded.parts.length,279);assert.deepEqual(decoded.nodes,source.nodes);
 let tris=0;for(const p of decoded.parts){assert(p.vertices.every(Number.isFinite));assert(p.normals.every(Number.isFinite));assert(p.triangles.every(i=>i>=0&&i<p.vertices.length/3));tris+=p.triangles.length/3;}
 assert.equal(tris,128152);
});
