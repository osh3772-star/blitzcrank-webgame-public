import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {createSkillVfx, SKILL_VFX_LIMITS, SKILL_VFX_PALETTE} from '../skill-vfx.js';

function harness() {
  const scene = new THREE.Scene(), viewScene = new THREE.Scene(), fullbody = new THREE.Group();
  const vm = new THREE.Group(), detached = new THREE.Group(); scene.add(fullbody, detached); viewScene.add(vm);
  fullbody.scale.setScalar(.78); fullbody.rotation.y = Math.PI;
  const worldHands = [], viewHands = [];
  for (const side of ['L', 'R']) {
    for (const [root, list, prefix] of [[fullbody, worldHands, 'BC'], [vm, viewHands, 'VM']]) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(.4, .3, .48), new THREE.MeshBasicMaterial());
      mesh.name = `${prefix}_Palm.${side}`; mesh.geometry.translate(side === 'L' ? -.8 : .8, .4, -.5);
      root.add(mesh); list.push(mesh);
    }
  }
  const clone = new THREE.Mesh(viewHands[1].geometry, viewHands[1].material); clone.name = 'VM_Palm.R_detached'; detached.add(clone); viewHands.push(clone);
  const vfx = createSkillVfx(THREE, {scene, viewScene, fullbody, worldHands, viewHands});
  return {vfx, scene, viewScene, fullbody, worldHands, viewHands, detached, vm};
}
const player = new THREE.Vector3(2, 1.7, -3);
const status = (phase = null, time = 0, rest = {}) => ({phase, boost: 0, slow: 0, armed: 0, animation: phase ? {name: phase, time} : null, ...rest});
function tick(h, dt, s = status(), extra = {}) { h.vfx.update(dt, {status: s, position: player, yaw: .4, ...extra}); }
function ownedObjects(h) {
  const result = [];
  for (const root of [h.scene, h.viewScene]) root.traverse(o => {
    if (o.name.match(/^(W_|E_|R_)/)) result.push(o);
  });
  return result;
}
function buffers(h) {
  return [...new Set(ownedObjects(h).flatMap(o => o.geometry?.isBufferGeometry ? Object.values(o.geometry.attributes).map(a => a.array) : []))];
}
function finiteAndBounded(h) {
  for (const o of ownedObjects(h)) {
    assert(o.position.toArray().every(Number.isFinite), o.name + ' position');
    assert(o.scale.toArray().every(Number.isFinite), o.name + ' scale');
    if (!o.geometry?.isBufferGeometry || o.isSprite) continue;
    for (const a of Object.values(o.geometry.attributes)) assert(a.array.every(Number.isFinite), o.name + ' attribute');
    assert(o.geometry.drawRange.count <= o.geometry.attributes.position.count, o.name + ' draw capacity');
  }
  const info = h.vfx.inspect(); assert(info.segments <= info.capacity);
}

test('reference palette distinguishes violet E, warm impact, ivory R, and yellow W', () => {
  assert.equal(SKILL_VFX_PALETTE.chargeGlow, 0x7022ff);
  assert.equal(SKILL_VFX_PALETTE.fieldIvory, 0xfffee6);
  assert.equal(SKILL_VFX_PALETTE.impact, 0xffedbd);
  assert.equal(SKILL_VFX_PALETTE.groundGold, 0xffd62b);
});

test('hand effects bind to actual palm centers and follow world, FPS, and detached Q transforms', () => {
  const h = harness(); tick(h, .1, status('E_Hold', .3, {armed: 4}));
  for (const hand of [...h.worldHands, ...h.viewHands]) {
    const g = hand.children.find(o => o.name.startsWith('E_charged_fist_'));
    assert(g); assert(g.visible); assert(g.position.equals(hand.geometry.boundingBox.getCenter(new THREE.Vector3())));
    hand.rotation.set(.25, -.7, .1); hand.position.set(-2, .6, 3); hand.updateMatrixWorld(true);
    assert(g.getWorldPosition(new THREE.Vector3()).distanceTo(hand.localToWorld(hand.geometry.boundingBox.getCenter(new THREE.Vector3()))) < 1e-9);
  }
  // Original FPS hand may be hidden during Q; the separately anchored clone lives on.
  h.viewHands[1].visible = false; h.detached.visible = true; tick(h, .1, status(null, 0, {armed: 3.5}));
  assert(h.viewHands[2].children[0].visible); assert.equal(h.viewHands[1].visible, false);
  // Mirror caller temporarily shows fullbody; no independent visibility override.
  h.fullbody.visible = false; tick(h, .1, status('E_Hold', .5, {armed: 3}));
  assert.equal(h.fullbody.visible, false); assert(h.worldHands[0].children[0].visible);
  h.fullbody.visible = true; assert(h.worldHands[0].children[0].visible);
  finiteAndBounded(h); h.vfx.dispose();
});

test('W onset, boost, rear streak taper, and yellow slowdown traces are distinct', () => {
  const h = harness(); tick(h, .01, status()); assert(!h.vfx.inspect().wVisible);
  tick(h, .04, status(null, 0, {boost: 3.96}), {moving: true}); assert(h.vfx.inspect().wVisible); assert(!h.vfx.inspect().groundVisible);
  tick(h, 3.93, status(null, 0, {boost: .03}), {moving: true}); assert(h.vfx.inspect().groundVisible);
  tick(h, .04, status(null, 0, {slow: 2})); assert(h.vfx.inspect().wVisible); assert(h.vfx.inspect().groundVisible);
  tick(h, .4, status(null, 0, {slow: 1.6})); assert(!h.vfx.inspect().wVisible); assert(h.vfx.inspect().groundVisible);
  tick(h, 1.6, status()); assert(!h.vfx.inspect().groundVisible); finiteAndBounded(h); h.vfx.dispose();
});

test('E charge, optional five-second hold, R/Q preservation, and exact strike contact cutoff', () => {
  const h = harness(); tick(h, .01, status('E_Charge', .01)); assert(h.vfx.inspect().eStrength > 0);
  tick(h, 26 / 30, status('E_Hold', 0, {armed: 5})); assert.equal(h.vfx.inspect().eStrength, 1);
  tick(h, 3, status('E_Hold', .3, {armed: 2})); assert.equal(h.vfx.inspect().eStrength, 1);
  tick(h, .2, status('R_Cast', .2, {armed: 1.8})); assert.equal(h.vfx.inspect().eStrength, 1);
  tick(h, .1, status(null, 0, {armed: 1.7})); assert.equal(h.vfx.inspect().eStrength, 1);
  tick(h, .39, status('E_Strike', .39)); assert.equal(h.vfx.inspect().eStrength, 1);
  tick(h, .01, status('E_Strike', .4)); assert.equal(h.vfx.inspect().eStrength, 0);
  assert(!h.vfx.inspect().impactVisible, 'strike time alone must not invent contact');
  h.vfx.event('power_fist_hit'); assert(!h.vfx.inspect().impactVisible, 'a miss consumes charge without contact flash');
  tick(h, .1, status('E_Strike', .5)); assert.equal(h.vfx.inspect().eStrength, 0);
  tick(h, 1, status()); assert.equal(h.vfx.inspect().eStrength, 0); h.vfx.dispose();
});

test('E contact flash is short, warm and independent of pose recovery', () => {
  const h = harness(), at = new THREE.Vector3(3, 1.2, -5);
  h.vfx.event('power_fist_hit', {position: at}); assert(h.vfx.inspect().impactVisible);
  const flash = h.scene.getObjectByName('E_reference_warm_contact_flash'); assert(flash.position.equals(at));
  tick(h, .12); assert(h.vfx.inspect().impactVisible);
  tick(h, .13); assert(!h.vfx.inspect().impactVisible); finiteAndBounded(h); h.vfx.dispose();
});

test('R grows a branching web, flickers through recovery, stays at cast origin and ends after f127', () => {
  const h = harness(); tick(h, .29, status('R_Cast', .29)); assert(!h.vfx.inspect().fieldVisible);
  assert(h.vfx.event('static_field_discharge', {position: player}));
  assert(h.vfx.inspect().fieldSegments > 1000); assert(h.vfx.inspect().fieldVisible);
  const root = h.scene.getObjectByName('R_reference_branching_electrical_field'), origin = root.position.clone();
  assert.equal(root.position.y, 0);
  tick(h, .4, status()); assert(h.vfx.inspect().fieldVisible); assert(h.vfx.inspect().fieldSegments > 0);
  h.vfx.update(.1, {status: status(), position: new THREE.Vector3(18, 1.7, 12)});
  assert(root.position.equals(origin), 'the world effect must not chase a moving player');
  assert.equal(h.vfx.inspect().fieldSegments, 0, 'f118 flicker gap');
  tick(h, 2 / 30); assert(h.vfx.inspect().fieldSegments > 0, 'lightning returns after gap');
  tick(h, .234); assert(h.vfx.inspect().fieldVisible, 'last source frame f127 is still in tail');
  tick(h, .04); assert(!h.vfx.inspect().fieldVisible); assert.equal(h.vfx.inspect().fieldSegments, 0);
  finiteAndBounded(h); h.vfx.dispose();
});

test('R target corona pool is bounded, does not recast field, and expires', () => {
  const h = harness(); h.vfx.event('static_field_discharge', {position: player, targets: Array.from({length: 30}, (_, i) => new THREE.Vector3(i, 1, 0))});
  assert.equal(h.vfx.inspect().targets, SKILL_VFX_LIMITS.rTargets);
  tick(h, .3); const age = h.vfx.inspect().fieldAge;
  for (let i = 0; i < 50; i++) h.vfx.event('static_field_target', {position: new THREE.Vector3(i, 1, 4)});
  assert.equal(h.vfx.inspect().fieldAge, age); assert.equal(h.vfx.inspect().targets, SKILL_VFX_LIMITS.rTargets);
  tick(h, .7); assert.equal(h.vfx.inspect().targets, 0); finiteAndBounded(h); h.vfx.dispose();
});

test('pause and invalid dt are strict no-ops, not wall-clock VFX', () => {
  const h = harness(); h.vfx.event('static_field_discharge', {position: player});
  tick(h, .1, status('E_Hold', .3, {armed: 4, boost: 3.8}));
  const info = h.vfx.inspect(), arrays = buffers(h).map(a => a.slice());
  for (const dt of [0, -1, NaN, Infinity, -Infinity]) tick(h, dt, status());
  assert.deepEqual(h.vfx.inspect(), info); buffers(h).forEach((a, i) => assert.deepEqual(a, arrays[i])); h.vfx.dispose();
});

test('repeated casts, delayed frames, malformed positions and reset never allocate more GPU resources', () => {
  const h = harness(), original = buffers(h), resources = h.vfx.inspect().resources;
  for (let i = 0; i < 40; i++) {
    h.vfx.event('static_field_discharge', {position: player});
    h.vfx.event('power_fist_hit', {position: new THREE.Vector3(1, 2, 3)});
    tick(h, .3, status('E_Hold', .1, {boost: 3, armed: 3}), {thirdPerson: i % 2 === 0});
    tick(h, 100, status());
    assert(!h.vfx.inspect().fieldVisible); assert(!h.vfx.inspect().impactVisible);
    h.vfx.reset(); assert.equal(h.vfx.inspect().segments, 0); assert.equal(h.vfx.inspect().eStrength, 0);
    assert.equal(h.vfx.event('static_field_discharge', {position: {x: NaN, y: 0, z: 0}}), false);
    assert.equal(h.vfx.event('static_field_target', {position: {x: 0, y: Infinity, z: 0}}), false);
    assert.deepEqual(h.vfx.inspect().resources, resources); assert.deepEqual(buffers(h), original);
  }
  finiteAndBounded(h); h.vfx.dispose();
});

test('reset removes in-flight effects and disposal releases only owned resources exactly once', () => {
  const h = harness(), events = {geometry: 0, material: 0, texture: 0}, seen = new Set();
  const initial = h.vfx.inspect().resources;
  for (const o of ownedObjects(h)) {
    for (const [kind, resource] of [['geometry', o.geometry], ['material', o.material], ['texture', o.material?.map]]) {
      if (!resource || seen.has(resource) || (kind === 'geometry' && o.isSprite)) continue;
      seen.add(resource); resource.addEventListener('dispose', () => events[kind]++);
    }
  }
  let handDisposed = false; h.viewHands[0].geometry.addEventListener('dispose', () => handDisposed = true);
  h.vfx.event('static_field_discharge', {position: player, targets: [new THREE.Vector3(1, 1, 1)]});
  tick(h, .1, status('E_Hold', .2, {armed: 4, boost: 3})); h.vfx.reset();
  assert.equal(h.vfx.inspect().segments, 0); assert(!h.vfx.inspect().fieldVisible); assert(!h.vfx.inspect().wVisible);
  h.vfx.dispose(); h.vfx.dispose(); assert(h.vfx.inspect().disposed);
  assert.equal(events.geometry, initial.geometries); assert.equal(events.material, initial.materials); assert.equal(events.texture, initial.textures);
  assert(!handDisposed); assert.equal(ownedObjects(h).length, 0);
  const after = h.vfx.inspect(); tick(h, 1, status('E_Hold', .1, {armed: 4})); h.vfx.reset();
  assert.equal(h.vfx.event('static_field_discharge', {position: player}), false); assert.deepEqual(h.vfx.inspect(), after);
});

test('invalid construction tuning fails early', () => {
  assert.throws(() => createSkillVfx(THREE), /requires/);
  const h = harness(); assert.throws(() => createSkillVfx(THREE, {...h, rRadius: NaN}), /tuning/); h.vfx.dispose();
});
