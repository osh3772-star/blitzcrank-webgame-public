import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {createHash} from 'node:crypto';
import {validateSkillAsset} from '../skill-animation.js';import {validateSkillAsset as baseline} from './fixtures/skill-animation-v0.24.54-baseline.js';import {SKILL_ASSET} from '../skill-animation-manifest.js';
const pose=()=>({p:[0,0,0],q:[0,0,0,1],s:[1,1,1]});const model=()=>({sourceParts:['a'],clips:[{name:'test',loop:false,fps:1,duration:1,events:[{type:'impact',time:.5}],frames:[{poses:[pose()]},{poses:[pose()]}]}]});const data=()=>({version:1,models:{viewmodel:model(),fullbody:model()}});
let comparisons=0;function outcome(fn,d,e){try{return {value:fn(d,e)===d};}catch(error){return {name:error.name,message:error.message};}}function same(d,e){assert.deepEqual(outcome(validateSkillAsset,d,e),outcome(baseline,d,e));comparisons++;}
test('actual asset and aliased bot model remain completely validated without mutation',()=>{
 const d=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))),hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex'),before=hash(d);same(d);assert.equal(hash(d),before);
 const shared={version:1,models:{viewmodel:d.models.fullbody,fullbody:d.models.fullbody}};same(shared);same(shared,{viewmodel:d.models.fullbody.sourceParts,fullbody:['wrong']});assert.equal(hash(d),before);
});
test('malformed versions, model/schema/timeline/event failures match frozen v54',()=>{
 for(const d of [null,undefined,{}, {version:2}, {version:1,models:{}}, {version:1,models:{viewmodel:null,fullbody:null}}])same(d);
 const mutate=[d=>d.models.viewmodel.sourceParts=[],d=>d.models.viewmodel.sourceParts=['a','a'],d=>d.models.viewmodel.sourceParts=[1],d=>d.models.viewmodel.sourceParts=[''],d=>d.models.viewmodel.clips=[],d=>d.models.viewmodel.clips=null,
 d=>d.models.viewmodel.clips[0].name=1,d=>d.models.viewmodel.clips.push(d.models.viewmodel.clips[0]),d=>d.models.viewmodel.clips[0].loop=1,d=>d.models.viewmodel.clips[0].fps=0,d=>d.models.viewmodel.clips[0].fps=121,d=>d.models.viewmodel.clips[0].duration=NaN,d=>d.models.viewmodel.clips[0].duration=2,d=>d.models.viewmodel.clips[0].frames=[],d=>d.models.viewmodel.clips[0].frames[0].poses=[],d=>d.models.viewmodel.clips[0].frames[0].poses=null,
 d=>d.models.viewmodel.clips[0].events={},d=>d.models.viewmodel.clips[0].events[0].type='',d=>d.models.viewmodel.clips[0].events[0].time=Infinity,d=>d.models.viewmodel.clips[0].events[0].time=-1,d=>d.models.viewmodel.clips[0].events[0].time=2];
 for(const fn of mutate){const d=data();fn(d);same(d);}same(data(),{viewmodel:['wrong']});same(data(),{fullbody:['wrong']});
});
test('every malformed transform component and quaternion/scale limit has identical rejection',()=>{
 for(const key of ['p','q','s'])for(const v of [undefined,null,{},new Float32Array([1,2,3]),[],[1],['1',0,0],[NaN,0,0],[Infinity,0,0],[-Infinity,0,0]]){const d=data();d.models.viewmodel.clips[0].frames[0].poses[0][key]=v;same(d);}
 for(const change of [p=>p.q=[0,0,0,0],p=>p.q=[0,0,0,1.006],p=>p.q=[0,0,0,.994],p=>p.q=[0,0,0,1.004],p=>p.s=[0,1,1],p=>p.s=[-1,1,1],p=>p.s=[Number.MIN_VALUE,1,1],p=>p.q=[0,0,NaN,1],p=>p.q=[0,0,Infinity,1]]){const d=data();change(d.models.viewmodel.clips[0].frames[0].poses[0]);same(d);}
 for(const v of [null,undefined]){const d=data();d.models.viewmodel.clips[0].frames[0].poses[0]=v;same(d);}
});
test('mutation between successful calls is still rejected; no validation cache exists',()=>{
 const d=data();same(d);d.models.fullbody.clips[0].frames[1].poses[0].p[2]=Infinity;same(d);assert.throws(()=>validateSkillAsset(d),/Invalid skill transform/);d.models.fullbody.clips[0].frames[1].poses[0].p[2]=0;same(d);
});
test('property access and short-circuit order are unchanged, including getters',()=>{
 for(const bad of [null,'p','q','s','norm']){const run=fn=>{const d=data(),trace=[],values=pose();if(bad==='norm')values.q=[0,0,0,0];else if(bad)values[bad]=null;const p={};for(const key of ['p','q','s'])Object.defineProperty(p,key,{get(){trace.push(key);return values[key];}});d.models.viewmodel.clips[0].frames[0].poses[0]=p;return {result:outcome(fn,d),trace};};assert.deepEqual(run(validateSkillAsset),run(baseline));comparisons++;}
});
test('scale-structure failure precedence and existing sparse-array semantics stay unchanged',()=>{
 const d=data(),p=d.models.viewmodel.clips[0].frames[0].poses[0];p.q=[0,0,0,0];p.s=null;same(d);assert.throws(()=>validateSkillAsset(d),/^Error: Invalid skill transform$/);
 for(const key of ['p','q','s']){const d=data();d.models.fullbody.clips[0].frames[1].poses[0][key]=new Array(key==='q'?4:3);same(d);}
});
test('validator removes four descriptor iterator calls per pose while retaining all checks',()=>{
 const measure=fn=>{const original=Array.prototype[Symbol.iterator];let calls=0;Array.prototype[Symbol.iterator]=function(){calls++;return original.call(this);};try{fn(data());}finally{Array.prototype[Symbol.iterator]=original;}return calls;};
 const old=measure(baseline),current=measure(validateSkillAsset);assert.equal(old-current,4*4);console.log('VALIDATOR_ITERATOR_CALLS '+old+' -> '+current);
});
test('schema equivalence count recorded',()=>{console.log('SKILL_VALIDATION_EQUIVALENT_CASES '+comparisons);assert(comparisons>=70);});
