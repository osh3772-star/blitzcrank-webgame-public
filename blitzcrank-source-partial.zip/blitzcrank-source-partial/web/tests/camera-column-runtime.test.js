import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

// Actual main.js and Three scene geometry. DOM/renderer are mocked; no GPU,
// browser pixels, physical input, or device frame-rate claims are made.
const root=process.env.CAMERA_TEST_APP_ROOT||fileURLToPath(new URL('../',import.meta.url));
const THREE=await import(pathToFileURL(path.join(root,'vendor/three.module.js')));
const {createGameplayHarness}=await import(pathToFileURL(path.join(root,'tests/helpers/runtime-harness.js')));
const {thirdPersonCameraPosition,rayBox}=await import(pathToFileURL(path.join(root,'core.js')));
const scratch=process.env.CAMERA_TEST_TMP_DIR||fs.mkdtempSync(path.join(os.tmpdir(),'camera-column-test-'));
const sourcePath=path.join(scratch,'camera-column-runtime-source.mjs');
fs.writeFileSync(sourcePath,fs.readFileSync(process.env.SOURCE_PATH||path.join(root,'main.js'),'utf8')+'\nwindow.__CAMERA_COLUMN_TEST__={syncCamera,resize,collides,arenaObstacles,nearestRay};');
let h;try{h=await createGameplayHarness({sourcePath,delta:()=>1/120});}finally{fs.unlinkSync(sourcePath);}
const a=globalThis.__CAMERA_COLUMN_TEST__,d=h.game.data;
d.scene.updateMatrixWorld(true);
const pillars=d.scene.children.filter(o=>o.isMesh&&o.geometry.type==='BoxGeometry'&&Math.abs(o.position.x)===24&&o.geometry.parameters.height===11).map(mesh=>({mesh,box:new THREE.Box3().setFromObject(mesh)}));
const sizes=[[1280,720],[390,844],[320,932]];
const near=(a,b,e=1e-9)=>assert(Math.abs(a-b)<=e,`${a} != ${b}`);
const vector=v=>new THREE.Vector3(v.x,v.y,v.z);
function viewport(w,h){globalThis.innerWidth=w;globalThis.innerHeight=h;a.resize();}
function fresh(third=true,duel=false){h.game.begin(true,false,duel);if((h.qa.view==='third')!==third)h.element('viewtoggle').onclick();assert.equal(h.qa.view,third?'third':'first');}
function pose(player,yaw=0,pitch=0){d.player.copy(player);h.game.aim((h.qa.player.yaw-yaw)/.0021,(h.qa.player.pitch-pitch)/.0021);a.syncCamera();d.camera.updateMatrixWorld(true);}
function snapshotObstacles(){return a.arenaObstacles().map(o=>({min:o.min.toArray(),max:o.max.toArray(),arenaSurface:!!o.arenaSurface,mirrorSurface:!!o.mirrorSurface,turretId:o.turretId??null}));}
function corners(){return [new THREE.Vector3(-1,-1,-1),new THREE.Vector3(1,-1,-1),new THREE.Vector3(1,1,-1),new THREE.Vector3(-1,1,-1)].map(p=>p.unproject(d.camera));}
function nearPlaneIntersects(box){const p=corners();return box.intersectsTriangle(new THREE.Triangle(p[0],p[1],p[2]))||box.intersectsTriangle(new THREE.Triangle(p[0],p[2],p[3]));}
function scenario(pillar,edge=false){
 const sign=Math.sign(pillar.mesh.position.x),z=pillar.mesh.position.z;
 const yaw=sign>0?(z===-44?2:0):(z===11?Math.PI+.1:Math.PI);
 const center=pillar.mesh.position.clone();center.y=2.5;
 if(edge)center.x+=sign>0&&z===-44?.32:-sign*.32;
 const offset=new THREE.Vector3(.9,.8,4.6).applyEuler(new THREE.Euler(0,yaw,0,'YXZ'));
 return{player:center.clone().sub(offset),yaw,desiredCamera:center};
}
const expectedObstacles=[{"min":[-26,-0.32999999999999996,-48],"max":[26,-0.03,22],"arenaSurface":true,"mirrorSurface":false,"turretId":null},{"min":[-26.5,-0.20000000000000018,-45.5],"max":[-25.5,8.8,19.5],"arenaSurface":true,"mirrorSurface":false,"turretId":null},{"min":[25.5,-0.20000000000000018,-45.5],"max":[26.5,8.8,19.5],"arenaSurface":true,"mirrorSurface":false,"turretId":null},{"min":[-26,-0.5,-46.5],"max":[26,12.5,-45.5],"arenaSurface":true,"mirrorSurface":false,"turretId":null},{"min":[-10.5,0,-9.5],"max":[-7.5,2.8,-6.5],"arenaSurface":false,"mirrorSurface":false,"turretId":null},{"min":[7,0,-15.5],"max":[11,3.2,-12.5],"arenaSurface":false,"mirrorSurface":false,"turretId":null},{"min":[-7.5,0,-26.5],"max":[-4.5,3.4,-23.5],"arenaSurface":false,"mirrorSurface":false,"turretId":null},{"min":[14,0,-31],"max":[18,4,-27],"arenaSurface":false,"mirrorSurface":false,"turretId":null},{"min":[-20.5,0,-36],"max":[-15.5,3,-32],"arenaSurface":false,"mirrorSurface":false,"turretId":null},{"min":[-4.5,0.25,-45.17],"max":[4.5,7.25,-45.05],"arenaSurface":false,"mirrorSurface":true,"turretId":null},{"min":[-13.05319546165509,-4.440892098500626e-16,-19.05319546165509],"max":[-10.638441995414238,4.8,-16.946804489894056],"arenaSurface":false,"mirrorSurface":false,"turretId":"west"},{"min":[10.94680453834491,-4.440892098500626e-16,-30.05319546165509],"max":[13.361558004585762,4.8,-27.946804489894056],"arenaSurface":false,"mirrorSurface":false,"turretId":"east"}];

test('all 12 unchanged visible side columns are present; gameplay obstacle lists remain exact',()=>{
 assert.equal(pillars.length,12);
 assert.deepEqual(pillars.map(p=>[p.mesh.position.x,p.mesh.position.z]).sort(),[-24,24].flatMap(x=>[11,0,-11,-22,-33,-44].map(z=>[x,z])).sort());
 for(const {mesh,box} of pillars){assert.deepEqual(mesh.geometry.parameters,{width:.6,height:11,depth:.8,widthSegments:1,heightSegments:1,depthSegments:1});near(box.min.y,-.2,1e-6);near(box.max.y,10.8,1e-6);assert.equal(mesh.material.side,THREE.FrontSide);}
 fresh();assert.deepEqual(snapshotObstacles(),expectedObstacles);
 fresh(true,true);assert.deepEqual(snapshotObstacles(),expectedObstacles.filter(o=>!o.turretId));
 fresh();assert.deepEqual(snapshotObstacles(),expectedObstacles);
});

test('actual camera boom and complete near plane clear all 12 columns in landscape and portrait',()=>{
 for(const duel of [false,true])for(const size of sizes)for(const pillar of pillars){
  fresh(true,duel);viewport(...size);const s=scenario(pillar);assert.equal(a.collides(s.player.x,s.player.z),false,'scenario player must be legal');pose(s.player,s.yaw);
  assert(!pillar.box.containsPoint(d.camera.position),`${size} column ${pillar.mesh.position.toArray()} contains camera`);
  assert(!nearPlaneIntersects(pillar.box),`${size} column near plane intersects`);
  const offset=d.camera.position.clone().sub(d.player),expanded=pillar.box.clone().expandByScalar(.18);
  assert.equal(rayBox(d.player,offset.clone().normalize(),expanded.min,expanded.max,offset.length()),null,'entire boom stops before column radius');
  assert(offset.length()<s.desiredCamera.distanceTo(s.player)-.1,'boom must shorten rather than rotate camera');
  assert(offset.clone().cross(s.desiredCamera.clone().sub(s.player)).length()<1e-9);
  near(d.camera.rotation.y,s.yaw);near(d.camera.rotation.x,0);
 }
});

test('point-clear but near-plane-clipping poses are protected for all columns and viewport sizes',()=>{
 for(const size of sizes)for(const pillar of pillars){
  fresh();viewport(...size);const s=scenario(pillar,true);assert.equal(a.collides(s.player.x,s.player.z),false);pose(s.player,s.yaw);
  const actual=d.camera.position.clone();d.camera.position.copy(s.desiredCamera);d.camera.updateMatrixWorld(true);
  assert(!pillar.box.containsPoint(d.camera.position),'legacy camera point is outside');
  assert(nearPlaneIntersects(pillar.box),'legacy near plane intersects actual visible geometry');
  d.camera.position.copy(actual);d.camera.updateMatrixWorld(true);
  assert(!nearPlaneIntersects(pillar.box),`${size} column ${pillar.mesh.position.toArray()} still clips its near plane`);
 }
});

test('ordinary clear-space framing, optics and first-person eye/aim remain unchanged',()=>{
 for(const size of sizes)for(const pitch of [-1.15,-.3,0,.3,.5]){
  fresh();viewport(...size);pose(new THREE.Vector3(0,1.7,7),.15,pitch);
  const expected=thirdPersonCameraPosition(d.player,.15,pitch,a.arenaObstacles());
  assert(d.camera.position.distanceTo(vector(expected))<1e-10);
  const expectedFov=size[0]<size[1]?Math.max(64,Math.min(120,THREE.MathUtils.radToDeg(2*Math.atan(Math.tan(Math.PI/6)/(size[0]/size[1]))))):64;
  near(d.camera.fov,expectedFov);
  const direction=d.camera.getWorldDirection(new THREE.Vector3());h.key('KeyV');
  assert.equal(h.qa.view,'first');assert(d.camera.position.distanceTo(d.player)<1e-12);assert.equal(d.camera.fov,64);
  assert(d.camera.getWorldDirection(new THREE.Vector3()).distanceTo(direction)<1e-12);
 }
 for(const pillar of pillars){fresh(false);const s=scenario(pillar);pose(s.player,s.yaw);assert(d.camera.position.distanceTo(d.player)<1e-12);}
});

test('paused first/third view toggles and portrait resizes immediately preserve column clearance without advancing time',()=>{
 for(const duel of [false,true])for(const pillar of pillars){
  fresh(false,duel);const s=scenario(pillar);pose(s.player,s.yaw);h.game.pause();const elapsed=h.qa.session.elapsed,player=d.player.clone();
  for(const size of sizes){viewport(...size);h.element('viewtoggle').onclick();d.camera.updateMatrixWorld(true);assert.equal(h.qa.view,'third');assert(!nearPlaneIntersects(pillar.box));const point=d.camera.position.clone();viewport(size[1],size[0]);d.camera.updateMatrixWorld(true);assert(d.camera.position.distanceTo(point)<1e-12);assert(!nearPlaneIntersects(pillar.box));h.element('viewtoggle').onclick();assert(d.camera.position.distanceTo(player)<1e-12);h.frames(3);assert.equal(h.qa.state,'paused');assert.equal(h.qa.session.elapsed,elapsed);assert(d.player.distanceTo(player)<1e-12);}
 }
});

test('walking from spawn remains identical while third-person camera avoids the reachable column',()=>{
 fresh();viewport(390,844);h.key('KeyD');h.frames(427);h.release('KeyD');h.key('KeyW');h.frames(12);h.release('KeyW');
 near(d.player.x,22.773333333333426);near(d.player.z,6.359999999999996);
 const pillar=pillars.find(p=>p.mesh.position.x===24&&p.mesh.position.z===11);d.camera.updateMatrixWorld(true);assert(!nearPlaneIntersects(pillar.box));
 h.key('KeyD');h.frames(6);h.release('KeyD');near(d.player.x,23.093333333333433);d.camera.updateMatrixWorld(true);assert(!pillar.box.containsPoint(d.camera.position));assert(!nearPlaneIntersects(pillar.box));
 for(const p of pillars){const z=Math.max(-42.5,p.mesh.position.z);assert.equal(a.collides(Math.sign(p.mesh.position.x)*23.35,z),false,'camera-only column must not alter player collision');}
});

test('camera-only columns do not change existing skill or hook-ray obstruction rules',()=>{
 fresh(false);viewport(1280,720);for(const target of d.targets){target.active=false;target.group.visible=false;target.respawn=Infinity;}
 for(const pillar of pillars){const origin=pillar.mesh.position.clone().add(new THREE.Vector3(-1,0,0)),direction=new THREE.Vector3(1,0,0);origin.y=1.7;const ray=a.nearestRay(origin,direction,2);assert.equal(ray.distance,2);assert.equal(ray.blocked,false);assert.equal(ray.target,null);}
 const target=d.targets[0];target.active=true;target.group.visible=true;target.captured=false;target.anchor.set(24.5,1.7,11);target.group.position.copy(target.anchor);target.amplitude=target.speed=0;
 pose(new THREE.Vector3(23.35,1.7,11),-Math.PI/2);h.game.castR();h.frames(40);
 assert.equal(h.qa.skills.metrics.pulseHits,1,'existing R must retain target visibility through decorative column');assert.equal(target.active,false);
 assert.deepEqual(snapshotObstacles(),expectedObstacles);
});
