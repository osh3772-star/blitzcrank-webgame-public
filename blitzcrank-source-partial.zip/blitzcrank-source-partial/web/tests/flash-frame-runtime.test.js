import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const h=await createGameplayHarness();
function fresh(){h.game.begin(true);h.frames(1);}
test('accepted actual G cast starts selected departure pixels at the old player location',()=>{
 fresh();const before=h.qa.player;h.key('KeyF');assert.equal(h.qa.flashFrames.active,true);assert.equal(h.qa.flashFrames.sourceFrame,26);assert.equal(h.qa.flashFrames.position[0],before.x);assert.equal(h.qa.flashFrames.position[2],before.z);assert.equal(h.qa.flashFrames.arrival,false);assert.equal(h.qa.flashFrames.audio,false);assert(Math.abs(h.qa.player.z-(before.z-4))<1e-6);assert.match(h.element('hitnotice').textContent,/출발 영상/);
});
test('moving after blink never drags the captured departure sprite with the player',()=>{
 fresh();h.key('KeyF');const origin=h.qa.flashFrames.position;h.key('KeyD');h.frames(10);h.release('KeyD');assert.deepEqual(h.qa.flashFrames.position,origin);assert(h.qa.player.x!==origin[0]);assert.equal(h.qa.flashFrames.sourceFrame,27);
});
test('pause and capture loss freeze the real frame cursor without restarting or fading it',()=>{
 fresh();h.key('KeyF');h.frames(8);h.game.pause();const frozen=h.qa.flashFrames;h.frames(100);assert.deepEqual(h.qa.flashFrames,frozen);h.game.resume();h.frames(8);assert(h.qa.flashFrames.sourceFrame>frozen.sourceFrame);document.pointerLockElement=null;const waiting=h.qa.flashFrames;h.frames(50);assert.deepEqual(h.qa.flashFrames,waiting);
});
test('rejected cooldown input does not replay the sprite and expiry leaves no lasting effect',()=>{
 fresh();h.key('KeyF');h.frames(13);const before=h.qa.flashFrames;h.key('KeyF');assert.deepEqual(h.qa.flashFrames,before);h.frames(30);assert.equal(h.qa.flashFrames.active,false);assert.equal(h.qa.flashFrames.frame,-1);assert.equal(h.qa.flashAbility.casts,1);
});
test('restart, menu, defeat and result states remove the pending frame effect immediately',()=>{
 for(const end of [()=>h.game.begin(true),()=>h.game.finish(),()=>h.game.damagePlayer(100),()=>{h.game.pause();h.element('mainmenu').onclick();}]){fresh();h.key('KeyF');assert(h.qa.flashFrames.active);end();assert.equal(h.qa.flashFrames.active,false);h.frames(10);assert.equal(h.qa.flashFrames.active,false);}
});
