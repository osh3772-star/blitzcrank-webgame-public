import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {createPlayerSocketHarness} from './helpers/player-socket-harness.js';
const h=await createPlayerSocketHarness(), names=Object.keys(h.sockets.current), coverage=new Map();let comparisons=0;
function key(code){h.key(code);h.release(code);}
function fresh(third=false){h.game.begin(true);if((h.qa.view==='third')!==third)key('KeyV');for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}h.frames(1);}
function compareAll(){for(const name of names){const current=h.sockets.current[name]().toArray(),expected=h.sockets.legacy[name]().toArray();assert.deepEqual(current,expected,`${name} / ${h.qa.view} / ${h.qa.hook?.phase}`);assert(current.every(Number.isFinite));comparisons++;}const phase=h.qa.hook?.phase||'idle';coverage.set(phase,(coverage.get(phase)||0)+1);}
function mirror(){
 const d=h.sockets.data,saved={body:d.fullbody.visible,fist:d.fist.visible,start:d.rope.userData.start?.toArray(),end:d.rope.userData.end?.toArray(),count:d.rope.links.count,instances:d.rope.links.instanceMatrix.array.slice(0,d.rope.links.count*16)};
 const token=h.sockets.prepareMirrorBody();
 assert.equal(d.fullbody.visible,true);assert.equal(d.fist.visible,false);
 if(token.chain){assert.deepEqual(d.rope.userData.start.toArray(),h.sockets.legacy.fullbodyCableSocket().toArray());assert.deepEqual(d.rope.userData.end.toArray(),h.sockets.legacy.fullbodyChainSocket().toArray());}
 h.sockets.restoreMirrorBody(token);
 assert.equal(d.fullbody.visible,saved.body);assert.equal(d.fist.visible,saved.fist);assert.equal(d.rope.links.count,saved.count);
 assert.deepEqual(d.rope.userData.start?.toArray(),saved.start);assert.deepEqual(d.rope.userData.end?.toArray(),saved.end);
 assert.deepEqual(d.rope.links.instanceMatrix.array.slice(0,d.rope.links.count*16),saved.instances);
}
test('player socket getters do not visit unrelated or VFX descendants', t=>{
 fresh(true);key('KeyQ');h.frames(22);
 const root=h.sockets.data.fullbody,extra=new THREE.Group();root.add(extra);for(let i=0;i<200;i++)extra.add(new THREE.Group());
 const count=fn=>{let rootPasses=0,nodeVisits=0;const prior=THREE.Object3D.prototype.updateMatrixWorld;
  THREE.Object3D.prototype.updateMatrixWorld=function(...args){nodeVisits++;if(this===root)rootPasses++;return prior.apply(this,args);};
  let result;try{result=fn().toArray();}finally{THREE.Object3D.prototype.updateMatrixWorld=prior;}return{rootPasses,nodeVisits,result};
 };
 try {for(const name of names){const current=count(h.sockets.current[name]),legacy=count(h.sockets.legacy[name]);assert.deepEqual(current.result,legacy.result);assert.equal(current.rootPasses,0,name);assert.equal(current.nodeVisits,0,name);assert.equal(legacy.rootPasses,1,name);assert(legacy.nodeVisits>=779,name);}}finally{extra.removeFromParent();}
 t.diagnostic('All four player socket queries avoid a 578-node full-body traversal, including 201 injected descendants.');
});
test('all Q phases, walking, turning, jumping and view changes preserve exact legacy socket positions',()=>{
 for(const third of [false,true]){fresh(third);compareAll();key('KeyQ');h.key('KeyD');key('Space');
  for(let i=0;i<165;i++){if(i===40)h.release('KeyD');if(i===27||i===78)key('KeyV');h.sockets.aim(i<60?.3:0,i<60?.02:0);h.frames(1);compareAll();mirror();}
  assert.equal(h.qa.hook,null);
 }
 for(const phase of ['idle','windup','outbound','return','recover'])assert(coverage.get(phase)>0,phase);
});
test('W/E/R authored poses and Q interruptions retain exact player and mirror sockets',()=>{
 for(const third of [false,true]){fresh(third);key('KeyE');h.frames(50);compareAll();key('KeyQ');h.key('KeyW');
  for(let i=0;i<160;i++){h.frames(1);compareAll();if(i%5===0)mirror();}h.release('KeyW');h.punch();h.frames(50);key('ShiftLeft');
  for(let i=0;i<60;i++){h.frames(1);compareAll();}key('KeyR');for(let i=0;i<70;i++){h.frames(1);compareAll();}
 }
});
test('ancestor and root transform mutations remain exact without caller-side matrix refresh',()=>{
 fresh(true);key('KeyQ');h.frames(25);const {scene,fullbody}=h.sockets.data;
 for(let i=0;i<20;i++){
  scene.position.set(.1*i,-.2,.4);scene.rotation.set(.02*i,.1,-.03);scene.scale.setScalar(1.2);
  fullbody.position.x+=.07;fullbody.rotation.y+=.04;fullbody.scale.multiplyScalar(1.001);compareAll();
 }
 scene.position.set(0,0,0);scene.rotation.set(0,0,0);scene.scale.setScalar(1);fullbody.scale.setScalar(.78);fresh(false);
});
test('paused view changes, restart and menu restore sockets and visible-chain ownership',()=>{
 for(const third of [false,true]){fresh(third);key('KeyQ');h.frames(25);h.game.pause();const before=h.sockets.data.hook.position.toArray();key('KeyV');h.frames(20);assert.deepEqual(h.sockets.data.hook.position.toArray(),before);compareAll();mirror();h.game.resume();h.frames(150);compareAll();fresh(third);assert.equal(h.qa.hook,null);compareAll();h.game.pause();h.element('mainmenu').click();assert.equal(h.sockets.data.rope.visible,false);}
});
test('actual duel human Q keeps independent bot sockets and chains through score and round reset',()=>{
 h.element('duelmode').click();h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,jump:false})});h.frames(150);h.game.data.duelBot.position.set(0,1.7,1);key('KeyV');key('KeyQ');
 for(let i=0;i<260;i++){h.frames(1);compareAll();if(h.sockets.data.rope.visible)mirror();}
 assert.equal(h.qa.duel.match.history.length,1);assert.equal(h.qa.duel.match.history[0].winnerId,'human');assert.equal(h.qa.duel.match.roundNumber,2);
});
test('comparison coverage is reported without implying GPU or browser validation',t=>{
 assert(comparisons>4000);t.diagnostic(`${comparisons} exact vector comparisons. Phase samples: ${JSON.stringify(Object.fromEntries(coverage))}. Actual Three CPU with mock DOM/no-op renderer only.`);
});
