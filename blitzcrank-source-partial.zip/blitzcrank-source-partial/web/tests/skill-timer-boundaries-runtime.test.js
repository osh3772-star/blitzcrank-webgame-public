import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
let dt=1/60;const h=await createGameplayHarness({delta:()=>dt});let failures=0,checks=0;
function check(ok,label){checks++;if(!ok)failures++;const detail=JSON.stringify({skills:h.qa.skills,hud:['W','E','R'].map(k=>[k,h.element('skillstate'+k).textContent,h.element('skill'+k).attributes['aria-disabled']])});test(label,()=>assert.ok(ok,detail));}
function fresh(hz){dt=1/hz;h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}}
for(const hz of [30,60,120]){
 // Exercise W and R simultaneously, then E in its own exact 5s clock.
 fresh(hz);h.key('ShiftLeft');h.release('ShiftLeft');h.key('KeyR');h.release('KeyR');h.frames(4*hz);
 check(h.qa.skills.moveMultiplier===.65&&h.element('skillstateW').textContent==='SLOW 2.0s','main W transition '+hz);
 h.frames(2*hz);check(h.qa.skills.moveMultiplier===1&&!h.element('skillstateW').textContent.startsWith('SLOW'),'main W slow expiry '+hz);
 h.frames(6*hz);for(const k of ['W','R'])check(h.element('skillstate'+k).textContent==='READY'&&h.element('skill'+k).attributes['aria-disabled']==='false','main ready HUD '+k+' '+hz);
 h.key('ShiftLeft');h.release('ShiftLeft');h.key('KeyR');h.release('KeyR');check(h.qa.skills.boost===4&&h.qa.skills.cooldown.R===12,'main W/R input recast '+hz);
 fresh(hz);h.key('KeyE');h.release('KeyE');h.frames(hz);h.punch();h.frames(4*hz);check(h.element('skillstateE').textContent==='READY'&&h.element('skillE').attributes['aria-disabled']==='false','main E ready '+hz);h.key('KeyE');h.release('KeyE');check(h.qa.skills.phase==='E_Charge','main E input recast '+hz);
}
console.log(JSON.stringify({checks,failures}));process.exitCode=failures?1:0;
