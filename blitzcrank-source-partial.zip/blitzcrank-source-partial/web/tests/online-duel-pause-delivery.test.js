import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createOnlineDuelWorld} from '../online-duel-world.js';
import {createOnlineSession} from '../online-duel-session.js';
import {makeInput,ONLINE_ACTIONS as A} from '../online-duel-protocol.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';
const skillClips=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))).models.fullbody.clips;
const session='online_pause_delivery_fixture_1';
function fixture({sync=false}={}){
 const world=createOnlineDuelWorld({session,skillClips,countdownMs:0}),toHost=[],toGuest=[],states=[],statuses=[],attempts=[];
 let failGuest=false,failHost=false,host,guest;
 const encode=v=>JSON.stringify(v);
 host=createOnlineSession({role:'host',session,world,send:v=>{if(failHost)return false;if(sync)guest.receiveText(encode(v));else toGuest.push(encode(v));return true;}});
 guest=createOnlineSession({role:'guest',session,send:v=>{attempts.push(structuredClone(v));if(failGuest)return false;if(sync)host.receiveText(encode(v));else toHost.push(encode(v));return true;},onState:s=>states.push(s),onStatus:s=>statuses.push(s)});
 function drain(){let count=0;while(toHost.length||toGuest.length){assert(count++<100,'bounded queue');while(toHost.length)host.receiveText(toHost.shift());while(toGuest.length)guest.receiveText(toGuest.shift());}}
 function step(n=1){for(let i=0;i<n;i++){host.step();drain();}}
 host.ready(true);drain();guest.ready(true);drain();
 return {world,host,guest,states,statuses,attempts,drain,step,toHost,toGuest,failGuest:v=>failGuest=v,failHost:v=>failHost=v};
}
function finish(f){let seq=0;for(let round=0;round<3;round++){for(let i=0;i<120;i++){assert(f.host.input(makeInput({...f.world.scope,seq:seq++,z:-1})));f.step();}assert(f.host.input(makeInput({...f.world.scope,seq:seq++,actions:A.R})));for(let i=0;i<60&&f.world.snapshot().match.history.length<=round;i++)f.step();if(round<2)f.step(180);}f.step(180);assert(f.world.snapshot().resultReady);}
function resume(f){assert(f.host.ready(true));f.drain();assert(f.guest.ready(true));f.drain();assert(!f.world.snapshot().paused);}
for(const pause of ['interrupt','ready'])test(`failed guest ${pause} is retried on incoming state instead of being silently lost`,()=>{
 const f=fixture();const before=f.world.snapshot();f.failGuest(true);if(pause==='interrupt')f.guest.interrupt('buffer blocked');else assert(!f.guest.ready(false));assert(!f.world.snapshot().paused,'pause could not yet be delivered');
 f.failGuest(false);f.step();assert(f.world.snapshot().paused,'next host state must retry the unsent pause');const paused=f.world.snapshot();f.step(500);assert.deepEqual(f.world.snapshot(),paused);assert.deepEqual(paused.match.scores,before.match.scores);assert(paused.epoch>before.epoch);resume(f);f.step();assert.equal(f.world.snapshot().tick,paused.tick+1);
});
test('a pending unsent pause blocks subsequent input, readiness and rematch until delivered',()=>{
 const f=fixture();f.failGuest(true);f.guest.interrupt();const count=f.attempts.length;f.failGuest(false);
 assert(!f.guest.input(makeInput({...f.world.scope,seq:50,actions:A.R})));assert(!f.guest.ready(true));assert(!f.guest.rematch());assert.equal(f.attempts.length,count,'no action or resume may overtake the pending pause');
 f.step();assert(f.world.snapshot().paused);resume(f);f.step(30);assert.equal(f.world.snapshot().actors.bot.skills.cooldown.R,0);
});
test('repeated failed retries remain bounded and do not automatically resume after delivery',()=>{
 const f=fixture();f.failGuest(true);f.guest.interrupt();for(let i=0;i<25;i++)f.step();assert(f.attempts.length<=28);assert(!f.world.snapshot().paused);
 f.failGuest(false);f.step();const count=f.attempts.length;assert(f.world.snapshot().paused);f.step(50);assert.equal(f.attempts.length,count,'a successfully queued reliable pause is not resent forever');
 assert(f.host.ready(true));f.drain();f.step();assert(f.world.snapshot().paused,'remote explicit consent is still required');
});
test('disconnect cancels the pending pause and late host snapshots cannot flush it',()=>{
 const f=fixture();f.failGuest(true);f.guest.interrupt();const count=f.attempts.length;f.guest.disconnect();f.failGuest(false);for(let i=0;i<10;i++)f.step();assert.equal(f.attempts.length,count);assert(f.guest.snapshot.closed);assert(!f.guest.ready(true));
});
test('synchronous delivery cannot recursively publish the same pending pause',()=>{
 const f=fixture({sync:true});f.failGuest(true);f.guest.interrupt();f.failGuest(false);f.step();assert(f.world.snapshot().paused);assert(f.guest.snapshot.paused);assert.equal(f.attempts.filter(x=>x.type==='ready'&&!x.ready).length,2);resume(f);f.step(3);assert(!f.world.snapshot().paused);
});
for(const first of ['host','guest'])test(`${first} rematch consent is withdrawn by an interruption and must be given again`,()=>{
 const f=fixture();finish(f);assert(f[first].rematch());f.drain();f.host.interrupt('focus lost');f.drain();resume(f);
 const second=first==='host'?'guest':'host';assert(f[second].rematch());f.drain();assert.equal(f.world.snapshot().match.winnerId,'human','old consent must not restart after a new epoch');
 assert(f[first].rematch());f.drain();assert.deepEqual(f.world.snapshot().match.scores.map(x=>x.points),[0,0]);
});
test('host publish backpressure also withdraws an earlier rematch vote',()=>{
 const f=fixture();finish(f);assert(f.host.rematch());f.failHost(true);assert(!f.host.step());assert(f.world.snapshot().paused);f.failHost(false);f.step();resume(f);assert(f.guest.rematch());f.drain();assert.equal(f.world.snapshot().match.winnerId,'human');assert(f.host.rematch());f.drain();assert.deepEqual(f.world.snapshot().match.scores.map(x=>x.points),[0,0]);
});
test('guest rematch cannot be offered while the authority is paused',()=>{
 const f=fixture();finish(f);f.host.interrupt();f.drain();assert(!f.guest.rematch());assert(!f.host.rematch());assert.equal(f.world.snapshot().match.winnerId,'human');
});
