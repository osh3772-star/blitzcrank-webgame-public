import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as THREE from '../vendor/three.module.js';
import { createTrainingMirror } from '../training-mirror.js';

function setup(options = {}, draw = () => {}) {
  const mirror = createTrainingMirror(THREE, options);
  mirror.updateMatrixWorld(true);
  const camera = new THREE.PerspectiveCamera(70, 16 / 9, 0.1, 300);
  camera.position.set(2, 1.7, -35);
  camera.lookAt(0, 3.75, -45.08);
  camera.updateMatrixWorld(true);
  const scene = new THREE.Scene();
  scene.add(mirror);
  const originalTarget = new THREE.WebGLRenderTarget(24, 16);
  const originalViewport = new THREE.Vector4(3, 4, 640, 360);
  const renderer = {
    xr: { enabled: true }, shadowMap: { autoUpdate: true }, autoClear: false,
    target: originalTarget, cubeFace: 2, mipLevel: 1,
    viewport: originalViewport.clone(), calls: [],
    getRenderTarget() { return this.target; },
    getActiveCubeFace() { return this.cubeFace; },
    getActiveMipmapLevel() { return this.mipLevel; },
    getViewport(out) { return out.copy(this.viewport); },
    setRenderTarget(target, cubeFace = 0, mipLevel = 0) {
      this.target = target; this.cubeFace = cubeFace; this.mipLevel = mipLevel;
      this.viewport.set(0, 0, target?.width ?? 800, target?.height ?? 600);
    },
    clear() { this.calls.push('clear'); },
    render(scene, reflectedCamera) {
      this.calls.push('render');
      assert.equal(mirror.visible, false);
      assert.equal(this.xr.enabled, false);
      assert.equal(this.shadowMap.autoUpdate, false);
      assert.equal(this.target, mirror.getRenderTarget());
      draw({ mirror, renderer: this, scene, camera: reflectedCamera });
    },
  };
  renderer.state = {
    buffers: { depth: { setMask(value) { assert.equal(value, true); } } },
    viewport(value) { renderer.viewport.copy(value); },
  };
  const run = () => mirror.onBeforeRender(renderer, scene, camera);
  const assertRestored = () => {
    assert.equal(mirror.visible, true);
    assert.equal(renderer.xr.enabled, true);
    assert.equal(renderer.shadowMap.autoUpdate, true);
    assert.equal(renderer.target, originalTarget);
    assert.equal(renderer.cubeFace, 2);
    assert.equal(renderer.mipLevel, 1);
    assert.deepEqual(renderer.viewport, originalViewport);
  };
  return { mirror, camera, scene, renderer, run, assertRestored };
}

test('official reflector is vendored verbatim except its local Three import', () => {
  const official = readFileSync(new URL('../node_modules/three/examples/jsm/objects/Reflector.js', import.meta.url), 'utf8');
  const vendored = readFileSync(new URL('../vendor/Reflector.js', import.meta.url), 'utf8');
  assert.equal(vendored, official.replace("from 'three';", "from './three.module.js';"));
});

test('mirror fits the backwall and uses bounded live render targets, no static image', () => {
  for (const isTouch of [false, true]) {
    const { mirror } = setup({ isTouch });
    assert.equal(mirror.isReflector, true);
    assert.equal(mirror.geometry.parameters.width, 9);
    assert.equal(mirror.geometry.parameters.height, 7);
    assert.deepEqual(mirror.position.toArray(), [0, 3.75, -45.08]);
    assert.deepEqual(mirror.rotation.toArray().slice(0, 3), [0, 0, 0]);
    const target = mirror.getRenderTarget();
    assert.equal(target.width, isTouch ? 512 : 1024);
    assert.equal(target.height, target.width);
    assert.equal(target.samples, 0);
    assert.equal(target.texture.type, THREE.UnsignedByteType);
    assert.equal(mirror.material.uniforms.tDiffuse.value, target.texture);
    assert.equal(target.texture.isRenderTargetTexture, true);
    assert.equal(target.texture.image.data, undefined);
    assert.match(mirror.material.fragmentShader, /texture2DProj\( tDiffuse/);
    mirror.dispose();
  }
});

test('reflects the real camera across the wall with finite projection and texture matrices', () => {
  const { mirror, camera, run, assertRestored } = setup();
  run();
  assert.equal(mirror.camera.position.x, camera.position.x);
  assert.ok(Math.abs(mirror.camera.position.y - camera.position.y) < 1e-10);
  assert.ok(Math.abs(mirror.camera.position.z - (2 * -45.08 - camera.position.z)) < 1e-10);
  assert.ok(mirror.camera.projectionMatrix.elements.every(Number.isFinite));
  assert.ok(mirror.material.uniforms.textureMatrix.value.elements.every(Number.isFinite));
  assert.notDeepEqual(mirror.camera.projectionMatrix.elements, camera.projectionMatrix.elements);
  assertRestored();
});

test('callbacks wrap the draw, transfer a token, and restore player visibility', () => {
  const events = [];
  const player = { fullbody: false, fist: true };
  const token = { ...player };
  const { run, assertRestored } = setup({
    beforeReflection() { events.push('before'); player.fullbody = true; player.fist = false; return token; },
    afterReflection(saved) { assert.equal(saved, token); events.push('after'); Object.assign(player, saved); },
  }, () => {
    events.push('draw');
    assert.deepEqual(player, { fullbody: true, fist: false });
  });
  run();
  assert.deepEqual(events, ['before', 'draw', 'after']);
  assert.deepEqual(player, token);
  assertRestored();
});

test('back-facing or invisible mirrors skip rendering and callbacks', () => {
  const { mirror, camera, renderer, run } = setup({ beforeReflection() { assert.fail('must skip callback'); } });
  camera.position.z = -50;
  camera.updateMatrixWorld(true);
  run();
  camera.position.z = -35;
  camera.updateMatrixWorld(true);
  mirror.visible = false;
  run();
  assert.deepEqual(renderer.calls, []);
  assert.equal(mirror.visible, false);
});

test('nested calls cannot double-render or run callbacks twice', () => {
  let before = 0, after = 0;
  const context = setup({ beforeReflection() { before++; }, afterReflection() { after++; } }, () => {
    context.mirror.visible = true; // Simulate another pass attempting reentry.
    context.run();
  });
  context.run();
  assert.equal(before, 1);
  assert.equal(after, 1);
  assert.equal(context.renderer.calls.filter(c => c === 'render').length, 1);
  context.assertRestored();
});

test('renderer failure still restores renderer and player, preserving original error', () => {
  const failure = new Error('draw failed');
  let playerVisible = false;
  const { run, assertRestored } = setup({
    beforeReflection() { const old = playerVisible; playerVisible = true; return old; },
    afterReflection(old) { playerVisible = old; },
  }, () => { throw failure; });
  assert.throws(run, error => error === failure);
  assert.equal(playerVisible, false);
  assertRestored();
});

test('before callback failure still invokes after and clears recursion guard', () => {
  let beforeCount = 0, afterCount = 0;
  const failure = new Error('prepare failed');
  const { run, assertRestored } = setup({
    beforeReflection() { if (++beforeCount === 1) throw failure; return 'ok'; },
    afterReflection(token) { afterCount++; assert.equal(token, afterCount === 1 ? undefined : 'ok'); },
  });
  assert.throws(run, error => error === failure);
  assertRestored();
  run();
  assert.equal(afterCount, 2);
  assertRestored();
});
