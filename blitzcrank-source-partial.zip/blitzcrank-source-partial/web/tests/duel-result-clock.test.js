import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const sourcePath=new URL('../main.js',import.meta.url);
const quiet=r=>r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});
function until(r,predicate){for(let i=0;i<500&&!predicate();i++)r.frames(1);assert(predicate());}
async function start(delta){const r=await createGameplayHarness({sourcePath,delta});r.element('duelmode').click();quiet(r);until(r,()=>r.qa.duel.active);return r;}
function score(r,skill='Q',winner='human'){
 const d=r.game.data,old=d.duel.state.history.length;d.duelBot.position.set(0,1.7,5);
 if(skill==='Q'){if(winner==='human')r.key('KeyQ');else assert(d.duel.cast('bot'));until(r,()=>!!d.duel.pendingGrab);assert.equal(d.duel.state.history.length,old);assert.equal(d.duel.active,false);}
 if(skill==='E'){const s=d.duel.getSkills(winner);assert(s.castE());until(r,()=>s.status.phase==='E_Hold');assert(s.strikeE());}
 if(skill==='R')assert(d.duel.getSkills(winner).castR());
 until(r,()=>d.duel.state.history.length===old+1);
 assert.equal(d.duel.state.history.at(-1).winnerId,winner);
}
const points=r=>r.qa.duel.match.scores.map(s=>s.points);
for(const hz of [120,60,30,20,10,5])for(const skill of ['Q','E','R'])test(`${skill} result hold consumes three running-clock seconds at ${hz}Hz`,async()=>{
 const delta=1/hz,r=await start(()=>delta);score(r,skill);const d=r.game.data,started=d.session.elapsed,h=d.player.toArray(),b=d.duelBot.position.toArray();
 assert.equal(d.duel.state.remainingMs,3000);
 for(let frame=1;frame<=hz*3;frame++){
  r.key('KeyW');r.key('KeyR');r.frames(1);
  if(frame<hz*3){assert.equal(d.duel.state.phase,'roundReset');assert.equal(d.player.x,h[0]);assert.equal(d.player.z,h[2]);assert.equal(d.duelBot.position.x,b[0]);assert.equal(d.duelBot.position.z,b[2]);}
  if(skill==='E'&&frame>=Math.ceil(hz*1.2)&&frame<hz*3){assert.equal(d.duelBot.knockup,null);assert.equal(d.duelBot.position.y,1.7);assert.notEqual(d.skills.status.phase,'E_Strike');}
 }
 assert(Math.abs(d.session.elapsed-started-3)<1e-8);assert.equal(d.duel.state.roundNumber,2);assert.equal(d.duel.state.phase,'countdown');assert.equal(d.duel.state.remainingMs,1600);assert.deepEqual(d.player.toArray(),[0,1.7,7]);assert.deepEqual(d.duelBot.position.toArray(),[0,1.7,-12]);assert.deepEqual([...d.keys],['KeyW'],'held movement survives, but blocked action keys do not');r.release('KeyW');assert.equal(d.keys.size,0,'keyup during countdown clears movement');assert.deepEqual(points(r),[1,0]);
});
