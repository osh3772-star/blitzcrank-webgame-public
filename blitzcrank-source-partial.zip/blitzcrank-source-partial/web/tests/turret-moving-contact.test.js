import test from'node:test';import assert from'node:assert/strict';import{createTurretSimulation,segmentSphereHit}from'../turret-core.js';
const zero={x:0,y:0,z:0},point=(x=0,y=0,z=0)=>({x,y,z});
function seeded({position=point(-.25,.55),velocity=point(.3),age=0,lifetime=4}={}){const s=createTurretSimulation({turrets:[],projectileLifetime:lifetime});s.bullets.push({id:1,turretId:'test',position,velocity,age,active:true});return s;}
const moving=()=>({position:point(0,-.07),previousPosition:point(),radius:.48});
test('continuous player movement catches mid-frame contact missed by endpoint-only collision',()=>{
 const s=seeded(),events=s.step(1,moving()),hit=events.find(e=>e.type==='hit');assert(hit);assert.equal(hit.damage,18);assert.equal(s.bullets.length,0);
 const t=segmentSphereHit(point(-.25,.55),point(.05,.62),zero,.6);assert(t>0&&t<1);assert(Math.abs(hit.position.x-(-.25+.3*t))<1e-12);assert.equal(hit.position.y,.55);
 const old=seeded();assert.deepEqual(old.step(1,{position:point(0,-.07),radius:.48}),[]);assert.equal(old.bullets.length,1);
});
test('moving into an already passed path no longer creates an endpoint-only phantom hit',()=>{
 const params={position:point(-1,.55),velocity:point(2)},s=seeded(params);assert.deepEqual(s.step(1,{previousPosition:point(0,-.5),position:point(),radius:.48}),[]);assert.equal(s.bullets.length,1);
 assert(seeded(params).step(1,{position:point(),radius:.48}).some(e=>e.type==='hit'));
});
for(const where of['before','tie','after'])test('moving player contact and cover choose the same earliest-time fraction: '+where,()=>{
 const t=segmentSphereHit(point(-.25,.55),point(.05,.62),zero,.6),fraction=where==='before'?t/2:where==='tie'?t:(1+t)/2,s=seeded(),e=s.step(1,moving(),{obstruction:()=>fraction});assert.equal(e.length,1);assert.equal(e[0].type,where==='after'?'hit':'blocked');assert.equal(s.bullets.length,0);
});
test('newborn projectile does not sweep a player location from before the shot exists',()=>{
 const s=createTurretSimulation({turrets:[{position:point()}],telegraph:.5,projectileSpeed:1,projectileRadius:.1});const e=s.step(1,{previousPosition:point(0,1.3),position:point(2,1.3),radius:.1});assert(e.some(x=>x.type==='shot'));assert(!e.some(x=>x.type==='hit'));assert.equal(s.bullets.length,1);assert.equal(s.bullets[0].age,.5);assert.equal(s.bullets[0].position.x,.5);
});
test('expiring bullet tests only player motion before its lifetime boundary',()=>{
 const s=seeded({position:point(),velocity:point(),lifetime:.5}),e=s.step(1,{previousPosition:point(2),position:point(),radius:.48});assert.deepEqual(e.map(x=>x.type),['expired']);assert.equal(s.bullets.length,0);
});
test('explicit stationary positions preserve default events and exact floating-point states',()=>{
 const create=()=>createTurretSimulation({turrets:[{position:point()}]}),a=create(),b=create(),p=point(10,1.3);for(let i=0;i<240;i++){assert.deepEqual(b.step(1/60,{position:p,previousPosition:p,radius:.48}),a.step(1/60,{position:p,radius:.48}));assert.deepEqual(b.turrets,a.turrets);assert.deepEqual(b.bullets,a.bullets);}
});
test('omitting previous position never carries old motion across a teleport or reset',()=>{
 const s=seeded({position:point(),velocity:point()});s.step(.1,{position:point(3),previousPosition:point(4),radius:.48});assert.deepEqual(s.step(.1,{position:point(-3),radius:.48}),[]);s.reset();assert.equal(s.bullets.length,0);assert.equal(s.events.length,0);
});
test('zero delta freezes contact and dead players cannot be hit by continuous movement',()=>{
 const s=seeded(),before=structuredClone(s.bullets);assert.deepEqual(s.step(0,moving()),[]);assert.deepEqual(s.bullets,before);assert.deepEqual(s.step(1,{...moving(),alive:false}),[]);
});
test('invalid previous positions fail before mutating simulation state',()=>{
 for(const value of[null,{},point(NaN),point(0,Infinity)]){const s=seeded(),before=structuredClone(s.bullets);assert.throws(()=>s.step(.1,{...moving(),previousPosition:value}),/Previous player torso/);assert.deepEqual(s.bullets,before);}
});
for(const rate of[20,30,60,120])test('linear motion contact time and world impact remain stable at '+rate+'Hz',()=>{
 const s=seeded(),dt=1/rate,oracle=segmentSphereHit(point(-.25,.55),point(.05,.62),zero,.6);let impact=null;
 for(let i=0;i<rate;i++){const e=s.step(dt,{previousPosition:point(0,-.07*i/rate),position:point(0,-.07*(i+1)/rate),radius:.48});const hit=e.find(x=>x.type==='hit');if(hit){assert.equal(impact,null);impact={frame:i,event:hit};}}
 assert(impact);assert.equal(impact.frame,Math.ceil(oracle*rate)-1);assert(Math.abs(impact.event.position.x-(-.25+.3*oracle))<2e-12);assert.equal(impact.event.position.y,.55);assert.equal(s.bullets.length,0);
});
