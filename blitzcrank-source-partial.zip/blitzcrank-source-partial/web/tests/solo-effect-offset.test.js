import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

// Execute the unmodified main.js context functions without booting a scene.
// Actual application, score and lifecycle paths are covered separately.
function context(){
 const source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8');
 const start=source.indexOf('let soloSkillFrame=null;'),end=source.indexOf('function skillEvent(event){',start);
 assert(start>=0&&end>start);
 const ctx=vm.createContext({});
 vm.runInContext('let skills=null;\n'+source.slice(start,end)+'\nglobalThis.api={step:stepSoloSkills,offset:soloEffectOffset,setSkills(value){skills=value},get frame(){return soloSkillFrame}};',ctx);
 return ctx.api;
}
const animation={name:'R_Cast',time:.25,duration:.8,sequence:4};
const event={clip:'R_Cast',time:.3,sequence:4};
test('exact-end impact skips the whole current VFX step, including boundary rounding',()=>{
 const api=context();let offset;
 api.setSkills({animation,step(){offset=api.offset(event)}});api.step(.05);
 assert.equal(offset,.05);assert.equal(api.frame,null);assert.equal(api.offset(event),0);
});
test('partial-frame and zero-offset events retain their exact remainder',()=>{
 const api=context();let offsets;
 api.setSkills({animation:{...animation,time:.28},step(){offsets=[api.offset(event),api.offset({...event,time:.28})]}});api.step(.05);
 assert(Math.abs(offsets[0]-.02)<1e-15);assert.equal(offsets[1],0);
});
test('wrong clip, sequence, invalid or outside-frame timestamps cannot borrow the step',()=>{
 const api=context();let offsets;
 api.setSkills({animation,step(){offsets=[{...event,clip:'E_Strike'},{...event,sequence:3},{...event,time:NaN},{...event,time:.4},{...event,time:.2}].map(e=>api.offset(e))}});api.step(.05);
 assert.deepEqual(offsets,[0,0,0,0,0]);
});
test('zero/invalid delta and no pre-step animation default to legacy immediate effects',()=>{
 const api=context();const offsets=[];
 api.setSkills({animation,step(){offsets.push(api.offset(event))}});
 for(const dt of [0,-.05,NaN,Infinity])api.step(dt);
 api.setSkills({animation:null,step(){offsets.push(api.offset(event))}});api.step(.05);
 assert.deepEqual(offsets,[0,0,0,0,0]);assert.equal(api.frame,null);
});
test('throwing or resetting during the controller step cannot leave stale event timing',()=>{
 const api=context(),failure=Error('test step failure');
 api.setSkills({animation,step(){assert.equal(api.offset(event),.05);throw failure;}});
 assert.throws(()=>api.step(.05),e=>e===failure);assert.equal(api.frame,null);assert.equal(api.offset(event),0);
 api.setSkills({animation:{...animation,sequence:5},step(){assert.equal(api.offset(event),0);api.setSkills(null)}});api.step(.05);
 assert.equal(api.frame,null);api.step(.05);assert.equal(api.offset(event),0);
});
test('the captured prior animation, not its post-step clock, owns the event offset',()=>{
 const api=context();let offset;const controller={animation:{...animation},step(){this.animation={...this.animation,time:.3};offset=api.offset(event)}};
 api.setSkills(controller);api.step(.05);assert.equal(offset,.05);assert.equal(controller.animation.time,.3);assert.equal(api.frame,null);
});
