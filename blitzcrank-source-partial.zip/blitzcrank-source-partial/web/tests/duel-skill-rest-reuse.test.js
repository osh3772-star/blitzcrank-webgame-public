import {assertApprovedSkillClips,AUTHORED_MIDPOINT_COUNT} from './helpers/approved-skill-clips.js';
import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {rig, THREE} from './helpers/locomotion-rig.js';
import {createDuelAvatarFactory} from '../duel-avatar.js';
import {createFullbodyLocomotion} from '../fullbody-locomotion.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';

// Frozen v77 source, unchanged. Only its relative import is resolved for the
// data URL. No proposed optimization is removed/reconstructed by this test.
const frozen = fs.readFileSync(new URL('./fixtures/duel-avatar-v0.24.77-skill-rest-baseline.txt', import.meta.url), 'utf8');
assert.equal(createHash('sha256').update(frozen).digest('hex'), 'cecc0a0014e88103367d11eb605bbab05357c3854da8041767e001bf04340c95');
const dependency = "'./skill-animation.js?v=0.24.70'";
assert.equal(frozen.split(dependency).length, 2);
const baselineSource = frozen.replace(dependency, JSON.stringify(new URL('../skill-animation.js?v=0.24.70', import.meta.url).href));
const {createDuelAvatarFactory: baselineFactory} = await import('data:text/javascript;base64,' + Buffer.from(baselineSource).toString('base64'));
const model = JSON.parse(fs.readFileSync(new URL('../' + SKILL_ASSET.raw, import.meta.url))).models.fullbody;
const original = rig(); // One geometry allocation, shared by all actor clones.
const state = {position:[0, 0, 0], yaw:0};
const skillState = (name = 'W_Loop', time = .2, extra = {}) => ({...state, ...extra, skill:{name, time}});
const list = root => {const out=[]; root.traverse(o=>out.push(o)); return out;};
// Actor application order is the original mesh Map insertion order, not its
// hierarchy traversal order. Partial-failure assertions must use that same order.
const surfaces = actor => {
 const byName=new Map(list(actor.object).filter(o=>o.isMesh).map(o=>[o.name,o]));
 return [...original.meshes.keys()].map(name=>byName.get(name)).filter(Boolean);
};
let comparedObjects=0, comparedStates=0;

function exactArray(a, b, label) {
 assert.equal(a.length,b.length,label+'.length');
 for(let i=0;i<a.length;i++) if(!Object.is(a[i],b[i])) {
  const show=v=>Object.is(v,-0)?'-0':String(v);
  assert.fail(`${label}[${i}]: ${show(a[i])} !== ${show(b[i])}`);
 }
}
function exactTree(a, b, label) {
 const left=list(a),right=list(b); assert.equal(left.length,right.length,label+'.nodes');
 for(let i=0;i<left.length;i++) {
  const x=left[i],y=right[i],key=label+'/'+i+'/'+x.name;
  for(const field of ['name','type','visible','matrixAutoUpdate','matrixWorldAutoUpdate','matrixWorldNeedsUpdate']) assert.equal(x[field],y[field],key+'.'+field);
  exactArray(x.position.toArray(),y.position.toArray(),key+'.position');
  exactArray(x.rotation.toArray(),y.rotation.toArray(),key+'.Euler');
  exactArray(x.quaternion.toArray(),y.quaternion.toArray(),key+'.quaternion');
  exactArray(x.scale.toArray(),y.scale.toArray(),key+'.scale');
  exactArray(x.matrix.elements,y.matrix.elements,key+'.matrix');
  exactArray(x.matrixWorld.elements,y.matrixWorld.elements,key+'.matrixWorld');
  assert.equal(x.children.length,y.children.length,key+'.children');
 }
 comparedObjects+=left.length;
}
function fixture(t, {optimized=false, staticRestMatrices=false, stationaryW=false, createLocomotion=createFullbodyLocomotion, setupSource=null, parents=false}={}) {
 if(setupSource)setupSource(original);
 let aFactory,bFactory;
 try {
  aFactory=(optimized?createDuelAvatarFactory:baselineFactory)(THREE,{...original,createLocomotion});
  bFactory=createDuelAvatarFactory(THREE,{...original,createLocomotion});
 } finally {
  // setupSource is restricted to valid rest-surface TRS in the signed-zero test.
  if(setupSource)for(const mesh of original.meshes.values()) {
   mesh.position.set(0,0,0);mesh.quaternion.identity();mesh.scale.set(1,1,1);mesh.updateMatrix();
  }
 }
 const worlds=parents?[new THREE.Group(),new THREE.Group()]:[null,null];
 const containers=parents?[new THREE.Group(),new THREE.Group()]:[null,null];
 if(parents)worlds.forEach((world,i)=>world.add(containers[i]));
 const a=aFactory.create({staticRestMatrices,stationaryW,parent:containers[0]}),b=bFactory.create({staticRestMatrices,stationaryW,parent:containers[1],...(optimized?{reuseSkillSurfaceRestPose:true}:{})});
 a.configureSkills(model);b.configureSkills(model);
 t.after(()=>{a.dispose();b.dispose();aFactory.dispose();bFactory.dispose();globalThis.gc?.();});
 const pair={a,b,worlds,containers,check(label,{sockets=true}={}) {
  exactTree(a.object,b.object,label+' before socket');assert.deepEqual(a.inspect(),b.inspect(),label+'.motion/inspection');
  if(sockets) {
   assert.deepEqual(a.getSockets(),b.getSockets(),label+'.sockets');
   exactTree(a.object,b.object,label+' after socket');
  }
  comparedStates++;
 },update(dt,input,label='update') {a.update(dt,input);b.update(dt,input);pair.check(label);}};
 pair.check('fresh configured actor');return pair;
}
function counts(actor, operation) {
 const meshes=new Set(surfaces(actor)),matrices=new Set([...meshes].map(o=>o.matrix));
 const update=THREE.Object3D.prototype.updateMatrix,compose=THREE.Matrix4.prototype.compose;
 const count={surfaceUpdateMatrix:0,surfaceCompose:0};
 THREE.Object3D.prototype.updateMatrix=function(){if(meshes.has(this))count.surfaceUpdateMatrix++;return update.apply(this,arguments);};
 THREE.Matrix4.prototype.compose=function(){if(matrices.has(this))count.surfaceCompose++;return compose.apply(this,arguments);};
 try {operation();} finally {THREE.Object3D.prototype.updateMatrix=update;THREE.Matrix4.prototype.compose=compose;}
 return count;
}

test('default API exactly preserves frozen v77 external surface TRS and reset behavior', t=>{
 const p=fixture(t);assert.deepEqual(Object.keys(p.b).sort(),[...Object.keys(p.a),'configureLoadedSkills'].sort());assert.equal(typeof p.b.configureLoadedSkills,'function');
 assert(Object.isFrozen(p.a)&&Object.isFrozen(p.b));
 for(let cycle=0;cycle<3;cycle++) {
  p.update(.03,skillState(),'enter');p.update(.03,skillState(),'first continuation');p.update(.03,skillState(),'warmed continuation');
  for(const actor of [p.a,p.b])for(const [i,mesh] of surfaces(actor).entries()) if(i%11===0) {
   mesh.position.set(i+.25,-0,-i-.5);mesh.rotation.set(.2,-.3,.4,'ZYX');mesh.scale.set(1.3,.7,2);
   mesh.matrixAutoUpdate=false;mesh.matrixWorldNeedsUpdate=false;
  }
  p.check('external mutation');p.update(.04,skillState('E_Hold',.31,{locomotion:{deltaZ:.1}}),'clear external TRS while active');
  for(const actor of [p.a,p.b])for(const mesh of surfaces(actor)) {
   exactArray(mesh.position.toArray(),[0,0,0],'default rest position');exactArray(mesh.quaternion.toArray(),[0,0,0,1],'default rest quaternion');exactArray(mesh.scale.toArray(),[1,1,1],'default rest scale');
  }
  p.update(0,state,'exit');p.a.reset();p.b.reset();p.check('reset');
 }
});

test('default API exactly preserves a custom locomotion surface writer',t=>{
 let writes=0;
 function customMotion(three,options) {
  const motion=createFullbodyLocomotion(three,options),restore=motion.restorePose;
  motion.restorePose=()=>{
   restore();writes++;
   for(const [i,mesh] of [...options.meshes.values()].entries()) if(i%17===0) {
    mesh.position.set(.7,-0,-.2);mesh.quaternion.set(.1,.2,.3,.9).normalize();mesh.scale.set(.8,1.2,1.1);
   }
  };
  return motion;
 }
 const p=fixture(t,{createLocomotion:customMotion});
 for(let cycle=0;cycle<3;cycle++) {
  for(const name of ['W_Loop','E_Hold','R_Cast'])for(let i=0;i<4;i++)p.update(.03,skillState(name,.1+i*.03),'custom writer '+name);
  p.update(0,state,'custom writer exit');
 }
 assert(writes>60);
});

for(const corruption of ['pose-p','pose-q','pose-s','rest-null','rest-short','rest-nan'])test(`default API matches frozen v77 after aliased data corruption: ${corruption}`,t=>{
 const p=fixture(t);for(let i=0;i<3;i++)p.update(.02,skillState(),'warmup');
 const meshes=surfaces(p.a),nameCounts=new Map();for(const mesh of meshes)nameCounts.set(mesh.userData.sourcePart,(nameCounts.get(mesh.userData.sourcePart)||0)+1);
 const index=meshes.findIndex((mesh,i)=>i>100&&nameCounts.get(mesh.userData.sourcePart)>1&&meshes.findIndex(other=>other.userData.sourcePart===mesh.userData.sourcePart)===i);
 assert(index>100,'exercise a mid-list source with material-split aliases');
 const sourceIndex=model.sourceParts.indexOf(meshes[index].userData.sourcePart);
 let undo;
 if(corruption.startsWith('pose-')) {
  const clip=model.clips.find(c=>c.name==='W_Loop'),field=corruption.slice(5),pose=clip.frames[6].poses[sourceIndex],saved=pose[field];
  pose[field]=null;undo=()=>{pose[field]=saved;};
 } else {
  const replacements=corruption==='rest-null'?null:corruption==='rest-short'?[0,0]:[NaN,0,0];
  for(const actor of [p.a,p.b])surfaces(actor)[index].userData.skillRestPoint=replacements;
  undo=()=>{};
 }
 const errors=[];
 try {
  for(const actor of [p.a,p.b])try {actor.update(.03,skillState());errors.push(null);}catch(error){errors.push({name:error.name,message:error.message});}
  assert.deepEqual(errors[0],errors[1],'exact throw type and message');
  p.check('corruption partial state',{sockets:false});
  if(corruption==='rest-nan') {
   assert.equal(errors[0],null);assert(meshes[index].matrix.elements.some(Number.isNaN),'existing non-finite metadata behavior remains');
  } else {
   assert(errors[0],'expected corrupted data to throw');
   assert.equal(meshes[0].matrixAutoUpdate,false,'earlier surfaces have already been applied');
   assert.equal(meshes[index].matrixAutoUpdate,true,'faulting surface was cleared, not applied');
   assert.equal(meshes.at(-1).matrixAutoUpdate,true,'unvisited surfaces were cleared before the throw');
   exactArray(meshes[index].position.toArray(),[0,0,0],'faulting surface reset position');
   assert.equal(p.a.inspect().skill,'W_Loop','skill state remains assigned before applicator throw');
   assert(p.a.inspect().locomotion.phase>=0);
  }
 } finally {undo();}
});

for(const staticRestMatrices of [false,true])test(`opt-in is exact at every authored frame and midpoint, static groups ${staticRestMatrices}`,t=>{
 const p=fixture(t,{optimized:true,staticRestMatrices});let frames=0;
 for(let cycle=0;cycle<2;cycle++) {
  for(const clip of model.clips) {
   // Remain active across clip changes; each sequence begins only after exit.
   for(let step=0;step<=2*(clip.frames.length-1);step++) {
    const time=step/(2*clip.fps);
    p.update(0,skillState(clip.name,time),`${cycle} ${clip.name} sample ${step}`);frames++;
   }
   p.update(0,skillState(clip.name,clip.duration*2+.013),'clamped/looped clip time');
  }
  p.update(0,state,'continuous sequence exit');
 }
 assertApprovedSkillClips(model.clips);assert.equal(AUTHORED_MIDPOINT_COUNT,372);assert.equal(frames,2*AUTHORED_MIDPOINT_COUNT);
 t.diagnostic(`${frames} exact authored frame/midpoint comparisons plus loop/clamp and exit boundaries`);
});

test('opt-in exactly preserves repeated walking E, jump/landing, zero dt, parent transforms and Q interruption',t=>{
 const p=fixture(t,{optimized:true,staticRestMatrices:true,parents:true});
 for(const actor of [p.a,p.b]) {
  const effect=new THREE.Group();effect.name='test-late-effect';effect.position.set(.1,.2,.3);actor.getSkillHands()[1].add(effect);
  const child=new THREE.Group();child.name='test-late-effect-child';child.scale.set(1.2,.8,1.1);effect.add(child);
 }
 let airborne=0,landed=0,zero=0,qChecks=0;
 for(let cycle=0;cycle<3;cycle++) {
  for(let frame=0;frame<42;frame++) {
   const grounded=frame<8||frame>=24,height=grounded?0:Math.sin((frame-7)/17*Math.PI)*.6,velocityY=grounded?0:frame<16?2:-2;
   for(let i=0;i<2;i++) {
    p.worlds[i].position.set(.4,1,-.7);p.worlds[i].rotation.set(.03*cycle,.04*frame,-.07);p.worlds[i].scale.setScalar(1.1);
    p.containers[i].position.set(2,-.2,-3);p.containers[i].rotation.set(.1,-.3,.06);p.containers[i].scale.setScalar(1.7);
    const effect=p[i?'b':'a'].getSkillHands()[1].children[0];effect.rotation.set(.02*frame,-.1,.15);effect.children[0].position.y=frame*.001;
   }
   const names=['E_Charge','E_Hold','E_Strike'],dt=frame%7===0?0:1/60;
   p.update(dt,skillState(names[Math.floor(frame/14)],frame*.031,{position:[cycle*.3,height,-2-frame*.02],yaw:frame*.04,locomotion:{deltaX:.017,deltaZ:.043,grounded,height,velocityY}}),'E locomotion '+cycle+'/'+frame);
   if(!grounded)airborne++;if(frame>=24)landed++;if(!dt)zero++;
  }
  for(const phase of ['windup','outbound','return','recover']) {
   p.update(1/60,{...state,yaw:.6,pitch:-.2,locomotion:{deltaZ:.03},skill:{name:'E_Hold',time:.2},hook:{phase,phaseTime:.1,position:[1,2,-6],returnDuration:.3,bodyOrientation:[0,.2,0,.98]}},'Q '+phase);
   for(const actor of [p.a,p.b])assert(surfaces(actor).every(mesh=>mesh.matrixAutoUpdate));qChecks++;
  }
  p.update(0,skillState('R_Cast',.2),'skill after Q');p.update(0,skillState('R_Cast',.21),'first continuation after Q');p.update(.02,skillState('W_Loop',.1),'warm change after Q');
  p.a.hide();p.b.hide();p.check('hide');p.update(0,skillState('E_Hold',.4),'hidden active update');p.a.show();p.b.show();p.check('show');
  p.a.reset({position:[2,0,-1],yaw:.4,visible:true});p.b.reset({position:[2,0,-1],yaw:.4,visible:true});p.check('reset after active');
 }
 assert(airborne&&landed&&zero);assert.equal(qChecks,12);
 const left=list(p.a.object),right=list(p.b.object);p.a.dispose();p.b.dispose();
 assert.deepEqual(p.a.inspect(),p.b.inspect());assert.equal(p.a.object.children.length,0);assert.equal(p.b.object.children.length,0);
 // Saved surface/effect references must retain identical transforms on disposal.
 for(let i=0;i<left.length;i++)exactTree(left[i],right[i],'disposed saved subtree '+i);
 for(const actor of [p.a,p.b])for(const action of [()=>actor.update(0,state),()=>actor.reset(),()=>actor.getSockets(),()=>actor.hide(),()=>actor.show()])assert.throws(action,/disposed/);
});

test('first continuation retains canonical Euler, signed zeros and quaternion w=-1 entry',t=>{
 const chosen=[...original.meshes.keys()][120];
 const p=fixture(t,{optimized:true,staticRestMatrices:true,setupSource:source=>{
  const mesh=source.meshes.get(chosen);mesh.position.set(-0,0,-0);mesh.quaternion.set(-0,0,-0,-1);
 }});
 const target=actor=>surfaces(actor).find(mesh=>mesh.name===chosen);
 for(const actor of [p.a,p.b])assert.equal(target(actor).quaternion.w,-1);
 p.update(0,skillState(),'first skill preserves initial TRS');
 for(const actor of [p.a,p.b])assert.equal(target(actor).quaternion.w,-1);
 const first=counts(p.b,()=>p.b.update(0,skillState()));p.a.update(0,skillState());p.check('canonical first continuation');
 assert.deepEqual(first,{surfaceUpdateMatrix:279,surfaceCompose:279});
 for(const actor of [p.a,p.b]) {
  assert.equal(target(actor).quaternion.w,1);exactArray(target(actor).position.toArray(),[0,0,0],'canonical position');
  assert(Object.is(target(actor).rotation.x,-0),'identity quaternion conversion retains canonical Euler negative zero');
 }
 const warm=counts(p.b,()=>p.b.update(0,skillState()));p.a.update(0,skillState());p.check('warmed signed-zero continuation');
 assert.deepEqual(warm,{surfaceUpdateMatrix:0,surfaceCompose:0});
});

test('only warmed active-to-active updates remove 279 surface updateMatrix/compose calls',t=>{
 const p=fixture(t,{optimized:true,staticRestMatrices:true});assert.equal(surfaces(p.a).length,279);
 for(let cycle=0;cycle<3;cycle++) {
  p.update(0,skillState(),'count entry');
  const firstA=counts(p.a,()=>p.a.update(0,skillState())),firstB=counts(p.b,()=>p.b.update(0,skillState()));
  assert.deepEqual(firstA,{surfaceUpdateMatrix:279,surfaceCompose:279});assert.deepEqual(firstB,firstA);p.check('count first continuation');
  for(const name of ['W_Loop','E_Hold','E_Strike','R_Cast']) {
   const a=counts(p.a,()=>p.a.update(0,skillState(name))),b=counts(p.b,()=>p.b.update(0,skillState(name)));
   assert.deepEqual(a,{surfaceUpdateMatrix:279,surfaceCompose:279});assert.deepEqual(b,{surfaceUpdateMatrix:0,surfaceCompose:0});p.check('count warmed '+name);
  }
  const a=counts(p.a,()=>p.a.update(0,state)),b=counts(p.b,()=>p.b.update(0,state));
  assert.deepEqual(a,b);assert(a.surfaceUpdateMatrix>=279);p.check('count exit');
 }
 t.diagnostic('Each first continuation: 279 -> 279; warmed active continuations: 279 -> 0 surface updateMatrix and compose calls. No CPU timing.');
});

test('stationary W opt-in preserves exact surface-rest reuse off/on through W, E/R, Q and reset',t=>{
 const p=fixture(t,{optimized:true,staticRestMatrices:true,stationaryW:true});
 for(let cycle=0;cycle<2;cycle++){
  for(const name of ['W_Start','W_Loop','W_End','E_Charge','E_Hold','E_Strike','R_Cast'])for(let frame=0;frame<12;frame++)p.update(frame%5===0?0:1/60,skillState(name,frame*.025),'stationary reuse '+cycle+'/'+name+'/'+frame);
  for(const phase of ['windup','outbound','return','recover']){
   p.update(1/60,{...state,skill:{name:'W_Loop',time:.2},hook:{phase,phaseTime:.1,position:[1,2,-6],returnDuration:.3,bodyOrientation:[0,.2,0,.98]}},'stationary Q '+phase);
   for(const actor of [p.a,p.b])assert(surfaces(actor).every(mesh=>mesh.matrixAutoUpdate));
  }
  p.update(0,skillState(),'stationary W after Q');p.update(0,skillState(),'stationary W first continuation');p.update(0,skillState(),'stationary W warmed continuation');
  p.a.reset();p.b.reset();p.check('stationary reset');p.update(0,skillState(),'stationary W after reset');p.update(0,state,'stationary final exit');
 }
});

after(()=>{
 console.log(`EXACT_SKILL_REST_SUMMARY ${JSON.stringify({comparedStates,comparedObjects,authoredClips:model.clips.length,surfaces:original.meshes.size,comparison:'Object.is numbers, including signed zero; all local/world matrices, Euler/quaternion/TRS/flags, sockets and motion'})}`);
 for(const mesh of original.meshes.values()){mesh.geometry.dispose();mesh.material.dispose();}
 original.body.removeFromParent();original.body.clear();original.nodes.clear();original.meshes.clear();
});
