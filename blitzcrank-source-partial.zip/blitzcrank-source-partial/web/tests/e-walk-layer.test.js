import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createFullbodyPoseApplicator,createFullbodyELocomotionLayer,bindSkillClips,clearFullbodySkillPose} from '../skill-animation.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';
import {rig,THREE,minY,fingerMinimum} from './helpers/locomotion-rig.js';
const data=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))),apply=createFullbodyPoseApplicator(THREE);
const make=()=>{const r=rig();r.surfaces=[...r.meshes.values()];r.clips=Object.fromEntries(bindSkillClips(data.models.fullbody,r.surfaces).map(c=>[c.name,c]));r.layer=createFullbodyELocomotionLayer(THREE,{body:r.body,nodes:r.nodes,surfaces:r.surfaces,locomotion:r.motion});return r;};
const lower=(r,m)=>{for(let n=m;n;n=n.parent){if(n===r.nodes.get('BC_Torso'))return false;if(n===r.nodes.get('BC_Pelvis'))return true;}return false;};
function authored(r,name,time){r.motion.restorePose();r.body.position.y=0;apply(r.clips[name],time,r.surfaces);}
function pose(r,name,time){authored(r,name,time);r.layer();r.body.updateMatrixWorld(true);}
const metrics={minSole:Infinity,maxSupportError:0,minFinger:Infinity,maxSeam:0,maxStep:0};
function seamPoint(r,name,point){const m=r.meshes.get(name);return new THREE.Vector3(...point).sub(new THREE.Vector3(...m.userData.skillRestPoint)).applyMatrix4(m.matrixWorld);}
function check(r){for(const l of r.motion.inspect().legs){assert.equal(l.clamped,false);const sole=r.meshes.get('BC_FootSole.'+l.side),y=minY(sole);metrics.minSole=Math.min(metrics.minSole,y);assert(y>-.00001,'sole penetrated floor '+y);if(l.step.stance)metrics.maxSupportError=Math.max(metrics.maxSupportError,Math.abs(y));const up=new THREE.Vector3(0,1,0).transformDirection(sole.matrixWorld);assert(up.y>1-1e-10);const s=l.side,sign=s==='L'?1:-1;for(const [a,b,p] of [['BC_Pelvis','BC_Hip.'+s,[sign*.35,.9226,-.014303]],['BC_Thigh.'+s,'BC_Knee.'+s,[sign*.3872,.5416,-.014303]],['BC_Shin.'+s,'BC_Foot.'+s,[sign*.4576,.146944,-.044303]]]){metrics.maxSeam=Math.max(metrics.maxSeam,seamPoint(r,a,p).distanceTo(seamPoint(r,b,p)));}}
 metrics.minFinger=Math.min(metrics.minFinger,fingerMinimum(r.fingers));
}

test('hierarchy lower layer covers material splits, excludes torso subtree, and stationary E is exact',()=>{
 const r=make(),ref=make();const names=r.surfaces.filter(m=>lower(r,m)).map(m=>m.name);assert(names.includes('BC_Pelvis'));assert(names.includes('BC_Pelvis__surface1'));assert(names.includes('BC_Knee__surface3.L'));assert(names.includes('BC_Foot__surface3.R'));assert(!names.includes('BC_PelvisRearCap'));assert(!names.includes('BC_Palm.R'));
 for(const name of ['E_Charge','E_Hold','E_Strike'])for(const t of [0,.1,.2,.3,.4,.7,1]){pose(r,name,t);authored(ref,name,t);ref.body.updateMatrixWorld(true);for(let i=0;i<r.surfaces.length;i++)assert.deepEqual(r.surfaces[i].matrixWorld.elements,ref.surfaces[i].matrixWorld.elements,name+' '+r.surfaces[i].name);}
});

test('E moving upper body is exact authored pose plus gait root translation, with no shoulder double transform',()=>{
 const r=make(),ref=make();for(const direction of [[0,-1],[1,0],[-1,1]]){r.motion.reset();for(let f=0;f<150;f++){r.motion.advance(1/60,{deltaX:direction[0]*.06,deltaZ:direction[1]*.06});const name=['E_Charge','E_Hold','E_Strike'][Math.floor(f/50)],t=(f%50)/60;pose(r,name,t);authored(ref,name,t);ref.body.position.y=r.motion.inspect().rootOffsetY;ref.body.updateMatrixWorld(true);for(let i=0;i<r.surfaces.length;i++)if(!lower(r,r.surfaces[i]))for(let k=0;k<16;k++)assert(Math.abs(r.surfaces[i].matrixWorld.elements[k]-ref.surfaces[i].matrixWorld.elements[k])<1e-11,name+' '+r.surfaces[i].name);for(const side of ['L','R'])assert.deepEqual(r.nodes.get('BC_Pivot_Shoulder.'+side).quaternion.toArray(),[0,0,0,1]);check(r);}}
});

test('real sole and finger vertices stay clear during all E phases, starts, stops, turns and airborne fade',()=>{
 const r=make();for(const speed of [.1,1.6,6.4,9.92])for(let direction=0;direction<8;direction++){const angle=direction*Math.PI/4;r.motion.reset();for(let f=0;f<160;f++){const move=f<90||f>130,air=f>=110&&f<130;r.motion.advance(1/120,{deltaX:move?-Math.sin(angle)*speed/120:0,deltaZ:move?-Math.cos(angle)*speed/120:0,grounded:!air});const name=['E_Charge','E_Hold','E_Strike'][Math.floor(f/60)%3];pose(r,name,(f%60)/120);check(r);}}
 assert(metrics.minFinger>.005,'fingers '+metrics.minFinger);assert(metrics.maxSupportError<.009,'authored strike lift crossfade '+metrics.maxSupportError);assert(metrics.maxSeam<.015,'joint seam '+metrics.maxSeam);
});

test('E strike moving-to-idle crossfade has no lower-body discontinuity when gait blend reaches zero',()=>{
 const r=make();for(let f=0;f<60;f++)r.motion.advance(1/60,{deltaZ:-.1});let prev=null,zero=false;for(let f=0;f<100;f++){r.motion.advance(1/60,{});pose(r,'E_Strike',.3);const p=seamPoint(r,'BC_Foot.L',[.4576,.146944,-.044303]);if(prev){const d=prev.distanceTo(p);metrics.maxStep=Math.max(metrics.maxStep,d);if(r.motion.blend===0&&!zero){assert(d<.00001,'blend-zero snap '+d);zero=true;}}prev=p;}assert(zero);assert(metrics.maxStep<.035);
});

test('return from E to ordinary gait clears every blended lower surface matrix and preserves exact gait',()=>{
 const r=make(),ref=make();for(let f=0;f<30;f++){r.motion.advance(1/60,{deltaX:.05,deltaZ:-.07});ref.motion.advance(1/60,{deltaX:.05,deltaZ:-.07});pose(r,'E_Strike',f/60);}clearFullbodySkillPose(r.surfaces);r.motion.restorePose();r.body.position.y=r.motion.applyPose();ref.motion.restorePose();ref.body.position.y=ref.motion.applyPose();r.body.updateMatrixWorld(true);ref.body.updateMatrixWorld(true);for(let i=0;i<r.surfaces.length;i++){assert(r.surfaces[i].matrixAutoUpdate);for(let k=0;k<16;k++)assert(Math.abs(r.surfaces[i].matrixWorld.elements[k]-ref.surfaces[i].matrixWorld.elements[k])<1e-11);}
});

test('settled E lower surfaces converge to the unchanged locomotion at the same phase and displacement',()=>{
 const r=make(),ref=make();for(let f=0;f<600;f++){r.motion.advance(1/60,{deltaX:.04,deltaZ:-.08});ref.motion.advance(1/60,{deltaX:.04,deltaZ:-.08});}
 for(const name of ['E_Charge','E_Hold','E_Strike'])for(const t of [0,.2,.4,.7]){pose(r,name,t);ref.motion.restorePose();ref.body.position.y=ref.motion.applyPose();ref.body.updateMatrixWorld(true);for(let i=0;i<r.surfaces.length;i++)if(lower(r,r.surfaces[i]))for(let k=0;k<16;k++)assert(Math.abs(r.surfaces[i].matrixWorld.elements[k]-ref.surfaces[i].matrixWorld.elements[k])<1e-12,name+' '+r.surfaces[i].name);}
});

test('E layer geometry diagnostics',()=>{console.log('E_LAYER_GEOMETRY '+JSON.stringify(metrics));});
