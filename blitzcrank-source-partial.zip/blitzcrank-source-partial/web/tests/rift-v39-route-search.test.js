import test from 'node:test';import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {findAuditedRoute,createTriangleIndex} from '../rift-v39-route-search.js';
const options={start:[0,0],goal:[4,0],bounds:[-2,-3,6,3],edgeAudit:()=>({pass:true})};
test('open grid finds a deterministic endpoint-exact route',()=>{
 const a=findAuditedRoute(options);assert.equal(a.status,'found');assert.equal(a.length,4);assert.deepEqual(a.path[0],[0,0]);assert.deepEqual(a.path.at(-1),[4,0]);assert.deepEqual(a,findAuditedRoute(options));assert(a.segments.every(s=>s.audit.pass));
});
test('all edges are audited and a wall forces a real detour',()=>{
 const edgeAudit=(a,b)=>({pass:!((Math.min(a[0],b[0])<=2&&Math.max(a[0],b[0])>=2)&&Math.min(a[1],b[1])<2)});
 const a=findAuditedRoute({...options,edgeAudit});assert.equal(a.status,'found');assert(a.length>4);assert(a.segments.every(s=>edgeAudit(s.from,s.to).pass));
});
test('blocked endpoints fail closed, even for zero-length requests',()=>{
 assert.equal(findAuditedRoute({...options,edgeAudit:()=>({pass:false})}).status,'invalid-endpoint');
 assert.equal(findAuditedRoute({...options,goal:[0,0],edgeAudit:()=>({pass:false})}).status,'invalid-endpoint');
});
test('disconnection is bounded-grid evidence, not global impossibility',()=>{
 const a=findAuditedRoute({...options,edgeAudit:(a,b)=>({pass:a[0]===b[0]&&a[1]===b[1]})});assert.equal(a.status,'no-route-in-grid');assert.equal(a.globalUnreachabilityProven,false);
});
test('budget exhaustion is distinguished from a completed search',()=>{
 assert.equal(findAuditedRoute({...options,maxExpanded:1}).status,'expansion-budget-exhausted');
});
test('off-grid endpoints are linked only through audited short edges',()=>{
 const a=findAuditedRoute({...options,start:[.25,.5],goal:[3.75,-.25]});assert.equal(a.status,'found');assert.deepEqual(a.path[0],[.25,.5]);assert.deepEqual(a.path.at(-1),[3.75,-.25]);assert(a.segments.every(s=>Math.hypot(s.to[0]-s.from[0],s.to[1]-s.from[1])<=Math.SQRT2+1e-9));
});
test('invalid and unbounded requests reject instead of doing unlimited work',()=>{
 for(const o of [{step:0},{bounds:[0,0,1000,1000]},{start:[Infinity,0]},{maxExpanded:0},{edgeAudit:()=>({pass:1})}])assert.throws(()=>findAuditedRoute({...options,...o}));
});
test('spatial index matches exhaustive bounds filtering at cell boundaries',()=>{
 let seed=9;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/2**32)*20-10;
 const ts=Array.from({length:100},()=>{const x=rand(),z=rand();return {bounds:new THREE.Box3(new THREE.Vector3(x,0,z),new THREE.Vector3(x+2,1,z+2))};});
 const idx=createTriangleIndex(ts);
 for(let i=0;i<100;i++){const p=[rand(),rand()],h=.7;assert.deepEqual(idx.query(p,p,h),ts.filter(t=>t.bounds.max.x>=p[0]-h&&t.bounds.min.x<=p[0]+h&&t.bounds.max.z>=p[1]-h&&t.bounds.min.z<=p[1]+h));}
});
test('coarse-grid failure does not hide a narrow passage found on a finer grid',()=>{
 const edgeAudit=(a,b)=>{
  if(Math.min(a[0],b[0])>2||Math.max(a[0],b[0])<2)return {pass:true};
  if(a[0]===b[0])return {pass:a[1]>=.2&&a[1]<=.3&&b[1]>=.2&&b[1]<=.3};
  const t=(2-a[0])/(b[0]-a[0]),y=a[1]+t*(b[1]-a[1]);return {pass:y>=.2&&y<=.3};
 };
 assert.equal(findAuditedRoute({...options,edgeAudit,step:1}).status,'no-route-in-grid');
 assert.equal(findAuditedRoute({...options,edgeAudit,step:.25}).status,'found');
});
