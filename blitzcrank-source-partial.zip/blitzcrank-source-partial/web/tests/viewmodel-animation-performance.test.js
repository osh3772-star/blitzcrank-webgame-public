import test from 'node:test';import assert from 'node:assert/strict';
import {THREE,createViewmodelAnimationHarness,animationState} from './helpers/viewmodel-animation-harness.js';
const original=new URL('./fixtures/viewmodel-animation-v0.24.52.txt',import.meta.url);let comparisons=0;
function pair(){const a=createViewmodelAnimationHarness({sourcePath:original}),b=createViewmodelAnimationHarness();return{a,b,configure(v){a.configure(v);b.configure(v);},step(dt=0,walking=false){a.apply(dt,walking);b.apply(dt,walking);assert.deepEqual(animationState(b),animationState(a));comparisons++;}};}
test('all actual base and skill frames/midpoints preserve exact VM transforms and flags',()=>{
 const p=pair();for(const clip of Object.values(p.a.clips)){for(const time of [-.0,0,clip.duration,clip.duration+1,...clip.frames.flatMap((_,i)=>[i/clip.fps,(i+.31)/clip.fps])]){p.configure({clipName:clip.name,clipTime:time,oneShot:0,hook:null,skill:null,state:'paused'});p.step();}}
 for(const clip of Object.values(p.a.skillClips.viewmodel)){for(const time of [0,clip.duration,clip.duration+1,...clip.frames.flatMap((_,i)=>[i/clip.fps,(i+.37)/clip.fps])]){p.configure({clipName:'Idle',clipTime:0,oneShot:0,hook:null,skill:{name:clip.name,time},state:'paused'});p.step();}}
});
test('actual Idle and W reduce slerp from 168 to shared endpoint runs',()=>{
 const h=createViewmodelAnimationHarness(),fn=THREE.Quaternion.prototype.slerp;let calls=0;THREE.Quaternion.prototype.slerp=function(...args){calls++;return fn.apply(this,args);};
 try{h.configure({clipName:'Idle',clipTime:.13});h.apply(0);assert.equal(calls,90);console.log('VM_IDLE_SLERPS '+calls);calls=0;h.configure({skill:{name:'W_Loop',time:.13}});h.apply(0);assert.equal(calls,84);console.log('VM_W_SLERPS '+calls);}finally{THREE.Quaternion.prototype.slerp=fn;}
 assert.equal(h.parts.length,168);
});
test('Q phases preserve hand visibility, one-shot state and sequential moving timeline',()=>{
 const p=pair();for(const phase of ['windup','outbound','return','recover'])for(const phaseTime of [0,.03,.13,.25,.7]){p.configure({hook:{phase,phaseTime},skill:{name:'E_Hold',time:.2},state:'running'});p.step(.016,true);}
 p.configure({hook:null,skill:null,oneShot:0,clipName:'Idle',clipTime:0});for(let i=0;i<70;i++)p.step([0,1/120,1/60,.05][i%4],i%7<4);
 p.configure({clipName:'Basic_Punch',clipTime:0,oneShot:.65,punchPlaybackRate:1.5});for(let i=0;i<65;i++)p.step(1/60,true);
});
test('new times and calls cannot reuse stale transforms or copy previous visibility',()=>{
 const p=pair();for(let i=0;i<15;i++){p.configure({clipName:'Walk_Arm_Sway',clipTime:i*.043,skill:null,state:'paused'});for(const h of [p.a,p.b])for(let j=0;j<h.parts.length;j++){h.parts[j].position.set(j,1,2);h.parts[j].quaternion.set(0,0,0,1);h.parts[j].scale.set(7,8,9);h.parts[j].visible=j%2===0;}p.step();}
});
test('either endpoint identity and nonadjacent repeated poses remain independently sampled',()=>{
 const p=pair();for(const h of [p.a,p.b]){const x={p:[1,2,3],q:[.1,.2,.3,.9],s:[1,2,3]},y={p:[3,2,1],q:[.3,.1,.2,.9],s:[3,2,1]},z={p:[2,1,3],q:[.2,.3,.1,.9],s:[2,1,3]};h.clips.synthetic={name:'synthetic',loop:false,fps:1,duration:1,frames:[{poses:h.parts.map((_,i)=>[x,x,z,x][i%4])},{poses:h.parts.map((_,i)=>[y,z,z,y][i%4])}]};}
 for(const time of [0,.2,.8,1,.2]){p.configure({clipName:'synthetic',clipTime:time});p.step();}
 for(const h of [p.a,p.b]){h.clips.synthetic.frames[0].poses[0].p[0]=13;h.clips.synthetic.frames[1].poses[0].q[2]=.7;}p.step();
});
test('zero part list and missing first endpoint retain original behavior',()=>{
 const p=pair();p.a.parts.splice(0);p.b.parts.splice(0);p.step();const q=pair();for(const h of [q.a,q.b])h.clips.bad={fps:1,duration:1,loop:false,frames:[{poses:[]},{poses:[]}]};q.configure({clipName:'bad'});assert.throws(()=>q.a.apply(0),TypeError);assert.throws(()=>q.b.apply(0),TypeError);
});
test('dot>=1 fallback preserves the original quaternion/Euler disagreement',()=>{
 const p=pair();for(const h of [p.a,p.b]){const x={p:[0,0,0],q:[0,0,0,1],s:[1,1,1]},y={p:[0,0,0],q:[.002,.001,.003,1],s:[1,1,1]};h.clips.rounded={fps:1,duration:1,loop:false,frames:[{poses:h.parts.map(()=>x)},{poses:h.parts.map(()=>y)}]};}
 for(const time of [.5,0,1,.2]){p.configure({clipName:'rounded',clipTime:time});p.step();}
 assert.notDeepEqual(p.b.parts[1].rotation.toArray(),new THREE.Euler().setFromQuaternion(p.b.parts[1].quaternion).toArray());
});
test('fallback comparison preserves vendor summation order at a unit-quaternion rounding boundary',()=>{
 const p=pair(),aq=[-.4748356848057785,-.17120920780494875,.39135754860295424,-.7694528892331977],bq=[-.4748356735762376,-.17120922736161906,.39135755758957186,-.7694528872407741];
 const a=new THREE.Quaternion(...aq),b=new THREE.Quaternion(...bq);assert(a.dot(b)<1);assert.equal(a.w*b.w+a.x*b.x+a.y*b.y+a.z*b.z,1);
 for(const h of [p.a,p.b]){const x={p:[0,0,0],q:[-aq[0],-aq[1],aq[2],aq[3]],s:[1,1,1]},y={p:[0,0,0],q:[-bq[0],-bq[1],bq[2],bq[3]],s:[1,1,1]};h.clips.boundary={fps:1,duration:1,loop:false,frames:[{poses:h.parts.map(()=>x)},{poses:h.parts.map(()=>y)}]};}
 p.configure({clipName:'boundary',clipTime:.37});p.step();assert.notDeepEqual(p.b.parts[1].rotation.toArray(),new THREE.Euler().setFromQuaternion(p.b.parts[1].quaternion).toArray());
});
test('exact animation comparison count is recorded',()=>{console.log('VM_EXACT_STATES '+comparisons);assert(comparisons>650);});
