import test from 'node:test';import assert from 'node:assert/strict';import * as THREE from '../vendor/three.module.js';
import {createProjectilePrepareHarness} from './helpers/projectile-prepare-harness.js';
let comparisons=0;const coverage=new Map();
function snapshot(d){
 const object=o=>({position:o.position.toArray(),quaternion:o.quaternion.toArray(),scale:o.scale.toArray(),matrix:o.matrix.toArray(),matrixWorld:o.matrixWorld.toArray(),dirty:o.matrixWorldNeedsUpdate,auto:o.matrixAutoUpdate,visible:o.visible});
 return {fist:object(d.fist),children:d.fist.children.map(object),camera:object(d.camera),viewmodel:object(d.viewmodel),parts:d.parts.map(object),hook:d.hook?{phase:d.hook.phase,position:d.hook.position.toArray(),direction:d.hook.direction.toArray()}:null};
}
function compare(current,legacy,place,getData){
 current(place);const actual=snapshot(getData());legacy(place);const expected=snapshot(getData());
 assert.deepEqual(actual,expected,`place=${place} / ${getData().hook?.phase}`);comparisons++;
 const label=(getData().thirdPerson?'third':'first')+':'+(getData().hook?.phase||'idle')+':'+place;coverage.set(label,(coverage.get(label)||0)+1);
}
const h=await createProjectilePrepareHarness({compare});
function key(code){h.key(code);h.release(code);}
function fresh(third=false){h.game.begin(true);if((h.qa.view==='third')!==third)key('KeyV');for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}h.frames(1);}
function manual(place){compare(h.projectile.current,h.projectile.legacy,place,()=>h.projectile.data);}
test('one projectile preparation refreshes camera and viewmodel once rather than twice',t=>{
 fresh();const {viewmodel,camera}=h.projectile.data;let count=0;viewmodel.traverse(()=>count++);
 const measure=fn=>{let viewPasses=0,cameraPasses=0,visits=0;const nodes=new Set();viewmodel.traverse(n=>nodes.add(n));const original=THREE.Object3D.prototype.updateMatrixWorld;
  THREE.Object3D.prototype.updateMatrixWorld=function(...args){if(this===viewmodel)viewPasses++;if(this===camera)cameraPasses++;if(nodes.has(this))visits++;return original.apply(this,args);};
  try{fn(false);}finally{THREE.Object3D.prototype.updateMatrixWorld=original;}return{viewPasses,cameraPasses,visits};
 };
 const old=measure(h.projectile.legacy),current=measure(h.projectile.current);
 assert.deepEqual(old,{viewPasses:2,cameraPasses:2,visits:count*2});assert.deepEqual(current,{viewPasses:1,cameraPasses:1,visits:count});
 t.diagnostic(`${count} viewmodel nodes: preparation visits ${old.visits} → ${current.visits}; camera and viewmodel refreshes 2 → 1.`);
});
test('exact original projectile matrices across Q phases, movement, jumping and both views',()=>{
 for(const third of [false,true]){fresh(third);manual(true);manual(false);key('KeyQ');h.key('KeyD');key('Space');
  for(let i=0;i<170;i++){if(i===45)h.release('KeyD');if(i===35||i===79)key('KeyV');h.projectile.aim(i<60?.4:0,i<60?.02:0);h.frames(1);if(i%8===0)manual(i%16===0);}
  assert.equal(h.qa.hook,null);
 }
});
test('W/E/R source matrices and Q interruptions remain exact',()=>{
 for(const third of [false,true]){fresh(third);key('KeyE');h.frames(50);manual(false);key('KeyQ');h.frames(150);h.punch();
  for(let i=0;i<60;i++){h.frames(1);if(i%5===0)manual(i%10===0);}key('ShiftLeft');for(let i=0;i<55;i++){h.frames(1);if(i%5===0)manual(false);}key('KeyR');for(let i=0;i<65;i++){h.frames(1);if(i%5===0)manual(true);}
 }
});
test('portrait/landscape FOV, direct transform edits and fresh standalone hand queries do not reuse stale conversions',()=>{
 for(const third of [false,true])for(const [w,ht] of [[320,568],[390,844],[844,390],[1280,720]]){
  fresh(third);globalThis.innerWidth=w;globalThis.innerHeight=ht;h.projectile.resize();
  const d=h.projectile.data, savedView={position:d.viewmodel.position.clone(),quaternion:d.viewmodel.quaternion.clone()};for(let i=0;i<8;i++){
   d.camera.position.x+=.07;d.camera.rotation.y+=.03;d.viewmodel.position.x+=.009;d.viewmodel.rotation.z+=.004;
   d.parts.find(p=>p.name==='VM_Palm.R').position.y+=.02;
   manual(i%2===0);assert.deepEqual(h.projectile.fpsHandPoint().toArray(),h.projectile.legacyFpsHandPoint().toArray());
  }
  d.viewmodel.position.copy(savedView.position);d.viewmodel.quaternion.copy(savedView.quaternion);
 }
 globalThis.innerWidth=1280;globalThis.innerHeight=720;h.projectile.resize();
});
test('paused view switch, resize, mirror preparation and restart preserve original projectile state',()=>{
 for(const third of [false,true]){fresh(third);key('KeyQ');h.frames(25);h.game.pause();const hook=h.projectile.data.hook.position.toArray();key('KeyV');globalThis.innerWidth=390;globalThis.innerHeight=844;h.projectile.resize();h.frames(10);assert.deepEqual(h.projectile.data.hook.position.toArray(),hook);manual(false);
  const {fist,fullbody}=h.projectile.data,saved=[fist.visible,fullbody.visible],token=h.projectile.prepareMirrorBody();h.projectile.restoreMirrorBody(token);assert.deepEqual([fist.visible,fullbody.visible],saved);
  h.game.resume();h.frames(160);fresh(third);manual(true);assert.equal(h.qa.hook,null);
 }
 globalThis.innerWidth=1280;globalThis.innerHeight=720;h.projectile.resize();
});
test('actual duel Q and menu cancellation preserve both original projectile state and one score',()=>{
 fresh(false);h.element('duelmode').click();h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,jump:false})});h.frames(150);h.game.data.duelBot.position.set(0,1.7,1);key('KeyQ');h.frames(260);assert.equal(h.qa.duel.match.history.length,1);assert.equal(h.qa.duel.match.history[0].winnerId,'human');
 key('KeyQ');h.frames(20);h.game.pause();h.element('mainmenu').click();assert.equal(h.qa.hook,null);assert.equal(h.projectile.data.fist.visible,false);manual(false);
});
test('original-equivalence coverage is reported as CPU scene-graph verification',t=>{
 assert(comparisons>700);for(const phase of ['windup','outbound','return','recover'])assert([...coverage.keys()].some(k=>k.includes(':'+phase+':')),phase);
 t.diagnostic(`${comparisons} exact full projectile/camera/viewmodel/parts snapshots; ${JSON.stringify(Object.fromEntries(coverage))}. CPU-only mock DOM/no-op renderer, not browser/GPU verification.`);
});
