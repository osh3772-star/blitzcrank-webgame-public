import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {createAuditedMovement} from '../rift-v49-audited-movement.js';
import {createPlanarTrial} from '../rift-v39-planar.js';import {createMapProbe} from '../rift-v39-study.js';import {MAP_STUDY_V39 as study} from '../rift-v39-revisions.js';
const pass=()=>({pass:true});
test('speed normalization and stalled-frame clamp retain the existing movement budget',()=>{
 const c=createAuditedMovement({spawn:[0,0],audit:pass});const a=c.advance({x:10,z:10},1);assert.equal(a.seconds,.05);assert(Math.abs(a.distance-.25)<1e-12);
});
test('every accepted axis slide is independently audited without diagonal speed gain',()=>{
 const calls=[],c=createAuditedMovement({spawn:[0,0],audit:(a,b)=>{calls.push([a,b]);return {pass:a[0]===b[0]||a[1]===b[1],reason:'diagonal-blocked'};}});
 const a=c.advance({x:1,z:1},.05);assert.equal(a.segments.length,2);assert.equal(calls.length,4);assert(a.segments.reduce((s,x)=>s+Math.hypot(x.to[0]-x.from[0],x.to[1]-x.from[1]),0)<=.25+1e-12);
});
test('rejected movement cannot advance through an obstacle',()=>{
 const c=createAuditedMovement({spawn:[0,0],audit:(a,b)=>({pass:a[0]===b[0]&&a[1]===b[1],reason:'wall'})});const a=c.advance({x:1,z:0},.05);assert.deepEqual(a.position,[0,0]);assert.deepEqual(a.blockedBy,['wall']);
});
test('an audit exception after a successful axis leaves the entire step atomic',()=>{
 let count=0;const c=createAuditedMovement({spawn:[0,0],audit:()=>{count++;if(count===4)throw Error('test failure');return {pass:count!==2};}});const before=c.snapshot();assert.throws(()=>c.advance({x:1,z:1},.05));assert.deepEqual(c.snapshot(),before);
});
test('invalid input, failed reset and disposed calls cannot mutate state',()=>{
 const c=createAuditedMovement({spawn:[0,0],audit:(a,b)=>({pass:b[0]<1})}),before=c.snapshot();
 for(const [input,dt] of [[{x:NaN,z:0},.01],[{x:0,z:0},-1]])assert.throws(()=>c.advance(input,dt));assert.throws(()=>c.reset([2,0]));assert.deepEqual(c.snapshot(),before);c.dispose();assert.throws(()=>c.advance({x:0,z:0},.01));assert.throws(()=>c.reset());
});
test('snapshot and callback coordinate mutations cannot corrupt internal state',()=>{
 const c=createAuditedMovement({spawn:[0,0],audit:(a,b)=>{a[0]=99;b[0]=99;return {pass:true};}});const s=c.snapshot();s.position[0]=99;assert.deepEqual(c.snapshot().position,[0,0]);assert(c.advance({x:1,z:0},.01).position[0]<1);
});
test('1000 seeded inputs exactly reproduce the original planar controller movement',()=>{
 const layout=JSON.parse(fs.readFileSync(new URL('../'+study.collision,import.meta.url))),p=createMapProbe(layout,{radius:.7,study});
 const a=createPlanarTrial(layout,{spawn:[-8,0],study}),b=createAuditedMovement({spawn:[-8,0],audit:(from,to)=>{const reason=p.probe(from,to).blockedBy;return {pass:!reason,reason};}});
 let seed=42;const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/2**32);
 for(let i=0;i<1000;i++){const input={x:rand()*4-2,z:rand()*4-2},dt=rand()*.12,x=a.advance(input,dt),y=b.advance(input,dt);for(const key of ['position','segments','blockedBy','distance','seconds'])assert.deepEqual(y[key],x[key],key+' step '+i);}
});
