import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';
import {GLTFLoader} from '../vendor/GLTFLoader.js';
import {TARGET_TYPES, TARGET_MODEL_FILES, loadCharacterTargets, attachCharacterTarget} from '../target-models.js';

// Frozen evidence is data only. All hits, geometry deltas and attach results are
// recomputed through the actual loader/Three objects below. No network or writes.
const crystalSurface = JSON.parse(fs.readFileSync(new URL('./fixtures/mage-crystal-surface.json', import.meta.url)));
const evidence = JSON.parse(fs.readFileSync(new URL('../validation/reference-models-v2472/mage-shoulder-evidence.json', import.meta.url)));
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function readAsset(filename) {
  const bytes = fs.readFileSync(new URL((Object.values(TARGET_MODEL_FILES).includes(filename)?'../assets/targets/':'../validation/recovered-assets/') + filename, import.meta.url));
  assert.equal(bytes.readUInt32LE(0), 0x46546c67);
  assert.equal(bytes.readUInt32LE(4), 2);
  assert.equal(bytes.readUInt32LE(8), bytes.length);
  const json = JSON.parse(bytes.subarray(20, 20 + bytes.readUInt32LE(12)));
  // Reject external/image resources before passing bytes to GLTFLoader.
  assert((json.buffers || []).every(buffer => !buffer.uri));
  assert.equal((json.images || []).length, 0);
  return {bytes, json, arrayBuffer: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)};
}
function collect(scene) {
  scene.updateMatrixWorld(true);
  const primitives = {};
  scene.traverse(object => {
    if (!object.isMesh) return;
    assert(!Array.isArray(object.material));
    assert(!primitives[object.material.name], 'one primitive per material');
    primitives[object.material.name] = object;
  });
  return primitives;
}
const beforeData = readAsset(evidence.baselineFile);
const beforeScene = (await new GLTFLoader().parseAsync(beforeData.arrayBuffer, '')).scene;
const before = {...beforeData, scene: beforeScene, primitives: collect(beforeScene)};
const requested = [], loadedBytes = new Map();
const allowed = new Map(TARGET_TYPES.map(type => [`./assets/targets/${TARGET_MODEL_FILES[type.id]}`, TARGET_MODEL_FILES[type.id]]));
const assets = await loadCharacterTargets(async url => {
  assert(allowed.has(url), 'loader requested an unexpected resource: ' + url);
  requested.push(url);
  const data = readAsset(allowed.get(url));
  loadedBytes.set(url, data);
  return {ok: true, status: 200, arrayBuffer: async () => data.arrayBuffer};
});
const actualMage = assets.find(asset => asset.id === 'mage');
assert(actualMage, 'actual loadCharacterTargets returns mage');
const after = {...loadedBytes.get('./assets/targets/' + TARGET_MODEL_FILES.mage), scene: actualMage.scene, primitives: collect(actualMage.scene)};
// Preserve shoulder-only cost and full-attribute deltas against its immutable output.
// Latest shoulder/collar hit probes below continue to use the current asset.
const historicalData = readAsset(evidence.candidateFile);
const historicalScene = (await new GLTFLoader().parseAsync(historicalData.arrayBuffer, '')).scene;
const historicalShoulder = {...historicalData, scene:historicalScene, primitives:collect(historicalScene)};
const changed = ['Ancient steel armor', 'Steel engraved marks', 'Hood and mantle | deep azure', 'Royal blue robe'];
const triangles = model => Object.values(model.primitives).reduce((sum, object) => sum + object.geometry.index.count / 3, 0);
const vertices = model => Object.values(model.primitives).reduce((sum, object) => sum + object.geometry.attributes.position.count, 0);
const materialMap = model => Object.fromEntries(model.json.materials.map(material => [material.name, material]));
const ray = (model, origin, direction, material) => {
  const caster = new THREE.Raycaster(new THREE.Vector3(...origin), new THREE.Vector3(...direction));
  return caster.intersectObject(material ? model.primitives[material] : model.scene, true)[0];
};
const name = hit => hit.object.material.name;

// Cyclic normalization keeps winding. Every corner includes every exported
// attribute, so normals/UV changes and duplicate-triangle changes are detected.
function canonicalTriangles(geometry) {
  const keys = Object.keys(geometry.attributes).sort(), result = [];
  for (let i = 0; i < geometry.index.count; i += 3) {
    const corners = [];
    for (let j = 0; j < 3; j++) {
      const index = geometry.index.array[i + j];
      corners.push(Object.fromEntries(keys.map(key => {
        const attribute = geometry.attributes[key];
        return [key, Array.from(attribute.array.subarray(index * attribute.itemSize, (index + 1) * attribute.itemSize))];
      })));
    }
    result.push([0, 1, 2].map(start => JSON.stringify([corners[start], corners[(start + 1) % 3], corners[(start + 2) % 3]])).sort()[0]);
  }
  return result;
}
function subtractMultiset(left, right) {
  const counts = new Map();
  for (const triangle of right) counts.set(triangle, (counts.get(triangle) || 0) + 1);
  return left.filter(triangle => {
    const count = counts.get(triangle) || 0;
    if (count) {counts.set(triangle, count - 1); return false;}
    return true;
  });
}
const hashTriangles = keys => sha256(JSON.stringify(keys.slice().sort()));
function assertEnvelope(keys, bounds, label) {
  for (const key of keys) for (const corner of JSON.parse(key)) {
    for (let axis = 0; axis < 3; axis++) {
      const value = corner.position[axis];
      assert(value >= bounds[0][axis] && value <= bounds[1][axis], `${label} escaped its local envelope on axis ${axis}: ${value}`);
    }
  }
}
const expectedDeltas = {
  'Ancient steel armor': {before:219, after:265, retained:214, removed:5, added:51, removedBounds:[[.498,1.229,.2199],[1.001,1.817,.2201]], addedBounds:[[.498,1.229,.2159],[1.001,1.817,.2201]]},
  'Steel engraved marks': {before:448, after:416, retained:376, removed:72, added:40, removedBounds:[[.558,1.327,.2719],[.904,1.735,.3221]], addedBounds:[[.553,1.324,.2019],[.906,1.733,.2161]]},
  'Hood and mantle | deep azure': {before:289, after:285, retained:261, removed:28, added:24, removedBounds:[[.376,1.151,-.2411],[.984,1.569,.371]], addedBounds:[[.376,1.151,-.2411],[.984,1.559,.1971]]},
  // Intersected triangles retain original corners outside the actual cut footprint.
  // The lower-sleeve rays below additionally verify their unchanged outer surface.
  'Royal blue robe': {before:236, after:268, retained:223, removed:13, added:45, removedBounds:[[.382,1.023,.059],[.886,1.616,.261]], addedBounds:[[.382,1.023,.059],[.886,1.616,.261]]}
};

test('mage shoulder: actual target loader requests the immutable verified asset without a network fetch', () => {
  assert.equal(evidence.schemaVersion, 1);
  assert.equal(evidence.baselineFile, 'mage.b3e2d52dc5b40951.glb');
  assert.equal(TARGET_MODEL_FILES.mage, 'mage.'+crystalSurface.expectedSha256.slice(0,16)+'.glb');
  assert.equal(evidence.candidateFile, 'mage.976c71bc6d1e06e4.glb');
  assert.deepEqual(requested, TARGET_TYPES.map(type => './assets/targets/' + TARGET_MODEL_FILES[type.id]));
  assert.deepEqual(assets.map(asset => asset.id), TARGET_TYPES.map(type => type.id));
  assert.equal(sha256(before.bytes), 'b3e2d52dc5b40951cd7bf781fdd0a92be52d983c29853efef322bffa22cc9e36');
  assert.equal(sha256(after.bytes), crystalSurface.expectedSha256);
});

test('historical mage shoulder: bounded geometry cost, embedded-only resources and exact global bounds', () => {
  const after = historicalShoulder;
  assert.equal(before.bytes.length, 207052); assert.equal(after.bytes.length, 208328);
  assert.equal(triangles(before), 2512); assert.equal(triangles(after), 2554);
  assert.equal(vertices(before), 5444); assert.equal(vertices(after), 5476);
  assert.equal((after.json.animations || []).length, 0);
  assert.equal((after.json.images || []).length, 0);
  assert(after.json.buffers.every(buffer => !buffer.uri));
  assert.deepEqual(new THREE.Box3().setFromObject(after.scene), new THREE.Box3().setFromObject(before.scene));
});

test('mage shoulder: 14 unaffected materials plus four verified crystal refinements preserve transforms and batching', () => {
  const expected = structuredClone(materialMap(before));
  for(const row of crystalSurface.materials){const m=expected[row.name],v=row.after;m.pbrMetallicRoughness.baseColorFactor=v['Base Color'];m.pbrMetallicRoughness.metallicFactor=v.Metallic;m.pbrMetallicRoughness.roughnessFactor=v.Roughness;m.emissiveFactor=v['Emission Color'].slice(0,3);}
  assert.deepEqual(materialMap(after), expected);
  assert.deepEqual(after.json.nodes, before.json.nodes);
  assert.equal(after.json.meshes.length, 1);
  assert.equal(after.json.meshes[0].primitives.length, 18);
  assert.equal(Object.keys(after.primitives).length, 18);
  assert.equal(after.json.materials.length, 18);
});

test('historical mage shoulder: all decoded indices and attributes of the 14 untouched primitives are exact', () => {
  const after = historicalShoulder;
  let count = 0;
  for (const material of Object.keys(before.primitives)) {
    if (changed.includes(material)) continue;
    const a = before.primitives[material].geometry, b = after.primitives[material].geometry;
    assert.deepEqual(b.index.array, a.index.array, material + ' indices');
    assert.deepEqual(Object.keys(b.attributes), Object.keys(a.attributes), material + ' attribute names');
    for (const key of Object.keys(a.attributes)) {
      assert.equal(b.attributes[key].itemSize, a.attributes[key].itemSize);
      assert.equal(b.attributes[key].normalized, a.attributes[key].normalized);
      assert.deepEqual(b.attributes[key].array, a.attributes[key].array, material + ' ' + key);
    }
    count++;
  }
  assert.equal(count, 14);
});

for (const material of changed) test(`historical mage shoulder: ${material} has only its exact bounded triangle delta`, () => {
  const after = historicalShoulder;
  const a = canonicalTriangles(before.primitives[material].geometry), b = canonicalTriangles(after.primitives[material].geometry);
  const removed = subtractMultiset(a, b), added = subtractMultiset(b, a), expected = expectedDeltas[material];
  assert.equal(a.length, expected.before); assert.equal(b.length, expected.after);
  assert.equal(removed.length, expected.removed); assert.equal(added.length, expected.added);
  assert.equal(a.length - removed.length, expected.retained);
  assert.equal(b.length - added.length, expected.retained);
  assertEnvelope(removed, expected.removedBounds, material + ' removed');
  assertEnvelope(added, expected.addedBounds, material + ' added');
  assert.equal(hashTriangles(removed), evidence.triangleDeltas[material].removedSha256);
  assert.equal(hashTriangles(added), evidence.triangleDeltas[material].addedSha256);
});

test('mage shoulder: all six engraved segments expose their dark floor at 18 first-surface probes', () => {
  assert.equal(evidence.grooveRays.length, 18);
  assert.equal(new Set(evidence.grooveRays.map(row => JSON.stringify([row.origin, row.direction]))).size, 18, 'distinct probe rays');
  assert.deepEqual([...new Set(evidence.grooveRays.map(row => row.segment))], [0,1,2,3,4,5]);
  for (const segment of [0,1,2,3,4,5]) assert.equal(evidence.grooveRays.filter(row => row.segment === segment).length, 3);
  for (const row of evidence.grooveRays) {
    const hit = ray(after, row.origin, row.direction);
    assert(hit, 'groove hit'); assert.equal(name(hit), 'Steel engraved marks');
    assert(Math.abs(hit.point.z - .202) < 1e-6, 'recessed floor position');
    assert(Math.abs(.2200000286102295 - hit.point.z - .018) < 1e-6, 'fitted 0.018 model-unit recess');
  }
});

test('mage shoulder: all 36 fitted sleeve-cap probes are behind the visible armor, never exposed', () => {
  assert.equal(evidence.sleeveCapRays.length, 36);
  assert.equal(new Set(evidence.sleeveCapRays.map(row => JSON.stringify([row.origin, row.direction]))).size, 36, 'distinct probe rays');
  for (const row of evidence.sleeveCapRays) {
    const cap = ray(after, row.origin, row.direction, 'Royal blue robe');
    const visible = ray(after, row.origin, row.direction);
    assert(cap && visible); assert(Math.abs(cap.point.z - .197) < 1e-6, 'probe actually reaches the new cap');
    assert(['Ancient steel armor', 'Steel engraved marks'].includes(name(visible)), 'cap is covered by armor');
    assert(visible.point.z - cap.point.z >= .005 - 1e-6, 'at least fitted 0.005 model-unit clearance');
  }
});

test('mage shoulder: the cuff cap stays hidden except the reviewed narrow inner-edge cloth strip', () => {
  assert.equal(evidence.cuffCapRays.length, 16);
  assert.equal(new Set(evidence.cuffCapRays.map(row => JSON.stringify([row.origin, row.direction]))).size, 16, 'distinct probe rays');
  let visibleCaps = 0;
  for (const row of evidence.cuffCapRays) {
    const hit = ray(after, row.origin, row.direction); assert(hit);
    if (name(hit) !== 'Hood and mantle | deep azure' || Math.abs(hit.point.z - .197) >= 1e-6) continue;
    visibleCaps++;
    assert(hit.point.x > .426 && hit.point.x < .434, 'cap stays beside inner armor edge');
    assert(hit.point.y > 1.320 && hit.point.y < 1.407, 'reviewed strip height');
  }
  assert.equal(visibleCaps, 4);
});

test('mage shoulder: 87 lower-sleeve first surfaces retain their material and original position', () => {
  assert.equal(evidence.lowerSleeveRays.length, 87);
  assert.equal(new Set(evidence.lowerSleeveRays.map(row => JSON.stringify([row.origin, row.direction]))).size, 87, 'distinct probe rays');
  for (const row of evidence.lowerSleeveRays) {
    const a = ray(before, row.origin, row.direction), b = ray(after, row.origin, row.direction);
    assert(a && b); assert.equal(name(a), row.material); assert.equal(name(b), row.material);
    assert(a.point.distanceTo(b.point) < 1e-7, 'lower sleeve surface moved');
  }
});

test('mage shoulder: all 17 collar and previously preserved surface probes remain exact', () => {
  assert.equal(evidence.preservedCollarRays.length, 17);
  assert.equal(new Set(evidence.preservedCollarRays.map(row => JSON.stringify([row.origin, row.direction]))).size, 17, 'distinct probe rays');
  for (const row of evidence.preservedCollarRays) {
    const a = ray(before, row.origin, row.direction), b = ray(after, row.origin, row.direction);
    assert(a && b); assert.equal(name(a), row.material); assert.equal(name(b), row.material);
    assert.deepEqual(b.point.toArray(), a.point.toArray());
  }
});

assert.deepEqual(evidence.placements, [[0,0,0], [12,3,-18], [-9,1.8,4]]);
for (const position of evidence.placements) test(`mage shoulder: actual attach normalization and collider stay exact at ${position.join(',')}`, () => {
  const attach = scene => {
    const group = new THREE.Group(), ring = new THREE.Group(); group.position.fromArray(position); group.add(ring);
    return attachCharacterTarget({group, ring}, {scene, id:'mage', label:'mage'});
  };
  const a = attach(before.scene), b = attach(actualMage.scene);
  assert.deepEqual(b.bounds, a.bounds);
  assert.deepEqual(b.character.position, a.character.position);
  assert.deepEqual(b.character.scale, a.character.scale);
  assert.deepEqual(b.ring.position, a.ring.position);
  assert.deepEqual(b.ring.scale, a.ring.scale);
  assert.equal(b.group.children.filter(child => child !== b.ring).length, 1);
});
