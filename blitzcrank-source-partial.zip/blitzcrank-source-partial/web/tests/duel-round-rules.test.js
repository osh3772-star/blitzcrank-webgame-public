import test from 'node:test';
import assert from 'node:assert/strict';
import { createDuelMatch, getDuelScope, isDuelState, transitionDuel } from '../duel-round-rules.js';

const options = { sessionId: 'session-a', playerIds: ['player-a', 'player-b'], countdownMs: 100, roundResetMs: 50 };
const create = (overrides = {}) => createDuelMatch({ ...options, ...overrides });
const command = (state, type, extra = {}) => ({ type, scope: getDuelScope(state), ...extra });
const reduce = (state, type, extra = {}) => transitionDuel(state, command(state, type, extra));
const points = (state) => state.scores.map((score) => score.points);
const clone = (state) => JSON.parse(JSON.stringify(state));

function accepted(result) {
  assert.equal(result.accepted, true, result.reason);
  assert.equal(isDuelState(result.state), true);
  return result.state;
}

function active(state = create().state) {
  if (state.phase === 'roundReset') state = accepted(reduce(state, 'step', { deltaMs: state.remainingMs || 1 }));
  if (state.phase === 'preparing') state = accepted(reduce(state, 'prepareRound'));
  if (state.phase === 'countdown') state = accepted(reduce(state, 'step', { deltaMs: state.remainingMs }));
  assert.equal(state.phase, 'active');
  return state;
}

function grab(state, winnerIndex = 0, extra = {}) {
  return reduce(state, 'confirmGrab', {
    eventId: `grab-${state.matchNumber}-${state.roundNumber}`,
    attackerId: state.playerIds[winnerIndex], targetId: state.playerIds[1 - winnerIndex],
    result: 'success', validated: true, ...extra,
  });
}

function rejected(result, state, reason) {
  assert.equal(result.accepted, false);
  assert.equal(result.changed, false);
  assert.equal(result.state, state);
  assert.equal(result.reason, reason);
  assert.deepEqual(result.effects, []);
}

test('creation has two stable independent scores and a scoped reset boundary', () => {
  const result = create();
  const state = accepted(result);
  assert.equal(state.phase, 'preparing');
  assert.deepEqual(points(state), [0, 0]);
  assert.deepEqual(state.playerIds, options.playerIds);
  assert.equal(state.roundNumber, 1);
  assert.equal(state.winsRequired, 3);
  assert.equal(state.maxRounds, 5);
  assert.deepEqual(result.effects, [{ type: 'reset-round', scope: getDuelScope(state) }]);
  assert.notEqual(state.playerIds, options.playerIds);
  assert.equal(Object.isFrozen(options.playerIds), false);
});

test('prepare acknowledgement starts countdown; only simulation steps advance it', () => {
  const initial = create().state;
  const start = reduce(initial, 'prepareRound');
  let state = accepted(start);
  assert.equal(state.phase, 'countdown');
  assert.equal(state.remainingMs, 100);
  assert.equal(start.effects[0].type, 'countdown-started');
  const paused = reduce(state, 'step', { deltaMs: 0 });
  assert.equal(paused.state, state);
  assert.equal(paused.changed, false);
  state = accepted(reduce(state, 'step', { deltaMs: 99.5 }));
  assert.equal(state.remainingMs, 0.5);
  const started = reduce(state, 'step', { deltaMs: 0.5 });
  state = accepted(started);
  assert.equal(state.phase, 'active');
  assert.equal(started.effects[0].type, 'round-started');
  assert.equal(initial.phase, 'preparing');
});

test('waiting on wall clock does not advance anything', async () => {
  const state = accepted(reduce(create().state, 'prepareRound'));
  const snapshot = clone(state);
  await new Promise((resolve) => setTimeout(resolve, 15));
  assert.deepEqual(state, snapshot);
  assert.equal(state.phase, 'countdown');
  assert.equal(state.remainingMs, 100);
});

test('a successful validated grab gives exactly one point, freezes round, then prepares next', () => {
  const before = active();
  const outcome = grab(before, 1);
  let state = accepted(outcome);
  assert.deepEqual(points(state), [0, 1]);
  assert.equal(state.phase, 'roundReset');
  assert.equal(state.roundNumber, 1);
  assert.equal(state.remainingMs, 50);
  assert.deepEqual(outcome.effects.map((item) => item.type), ['cancel-pending-work', 'round-scored', 'round-reset-started']);
  assert.deepEqual(outcome.effects[0].scope, getDuelScope(before));
  assert.deepEqual(outcome.effects[1].scope, getDuelScope(state));
  const reset = reduce(state, 'step', { deltaMs: 50 });
  state = accepted(reset);
  assert.equal(state.phase, 'preparing');
  assert.equal(state.roundNumber, 2);
  assert.deepEqual(points(state), [0, 1]);
  assert.deepEqual(state.playerIds, before.playerIds);
  assert.equal(reset.effects[0].type, 'reset-round');
  assert.equal(reduce(state, 'step', { deltaMs: 1e9 }).state, state, 'cannot bypass reset acknowledgement');
});

test('cast, miss, block, unvalidated or wrong-target grabs never score', () => {
  const state = active();
  for (const result of ['miss', 'blocked', 'cast', 'cancelled', undefined, true, 1, {}, null]) {
    rejected(grab(state, 0, { result }), state, 'non_scoring_result');
  }
  for (const validated of [false, undefined, 1, 'true', {}, null]) {
    rejected(grab(state, 0, { validated }), state, 'unvalidated_grab');
  }
  for (const [attackerId, targetId] of [['player-a', 'player-a'], ['player-b', 'player-b'], ['unknown', 'player-a'], ['player-a', 'unknown'], [null, 'player-b']]) {
    rejected(grab(state, 0, { attackerId, targetId }), state, 'invalid_opponents');
  }
  assert.deepEqual(points(state), [0, 0]);
});

test('grabs cannot score during prepare, countdown or round reset', () => {
  const preparing = create().state;
  const countdown = accepted(reduce(preparing, 'prepareRound'));
  const reset = accepted(grab(active()));
  for (const state of [preparing, countdown, reset]) {
    rejected(grab(state, 0, { eventId: 'different-event' }), state, 'wrong_phase');
  }
});

test('all 32 five-round winner sequences stop at first to three, never a sixth round', () => {
  for (let mask = 0; mask < 32; mask += 1) {
    let state = create().state;
    let rounds = 0;
    while (state.phase !== 'matchComplete') {
      state = active(state);
      const winnerIndex = (mask >> rounds) & 1;
      const scored = grab(state, winnerIndex);
      state = accepted(scored);
      rounds += 1;
      assert.equal(points(state).reduce((a, b) => a + b), rounds);
      assert.equal(state.history.length, rounds);
      assert.ok(rounds <= 5);
      if (state.phase === 'matchComplete') assert.equal(scored.effects.at(-1).type, 'match-completed');
    }
    assert.ok(rounds >= 3 && rounds <= 5);
    assert.equal(state.scores.find((score) => score.playerId === state.winnerId).points, 3);
    assert.ok(state.scores.find((score) => score.playerId !== state.winnerId).points <= 2);
    assert.equal(state.roundNumber, rounds);
    for (const type of ['step', 'prepareRound', 'confirmGrab', 'cancelMatch']) {
      rejected(reduce(state, type, { deltaMs: 1000 }), state, 'terminal_phase');
    }
  }
});

test('3–2 clincher completes immediately without scheduling round six or a reset', () => {
  let state = create().state;
  let result;
  for (const index of [0, 1, 1, 0, 0]) {
    result = grab(active(state), index);
    state = accepted(result);
  }
  assert.deepEqual(points(state), [3, 2]);
  assert.equal(state.winnerId, 'player-a');
  assert.equal(state.phase, 'matchComplete');
  assert.equal(state.remainingMs, 0);
  assert.equal(result.effects.some((item) => item.type === 'reset-round'), false);
});

test('duplicate confirmed event and stale round/phase scopes are rejected', () => {
  const before = active();
  const oldScope = getDuelScope(before);
  const first = accepted(grab(before));
  rejected(grab(first), first, 'duplicate_event');
  rejected(grab(first, 1, { scope: oldScope }), first, 'stale_phase');
  const next = active(first);
  rejected(grab(next, 1, { scope: oldScope }), next, 'stale_round');
  rejected(grab(next, 1, { eventId: 'grab-1-1' }), next, 'duplicate_event');
  assert.deepEqual(points(next), [1, 0]);
});

test('same-tick opposite confirmed grabs: first accepted valid event wins, no timestamp fairness claim', () => {
  for (const firstIndex of [0, 1]) {
    let state = active();
    const first = command(state, 'confirmGrab', {
      eventId: 'first', result: 'success', validated: true,
      attackerId: state.playerIds[firstIndex], targetId: state.playerIds[1 - firstIndex], clientTimestamp: 999999,
    });
    const second = command(state, 'confirmGrab', {
      eventId: 'second', result: 'success', validated: true,
      attackerId: state.playerIds[1 - firstIndex], targetId: state.playerIds[firstIndex], clientTimestamp: 0,
    });
    state = accepted(transitionDuel(state, first));
    rejected(transitionDuel(state, second), state, 'stale_phase');
    assert.equal(state.scores[firstIndex].points, 1);
    assert.equal(state.scores[1 - firstIndex].points, 0);
  }
});

test('invalid first event does not consume an otherwise valid round', () => {
  const state = active();
  rejected(grab(state, 0, { validated: false }), state, 'unvalidated_grab');
  const result = accepted(grab(state, 1));
  assert.deepEqual(points(result), [0, 1]);
});

test('restart invalidates old events, timer commands and reset completions, even in round one', () => {
  const original = active();
  const oldCommands = [command(original, 'step', { deltaMs: 1000 }), command(original, 'confirmGrab', { eventId: 'late', result: 'success', validated: true, attackerId: 'player-a', targetId: 'player-b' })];
  const oldPrepare = command(create().state, 'prepareRound');
  const restartCommand = command(original, 'restartMatch');
  const result = transitionDuel(original, restartCommand);
  let state = accepted(result);
  assert.equal(state.matchNumber, 2);
  assert.notEqual(state.matchId, original.matchId);
  assert.deepEqual(points(state), [0, 0]);
  assert.deepEqual(state.playerIds, original.playerIds);
  assert.deepEqual(result.effects.map((item) => item.type), ['cancel-pending-work', 'reset-round']);
  for (const pending of [...oldCommands, oldPrepare, restartCommand]) rejected(transitionDuel(state, pending), state, 'stale_match');
  state = active(state);
  for (const pending of oldCommands) rejected(transitionDuel(state, pending), state, 'stale_match');
});

test('cancel invalidates active callbacks, remains inert, and can restart cleanly', () => {
  const before = active();
  const old = command(before, 'confirmGrab', { eventId: 'late', result: 'success', validated: true, attackerId: 'player-a', targetId: 'player-b' });
  const result = reduce(before, 'cancelMatch');
  const state = accepted(result);
  assert.equal(state.phase, 'cancelled');
  assert.deepEqual(points(state), [0, 0]);
  assert.deepEqual(result.effects.map((item) => item.type), ['cancel-pending-work', 'match-cancelled']);
  rejected(transitionDuel(state, old), state, 'stale_phase');
  rejected(reduce(state, 'step', { deltaMs: 1000 }), state, 'terminal_phase');
  rejected(reduce(state, 'cancelMatch'), state, 'terminal_phase');
  assert.equal(accepted(reduce(state, 'restartMatch')).phase, 'preparing');
});

test('cancel from each nonterminal phase preserves already earned scores', () => {
  const afterPoint = accepted(grab(active()));
  for (const state of [create().state, accepted(reduce(create().state, 'prepareRound')), active(), afterPoint, active(afterPoint)]) {
    const cancelled = accepted(reduce(state, 'cancelMatch'));
    assert.equal(cancelled.phase, 'cancelled');
    assert.deepEqual(cancelled.scores, state.scores);
    assert.equal(cancelled.history, state.history);
  }
});

test('repeated prepare acknowledgement cannot start twice', () => {
  const before = create().state;
  const ack = command(before, 'prepareRound');
  const state = accepted(transitionDuel(before, ack));
  rejected(transitionDuel(state, ack), state, 'stale_phase');
  rejected(reduce(state, 'prepareRound'), state, 'wrong_phase');
});

test('zero countdown starts on prepare, zero reset still needs a positive simulation step', () => {
  const initial = create({ countdownMs: 0, roundResetMs: 0 }).state;
  const ready = reduce(initial, 'prepareRound');
  let state = accepted(ready);
  assert.equal(state.phase, 'active');
  assert.equal(ready.effects[0].type, 'round-started');
  state = accepted(grab(state));
  assert.equal(state.phase, 'roundReset');
  assert.equal(reduce(state, 'step', { deltaMs: 0 }).state, state);
  state = accepted(reduce(state, 'step', { deltaMs: 0.1 }));
  assert.equal(state.phase, 'preparing');
  assert.equal(state.roundNumber, 2);
});

test('a huge step stops at preparation; overflow does not bypass cleanup or countdown', () => {
  let state = accepted(grab(active()));
  state = accepted(reduce(state, 'step', { deltaMs: Number.MAX_SAFE_INTEGER }));
  assert.equal(state.phase, 'preparing');
  assert.equal(state.roundNumber, 2);
  state = accepted(reduce(state, 'prepareRound'));
  assert.equal(state.remainingMs, 100);
});

test('fractional steps are deterministic and partition-equivalent within a timed phase', () => {
  const initial = accepted(reduce(create().state, 'prepareRound'));
  let partitioned = initial;
  for (const deltaMs of [1.25, 10, 20.5, 68.25]) partitioned = accepted(reduce(partitioned, 'step', { deltaMs }));
  const single = accepted(reduce(initial, 'step', { deltaMs: 100 }));
  assert.deepEqual(partitioned, single);
});

test('invalid creation options fail safely without creating state', () => {
  for (const input of [undefined, null, false, 1, 'a', [], {}, { ...options, sessionId: '' }, { ...options, sessionId: ' padded' }, { ...options, sessionId: 'a\n' }, { ...options, playerIds: ['a', 'a'] }, { ...options, playerIds: ['a'] }, { ...options, playerIds: new Array(2) }, { ...options, playerIds: [null, 'b'] }, { ...options, playerIds: ['a', 'b', 'c'] }, ...[NaN, Infinity, -1, '0', null].map((countdownMs) => ({ ...options, countdownMs }))]) {
    const result = createDuelMatch(input);
    assert.equal(result.accepted, false);
    assert.equal(result.state, null);
    assert.deepEqual(result.effects, []);
  }
});

test('malformed commands, scope, deltas and event IDs fail without mutation', () => {
  const state = active();
  const snapshot = clone(state);
  for (const input of [undefined, null, 1, false, 'x', [], {}]) rejected(transitionDuel(state, input), state, 'invalid_command');
  for (const scope of [undefined, null, 1, {}, { ...getDuelScope(state), phaseNumber: NaN }]) rejected(reduce(state, 'step', { scope, deltaMs: 1 }), state, 'invalid_scope');
  for (const deltaMs of [undefined, null, NaN, Infinity, -Infinity, -1, '1', {}, Number.MAX_SAFE_INTEGER + 1]) rejected(reduce(state, 'step', { deltaMs }), state, 'invalid_delta');
  for (const eventId of [undefined, null, 1, '', ' ', 'a\nb', 'x'.repeat(201)]) rejected(grab(state, 0, { eventId }), state, 'invalid_event_id');
  rejected(reduce(state, 'unexpected'), state, 'unknown_command');
  assert.deepEqual(state, snapshot);
});

test('malformed or contradictory state is rejected, while valid JSON snapshots replay', () => {
  const state = active();
  const invalid = [undefined, null, 1, false, 'x', [], {}, { ...clone(state), scores: [{ playerId: 'player-a', points: 2 }, { playerId: 'player-b', points: 0 }] }, { ...clone(state), playerIds: new Array(2), scores: new Array(2) }, { ...clone(state), phase: 'matchComplete' }, { ...clone(state), roundNumber: 6 }, { ...clone(state), remainingMs: 1 }, { ...clone(state), history: new Array(1) }];
  for (const input of invalid) {
    assert.equal(isDuelState(input), false);
    assert.equal(getDuelScope(input), null);
    rejected(transitionDuel(input, command(state, 'step', { deltaMs: 1 })), null, 'invalid_state');
  }
  const restored = clone(state);
  assert.equal(isDuelState(restored), true);
  assert.deepEqual(grab(restored), grab(state));
});

test('all returned state, effect, history and score data is deeply frozen', () => {
  const result = grab(active());
  accepted(result);
  for (const value of [result, result.state, result.state.scores, result.state.scores[0], result.state.history, result.state.history[0], result.effects, result.effects[0], result.effects[0].scope]) assert.equal(Object.isFrozen(value), true);
  assert.throws(() => { result.state.scores[0].points = 3; }, TypeError);
  assert.throws(() => { result.effects[0].scope.matchNumber = 100; }, TypeError);
});

test('unexpected state fields and circular payload additions fail closed', () => {
  const state = clone(active());
  state.extra = state;
  assert.equal(isDuelState(state), false);
  rejected(transitionDuel(state, {}), null, 'invalid_state');
  const nested = clone(active());
  nested.scores[0].extra = nested;
  assert.equal(isDuelState(nested), false);
  rejected(transitionDuel(nested, {}), null, 'invalid_state');
});

test('non-property player IDs are stable and cannot corrupt scoring', () => {
  const state = active(create({ playerIds: ['__proto__', 'constructor'] }).state);
  const scored = accepted(grab(state, 1));
  assert.deepEqual(points(scored), [0, 1]);
  assert.equal(scored.history[0].winnerId, 'constructor');
});

test('a different session cannot send a command to the current session', () => {
  const current = active();
  const unrelated = active(create({ sessionId: 'session-b' }).state);
  rejected(reduce(current, 'cancelMatch', { scope: getDuelScope(unrelated) }), current, 'stale_match');
});

test('rematch after completion retains players and timing, clears scores and history', () => {
  let state = create().state;
  for (let round = 0; round < 3; round += 1) state = accepted(grab(active(state)));
  assert.equal(state.phase, 'matchComplete');
  const next = accepted(reduce(state, 'restartMatch'));
  assert.equal(next.matchNumber, 2);
  assert.equal(next.roundNumber, 1);
  assert.equal(next.winnerId, null);
  assert.deepEqual(next.playerIds, state.playerIds);
  assert.deepEqual(next.timing, state.timing);
  assert.deepEqual(points(next), [0, 0]);
  assert.deepEqual(next.history, []);
});

test('counter exhaustion fails closed rather than aliasing old scope identities', () => {
  const state = clone(active());
  state.matchNumber = Number.MAX_SAFE_INTEGER;
  state.matchId = `${state.sessionId}/match/${state.matchNumber}`;
  state.roundId = `${state.matchId}/round/1`;
  assert.equal(isDuelState(state), true);
  rejected(reduce(state, 'restartMatch'), state, 'counter_exhausted');
  const phaseExhausted = { ...clone(active()), phaseNumber: Number.MAX_SAFE_INTEGER };
  rejected(reduce(phaseExhausted, 'prepareRound'), phaseExhausted, 'counter_exhausted');
});

test('1,000 deterministic command traces conserve points and never award invalid events', () => {
  let seed = 123456789;
  const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32; };
  for (let run = 0; run < 1000; run += 1) {
    let state = create({ sessionId: `trace-${run}`, countdownMs: 0, roundResetMs: 0 }).state;
    for (let step = 0; step < 50 && state.phase !== 'matchComplete'; step += 1) {
      if (state.phase === 'preparing') state = accepted(reduce(state, 'prepareRound'));
      else if (state.phase === 'roundReset') state = accepted(reduce(state, 'step', { deltaMs: 1 }));
      else if (random() < 0.4) {
        const before = state;
        rejected(grab(state, 0, { result: random() < 0.5 ? 'miss' : 'blocked' }), state, 'non_scoring_result');
        assert.equal(state, before);
      } else state = accepted(grab(state, random() < 0.5 ? 0 : 1));
      assert.equal(points(state).reduce((a, b) => a + b), state.history.length);
      assert.ok(state.roundNumber <= 5);
    }
    assert.equal(state.phase, 'matchComplete');
  }
});
