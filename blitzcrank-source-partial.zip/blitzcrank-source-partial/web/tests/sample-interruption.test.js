import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameAudio} from '../game-audio.js';
function harness(options={}){
 const sources=[],listeners=new Set();
 const context={state:'suspended',currentTime:0,destination:{},
  addEventListener(type,fn){if(type==='statechange')listeners.add(fn);},
  removeEventListener(type,fn){if(type==='statechange')listeners.delete(fn);},
  setState(state,notify=true){this.state=state;if(notify)for(const fn of listeners)fn();},
  resume(){this.setState('running');return Promise.resolve();},close(){this.setState('closed');return Promise.resolve();},
  createGain(){return {connect(){},disconnect(){},gain:{cancelScheduledValues(){},setValueAtTime(){}}};},
  decodeAudioData(){return Promise.resolve({duration:.57});},
  createBufferSource(){const ctx=this,s={connect(){},disconnect(){this.disconnected=true;},start(){this.started=true;},stop(){this.stopped=true;this.onended?.();},get audible(){return ctx.state==='running'&&this.started&&!this.stopped&&!this.disconnected;}};sources.push(s);return s;}
 };
 const audio=createGameAudio({createContext:()=>context,fetchImpl:async()=>({ok:true,arrayBuffer:async()=>new ArrayBuffer(1)}),...options});
 return {audio,context,sources,listeners};
}
test('automatic AudioContext interruption/resume never replays an old sample',async()=>{
 const h=harness();await h.audio.unlock();assert(h.audio.playEvent('hookWindup'));const old=h.sources[0];assert(old.audible);
 h.context.setState('suspended');assert(!old.audible);
 h.context.setState('running');assert.equal(old.audible,false,'old Q sample becomes audible again after automatic resume');assert.equal(h.audio.status.active,0);
 assert(h.audio.playEvent('punchHit'));assert(h.sources.at(-1).audible);h.audio.dispose();assert.equal(h.listeners.size,0);
});
test('unlock before delayed statechange stops suspended samples',async()=>{
 const h=harness();await h.audio.unlock();h.audio.playEvent('hookWindup');const old=h.sources[0];h.context.setState('suspended',false);
 await h.audio.unlock();assert.equal(old.audible,false,'unlock resumes a frozen Q sample');h.audio.dispose();
});
test('event while context interrupted drops both event and stale sample',async()=>{
 const h=harness();await h.audio.unlock();h.audio.playEvent('hookWindup');const old=h.sources[0];h.context.setState('interrupted',false);
 assert.equal(h.audio.playEvent('punchHit'),false);h.context.setState('running');assert.equal(old.audible,false,'next event drops itself but keeps stale sample');h.audio.dispose();
});

test('unlock while other priority audio loads still discards a frozen ready sample',async()=>{
 let release,requests=0;const h=harness({fetchImpl:async()=>{if(++requests===2)await new Promise(resolve=>release=resolve);return{ok:true,arrayBuffer:async()=>new ArrayBuffer(1)};}});
 const pending=h.audio.unlock();await new Promise(resolve=>setImmediate(resolve));assert(h.audio.playEvent('hookWindup'));const old=h.sources[0];h.context.setState('suspended',false);
 const repeated=h.audio.unlock();assert.notEqual(repeated,pending);assert.equal(h.context.state,'running','new gesture resumes immediately despite pending preload');assert.equal(old.stopped,true,'cleanup must precede the new resume');assert.equal(h.audio.status.active,0);
 release();assert.deepEqual(await Promise.all([pending,repeated]),[true,true]);assert.equal(requests,2,'both cues fetch only once');h.context.setState('running');assert.equal(old.audible,false);h.audio.dispose();
});
test('one interruption clears simultaneous groups and repeated unlocks do not duplicate listeners',async()=>{
 const h=harness();await h.audio.unlock();await h.audio.unlock();assert.equal(h.listeners.size,2); // decoded samples plus existing neutral tones
 assert(h.audio.playEvent('hookWindup'));assert(h.audio.playEvent('punchHit'));assert.equal(h.audio.status.active,2);h.context.setState('interrupted');
 assert(h.sources.every(source=>source.stopped&&source.disconnected));assert.equal(h.audio.status.active,0);h.context.setState('running');assert(h.sources.every(source=>!source.audible));
 h.audio.dispose();assert.equal(h.listeners.size,0);
});
