import test from 'node:test';import assert from 'node:assert/strict';
import {createAuditedFlash} from '../rift-v49-audited-flash.js';
const pass=()=>({pass:true}),options={spawn:[0,0],bounds:{minX:-10,maxX:10,minZ:-10,maxZ:10},landingAudit:pass,pathAudit:pass,boundaryAudit:pass};
test('production resolver range is preserved and previews never mutate state',()=>{
 const c=createAuditedFlash(options),before=c.snapshot(),p=c.preview({aim:[20,0]});assert(p.accepted);assert(p.distance<=4&&p.distance>3.99);assert.deepEqual(c.snapshot(),before);
});
test('only successful casts move and start the existing 15-second cooldown',()=>{
 const c=createAuditedFlash(options),a=c.cast({aim:[4,0]});assert(a.accepted);assert.equal(c.snapshot().remaining,15);assert.equal(c.snapshot().casts,1);assert.equal(c.cast({aim:[8,0]}).reason,'cooldown');c.step(15);assert(c.snapshot().ready);
});
test('clear-path rejection preserves both position and cooldown',()=>{
 const c=createAuditedFlash({...options,pathAudit:()=>({pass:false})}),before=c.snapshot();assert.equal(c.cast({aim:[4,0]}).reason,'path-blocked');assert.deepEqual(c.snapshot(),before);
});
test('explicit landing-only allows interior crossing but still forbids boundary crossing',()=>{
 const c=createAuditedFlash({...options,pathAudit:()=>({pass:false})});assert(c.cast({aim:[4,0],policy:'landing-only'}).crossesRejectedPath);
 const d=createAuditedFlash({...options,boundaryAudit:()=>({pass:false})}),before=d.snapshot();assert.equal(d.cast({aim:[4,0],policy:'landing-only'}).reason,'boundary-crossing');assert.deepEqual(d.snapshot(),before);
});
test('resolver backs off a blocked endpoint to an audited landing',()=>{
 const c=createAuditedFlash({...options,landingAudit:([x])=>({pass:x<2})});const a=c.cast({aim:[4,0]});assert(a.accepted);assert(a.position[0]<2&&a.position[0]>1.99);
});
test('exceptions and malformed requests cannot partially consume a cast',()=>{
 const c=createAuditedFlash({...options,pathAudit:()=>{throw Error('audit failure');}}),before=c.snapshot();assert.throws(()=>c.cast({aim:[4,0]}));assert.deepEqual(c.snapshot(),before);
 for(const p of [{aim:[NaN,0]},{aim:[0,0]},{aim:[1,0],policy:'unknown'}])assert.equal(c.preview(p).accepted,false);assert.throws(()=>c.step(Infinity));assert.deepEqual(c.snapshot(),before);
});
test('cast recomputes its preview and cannot commit an earlier stale destination',()=>{
 let blocked=false;const c=createAuditedFlash({...options,landingAudit:([x])=>({pass:!blocked||x===0})});assert(c.preview({aim:[4,0]}).accepted);blocked=true;assert.equal(c.cast({aim:[4,0]}).accepted,false);assert.equal(c.snapshot().casts,0);
});
test('all eight XZ aim directions match the production yaw convention',()=>{
 for(const [x,z] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){
  const c=createAuditedFlash(options),r=c.preview({aim:[x*4,z*4]});assert(r.accepted);const d=Math.hypot(x,z);
  assert(Math.abs(r.position[0]-x/d*r.distance)<1e-12);assert(Math.abs(r.position[1]-z/d*r.distance)<1e-12);
 }
});
