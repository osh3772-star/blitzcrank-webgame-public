import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as THREE from '../vendor/three.module.js';
import {decodeModelBuffer} from '../model-codec.js';
import {PLAYER_MODELS} from '../player-model-manifest.js';
import {createWalkState,createFullbodyLocomotion,WALK_TUNING} from '../fullbody-locomotion.js';

import {rig,fingerMinimum} from './helpers/locomotion-rig.js';
function soleRange(mesh){mesh.updateWorldMatrix(true,false);const p=mesh.geometry.attributes.position,v=new THREE.Vector3();let min=Infinity,max=-Infinity;for(let i=0;i<p.count;i++){v.fromBufferAttribute(p,i).applyMatrix4(mesh.matrixWorld);min=Math.min(min,v.y);max=Math.max(max,v.y);}return{min,max};}

test('distance phase is independent of elapsed idle and frame rate',()=>{
 const a=createWalkState(),b=createWalkState();for(let i=0;i<60;i++)a.advance(1/60,{deltaZ:-.04});for(let i=0;i<30;i++)b.advance(1/30,{deltaZ:-.08});assert(Math.abs(a.inspect().phase-b.inspect().phase)<1e-12);
 const phase=a.inspect().phase;for(let i=0;i<600;i++)a.advance(1/60,{});assert.equal(a.inspect().phase,phase);assert.equal(a.inspect().blend,0);
});
test('zero-dt refresh, blocked movement, airborne travel, and reset do not make steps',()=>{
 const s=createWalkState();s.advance(1/60,{deltaZ:-.1});const before=s.inspect();s.advance(0,{deltaZ:-100});assert.deepEqual(s.inspect(),before);
 for(let i=0;i<60;i++)s.advance(1/60,{deltaX:0,deltaZ:0});assert.equal(s.inspect().phase,before.phase);assert.equal(s.inspect().blend,0);
 s.advance(1/60,{deltaZ:-.1});const phase=s.inspect().phase;for(let i=0;i<60;i++)s.advance(1/60,{deltaZ:-.1,grounded:false});assert.equal(s.inspect().phase,phase);assert.equal(s.inspect().blend,0);assert.equal(s.inspect().moving,false);
 s.reset();assert.equal(s.inspect().phase,0);assert.equal(s.inspect().blend,0);
});
test('direction reflects facing, backwards and strafe, without diagonal gain',()=>{
 for(const [dx,dz,yaw,x,z] of [[0,-1,0,0,1],[0,1,0,0,-1],[1,0,0,-1,0],[-1,0,0,1,0],[-1,0,Math.PI/2,0,1]]){
  const s=createWalkState();for(let i=0;i<100;i++)s.advance(.02,{deltaX:dx*.1,deltaZ:dz*.1,yaw});assert(Math.abs(s.inspect().directionX-x)<1e-5);assert(Math.abs(s.inspect().directionZ-z)<1e-5);
 }
 const a=createWalkState(),b=createWalkState();a.advance(.02,{deltaZ:-.1});b.advance(.02,{deltaZ:-.1/Math.SQRT2,deltaX:.1/Math.SQRT2});assert(Math.abs(a.inspect().phase-b.inspect().phase)<1e-10);
});
test('actual rig calibrated knee is at visible joint, rest returns exact transforms',()=>{
 const {motion,nodes,body}=rig(),rest=new Map([...nodes].map(([n,o])=>[n,{p:o.position.toArray(),q:o.quaternion.toArray()}]));
 for(const leg of motion.inspect().legs){assert(Math.abs(leg.kneeCenter[1]-.5416)<1e-5);assert(leg.upperLength>.38&&leg.upperLength<.39);assert(leg.lowerLength>.4&&leg.lowerLength<.41);}
 for(let i=0;i<30;i++){motion.advance(1/60,{deltaZ:-6.4/60});motion.restorePose();body.position.y=motion.applyPose();}
 assert(Math.abs(nodes.get('BC_Knee.L').quaternion.x)>.02);
 motion.restorePose();for(const [n,o]of nodes){assert.deepEqual(o.position.toArray(),rest.get(n).p,n);assert.deepEqual(o.quaternion.toArray(),rest.get(n).q,n);}
 motion.reset();assert.equal(motion.applyPose(),0);
});
test('actual transformed soles remain at floor in stance and lift in swing across directions',()=>{
 const report=[];
 for(const [name,deltaX,deltaZ]of [['forward',0,-6.4/120],['backward',0,6.4/120],['right',6.4/120,0],['diagonal',6.4/120/Math.SQRT2,-6.4/120/Math.SQRT2]]){
  const{motion,body,meshes}=rig();let lowest=Infinity,stanceError=0,maxLift=0,clamps=0,maxTargetError=0,maxSoleTilt=0;
  for(let i=0;i<480;i++){
   motion.advance(1/120,{deltaX,deltaZ});motion.restorePose();body.position.y=motion.applyPose();body.updateMatrixWorld(true);
   for(const leg of motion.inspect().legs){const sole=soleRange(meshes.get('BC_FootSole.'+leg.side));lowest=Math.min(lowest,sole.min);if(leg.step.stance){stanceError=Math.max(stanceError,Math.abs(sole.min));const n=new THREE.Vector3(0,1,0).transformDirection(meshes.get('BC_FootSole.'+leg.side).matrixWorld);maxSoleTilt=Math.max(maxSoleTilt,n.angleTo(new THREE.Vector3(0,1,0)));}else maxLift=Math.max(maxLift,sole.min);if(leg.clamped)clamps++;maxTargetError=Math.max(maxTargetError,leg.targetError);}
  }
  report.push({name,lowest,stanceError,maxLift,clamps,maxTargetError,maxSoleTilt});
  assert.equal(clamps,0,name+' reach clamp');assert(maxSoleTilt<1e-7,name+' support sole tilted: '+maxSoleTilt);assert(lowest>-.0001,name+' penetrates ground: '+lowest);assert(stanceError<.003,name+' stance misses floor: '+stanceError);assert(maxLift>.06,name+' swing never lifts: '+maxLift);
 }
 // Test does not rewrite evidence.
});
test('repeated apply is stable and zero-dt cannot accumulate bob or knee transform',()=>{
 const{motion,body,nodes}=rig();for(let i=0;i<30;i++)motion.advance(1/60,{deltaZ:-.1});motion.restorePose();body.position.y=motion.applyPose();const height=body.position.y,knee=nodes.get('BC_Knee.L').matrixWorld.clone();body.updateMatrixWorld(true);const before=nodes.get('BC_Knee.L').matrixWorld.clone();
 for(let i=0;i<100;i++){motion.advance(0,{deltaZ:-100});motion.restorePose();body.position.y=motion.applyPose();body.updateMatrixWorld(true);}assert.equal(body.position.y,height);assert.deepEqual(nodes.get('BC_Knee.L').matrixWorld.elements,before.elements);
});

test('cadence is capped at 2.1 cycles/s independently of forward, diagonal, or boosted speed',()=>{
 for(const speed of [.1,.5,1.6,6.4,9.92,30])for(const angle of [0,.7,Math.PI/2,Math.PI]){
  const s=createWalkState();for(let i=0;i<300;i++)s.advance(1/120,{deltaX:-Math.sin(angle)*speed/120,deltaZ:-Math.cos(angle)*speed/120});
  const limit=1/(Math.abs(s.pose.directionX/WALK_TUNING.sideReach)**1.5+Math.abs(s.pose.directionZ/WALK_TUNING.forwardReach)**1.5)**(1/1.5),comfortable=WALK_TUNING.slowCycleDistance+(WALK_TUNING.cycleDistance-WALK_TUNING.slowCycleDistance)*Math.min(speed,1),nominal=Math.min(comfortable,2*.78*limit/WALK_TUNING.stanceFraction);assert(Math.abs(s.pose.cadence-Math.min(speed/nominal,WALK_TUNING.maxCadence))<1e-12);assert(s.pose.cadence<=2.1+1e-12);
 }
});

test('steady low-speed forward support cancels root travel; strafe and diagonals stay direction aligned',()=>{
 for(const speed of [.1,.5,1,1.6])for(const angle of [0,Math.PI]){
  const s=createWalkState(),dt=1/1000,deltaX=-Math.sin(angle)*speed*dt,deltaZ=-Math.cos(angle)*speed*dt;
  for(let i=0;i<4000;i++)s.advance(dt,{deltaX,deltaZ});
  let old=s.sample('L');for(let i=0;i<4000;i++){s.advance(dt,{deltaX,deltaZ});const n=s.sample('L');if(old.stance&&n.stance&&n.phase>old.phase){assert(Math.hypot(deltaX-.78*(n.x-old.x),deltaZ-.78*(n.z-old.z))<1e-10);}old=n;}
 }
 for(const angle of [.2,.7,1.2,Math.PI/2,2.4]){
  const s=createWalkState();for(let i=0;i<500;i++)s.advance(.01,{deltaX:-Math.sin(angle)*.064,deltaZ:-Math.cos(angle)*.064});const p=s.sample('L');assert(Math.abs(p.x*Math.cos(angle)-p.z*Math.sin(angle))<1e-12);
 }
});

test('stance and recovery have continuous positions and first derivatives, with bounded overshoot',()=>{
 const t=WALK_TUNING,m=-2*(1-t.stanceFraction)/t.stanceFraction;
 const x=u=>-1+m*u+(6-3*m)*u*u+(-4+2*m)*u*u*u,derivative=u=>m+2*(6-3*m)*u+3*(-4+2*m)*u*u;
 assert.equal(x(0),-1);assert.equal(x(1),1);assert.equal(derivative(0)/(1-t.stanceFraction),-2/t.stanceFraction);assert.equal(derivative(1)/(1-t.stanceFraction),-2/t.stanceFraction);
 let max=0;for(let i=0;i<=10000;i++)max=Math.max(max,Math.abs(x(i/10000)));assert(max<1.08867);assert(max>1.0886);
});

test('actual vertices stay clear through 16 directions, speeds, hard reversals, turns, stops, airborne and restart',()=>{
 const r=rig();let minFinger=Infinity,clamps=0,maxSupportError=0,maxJump=0,previous=null;
 function frame(speed,angle,{air=false,yaw=0}={}){
  const dt=1/120;r.motion.advance(dt,{deltaX:-Math.sin(angle)*speed*dt,deltaZ:-Math.cos(angle)*speed*dt,yaw,grounded:!air});r.motion.restorePose();r.body.position.y=r.motion.applyPose();r.body.updateMatrixWorld(true);
  minFinger=Math.min(minFinger,fingerMinimum(r.fingers));
  const diagnostics=r.motion.inspect();for(const l of diagnostics.legs){clamps+=+l.clamped;const y=soleRange(r.meshes.get('BC_FootSole.'+l.side)).min;if(l.step.stance)maxSupportError=Math.max(maxSupportError,Math.abs(y));}
  const p=r.nodes.get('BC_Pivot_Ankle.L').getWorldPosition(new THREE.Vector3());if(previous)maxJump=Math.max(maxJump,p.distanceTo(previous));previous=p;
 }
 for(const speed of [.1,1.6,6.4,9.92])for(let angle=0;angle<16;angle++){r.motion.reset();previous=null;for(let i=0;i<180;i++)frame(speed,angle*Math.PI/8);}
 // No reset between these cases: actual blend/direction/stride state must adapt.
 for(let i=0;i<360;i++)frame(6.4,0);for(let i=0;i<120;i++)frame(6.4,Math.PI/2);for(let i=0;i<120;i++)frame(6.4,Math.PI);for(let i=0;i<120;i++)frame(.1,Math.PI);for(let i=0;i<120;i++)frame(9.92,.5);for(let i=0;i<120;i++)frame(6.4,2,{air:true});for(let i=0;i<120;i++)frame(0,0);for(let i=0;i<120;i++)frame(6.4,0,{yaw:1.5});
 assert.equal(clamps,0);assert(minFinger>.01,'finger clearance '+minFinger);assert(maxSupportError<1e-6,'support error '+maxSupportError);assert(maxJump<.12,'ankle jump per 120Hz frame '+maxJump);
});

import {bindSkillClips,createFullbodyPoseApplicator,clearFullbodySkillPose} from '../skill-animation.js';
import {SKILL_ASSET} from '../skill-animation-manifest.js';
test('every authored W/E/R clip is exactly identical after walking/restoring versus untouched rig',()=>{
 const data=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))),walked=rig(),fresh=rig(),apply=createFullbodyPoseApplicator(THREE),a=[...walked.meshes.values()],b=[...fresh.meshes.values()],clips=bindSkillClips(data.models.fullbody,a);
 for(const clip of clips)for(const fraction of [0,.5,1]){
  for(let i=0;i<100;i++){walked.motion.advance(1/60,{deltaX:.04,deltaZ:-.08});walked.motion.restorePose();walked.body.position.y=walked.motion.applyPose();}
  walked.motion.restorePose();walked.body.position.y=0;
  apply(clip,clip.duration*fraction,a);apply(clip,clip.duration*fraction,b);walked.body.updateMatrixWorld(true);fresh.body.updateMatrixWorld(true);
  for(let i=0;i<a.length;i++)assert.deepEqual(a[i].matrixWorld.elements,b[i].matrixWorld.elements,clip.name+' '+fraction+' '+a[i].name);
  clearFullbodySkillPose(a);clearFullbodySkillPose(b);
 }
});


test('comfortable forward steps are slower at 1.6 m/s while lateral and diagonal cadence preserve matching',()=>{
 for(const speed of [.02,.1,.5,1,1.6,6.4])for(const angle of [0,.05,.12,.4,Math.PI/4,Math.PI/2,Math.PI]){
  const s=createWalkState();for(let i=0;i<800;i++)s.advance(.01,{deltaX:-Math.sin(angle)*speed*.01,deltaZ:-Math.cos(angle)*speed*.01});
  if(speed===1.6&&angle===0){assert(Math.abs(s.pose.cadence-1.6/.88)<1e-12);assert(Math.abs(s.pose.stride-.88*.5/(2*.78))<1e-12);}
  if(speed===6.4)assert.equal(s.pose.cadence,2.1);
  if(speed<=1)assert(s.pose.cadence<=2.1);
 }
});
