import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {TURRET_MODEL_FILE} from '../turret-view.js';

const manifest = JSON.parse(fs.readFileSync(new URL('../assets/turret/turret-manifest.json', import.meta.url)));
const bytes = fs.readFileSync(new URL('../assets/turret/' + TURRET_MODEL_FILE, import.meta.url));
const gltf = JSON.parse(bytes.subarray(20, 20 + bytes.readUInt32LE(12)));
const primitives = gltf.meshes.flatMap(mesh => mesh.primitives);

test('turret manifest identifies the actual loader asset and content digest', () => {
  assert.equal(manifest.file, TURRET_MODEL_FILE);
  assert.equal(manifest.sha256, crypto.createHash('sha256').update(bytes).digest('hex'));
  assert.equal(manifest.file, 'turret.' + manifest.sha256.slice(0, 16) + '.glb');
});

test('turret manifest cost counts describe the actual runtime GLB', () => {
  assert.equal(manifest.bytes, bytes.length);
  assert.equal(manifest.meshes, gltf.meshes.length);
  assert.equal(manifest.primitives, primitives.length);
  assert.equal(manifest.materials, gltf.materials.length);
  assert.equal(manifest.animations, (gltf.animations || []).length);
  for (const primitive of primitives) assert.equal(primitive.mode ?? 4, 4);
  assert.equal(manifest.triangles, primitives.reduce((sum, primitive) => sum + gltf.accessors[primitive.indices].count / 3, 0));
});
