import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {blitzMaterialProperties,blitzMaterialKey,createBlitzMaterial,loadBlitzTextures,attachBlitzUV} from '../blitz-materials.js';
test('source part PBR values and eye emission survive without color conversion',()=>{
 const part={color:[.55,.27,.045,1],material:{metalness:.82,roughness:.41,emissive:[.8,.46,.08],emissiveIntensity:2.4}},mat=createBlitzMaterial(THREE,part);
 assert.deepEqual(mat.color.toArray(),part.color.slice(0,3));assert.deepEqual(mat.emissive.toArray(),part.material.emissive);
 assert.equal(mat.metalness,.82);assert.equal(mat.roughness,.41);assert.equal(mat.emissiveIntensity,2.4);
});
test('legacy assets retain their original defaults and opaque colors',()=>{
 const p=blitzMaterialProperties({color:[.2,.3,.4,1]},{metalness:.76,roughness:.34});
 assert.deepEqual(p,{color:[.2,.3,.4],metalness:.76,roughness:.34,emissive:[0,0,0],emissiveIntensity:1});
});
test('material cache distinguishes steel, brass and emissive pieces with identical color',()=>{
 const base={color:[.5,.3,.1,1]},steel={...base,material:{metalness:.8,roughness:.6}},eyes={...base,material:{emissive:[1,.7,.1],emissiveIntensity:3}};
 assert.notEqual(blitzMaterialKey(base),blitzMaterialKey(steel));assert.notEqual(blitzMaterialKey(base),blitzMaterialKey(eyes));assert.equal(blitzMaterialKey(eyes),blitzMaterialKey(structuredClone(eyes)));
});
test('authored UVs retain per-corner order and malformed textured parts fail clearly',()=>{
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute([0,0,0,1,0,0,0,1,0],3));
 const part={name:'armor',uvs:[0,0,1,0,0,1]};attachBlitzUV(THREE,g,part);assert.deepEqual(Array.from(g.attributes.uv.array),part.uvs);
 assert.throws(()=>attachBlitzUV(THREE,g,{name:'bad',uvs:[1,2]}),/Invalid player UVs/);
 assert.throws(()=>attachBlitzUV(THREE,g,{name:'missing',material:{baseColorTexture:'./assets/blitz-materials/armor.png'}}),/no UVs/);
});
test('bundled maps preload once and keep sRGB albedo separate from linear roughness',async()=>{
 const paths=[],loader={async loadAsync(path){paths.push(path);return new THREE.Texture();}},bank=new Map();
 const part={color:[1,1,1,1],material:{baseColorTexture:'./assets/blitz-materials/yellow.png',roughnessTexture:'./assets/blitz-materials/rough.png'}},data={parts:[part,structuredClone(part)]};
 await loadBlitzTextures(THREE,data,bank,loader);await loadBlitzTextures(THREE,data,bank,loader);assert.equal(paths.length,2);
 const m=createBlitzMaterial(THREE,part,undefined,bank);assert.equal(m.map.colorSpace,THREE.SRGBColorSpace);assert.equal(m.roughnessMap.colorSpace,THREE.NoColorSpace);assert.equal(m.map.anisotropy,4);assert.equal(m.map.wrapS,THREE.RepeatWrapping);assert.equal(m.roughnessMap.wrapT,THREE.RepeatWrapping);
 assert.notEqual(blitzMaterialKey(part),blitzMaterialKey({...part,material:{}}));
});
test('unready or external texture references cannot silently substitute blank artwork',async()=>{
 assert.throws(()=>createBlitzMaterial(THREE,{material:{baseColorTexture:'./assets/blitz-materials/yellow.png'}}),/not ready/);
 await assert.rejects(loadBlitzTextures(THREE,{parts:[{material:{baseColorTexture:'https://example.com/a.png'}}]},new Map(),{loadAsync(){throw new Error('should not fetch');}}),/Invalid player texture path/);
});
test('failed texture fetch clears cache for a later explicit reload',async()=>{
 const data={parts:[{material:{baseColorTexture:'./assets/blitz-materials/yellow.png'}}]},bank=new Map();
 await assert.rejects(loadBlitzTextures(THREE,data,bank,{async loadAsync(){throw new Error('missing');}}),/missing/);assert.equal(bank.size,0);
 await loadBlitzTextures(THREE,data,bank,{async loadAsync(){return new THREE.Texture();}});assert.equal(bank.size,1);
});
