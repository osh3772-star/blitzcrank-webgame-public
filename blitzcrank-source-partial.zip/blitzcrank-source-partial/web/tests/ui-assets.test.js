import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('mechanical action art is self-contained and all image references resolve',()=>{
 const html=read('index.html');
 for(const action of ['punch','jump']){
  const file=`assets/ui/${action}.svg`,svg=read(file);
  assert(svg.includes('viewBox="0 0 48 48"'));
  assert(!/<script|<foreignObject|<image|href=|url\(/i.test(svg));
  assert(html.includes(file),`${action} is in the actual UI`);
 }
 for(const [,src] of html.matchAll(/<img[^>]+src="([^"]+)"/g))assert(fs.existsSync(new URL('../'+src,import.meta.url)),src);
});
test('reskin preserves action IDs, semantic labels and native buttons',()=>{
 const html=read('index.html');
 for(const id of ['start','practice','pause','viewtoggle','sound','capturestart','mousecapture','touchhook','touchpunch','touchjump'])assert.equal((html.match(new RegExp(`<button[^>]*id="${id}"`,'g'))??[]).length,1,id);
 for(const label of ['로켓 손 발사','펀치','점프'])assert(html.includes(`aria-label="${label}"`));
 assert(!html.includes('↗'));
});
