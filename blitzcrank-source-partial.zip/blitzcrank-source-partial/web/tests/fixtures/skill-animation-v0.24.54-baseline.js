// Animation-only companion data. No player geometry or texture is duplicated.
export function validateSkillAsset(data, expected = {}) {
  if (data?.version !== 1 || !data.models) throw new Error('Invalid skill animation version');
  for (const type of ['viewmodel', 'fullbody']) {
    const model = data.models[type];
    if (!model || !Array.isArray(model.sourceParts) || !model.sourceParts.length || new Set(model.sourceParts).size !== model.sourceParts.length) throw new Error('Invalid skill source parts: ' + type);
    if (model.sourceParts.some(n => typeof n !== 'string' || !n)) throw new Error('Invalid skill part name');
    if (expected[type]) {
      const names = new Set(expected[type]);
      if (names.size !== model.sourceParts.length || model.sourceParts.some(n => !names.has(n))) throw new Error('Skill model mismatch: ' + type);
    }
    if (!Array.isArray(model.clips) || !model.clips.length) throw new Error('No skill clips');
    const names = new Set();
    for (const clip of model.clips) {
      if (typeof clip.name !== 'string' || names.has(clip.name)) throw new Error('Invalid skill clip name');
      names.add(clip.name);
      if (clip.events != null && (!Array.isArray(clip.events) || clip.events.some(e => typeof e.type !== 'string' || !e.type || !Number.isFinite(e.time) || e.time < 0 || e.time > clip.duration))) throw new Error('Invalid skill events');
      if (typeof clip.loop !== 'boolean') throw new Error('Invalid skill loop flag');
      if (!Number.isFinite(clip.fps) || clip.fps <= 0 || clip.fps > 120 || !Number.isFinite(clip.duration) || clip.duration <= 0 || !Array.isArray(clip.frames) || clip.frames.length < 2 || clip.frames.length > 3600) throw new Error('Invalid skill timeline');
      if (Math.abs((clip.frames.length - 1) / clip.fps - clip.duration) > 1e-4) throw new Error('Skill duration/frame mismatch');
      for (const frame of clip.frames) {
        if (!Array.isArray(frame.poses) || frame.poses.length !== model.sourceParts.length) throw new Error('Skill pose count mismatch');
        for (const pose of frame.poses) {
          for (const [key, size] of [['p', 3], ['q', 4], ['s', 3]]) if (!Array.isArray(pose[key]) || pose[key].length !== size || !pose[key].every(Number.isFinite)) throw new Error('Invalid skill transform');
          const qlen = Math.hypot(...pose.q);
          if (Math.abs(qlen - 1) > .005 || pose.s.some(s => s <= 0)) throw new Error('Invalid skill quaternion/scale');
        }
      }
    }
  }
  return data;
}

export function clipFramePair(clip, time) {
  const safe = Number.isFinite(time) ? Math.max(0, time) : 0;
  const t = clip.loop ? safe % clip.duration : Math.min(safe, clip.duration);
  const frame = t * clip.fps;
  const a = Math.min(Math.floor(frame), clip.frames.length - 1);
  return {a, b: Math.min(a + 1, clip.frames.length - 1), u: frame - a};
}

/** Expand by name, never rely on mesh order or material-split counts. */
export function bindSkillClips(model, parts) {
  const names = new Map(model.sourceParts.map((name, i) => [name, i]));
  const indices = parts.map(part => {
    const name = part.sourcePart || part.userData?.sourcePart || part.name;
    if (!names.has(name)) throw new Error('Unmapped skill part: ' + name);
    return names.get(name);
  });
  return model.clips.map(clip => ({...clip, frames: clip.frames.map(frame => ({poses: indices.map(i => frame.poses[i])}))}));
}

/** Root-space rigid delta -> a surface beneath its unchanged rest-position node.
 * P(node) * [inverse(P(node)) * delta * P(node)] * (vertex - node) = delta * vertex.
 * Call only after clearing the existing procedural pivot pose. */
export function createFullbodyPoseApplicator(THREE) {
  const q1 = new THREE.Quaternion(), q2 = new THREE.Quaternion();
  const p = new THREE.Vector3(), s = new THREE.Vector3(), p2 = new THREE.Vector3(), s2 = new THREE.Vector3();
  const delta = new THREE.Matrix4(), translation = new THREE.Matrix4();
  return function apply(clip, time, surfaces) {
    const {a, b, u} = clipFramePair(clip, time);
    let previousX, previousY;
    for (let i = 0; i < surfaces.length; i++) {
      const mesh = surfaces[i], rest = mesh.userData.skillRestPoint;
      if (!rest || rest.length !== 3) throw new Error('Missing skill rest point: ' + mesh.name);
      const x = clip.frames[a].poses[i], y = clip.frames[b].poses[i];
      // Material-split neighbors share the same bound pose objects. Reuse only
      // within this call; distinct endpoints and later frames always resample.
      if (i === 0 || x !== previousX || y !== previousY) {
        p.fromArray(x.p).lerp(p2.fromArray(y.p), u);
        s.fromArray(x.s).lerp(s2.fromArray(y.s), u);
        q1.fromArray(x.q).normalize(); q2.fromArray(y.q).normalize(); q1.slerp(q2, u);
        delta.compose(p, q1, s);
        previousX = x; previousY = y;
      }
      mesh.matrixAutoUpdate = false;
      mesh.matrix.makeTranslation(-rest[0], -rest[1], -rest[2]).multiply(delta).multiply(translation.makeTranslation(...rest));
      mesh.matrixWorldNeedsUpdate = true;
    }
  };
}
export function clearFullbodySkillPose(surfaces) {
  for (const mesh of surfaces) {
    mesh.matrixAutoUpdate = true;
    mesh.position.set(0, 0, 0); mesh.quaternion.identity(); mesh.scale.set(1, 1, 1);
    mesh.updateMatrix();
  }
}

/** Crossfade only the pelvis surface and both hip subtrees into the existing gait.
 * Torso (including arms) is a separate child of pelvis: exclude its entire subtree,
 * not names such as "Hip" that would miss material-split descendants.
 * Call after applying the authored pose to restored parents. Lower targets are
 * blended in model space, then converted back under their posed parents, so an
 * authored root-space delta is never accidentally applied twice by a bent knee.
 */
export function createFullbodyELocomotionLayer(THREE,{body,nodes,surfaces,locomotion}) {
 const pelvis=nodes.get('BC_Pelvis'),torso=nodes.get('BC_Torso');
 if(!pelvis||torso?.parent!==pelvis||['L','R'].some(side=>nodes.get('BC_Pivot_Hip.'+side)?.parent!==pelvis))throw new Error('Unexpected E locomotion pelvis hierarchy');
 const lower=surfaces.filter(mesh=>{for(let node=mesh;node;node=node.parent){if(node===torso)return false;if(node===pelvis)return true;}return false;});
 // Use the real hip, knee axle, and ankle anchors for rotation interpolation.
 // Interpolating rotations around model origin would pull hip collars apart.
 body.updateWorldMatrix(true,true);
 const anchors=new Map();
 for(const side of ['L','R']){
  const hip=nodes.get('BC_Pivot_Hip.'+side),knee=nodes.get('BC_Knee.'+side),ankle=nodes.get('BC_Pivot_Ankle.'+side);
  const kneeMesh=surfaces.find(mesh=>mesh.parent===knee);
  if(!kneeMesh?.geometry.boundingBox)throw new Error('Missing E locomotion knee geometry');
  anchors.set(hip,body.worldToLocal(hip.getWorldPosition(new THREE.Vector3())));
  anchors.set(knee,body.worldToLocal(kneeMesh.localToWorld(kneeMesh.geometry.boundingBox.getCenter(new THREE.Vector3()))));
  anchors.set(ankle,body.worldToLocal(ankle.getWorldPosition(new THREE.Vector3())));
 }
 const entries=lower.map(mesh=>{
  const pivot=new THREE.Vector3();
  for(let node=mesh.parent;node&&node!==pelvis;node=node.parent)if(anchors.has(node)){pivot.copy(anchors.get(node)).sub(new THREE.Vector3(...mesh.userData.skillRestPoint));break;}
  return {mesh,pivot,authored:new THREE.Matrix4()};
 });
 const inverseBody=new THREE.Matrix4(),parent=new THREE.Matrix4(),target=new THREE.Matrix4();
 const pivotA=new THREE.Vector3(),pivotB=new THREE.Vector3(),rotatedPivot=new THREE.Vector3();
 const p=new THREE.Vector3(),q=new THREE.Quaternion(),s=new THREE.Vector3(),p2=new THREE.Vector3(),q2=new THREE.Quaternion(),s2=new THREE.Vector3();
 return function apply() {
  const blend=locomotion.poseBlend??locomotion.blend;
  if(!blend)return 0; // Exact grounded stationary E; jump shares this lower-only boundary.
  // Save the authored target before moving any procedural parents.
  for(const {mesh,authored} of entries)authored.makeTranslation(...mesh.userData.skillRestPoint).multiply(mesh.matrix);
  const offset=locomotion.applyPose({armSwing:false});
  body.position.y+=offset;body.updateMatrixWorld(true);inverseBody.copy(body.matrixWorld).invert();
  for(const {mesh,pivot,authored} of entries){
   parent.multiplyMatrices(inverseBody,mesh.parent.matrixWorld);
   authored.decompose(p,q,s);parent.decompose(p2,q2,s2);
   // Authored feet are calibrated to the floor without gait's root drop. Keep
   // that world height on the authored side throughout the continuous blend.
   pivotA.copy(pivot).applyMatrix4(authored);pivotB.copy(pivot).applyMatrix4(parent);
   pivotA.y-=offset/body.scale.y;
   q.slerp(q2,blend);s.lerp(s2,blend);
   rotatedPivot.copy(pivot).multiply(s).applyQuaternion(q);
   p.copy(pivotA).lerp(pivotB,blend).sub(rotatedPivot);
   target.compose(p,q,s);
   mesh.matrix.copy(parent).invert().multiply(target);mesh.matrixWorldNeedsUpdate=true;
  }
  return offset;
 };
}

/** Content-addressed animation companion, gzip when supported and raw otherwise. */
export async function loadSkillAsset(entry,{fetchImpl=globalThis.fetch,DecompressionStreamImpl=globalThis.DecompressionStream}={}) {
 let stream;try{if(typeof DecompressionStreamImpl==='function')stream=new DecompressionStreamImpl('gzip');}catch{}
 const url=stream?entry.gzip:entry.raw,response=await fetchImpl(url,{cache:'force-cache'});
 if(!response.ok)throw new Error('Skill animation HTTP '+response.status+': '+url);
 let bytes=await response.arrayBuffer();if(bytes.byteLength>16*1024*1024)throw new Error('Skill animation exceeds size limit');
 const signature=new Uint8Array(bytes);if(signature[0]===0x1f&&signature[1]===0x8b){if(!stream)throw new Error('Unexpected compressed skill animation');try{bytes=await new Response(new Blob([bytes]).stream().pipeThrough(stream)).arrayBuffer();}catch{throw new Error('Skill animation decompression failed');}}
 if(bytes.byteLength!==entry.bytes)throw new Error('Skill animation byte length mismatch');
 return validateSkillAsset(JSON.parse(new TextDecoder().decode(bytes)));
}
