// Preserved v0.24.31 gameplay/timeline reference for presentation-only regression.
import {createSkillTimeline} from '../../skill-timeline.js';

// Original Rocket Hand training balance, not current League of Legends values.
export const SKILL_TUNING = Object.freeze({wCooldown:12,wDuration:4,wSlowDuration:2,wMoveMultiplier:1.55,wAttackMultiplier:1.5,wSlowMultiplier:.65,eCooldown:5,eArmedDuration:5,eRange:3.4,eKnockupDuration:1.1,eKnockupHeight:2.2,ePoints:80,rCooldown:12,rRadius:7,rPoints:60});
export const SKILL_CLIP_NAMES = Object.freeze(['W_Start','W_Loop','W_End','E_Charge','E_Hold','E_Strike','R_Cast']);

/** One simulation clock owns poses and impact events. Pause means no step(). */
export function createSkillController(clips,{onEvent=()=>{}}={}) {
 const byName = new Map(clips.map(c=>[c.name,c]));
 for(const name of SKILL_CLIP_NAMES)if(!byName.has(name))throw new Error('Missing skill clip: '+name);
 for(const [name,type,time] of [['E_Strike','power_fist_hit',.4],['R_Cast','static_field_discharge',.3]]){const events=byName.get(name).events?.filter(e=>e.type===type)||[];if(events.length!==1||Math.abs(events[0].time-time)>1e-6)throw new Error('Missing or incorrect skill impact event: '+type);}
 let cooldown={W:0,E:0,R:0},boost=0,slow=0,armed=0,phase=null;
 const w=createSkillTimeline({onComplete:({name})=>{if(name==='W_Start'&&boost>0)w.play(byName.get('W_Loop'));}});
 const action=createSkillTimeline({onEvent,onComplete:({name})=>{
  if(name==='E_Charge'){phase='E_Hold';armed=SKILL_TUNING.eArmedDuration;action.play(byName.get('E_Hold'));}
  else if(name==='R_Cast'&&armed>0){phase='E_Hold';action.play(byName.get('E_Hold'));}
  else {phase=null;}
 }});
 function cancelAction(){action.stop();phase=null;armed=0;}
 // Shared by casts and the HUD. Querying never mutates timelines or cooldowns.
 function blockReason(key,{busy=false}={}){
  if(!['W','E','R'].includes(key))return 'unknown';
  if(key!=='W'&&busy)return 'busy';
  if(cooldown[key]>0)return 'cooldown';
  if(key==='E'&&phase)return 'casting';
  if(key==='R'&&['E_Charge','E_Strike','R_Cast'].includes(phase))return 'casting';
  return null;
 }
 return {
  blockReason,
  castW(){if(blockReason('W'))return false;cooldown.W=SKILL_TUNING.wCooldown;boost=SKILL_TUNING.wDuration;slow=0;w.play(byName.get('W_Start'));return true;},
  castE({busy=false}={}){if(blockReason('E',{busy}))return false;cooldown.E=SKILL_TUNING.eCooldown;phase='E_Charge';action.play(byName.get(phase));return true;},
  strikeE({busy=false}={}){if(busy||phase!=='E_Hold')return false;armed=0;phase='E_Strike';action.play(byName.get(phase));return true;},
  castR({busy=false}={}){if(blockReason('R',{busy}))return false;action.stop();cooldown.R=SKILL_TUNING.rCooldown;phase='R_Cast';action.play(byName.get(phase));return true;},
  step(dt){if(!Number.isFinite(dt)||dt<=0)return;
   for(const key of Object.keys(cooldown))cooldown[key]=Math.max(0,cooldown[key]-dt);
   if(boost>0){boost=Math.max(0,boost-dt);if(boost===0){slow=SKILL_TUNING.wSlowDuration;w.play(byName.get('W_End'));}else w.step(dt);}else{slow=Math.max(0,slow-dt);w.step(dt);}
   if(armed>0){armed=Math.max(0,armed-dt);if(armed===0&&phase==='E_Hold')cancelAction();}
   action.step(dt);
  },
  reset(){w.stop();cancelAction();cooldown={W:0,E:0,R:0};boost=slow=0;},
  get animation(){return action.state||w.state;},
  get moveMultiplier(){return boost>0?SKILL_TUNING.wMoveMultiplier:slow>0?SKILL_TUNING.wSlowMultiplier:1;},
  get attackMultiplier(){return boost>0?SKILL_TUNING.wAttackMultiplier:1;},
  get blocksAttack(){return ['E_Charge','E_Strike','R_Cast'].includes(phase);},
  get status(){return {cooldown:{...cooldown},boost,slow,armed,phase,animation:action.state||w.state};}
 };
}
