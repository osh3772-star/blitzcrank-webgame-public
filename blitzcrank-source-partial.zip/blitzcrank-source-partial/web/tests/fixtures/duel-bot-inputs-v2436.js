/**
 * Deterministic local input source, not game authority. No renderer, clock,
 * callbacks, network, or actor writes. Pass the same public observations that
 * another input source could know; the shared simulation validates every input.
 */
const TAU = Math.PI * 2;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const angle = v => ((v + Math.PI) % TAU + TAU) % TAU - Math.PI;
const finite = (v, fallback = 0) => Number.isFinite(v) ? v : fallback;
const vector = v => v && ['x', 'y', 'z'].every(k => Number.isFinite(v[k]) && Math.abs(v[k]) <= 1e9)
  ? { x: v.x, y: v.y, z: v.z } : null;
const unit = (x, z) => { const n = Math.hypot(x, z); return n > 1e-9 ? { x: x / n, z: z / n } : { x: 0, z: 0 }; };
const toward = (current, target, maxStep) => angle(current + clamp(angle(target - current), -maxStep, maxStep));

function seedNumber(seed) {
  if (typeof seed === 'number' && Number.isFinite(seed)) return (seed >>> 0) || 0x9e3779b9;
  let hash = 2166136261;
  for (const c of String(seed)) hash = Math.imul(hash ^ c.charCodeAt(0), 16777619);
  return (hash >>> 0) || 0x9e3779b9;
}

function segmentIntersects(from, to, min, max, axes = ['x', 'y', 'z']) {
  let near = 0, far = 1;
  for (const k of axes) {
    const delta = to[k] - from[k];
    if (Math.abs(delta) < 1e-9) { if (from[k] < min[k] || from[k] > max[k]) return false; }
    else {
      let a = (min[k] - from[k]) / delta, b = (max[k] - from[k]) / delta;
      if (a > b) [a, b] = [b, a];
      near = Math.max(near, a); far = Math.min(far, b);
      if (near > far) return false;
    }
  }
  return true;
}

/**
 * tuning uses the actual simulation's playerSpeed, hookSpeed, maxRange,
 * cooldown and windup. Optional bodyRadius/eyeHeight are planning hints only.
 * arena min/max x/z are legal actor-center bounds, not wall mesh dimensions.
 * obstacles are static world AABBs {min:{x,y,z},max:{x,y,z}} copied at creation.
 */
export function createDuelBotInputs({ seed = 1, tuning, arena, obstacles = [] } = {}) {
  for (const key of ['playerSpeed', 'hookSpeed', 'maxRange', 'cooldown', 'windup']) {
    if (!Number.isFinite(tuning?.[key]) || tuning[key] <= 0 || tuning[key] > 1e6) throw new TypeError(`Positive simulation tuning.${key} is required`);
  }
  for (const k of ['x', 'z']) {
    if (!Number.isFinite(arena?.min?.[k]) || !Number.isFinite(arena?.max?.[k]) || Math.abs(arena.min[k]) > 1e9 || Math.abs(arena.max[k]) > 1e9 || arena.min[k] >= arena.max[k]) {
      throw new TypeError('arena must provide finite ordered min/max x/z actor-center bounds');
    }
  }
  const rules = { ...tuning };
  const bounds = { min: { x: arena.min.x, z: arena.min.z }, max: { x: arena.max.x, z: arena.max.z } };
  const radius = clamp(finite(tuning.bodyRadius, .7), 0, 1e6);
  const eyeHeight = clamp(finite(tuning.eyeHeight, 1.7), .1, 1e6);
  const cover = obstacles.map(box => {
    const min = vector(box?.min), max = vector(box?.max);
    if (!min || !max || ['x', 'y', 'z'].some(k => min[k] > max[k])) throw new TypeError('obstacles must be finite ordered world AABBs');
    return { min, max };
  });
  let baseSeed = seedNumber(seed), rng, time, initialized, aimYaw, aimPitch;
  let reactionDelay, nextSample, samples, perceived, wasVisible, visibleTime, freshPerception;
  let strafeSign, strafeUntil, nextShot, settleTime, shotErrorYaw, shotErrorPitch, shots;
  let lastMove, preferredDistance, searchPoint;
  const random = () => {
    rng ^= rng << 13; rng ^= rng >>> 17; rng ^= rng << 5; rng >>>= 0;
    return rng / 4294967296;
  };
  const chooseSearchPoint = () => {
    searchPoint = { x: bounds.min.x + (bounds.max.x - bounds.min.x) * (.2 + random() * .6),
      z: bounds.min.z + (bounds.max.z - bounds.min.z) * (.2 + random() * .6) };
  };
  const drawShotError = () => {
    // Stable during one attempt, not fresh noise every render frame.
    shotErrorYaw = (random() * 2 - 1) * .018;
    shotErrorPitch = (random() * 2 - 1) * .009;
  };
  function reset(options = {}) {
    if (Object.hasOwn(options, 'seed')) baseSeed = seedNumber(options.seed);
    rng = baseSeed; time = 0; initialized = false; aimYaw = 0; aimPitch = 0;
    reactionDelay = .24 + random() * .08;
    nextSample = 0; samples = []; perceived = null; wasVisible = false; visibleTime = 0; freshPerception = false;
    strafeSign = random() < .5 ? -1 : 1; strafeUntil = 1.2 + random() * 1.1;
    nextShot = 0; settleTime = 0; shots = 0; lastMove = { x: 0, z: 0 };
    preferredDistance = rules.maxRange * (.35 + random() * .1);
    drawShotError(); chooseSearchPoint();
  }
  function neutral(self) {
    return { move: { x: 0, z: 0 }, yaw: initialized ? aimYaw : angle(finite(self?.yaw)),
      pitch: initialized ? aimPitch : clamp(finite(self?.pitch), -1.2, 1.2), castQ: false, jump: false };
  }
  function clearSegment(from, to) { return !cover.some(o => segmentIntersects(from, to, o.min, o.max)); }
  function safeHeading(position, heading) {
    const reach = Math.max(radius + .15, rules.playerSpeed * .3);
    const end = { x: position.x + heading.x * reach, z: position.z + heading.z * reach };
    for (const k of ['x', 'z']) {
      // If a public actor starts outside a legal bound, allow motion inward.
      if (end[k] < bounds.min[k] && end[k] < position[k]) return false;
      if (end[k] > bounds.max[k] && end[k] > position[k]) return false;
    }
    const feet = position.y - eyeHeight;
    return !cover.some(o => {
      if (o.max.y <= feet + .08 || o.min.y >= position.y + 1.2) return false;
      const min = { x: o.min.x - radius - .05, z: o.min.z - radius - .05 };
      const max = { x: o.max.x + radius + .05, z: o.max.z + radius + .05 };
      const depth = p => Math.min(p.x - min.x, max.x - p.x, p.z - min.z, max.z - p.z);
      // A collision-corrected actor can sit in the planner's extra 5cm margin.
      // Permit an outward intent instead of getting stuck at that margin.
      if (depth(position) >= 0 && depth(end) < depth(position) - 1e-6) return false;
      return segmentIntersects(position, end, min, max, ['x', 'z']);
    });
  }
  function movement(position, target, searching = false) {
    const towardTarget = unit(target.x - position.x, target.z - position.z);
    const distance = Math.hypot(target.x - position.x, target.z - position.z);
    const radial = searching ? 1 : clamp((distance - preferredDistance) / 3, -.9, .9);
    const desired = unit(towardTarget.x * radial - towardTarget.z * .72 * strafeSign,
      towardTarget.z * radial + towardTarget.x * .72 * strafeSign);
    // Lookahead only chooses an input. Collision resolution stays in the sim.
    let best = { x: 0, z: 0 }, bestScore = -Infinity;
    for (const degrees of [0, 30, -30, 60, -60, 90, -90, 135, -135, 180]) {
      const turn = degrees * Math.PI / 180 * strafeSign, c = Math.cos(turn), s = Math.sin(turn);
      const candidate = { x: desired.x * c - desired.z * s, z: desired.x * s + desired.z * c };
      if (!safeHeading(position, candidate)) continue;
      const score = candidate.x * desired.x + candidate.z * desired.z +
        .16 * (candidate.x * lastMove.x + candidate.z * lastMove.z);
      if (score > bestScore) { bestScore = score; best = candidate; }
    }
    return best;
  }
  function step(observation = {}) {
    observation ||= {};
    const { self, opponent } = observation;
    const position = vector(self?.position), targetPosition = vector(opponent?.position);
    // Paused/inactive/invalid calls do not change timers, PRNG, queued observations
    // or held aim. The caller resets at each round/restart boundary.
    if (observation.active !== true || !Number.isFinite(observation.dt) || observation.dt <= 0 || !position || !targetPosition) return neutral(self);
    const dt = Math.min(observation.dt, .1); // A hitch cannot cause an instant turn.
    if (!initialized) { aimYaw = angle(finite(self.yaw)); aimPitch = clamp(finite(self.pitch), -1.2, 1.2); initialized = true; }
    time += dt;
    const visible = observation.canSeeOpponent !== false && clearSegment(position, targetPosition);
    if (!visible) {
      // Never learn current opponent motion through cover; retain last seen point
      // for repositioning only, and require a fresh reaction after reacquisition.
      samples = []; nextSample = time; visibleTime = 0; settleTime = 0; freshPerception = false;
    } else {
      visibleTime += dt;
      if (!wasVisible) { samples = []; nextSample = time; }
      if (time + 1e-9 >= nextSample) {
        const velocity = vector(opponent.velocity) || { x: 0, y: 0, z: 0 };
        // Observed velocity, capped to avoid malformed values producing huge lead.
        const speed = Math.hypot(velocity.x, velocity.y, velocity.z);
        const cap = Math.max(rules.playerSpeed * 2, 12);
        if (speed > cap) for (const k of ['x', 'y', 'z']) velocity[k] *= cap / speed;
        samples.push({ sampledAt: time, available: time + reactionDelay, position: targetPosition, velocity });
        nextSample += .12;
        if (nextSample <= time) nextSample = time + .12;
      }
      while (samples.length && samples[0].available <= time + 1e-9) { perceived = samples.shift(); freshPerception = true; }
    }
    wasVisible = visible;
    if (time >= strafeUntil) { strafeSign *= -1; strafeUntil = time + 1.2 + random() * 1.1; }
    if (!perceived && Math.hypot(searchPoint.x - position.x, searchPoint.z - position.z) < 2) chooseSearchPoint();
    let castQ = false;
    if (perceived) {
      lastMove = movement(position, perceived.position);
      if (visible && freshPerception && visibleTime >= reactionDelay) {
        const dist = Math.hypot(perceived.position.x - position.x, perceived.position.y - position.y, perceived.position.z - position.z);
        // Extrapolate the age of a delayed observation, then only part of the
        // prospective windup/travel. This is not access to a future position.
        const sampleAge = Math.max(0, time - perceived.sampledAt);
        const lead = Math.min(.7, sampleAge + Math.min(.35, (rules.windup + dist / rules.hookSpeed) * .45));
        const target = { x: perceived.position.x + perceived.velocity.x * lead,
          y: perceived.position.y + perceived.velocity.y * lead,
          z: perceived.position.z + perceived.velocity.z * lead };
        const dx = target.x - position.x, dy = target.y - position.y, dz = target.z - position.z;
        const desiredYaw = angle(Math.atan2(-dx, -dz) + shotErrorYaw);
        const desiredPitch = clamp(Math.atan2(dy, Math.hypot(dx, dz)) + shotErrorPitch, -1.2, 1.2);
        aimYaw = toward(aimYaw, desiredYaw, 2.6 * dt);
        aimPitch += clamp(desiredPitch - aimPitch, -1.8 * dt, 1.8 * dt);
        const aligned = Math.abs(angle(desiredYaw - aimYaw)) < .025 && Math.abs(desiredPitch - aimPitch) < .025;
        settleTime = aligned ? settleTime + dt : 0;
        const aimDistance = Math.hypot(dx, dy, dz);
        const aimEnd = { x: position.x - Math.sin(aimYaw) * Math.cos(aimPitch) * aimDistance,
          y: position.y + Math.sin(aimPitch) * aimDistance, z: position.z - Math.cos(aimYaw) * Math.cos(aimPitch) * aimDistance };
        const currentRange = Math.hypot(targetPosition.x - position.x, targetPosition.y - position.y, targetPosition.z - position.z);
        if (settleTime >= .085 && time >= nextShot && Number.isFinite(self.cooldown) && self.cooldown <= 0 &&
            self.canCastQ !== false && !self.hookActive && currentRange <= rules.maxRange * .92 &&
            dist > radius * 1.1 && clearSegment(position, target) && clearSegment(position, aimEnd)) {
          castQ = true; shots++; settleTime = 0;
          nextShot = time + rules.cooldown + .12 + random() * .18;
          drawShotError();
        }
      }
    } else lastMove = movement(position, searchPoint, true);
    return { move: { ...lastMove }, yaw: aimYaw, pitch: aimPitch, castQ, jump: false };
  }
  function snapshot() {
    return { time, initialized, yaw: aimYaw, pitch: aimPitch, seed: baseSeed, rng,
      reactionDelay, nextSample, queuedSamples: samples.length, perceived: perceived ? {
        position: { ...perceived.position }, velocity: { ...perceived.velocity }, sampledAt: perceived.sampledAt, available: perceived.available } : null,
      wasVisible, visibleTime, freshPerception, searchPoint: { ...searchPoint }, strafeSign, strafeUntil, nextShot, settleTime, shotErrorYaw, shotErrorPitch,
      preferredDistance, shots, move: { ...lastMove } };
  }
  reset();
  return Object.freeze({ step, reset, snapshot });
}
