import * as THREE from '../../vendor/three.module.js';
import {GLTFLoader} from '../../vendor/GLTFLoader.js';
import {createTurretSimulation} from '../../turret-core.js';
import {rayBox} from '../../core.js';
// Exact swept sphere against an AABB. Face crossings split the segment into
// intervals where squared distance to the box is a single quadratic.
export function sweptSphereBox(from,to,min,max,radius){
 const d={x:to.x-from.x,y:to.y-from.y,z:to.z-from.z},cuts=[0,1];
 for(const k of ['x','y','z'])if(d[k]!==0)for(const plane of [min[k],max[k]]){const t=(plane-from[k])/d[k];if(t>0&&t<1)cuts.push(t);}
 cuts.sort((a,b)=>a-b);
 for(let i=0;i<cuts.length-1;i++){
  const start=cuts[i],end=cuts[i+1],mid=(start+end)/2;let a=0,b=0,c=-radius*radius,magnitude=radius*radius;
  for(const k of ['x','y','z']){const p=from[k]+d[k]*mid,bound=p<min[k]?min[k]:p>max[k]?max[k]:null;if(bound===null)continue;const m=from[k]+d[k]*start-bound;a+=d[k]*d[k];b+=2*m*d[k];c+=m*m;magnitude+=m*m;}
  // Only absorb arithmetic roundoff, not a world-space collision margin.
  if(c<=16*Number.EPSILON*Math.max(1,magnitude))return start;
  const discriminant=b*b-4*a*c,tolerance=16*Number.EPSILON*(b*b+Math.abs(4*a*c));
  if(a>0&&discriminant>=-tolerance){const root=(-b-Math.sqrt(Math.max(0,discriminant)))/(2*a);if(root>=0&&root<=end-start){
   const t=start+root;
   if(discriminant>0)return t;
   let distanceSquared=0;
   for(const k of ['x','y','z']){const p=from[k]+d[k]*t,offset=p<min[k]?p-min[k]:p>max[k]?p-max[k]:0;distanceSquared+=offset*offset;}
   // A clamped discriminant must not turn a long-sweep near miss into a hit.
   if(distanceSquared-radius*radius<=16*Number.EPSILON*Math.max(1,distanceSquared,radius*radius))return t;
  }}
 }
 return null;
}
export const TURRET_MODEL_FILE='turret.5a9fd4b0b1c143e9.glb';
export async function loadTurretModel(fetchAsset=fetch){const response=await fetchAsset('./assets/turret/'+TURRET_MODEL_FILE);if(!response.ok)throw new Error('turret HTTP '+response.status);return(await new GLTFLoader().parseAsync(await response.arrayBuffer(),'')).scene;}
export function createTurretArena(scene,asset,obstacles,{onDamage=()=>{},onWarning=()=>{},onShot=()=>{},onAcquired=()=>{},onLost=()=>{}}={}){
 const definitions=[{id:'west',position:{x:-12,y:0,z:-18}},{id:'east',position:{x:12,y:0,z:-29}}],sim=createTurretSimulation({turrets:definitions}),visuals=new Map(),bulletMeshes=new Map();
 const bulletGeometry=new THREE.SphereGeometry(.14,10,8),bulletMaterial=new THREE.MeshBasicMaterial({color:0x8aefff});
 for(const def of definitions){const root=asset.clone(true),bounds=new THREE.Box3().setFromObject(root),scale=4.8/(bounds.max.y-bounds.min.y);root.scale.multiplyScalar(scale);root.position.set(def.position.x,def.position.y-bounds.min.y*scale,def.position.z);root.traverse(n=>{if(n.isMesh){n.castShadow=true;n.receiveShadow=true;}});scene.add(root);
  const head=root.getObjectByName('HeadPivot'),barrel=root.getObjectByName('Barrel'),muzzle=root.getObjectByName('MuzzleAnchor');if(!head||!barrel||!muzzle)throw new Error('Turret aiming hierarchy missing');
  const ring=new THREE.Mesh(new THREE.RingGeometry(11.92,12,96),new THREE.MeshBasicMaterial({color:0xe0b35e,transparent:true,opacity:.3,side:THREE.DoubleSide,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.set(def.position.x,.025,def.position.z);scene.add(ring);
  const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]),new THREE.LineBasicMaterial({color:0xff795f,transparent:true,opacity:.8}));line.visible=false;scene.add(line);
  const flare=new THREE.Mesh(new THREE.SphereGeometry(.12,8,6),new THREE.MeshBasicMaterial({color:0xffbc72}));flare.visible=false;scene.add(flare);
  root.updateWorldMatrix(true,true);const worldBox=new THREE.Box3().setFromObject(root);obstacles.push({min:worldBox.min.clone(),max:worldBox.max.clone(),turretId:def.id});
  visuals.set(def.id,{root,head,barrel,muzzle,ring,line,flare,headBase:head.quaternion.clone(),barrelBase:barrel.position.clone(),barrelRotation:barrel.quaternion.clone(),recoil:0});
 }
 function blocking(from,to,ignoreId,radius=0){
  const origin=new THREE.Vector3(from.x,from.y,from.z),delta=new THREE.Vector3(to.x-from.x,to.y-from.y,to.z-from.z),length=delta.length();
  if(!radius&&length<1e-8)return null;
  if(length>0)delta.divideScalar(length);
  let nearest=null;
  for(const box of obstacles){
   if(box.turretId===ignoreId)continue;
   let fraction;
   if(radius){
    // Zero-travel newborn/overlapping projectiles still need a contact test.
    if(length>=1e-8&&rayBox(origin,delta,box.min.clone().addScalar(-radius),box.max.clone().addScalar(radius),length)===null)continue;
    fraction=sweptSphereBox(from,to,box.min,box.max,radius);
   }else{const distance=rayBox(origin,delta,box.min,box.max,length);fraction=distance===null?null:distance/length;}
   if(fraction!==null&&(nearest===null||fraction<nearest))nearest=fraction;
  }
  return nearest;
 }

 let resetGeneration=0;
 function step(dt,player,alive=true){const generation=resetGeneration,torso={x:player.x,y:player.y-.55,z:player.z};
  for(const turret of sim.turrets){const v=visuals.get(turret.id),base=v.head.getWorldPosition(new THREE.Vector3()),heading=Math.atan2(torso.x-base.x,torso.z-base.z);v.head.quaternion.copy(v.headBase).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),heading));v.barrel.quaternion.copy(v.barrelRotation).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),Math.atan2(base.y-torso.y,Math.hypot(torso.x-base.x,torso.z-base.z))));v.recoil=Math.max(0,v.recoil-dt*4);v.barrel.position.copy(v.barrelBase).add(new THREE.Vector3(0,0,-v.recoil*.08));v.root.updateWorldMatrix(true,true);turret.muzzlePosition=v.muzzle.getWorldPosition(new THREE.Vector3());}
  const events=sim.step(dt,{position:torso,radius:.48,alive},{isVisible:(from,to,t)=>blocking(from,to,t.id)===null,obstruction:(from,to,b)=>blocking(from,to,b.turretId,sim.settings.projectileRadius)});
  for(const event of events){if(event.type==='acquired')onAcquired(event);if(event.type==='lost')onLost(event);if(event.type==='windup')onWarning(event);if(event.type==='shot'){visuals.get(event.turretId).recoil=1;onShot(event);}if(event.type==='hit')onDamage(event.damage,event);if(generation!==resetGeneration)return events;}
  for(const turret of sim.turrets){const v=visuals.get(turret.id),warning=turret.state==='windup';v.ring.material.color.setHex(warning?0xff7258:0xe0b35e);v.ring.material.opacity=warning?.65:.25;v.line.visible=warning;v.flare.visible=warning||v.recoil>0;v.flare.position.copy(turret.muzzlePosition);v.flare.scale.setScalar(warning?1+(1-turret.remaining/sim.settings.telegraph)*2:2*v.recoil);if(warning){const a=v.line.geometry.attributes.position.array;a.set([turret.muzzlePosition.x,turret.muzzlePosition.y,turret.muzzlePosition.z,torso.x,torso.y,torso.z]);v.line.geometry.attributes.position.needsUpdate=true;v.line.geometry.computeBoundingSphere();}}
  const aliveIds=new Set(sim.bullets.map(b=>b.id));for(const[id,mesh]of bulletMeshes){if(!aliveIds.has(id)){scene.remove(mesh);bulletMeshes.delete(id);}}
  for(const bullet of sim.bullets){let mesh=bulletMeshes.get(bullet.id);if(!mesh){mesh=new THREE.Mesh(bulletGeometry,bulletMaterial);scene.add(mesh);bulletMeshes.set(bullet.id,mesh);}mesh.position.set(bullet.position.x,bullet.position.y,bullet.position.z);}
  return events;
 }
 function reset(){resetGeneration++;sim.reset();for(const mesh of bulletMeshes.values())scene.remove(mesh);bulletMeshes.clear();for(const v of visuals.values()){v.recoil=0;v.head.quaternion.copy(v.headBase);v.barrel.position.copy(v.barrelBase);v.barrel.quaternion.copy(v.barrelRotation);v.line.visible=v.flare.visible=false;v.ring.material.color.setHex(0xe0b35e);v.ring.material.opacity=.25;}}
 return{step,reset,sim,visuals,bulletMeshes,get warning(){return sim.turrets.some(t=>t.state==='windup');}};
}
