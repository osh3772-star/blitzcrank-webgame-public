/**
 * Reconstructed from the reviewed Riot 2017 W/E/R frames, not extracted game VFX.
 * See skill-vfx-reference.md for observed colors/shapes and adaptation limits.
 * All render resources are fixed at construction; update uses simulation time only.
 */
export const SKILL_VFX_LIMITS = Object.freeze({
  wStreaks: 40, wGroundSegments: 48, eSegments: 144,
  rSegments: 1728, rTargets: 12, rTargetSegments: 480,
  impactSegments: 28, rLifetime: 25 / 30, impactLifetime: .24,
});
export const SKILL_VFX_PALETTE = Object.freeze({
  speedGold: 0xe4d298, speedWhite: 0xe4ddff, groundGold: 0xffd62b,
  chargeCore: 0xe6d8ff, chargeGlow: 0x7022ff, impact: 0xffedbd,
  fieldIvory: 0xfff5db, fieldBlue: 0xbfeaff, release: 0xc5afff,
});
const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, x));
const frac = x => x - Math.floor(x);
const noise = n => frac(Math.sin(n * 127.1 + 311.7) * 43758.5453123);
const finitePosition = p => p && Number.isFinite(p.x) && Number.isFinite(p.y) && Number.isFinite(p.z);
const colorComponents = hex => [(hex >> 16 & 255) / 255, (hex >> 8 & 255) / 255, (hex & 255) / 255];
const C = Object.fromEntries(Object.entries(SKILL_VFX_PALETTE).map(([k, v]) => [k, colorComponents(v)]));

/**
 * worldHands/viewHands are the actual palm meshes, not pivot nodes. A third
 * viewHands entry may be the detached FPS Q palm clone. Its own visibility wins.
 * update AFTER animation and syncCamera. Do not call update while paused.
 * event('power_fist_hit', {position: targetPosition}) creates a contact flash;
 * omitting position on a miss consumes charge without inventing an impact.
 * event('static_field_discharge', {position: playerEyePosition, targets: []})
 * captures the cast origin. Optional groundY is an absolute world height.
 */
export function createSkillVfx(THREE, {
  scene, viewScene, fullbody, worldHands = [], viewHands = [],
  rRadius = 7, wDuration = 4, wSlowDuration = 2,
} = {}) {
  if (!scene?.add || !viewScene?.add || !fullbody?.add) throw new Error('Skill VFX requires world, view, and fullbody roots');
  if (!Array.isArray(worldHands) || !Array.isArray(viewHands) || [...worldHands, ...viewHands].some(h => !h?.geometry?.isBufferGeometry)) throw new Error('Skill VFX hand anchor must be a mesh');
  if (![rRadius, wDuration, wSlowDuration].every(x => Number.isFinite(x) && x > 0)) throw new Error('Invalid skill VFX tuning');
  rRadius = Math.min(rRadius, 30);
  const geometries = new Set(), materials = new Set(), textures = new Set(), attachments = [];
  const batches = [], viewport = new THREE.Vector4(), size = new THREE.Vector2();
  const center = new THREE.Vector3(), extent = new THREE.Vector3();
  let time = 0, disposed = false, rAge = Infinity, hitAge = Infinity;
  let wTail = 0, wasBoost = false, eStrength = 0, sequence = 0;
  let lastPhase = null, consumedStrike = false;
  const ownGeometry = g => (geometries.add(g), g);
  const ownMaterial = m => (materials.add(m), m);
  const attach = (parent, child) => { parent.add(child); attachments.push(child); return child; };
  const group = name => { const g = new THREE.Group(); g.name = name; return g; };
  function softTexture() {
    const n = 64, bytes = new Uint8Array(n * n * 4);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const d = Math.hypot((x + .5) / n * 2 - 1, (y + .5) / n * 2 - 1);
      const a = Math.pow(Math.max(0, 1 - d), 2.4), i = (y * n + x) * 4;
      bytes[i] = bytes[i + 1] = bytes[i + 2] = 255; bytes[i + 3] = Math.round(255 * a);
    }
    const t = new THREE.DataTexture(bytes, n, n, THREE.RGBAFormat);
    t.magFilter = t.minFilter = THREE.LinearFilter; t.generateMipmaps = false; t.needsUpdate = true;
    textures.add(t); return t;
  }
  const glowTexture = softTexture();
  function glowMaterial(color, opacity = 1) {
    return ownMaterial(new THREE.SpriteMaterial({map: glowTexture, color, opacity, transparent: true,
      blending: THREE.AdditiveBlending, depthWrite: false, depthTest: true, toneMapped: false}));
  }
  function sprite(parent, material, scaleX, scaleY = scaleX) {
    const o = new THREE.Sprite(material); o.name = parent.name + '_glow'; o.scale.set(scaleX, scaleY, 1); o.frustumCulled = false; parent.add(o); return o;
  }
  // Screen-width ribbon strokes avoid WebGL's implementation-dependent 1 px
  // LineBasicMaterial width. One draw call contains all soft-edged bolt segments.
  function strokes(name, capacity, width = 1.5) {
    const positions = new Float32Array(capacity * 18), ends = new Float32Array(capacity * 18);
    const colors = new Float32Array(capacity * 18), uv = new Float32Array(capacity * 12);
    const alphas = new Float32Array(capacity * 6);
    const pattern = [0, -1, 1, -1, 0, 1, 1, -1, 1, 1, 0, 1];
    for (let i = 0; i < capacity; i++) uv.set(pattern, i * 12);
    const g = ownGeometry(new THREE.BufferGeometry());
    for (const [key, array, components] of [['position', positions, 3], ['aEnd', ends, 3], ['color', colors, 3], ['uv', uv, 2], ['aAlpha', alphas, 1]]) {
      const attr = new THREE.BufferAttribute(array, components);
      if (key !== 'uv') attr.setUsage(THREE.DynamicDrawUsage);
      g.setAttribute(key, attr);
    }
    g.setDrawRange(0, 0);
    const m = ownMaterial(new THREE.ShaderMaterial({
      uniforms: {uResolution: {value: new THREE.Vector2(1280, 720)}, uWidth: {value: width}, uOpacity: {value: 1}},
      vertexColors: true, transparent: true, blending: THREE.AdditiveBlending,
      depthTest: true, depthWrite: false, toneMapped: false, side: THREE.DoubleSide,
      vertexShader: `
        attribute vec3 aEnd; attribute float aAlpha;
        uniform vec2 uResolution; uniform float uWidth;
        varying vec3 vTint; varying float vAlpha; varying float vEdge;
        void main() {
          vec4 a = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          vec4 b = projectionMatrix * modelViewMatrix * vec4(aEnd, 1.0);
          float wa = max(abs(a.w), 0.0001), wb = max(abs(b.w), 0.0001);
          vec2 delta = (b.xy / wb - a.xy / wa) * uResolution;
          float len = length(delta);
          vec2 normal = len > 0.001 ? vec2(-delta.y, delta.x) / len : vec2(0.0, 1.0);
          gl_Position = mix(a, b, uv.x);
          gl_Position.xy += normal * uv.y * uWidth * 2.0 / uResolution * gl_Position.w;
          vTint = color; vAlpha = aAlpha * step(0.0001, min(a.w, b.w)); vEdge = uv.y;
        }`,
      fragmentShader: `
        uniform float uOpacity; varying vec3 vTint; varying float vAlpha; varying float vEdge;
        void main() {
          float edge = abs(vEdge);
          float core = pow(max(0.0, 1.0 - edge), 2.5);
          gl_FragColor = vec4(vTint, core * vAlpha * uOpacity);
        }`,
    }));
    const mesh = new THREE.Mesh(g, m); mesh.name = name; mesh.frustumCulled = false;
    mesh.onBeforeRender = renderer => {
      // A reflection render target has a different viewport from the main scene.
      if (renderer.getCurrentViewport) { renderer.getCurrentViewport(viewport); m.uniforms.uResolution.value.set(Math.max(1, viewport.z), Math.max(1, viewport.w)); }
      else { renderer.getDrawingBufferSize(size); m.uniforms.uResolution.value.copy(size); }
    };
    const batch = {mesh, capacity, count: 0,
      clear() { this.count = 0; },
      line(ax, ay, az, bx, by, bz, tint, alpha = 1, tailAlpha = alpha) {
        if (this.count >= capacity) return false;
        const slot = this.count++;
        for (let v = 0; v < 6; v++) {
          const i = slot * 18 + v * 3;
          positions[i] = ax; positions[i + 1] = ay; positions[i + 2] = az;
          ends[i] = bx; ends[i + 1] = by; ends[i + 2] = bz;
          colors[i] = tint[0]; colors[i + 1] = tint[1]; colors[i + 2] = tint[2];
          alphas[slot * 6 + v] = pattern[v * 2] ? tailAlpha : alpha;
        }
        return true;
      },
      commit(opacity = 1) {
        for (const key of ['position', 'aEnd', 'color', 'aAlpha']) g.attributes[key].needsUpdate = true;
        g.setDrawRange(0, this.count * 6); mesh.visible = this.count > 0 && opacity > 0;
        m.uniforms.uOpacity.value = opacity;
      },
    };
    batches.push(batch); return batch;
  }
  const worldW = attach(fullbody, group('W_reference_speed_streaks'));
  const viewW = attach(viewScene, group('W_FPS_peripheral_adaptation'));
  const groundW = attach(scene, group('W_reference_yellow_ground_traces'));
  const wWorld = strokes('W_pale_gold_and_white_streaks', SKILL_VFX_LIMITS.wStreaks, 1.4);
  const wView = strokes('W_FPS_speed_streaks', 24, 1.3);
  const wGround = strokes('W_late_yellow_ground_sparks', SKILL_VFX_LIMITS.wGroundSegments, 1.5);
  worldW.add(wWorld.mesh); viewW.add(wView.mesh); groundW.add(wGround.mesh);
  const eWorld = [], eView = [];
  const eBolts = [strokes('E_lavender_fist_lightning_A', SKILL_VFX_LIMITS.eSegments, 2), strokes('E_lavender_fist_lightning_B', SKILL_VFX_LIMITS.eSegments, 2)];
  const eGlow = glowMaterial(SKILL_VFX_PALETTE.chargeGlow, .55);
  function bindHand(hand, index, out) {
    if (!hand?.geometry) throw new Error('Skill VFX hand anchor must be a mesh');
    if (!hand.geometry.boundingBox) hand.geometry.computeBoundingBox();
    hand.geometry.boundingBox.getCenter(center); hand.geometry.boundingBox.getSize(extent);
    const radius = clamp(Math.max(extent.x, extent.y, extent.z) * .82, .12, 1.2);
    const g = attach(hand, group('E_charged_fist_' + hand.name));
    g.position.copy(center); g.scale.setScalar(radius); g.visible = false;
    // A mesh clone shares our two immutable resource identities, not the hand.
    const base = eBolts[index % 2].mesh, arcs = new THREE.Mesh(base.geometry, base.material);
    arcs.frustumCulled = false; arcs.onBeforeRender = base.onBeforeRender; arcs.name = base.name; g.add(arcs);
    sprite(g, eGlow, 3.5); out.push(g);
  }
  worldHands.forEach((h, i) => bindHand(h, i, eWorld));
  viewHands.forEach((h, i) => bindHand(h, i, eView));
  const field = attach(scene, group('R_reference_branching_electrical_field'));
  const fieldBolts = strokes('R_ivory_branched_web', SKILL_VFX_LIMITS.rSegments, 1.65);
  field.add(fieldBolts.mesh);
  const releaseMaterial = glowMaterial(SKILL_VFX_PALETTE.release, 1);
  const release = sprite(field, releaseMaterial, rRadius * 2, .22); release.position.y = 1.05;
  const releaseCoreMaterial = glowMaterial(0xffffff, 1);
  const releaseCore = sprite(field, releaseCoreMaterial, rRadius * 1.75, .065); releaseCore.position.y = 1.05;
  const impact = attach(scene, group('E_reference_warm_contact_flash'));
  const impactBolts = strokes('E_white_gold_contact_star', SKILL_VFX_LIMITS.impactSegments, 2.2);
  impact.add(impactBolts.mesh);
  const impactMaterial = glowMaterial(SKILL_VFX_PALETTE.impact, 1);
  const impactGlow = sprite(impact, impactMaterial, 1.1);
  const targetRoot = attach(scene, group('R_target_violet_coronas'));
  const targetBolts = strokes('R_target_sparks', SKILL_VFX_LIMITS.rTargetSegments, 1.8); targetRoot.add(targetBolts.mesh);
  const targetPool = Array.from({length: SKILL_VFX_LIMITS.rTargets}, () => {
    const root = group('R_target_corona'); root.visible = false; targetRoot.add(root);
    const material = glowMaterial(SKILL_VFX_PALETTE.chargeGlow, 0);
    const core = glowMaterial(0xe5deff, 0);
    const halo = sprite(root, material, 1.5), star = sprite(root, core, .65);
    return {root, material, core, halo, star, age: Infinity, seed: 0};
  });
  let targetCursor = 0;
  function addTarget(p) {
    if (!finitePosition(p)) return false;
    const slot = targetPool[targetCursor++ % targetPool.length];
    slot.age = 0; slot.seed = sequence * 79 + targetCursor * 11; slot.root.position.copy(p); slot.root.visible = true; return true;
  }
  function updateW(status, moving, position, yaw) {
    const boost = Math.max(0, Number.isFinite(status.boost) ? status.boost : 0);
    const slow = Math.max(0, Number.isFinite(status.slow) ? status.slow : 0);
    if (wasBoost && !boost) wTail = 11 / 30;
    wasBoost = boost > 0;
    const onset = clamp((wDuration - boost + 1 / 30) / .14);
    const strength = boost ? onset : clamp(wTail / (11 / 30));
    wWorld.clear(); wView.clear(); wGround.clear();
    if (strength > 0) for (let i = 0; i < SKILL_VFX_LIMITS.wStreaks; i++) {
      const p = frac(time * (2.8 + noise(i) * 1.4) + noise(i + 23));
      const n = noise(i + 51), x = (noise(i + 9) - .5) * 2.9;
      const y = .5 + n * 1.85 + p * .45, z = -.18 - p * 2.7;
      const mote = i % 7 === 0;
      const len = mote ? .035 : (.28 + noise(i + 7) * 1.6) * (moving ? 1 : .56);
      const a = Math.sin(p * Math.PI) * (.38 + noise(i + 12) * .53);
      wWorld.line(x, y, z, x + (x * .05), y + len * .16, z - len,
        mote ? C.fieldBlue : i % 3 ? C.speedGold : C.speedWhite, a, mote ? a : .02);
      if (i < 24) {
        // This side-of-screen layer is an FPS adaptation of rear-body streaks,
        // not a claim that the source video provides a first-person camera.
        const side = i % 2 ? 1 : -1;
        const vx = side * (1.12 + noise(i + 36) * .6), vy = -.75 + n * 1.75;
        const vz = -3.4 + p * 1.35;
        wView.line(vx, vy, vz, vx * 1.13, vy - .03, vz + len * .65,
          i % 3 ? C.speedGold : C.speedWhite, a * .55, .01);
      }
    }
    const groundStrength = slow ? clamp(slow / .18) : boost > 0 && boost < .12 ? 1 - boost / .12 : 0;
    if (groundStrength > 0) for (let i = 0; i < 12; i++) {
      const seed = i + Math.floor(time * 24) * 17;
      const x = (i % 2 ? 1 : -1) * (.22 + noise(seed) * .32);
      const z = -.15 - noise(seed + 10) * 1.3, y = .04 + noise(seed + 2) * .07;
      let px = x, pz = z;
      for (let j = 1; j <= 4; j++) {
        const nx = x + j * .055, nz = z + (noise(seed + j * 5) - .5) * .15;
        wGround.line(px, y, pz, nx, y, nz, C.groundGold, .85 - j * .1); px = nx; pz = nz;
      }
    }
    if (finitePosition(position)) groundW.position.set(position.x, position.y - 1.7, position.z);
    if (Number.isFinite(yaw)) groundW.rotation.y = yaw + Math.PI;
    wWorld.commit(strength); wView.commit(strength); wGround.commit(groundStrength);
    worldW.visible = viewW.visible = strength > 0; groundW.visible = groundStrength > 0;
  }
  function updateE(status) {
    const phase = status.phase, t = Math.max(0, status.animation?.time || 0);
    if (phase !== lastPhase) { if (phase === 'E_Strike') consumedStrike = false; lastPhase = phase; }
    const active = phase === 'E_Charge' || phase === 'E_Hold' ||
      (phase === 'E_Strike' ? !consumedStrike && t < .4 : status.armed > 0);
    eStrength = active ? (phase === 'E_Charge' ? .45 + .55 * clamp(t / .12) : 1) : 0;
    eGlow.opacity = .72 * eStrength;
    for (const g of eWorld) g.visible = active;
    for (const g of eView) g.visible = active;
    for (let variant = 0; variant < 2; variant++) {
      const b = eBolts[variant]; b.clear();
      if (active) {
        const tick = Math.floor(time * 30);
        for (let bolt = 0; bolt < 12; bolt++) {
          const seed = tick * 53 + bolt * 17 + variant * 751;
          // Incomplete jagged arcs with short branches, never a tidy fist ring.
          const theta = noise(seed) * TAU, phi = .22 + noise(seed + 1) * (Math.PI - .44);
          const sweep = .28 + noise(seed + 2) * .9;
          let ax = 0, ay = 0, az = 0;
          for (let j = 0; j <= 7; j++) {
            const angle = theta + j / 7 * sweep;
            const r = 1 + (noise(seed + j * 11) - .5) * .22;
            const py = phi + (noise(seed + j * 13) - .5) * .3;
            const bx = Math.cos(angle) * Math.sin(py) * r;
            const by = Math.cos(py) * r, bz = Math.sin(angle) * Math.sin(py) * r;
            if (j) b.line(ax, ay, az, bx, by, bz, C.chargeCore, .75 + noise(seed + j) * .25);
            if (j === 4 || j === 6) b.line(bx, by, bz, bx * 1.22, by * 1.18 + .09, bz * 1.2, C.chargeCore, .7, .05);
            ax = bx; ay = by; az = bz;
          }
        }
      }
      b.commit(eStrength);
    }
  }
  function updateField() {
    const life = SKILL_VFX_LIMITS.rLifetime, age = rAge;
    field.visible = age < life; fieldBolts.clear();
    if (!field.visible) { fieldBolts.commit(0); release.visible = releaseCore.visible = false; return; }
    const sourceFrame = Math.floor(age * 30 + 1e-7);
    // The reference visibly drops out at f118/f119/f124, then flashes back.
    const gap = sourceFrame === 15 || sourceFrame === 16 || sourceFrame === 21;
    const fade = age < .5 ? 1 : .95 - clamp((age - .5) / (life - .5)) * .48;
    const radius = rRadius * (.46 + .54 * clamp(age / .22));
    const tick = Math.floor(age * 30), seed = tick * 197 + sequence * 337;
    release.visible = releaseCore.visible = age < .24;
    releaseMaterial.opacity = Math.pow(clamp(1 - age / .24), 1.3) * .9;
    releaseCoreMaterial.opacity = clamp(1 - age / .22);
    // Radial trunks branch near mid-radius. Additional broken rim arcs connect
    // only some endpoints, creating an irregular electrical shell, not a ring.
    if (!gap) {
      for (let ray = 0; ray < 22; ray++) {
        const a = ray / 22 * TAU + (noise(seed + ray) - .5) * .23;
        let px = Math.cos(a) * .28, py = .65, pz = Math.sin(a) * .28;
        for (let j = 1; j <= 27; j++) {
          const u = j / 27, rr = radius * u;
          const jag = (noise(seed + ray * 73 + j * 13) - .5) * .4 * Math.sin(u * Math.PI);
          const angle = a + jag;
          const nx = Math.cos(angle) * rr, nz = Math.sin(angle) * rr;
          const ny = .13 + Math.sin(u * Math.PI) * (ray % 5 === 0 ? 1.6 : .55) + noise(seed + j * 3 + ray) * .16;
          fieldBolts.line(px, py, pz, nx, ny, nz, ray % 6 ? C.fieldIvory : C.fieldBlue, .9, .85);
          if (j === 11 || j === 18) {
            let bx = nx, by = ny, bz = nz;
            for (let k = 1; k <= 8; k++) {
              const ru = u + k * .025, ba = a + (j === 11 ? -1 : 1) * k * .027 + (noise(seed + ray * 43 + k) - .5) * .09;
              const ex = Math.cos(ba) * radius * ru, ez = Math.sin(ba) * radius * ru;
              const ey = .1 + Math.sin(ru * Math.PI) * .4 + noise(seed + k + ray) * .15;
              fieldBolts.line(bx, by, bz, ex, ey, ez, C.fieldIvory, .68, .58); bx = ex; by = ey; bz = ez;
            }
          }
          px = nx; py = ny; pz = nz;
        }
      }
      for (let arc = 0; arc < 13; arc++) {
        const start = arc / 13 * TAU + noise(seed + arc * 11) * .09;
        const sweep = .22 + noise(seed + arc * 19) * .15;
        let px = 0, py = 0, pz = 0;
        for (let j = 0; j <= 20; j++) {
          const a = start + sweep * j / 20;
          const rr = radius * (.95 + (noise(seed + arc * 63 + j * 7) - .5) * .07);
          const nx = Math.cos(a) * rr, nz = Math.sin(a) * rr, ny = .15 + noise(seed + j + arc * 9) * .17;
          if (j) fieldBolts.line(px, py, pz, nx, ny, nz, C.fieldIvory, .65, .65);
          px = nx; py = ny; pz = nz;
        }
      }
    }
    fieldBolts.commit(gap ? 0 : fade);
  }
  function updateImpact() {
    const u = hitAge / SKILL_VFX_LIMITS.impactLifetime;
    impact.visible = u < 1; impactBolts.clear();
    if (u < 1) {
      const fade = Math.pow(1 - u, 1.4);
      impactMaterial.opacity = fade;
      impactGlow.scale.setScalar(.45 + Math.sin(Math.min(1, u * 2) * Math.PI) * .9);
      for (let i = 0; i < SKILL_VFX_LIMITS.impactSegments; i++) {
        const a = i / SKILL_VFX_LIMITS.impactSegments * TAU, n = noise(i + sequence * 17);
        const inner = .03 + u * .2, outer = inner + (.2 + n * .55) * (1 - u);
        const y = (n - .5) * 1.2;
        impactBolts.line(Math.cos(a) * inner, y * inner, Math.sin(a) * inner,
          Math.cos(a) * outer, y * outer, Math.sin(a) * outer, C.impact, fade, .02);
      }
    }
    impactBolts.commit();
  }
  function updateTargets(dt) {
    targetBolts.clear(); let live = 0;
    for (const slot of targetPool) {
      if (slot.age >= .65) { slot.root.visible = false; continue; }
      slot.age += dt;
      const u = clamp(slot.age / .65), fade = (1 - u) ** 1.5;
      slot.root.visible = fade > 0; if (!slot.root.visible) continue; live++;
      slot.material.opacity = fade * .9; slot.core.opacity = fade;
      slot.halo.scale.setScalar(1.15 + u * .8); slot.star.scale.setScalar(.55 * (1 - u));
      const p = slot.root.position, seed = slot.seed + Math.floor(time * 30) * 17;
      for (let bolt = 0; bolt < 8; bolt++) {
        const a = bolt / 8 * TAU, r = .24 + u * .3;
        let px = p.x, py = p.y + .05, pz = p.z;
        for (let j = 1; j <= 4; j++) {
          const nx = p.x + Math.cos(a) * r * j / 4 + (noise(seed + bolt * 7 + j) - .5) * .12;
          const ny = p.y + .07 + j * .1 + (noise(seed + j * 3) - .5) * .1;
          const nz = p.z + Math.sin(a) * r * j / 4;
          targetBolts.line(px, py, pz, nx, ny, nz, C.chargeCore, fade, fade * .7); px = nx; py = ny; pz = nz;
        }
      }
    }
    targetBolts.commit(); targetRoot.visible = live > 0;
  }
  function reset() {
    time = 0; rAge = hitAge = Infinity; wTail = 0; wasBoost = false; eStrength = 0;
    consumedStrike = false; lastPhase = null; targetCursor = 0; sequence = 0;
    for (const b of batches) { b.clear(); b.commit(0); }
    for (const o of [worldW, viewW, groundW, field, impact, targetRoot, ...eWorld, ...eView]) o.visible = false;
    for (const slot of targetPool) { slot.age = Infinity; slot.root.visible = false; slot.material.opacity = slot.core.opacity = 0; }
  }
  reset();
  return {
    update(dt, {status = {}, position, yaw = 0, moving = false, thirdPerson = false} = {}) {
      if (disposed || !Number.isFinite(dt) || dt <= 0) return;
      // A delayed frame advances directly, without allocating/replaying particles.
      time += dt; rAge += dt; hitAge += dt; wTail = Math.max(0, wTail - dt);
      updateW(status, moving, position, yaw); viewW.visible &&= !thirdPerson;
      updateE(status); updateField(); updateImpact(); updateTargets(dt);
    },
    event(type, {position, targets, groundY} = {}) {
      if (disposed) return false;
      if (type === 'power_fist_hit') {
        consumedStrike = true;
        if (finitePosition(position)) { impact.position.copy(position); hitAge = 0; updateImpact(); }
        return true;
      }
      if (type === 'static_field_target') return addTarget(position);
      if (type !== 'static_field_discharge' || !finitePosition(position)) return false;
      sequence++; rAge = 0;
      field.position.set(position.x, Number.isFinite(groundY) ? groundY : position.y - 1.7, position.z);
      if (Array.isArray(targets)) for (let i = 0; i < Math.min(targets.length, targetPool.length); i++) addTarget(targets[i]);
      updateField(); updateTargets(0); return true;
    },
    reset() { if (!disposed) reset(); },
    dispose() {
      if (disposed) return;
      reset(); disposed = true;
      for (const o of attachments) o.removeFromParent();
      for (const g of geometries) g.dispose();
      for (const m of materials) m.dispose();
      for (const t of textures) t.dispose();
    },
    inspect() {
      return {disposed, time, wVisible: worldW.visible, groundVisible: groundW.visible, eStrength,
        fieldAge: Number.isFinite(rAge) ? rAge : null, fieldVisible: field.visible,
        fieldSegments: fieldBolts.count, impactVisible: impact.visible,
        targets: targetPool.filter(t => t.root.visible).length,
        segments: batches.reduce((n, b) => n + b.count, 0),
        capacity: batches.reduce((n, b) => n + b.capacity, 0),
        resources: {geometries: geometries.size, materials: materials.size, textures: textures.size},
      };
    },
  };
}
