// Collision-resolved bounded gait: linear support travel reduces horizontal slip.
// Exact low-speed cancellation is steady-state only, not world-space locking.
// Gameplay speed can exceed this short rig's reach at the readable cadence cap.
const TAU = Math.PI * 2;
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const damp = (a, b, rate, dt) => a + (b - a) * (1 - Math.exp(-rate * dt));
export const WALK_TUNING = Object.freeze({cycleDistance:.88,slowCycleDistance:.5,maxCadence:2.1,stanceFraction:.5,forwardReach:.285,backwardReach:.285,sideReach:.19,footLift:.12,bodyDrop:.075,bodyBounce:.009,startRate:10,stopRate:13,strideRate:10});

/** dx/dz are actual collision-resolved displacement; yaw is camera/game yaw.
 * At a fixed speed, phase follows distance until maxCadence. A zero-dt refresh
 * never consumes travel, changes direction, or advances/decays the animation. */
export function createWalkState({scale=.78,tuning=WALK_TUNING}={}) {
 let phase=0,blend=0,directionX=0,directionZ=1,speed=0,moving=false,grounded=true;
 let stride=0,strideRatio=0,cadence=0,liftScale=0;
 const pose={};
 const state={advance,reset,inspect,sample,pose};
 function reachLimit(){
  const longitudinal=directionZ>=0?tuning.forwardReach:tuning.backwardReach;
  // A scalar rounded-diamond bound preserves exact direction, unlike independently
  // scaling x/z. Diagonal support motion has no artificial transverse drift.
  return 1/(Math.abs(directionX/tuning.sideReach)**1.5+Math.abs(directionZ/longitudinal)**1.5)**(1/1.5);
 }
 function sync(){pose.phase=phase;pose.blend=blend;pose.directionX=directionX;pose.directionZ=directionZ;pose.speed=speed;pose.moving=moving;pose.grounded=grounded;pose.stride=stride;pose.cadence=cadence;pose.liftScale=liftScale;pose.rootOffsetY=blend*(-tuning.bodyDrop+tuning.bodyBounce*(1-Math.cos(phase*TAU*2))*.5)*scale;}
 function reset(){phase=0;blend=0;directionX=0;directionZ=1;speed=0;moving=false;grounded=true;stride=0;strideRatio=0;cadence=0;liftScale=0;sync();}
 function advance(dt,{deltaX=0,deltaZ=0,yaw=0,grounded:onGround=true}={}) {
  if(!Number.isFinite(dt)||dt<=0)return;
  dt=Math.min(dt,.1);grounded=!!onGround;
  const dx=Number.isFinite(deltaX)?deltaX:0,dz=Number.isFinite(deltaZ)?deltaZ:0;
  const distance=Math.hypot(dx,dz);speed=distance/dt;moving=grounded&&speed>.015;
  if(moving){
   const bodyYaw=(Number.isFinite(yaw)?yaw:0)+Math.PI;
   const x=(Math.cos(bodyYaw)*dx-Math.sin(bodyYaw)*dz)/distance;
   const z=(Math.sin(bodyYaw)*dx+Math.cos(bodyYaw)*dz)/distance;
   const current=Math.atan2(directionX,directionZ),wanted=Math.atan2(x,z);
   const difference=Math.atan2(Math.sin(wanted-current),Math.cos(wanted-current));
   const angle=current+difference*(1-Math.exp(-14*dt));
   directionX=Math.sin(angle);directionZ=Math.cos(angle);
   const limit=reachLimit();
   // Longer comfortable steps at ordinary speed. Creep retains shorter steps
   // because its lower swing clearance cannot safely support full reach.
   const comfortable=tuning.slowCycleDistance+(tuning.cycleDistance-tuning.slowCycleDistance)*clamp(speed,0,1);
   const nominal=Math.min(comfortable,2*scale*limit/tuning.stanceFraction);
   const cycleDistance=Math.max(nominal,speed/tuning.maxCadence);
   cadence=speed/cycleDistance;
   phase=(phase+distance/cycleDistance)%1;
   const requested=cycleDistance*tuning.stanceFraction/(2*scale);
   strideRatio=damp(strideRatio,Math.min(1,requested/limit),tuning.strideRate,dt);
   stride=limit*strideRatio;
   liftScale=damp(liftScale,clamp(speed,0,1),tuning.strideRate,dt);
  }else cadence=0;
  blend=damp(blend,moving?1:0,moving?tuning.startRate:tuning.stopRate,dt);
  if(blend<1e-5){blend=0;stride=0;strideRatio=0;liftScale=0;}
  sync();
 }
 function sample(side,out={}){
  const p=(phase+(side==='R'?.5:0))%1,stance=p<tuning.stanceFraction;
  const u=stance?p/tuning.stanceFraction:(p-tuning.stanceFraction)/(1-tuning.stanceFraction);
  // Linear support speed, with a C1 Hermite recovery. The short overshoot in
  // recovery is intentional and tested against the actual rig at lifted y.
  const m=-2*(1-tuning.stanceFraction)/tuning.stanceFraction;
  const along=stance?1-2*u:-1+m*u+(6-3*m)*u*u+(-4+2*m)*u*u*u;
  const lift=stance?0:Math.sin(Math.PI*u)**2*tuning.footLift*blend*liftScale;
  out.phase=p;out.stance=stance;out.along=along;out.x=along*directionX*stride*blend;out.z=along*directionZ*stride*blend;out.lift=lift;return out;
 }
 function inspect(){return {...pose};}
 sync();
 Object.defineProperties(state,{blend:{get:()=>blend},moving:{get:()=>moving},phase:{get:()=>phase}});
 return state;
}

/** Calibrates knee centers from the actual existing BC_Knee mesh geometry.
 * No new joints, reparenting, vertex edits, or asset changes. The only non-pivot
 * node modified is BC_Knee, rotated by a conjugated transform about its axle.
 * restorePose() MUST precede an authored full-body skill pose or other override. */
export function createFullbodyLocomotion(THREE,{nodes,meshes,scale=.78,tuning=WALK_TUNING}={}) {
 const state=createWalkState({scale,tuning}),legs=[],touched=[],forward=new THREE.Vector3(0,0,1);
 for(const side of ['L','R']){
  const hip=nodes.get('BC_Pivot_Hip.'+side),knee=nodes.get('BC_Knee.'+side),ankle=nodes.get('BC_Pivot_Ankle.'+side),shoulder=nodes.get('BC_Pivot_Shoulder.'+side),mesh=meshes.get('BC_Knee.'+side);
  if(!hip||!knee||!ankle||!mesh)throw new Error('Missing locomotion rig: '+side);
  // World positions are used only for calibration at rest, then mapped back to
  // unscaled model space. The parent must construct this before posing the rig.
  hip.updateWorldMatrix(true,false);knee.updateWorldMatrix(true,false);ankle.updateWorldMatrix(true,false);
  const root=hip;let body=root;while(body.parent&&body.parent.type!=='Scene')body=body.parent;
  body.updateWorldMatrix(true,true);
  if(!mesh.geometry.boundingBox)mesh.geometry.computeBoundingBox();
  const center=mesh.geometry.boundingBox.getCenter(new THREE.Vector3());
  const hipRest=body.worldToLocal(hip.getWorldPosition(new THREE.Vector3()));
  const kneeRest=body.worldToLocal(mesh.localToWorld(center.clone()));
  const ankleRest=body.worldToLocal(ankle.getWorldPosition(new THREE.Vector3()));
  const upper=kneeRest.clone().sub(hipRest),lower=ankleRest.clone().sub(kneeRest),restTarget=ankleRest.clone().sub(hipRest);
  const axis=restTarget.clone().normalize(),restBend=upper.clone().addScaledVector(axis,-upper.dot(axis)).normalize();
  const kneeCenter=knee.worldToLocal(body.localToWorld(kneeRest.clone()));
  const leg={side,hip,knee,ankle,shoulder,hipRest,kneeRest,ankleRest,upper,lower,restTarget,restBend,kneeCenter,l1:upper.length(),l2:lower.length(),target:new THREE.Vector3(),axis:new THREE.Vector3(),bend:new THREE.Vector3(),upperTarget:new THREE.Vector3(),lowerTarget:new THREE.Vector3(),rotatedCenter:new THREE.Vector3(),qHip:new THREE.Quaternion(),qKnee:new THREE.Quaternion(),qAnkle:new THREE.Quaternion(),inverseHip:new THREE.Quaternion(),unitUpper:upper.clone().normalize(),unitLower:lower.clone().normalize(),unitUpperTarget:new THREE.Vector3(),unitLowerTarget:new THREE.Vector3(),step:{},clamped:false,error:0};
  for(const node of [hip,knee,ankle,shoulder].filter(Boolean))touched.push({node,position:node.position.clone(),quaternion:node.quaternion.clone()});
  legs.push(leg);
 }
 function restorePose(){for(const t of touched){t.node.position.copy(t.position);t.node.quaternion.copy(t.quaternion);}}
 function applyPose({armSwing=true}={}){
  const pose=state.pose;
  if(!pose.blend)return 0;
  for(const leg of legs){
   const step=state.sample(leg.side,leg.step),{target,axis,bend,upperTarget,lowerTarget}=leg;
   target.copy(leg.restTarget);target.x+=step.x;target.z+=step.z;
   target.y+=step.lift-pose.rootOffsetY/scale;
   const requested=target.length(),distance=clamp(requested,Math.abs(leg.l1-leg.l2)+1e-5,leg.l1+leg.l2-1e-5);
   leg.clamped=Math.abs(distance-requested)>1e-7;
   axis.copy(target).normalize();target.copy(axis).multiplyScalar(distance);
   // Existing rest bend approaches a forward knee plane continuously as the
   // gait fades in, rather than snapping its short mechanical legs sideways.
   bend.copy(leg.restBend).lerp(forward,pose.blend);
   bend.addScaledVector(axis,-bend.dot(axis));
   if(bend.lengthSq()<1e-8)bend.copy(leg.restBend);bend.normalize();
   const along=(leg.l1*leg.l1-leg.l2*leg.l2+distance*distance)/(2*distance);
   const height=Math.sqrt(Math.max(0,leg.l1*leg.l1-along*along));
   upperTarget.copy(axis).multiplyScalar(along).addScaledVector(bend,height);
   lowerTarget.copy(target).sub(upperTarget);
   leg.qHip.setFromUnitVectors(leg.unitUpper,leg.unitUpperTarget.copy(upperTarget).normalize());
   leg.inverseHip.copy(leg.qHip).invert();
   leg.qKnee.setFromUnitVectors(leg.unitLower,leg.unitLowerTarget.copy(lowerTarget).applyQuaternion(leg.inverseHip).normalize());
   leg.hip.quaternion.copy(leg.qHip);
   leg.knee.quaternion.copy(leg.qKnee);
   // T(center) R T(-center), retaining the existing node's rest translation.
   const base=leg.knee.userData.base;
   leg.rotatedCenter.copy(leg.kneeCenter).applyQuaternion(leg.qKnee);
   leg.knee.position.fromArray(base).add(leg.kneeCenter).sub(leg.rotatedCenter);
   leg.qAnkle.copy(leg.qHip).multiply(leg.qKnee).invert();leg.ankle.quaternion.copy(leg.qAnkle);
   if(armSwing&&leg.shoulder){leg.shoulder.rotation.x=step.z/tuning.forwardReach*.22;leg.shoulder.rotation.z=-step.x/tuning.sideReach*.02;}
   leg.error=Math.abs(requested-distance);
  }
  return pose.rootOffsetY;
 }
 function reset(){state.reset();restorePose();for(const leg of legs){leg.clamped=false;leg.error=0;}}
 function inspect(){return {...state.inspect(),legs:legs.map(l=>({side:l.side,upperLength:l.l1,lowerLength:l.l2,kneeCenter:l.kneeRest.toArray(),clamped:l.clamped,targetError:l.error,step:state.sample(l.side)}))};}
 return {advance:state.advance,restorePose,applyPose,reset,inspect,get blend(){return state.blend;},get moving(){return state.moving;},get phase(){return state.phase;}};
}
