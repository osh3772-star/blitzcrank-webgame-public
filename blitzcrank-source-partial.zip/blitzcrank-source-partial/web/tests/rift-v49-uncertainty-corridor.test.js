import test from 'node:test';import assert from 'node:assert/strict';import {auditUncertaintyCorridor as audit} from '../rift-v49-uncertainty-corridor.js';
const component={mesh:'open',topologicallyClosed:false,bounds:{min:{x:-1,y:0,z:-1},max:{x:1,y:2,z:1}}};
test('rejects crossing envelope even with clear endpoints',()=>{const r=audit([component],{from:[-2,0],to:[2,0]});assert(!r.pass);assert.equal(r.blocked[0].enter,.25);assert.equal(r.blocked[0].leave,.75);});
test('separated and vertically outside centerlines pass',()=>{assert(audit([component],{from:[-2,3],to:[2,3]}).pass);assert(audit([component],{from:[-2,0],to:[2,0],centerY:3}).pass);});
test('endpoint contact and stationary uncertain positions reject conservatively',()=>{assert(!audit([component],{from:[-2,0],to:[-1,0]}).pass);assert(!audit([component],{from:[0,0],to:[0,0]}).pass);});
test('closed components remain delegated to surface/interior checks',()=>{assert(audit([{...component,topologicallyClosed:true}],{from:[-2,0],to:[2,0]}).pass);});
test('reverse traversal agrees without mutating component bounds',()=>{const before=JSON.stringify(component);assert.equal(audit([component],{from:[-2,0],to:[2,0]}).pass,audit([component],{from:[2,0],to:[-2,0]}).pass);assert.equal(JSON.stringify(component),before);});
test('invalid corridor fails closed',()=>{assert.throws(()=>audit([],{from:[NaN,0],to:[0,0]}));assert.throws(()=>audit([],{from:[0,0],to:[0,0],centerY:Infinity}));});
