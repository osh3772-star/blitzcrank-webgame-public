import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {rig,THREE} from './helpers/locomotion-rig.js';
import {createDuelAvatarFactory} from '../duel-avatar.js';
import {createFullbodyLocomotion} from '../fullbody-locomotion.js';
const model=JSON.parse(fs.readFileSync(new URL('../assets/skill-animations/skills.9b293d06ddb21614.json',import.meta.url))).models.fullbody;
const original=rig(),factory=createDuelAvatarFactory(THREE,{...original,createLocomotion:createFullbodyLocomotion});
const authored=factory.create(),game=factory.create({staticRestMatrices:true,reuseSkillSurfaceRestPose:true,stationaryW:true});
authored.configureSkills(model);game.configureSkills(model);
const surfaces=a=>{const m=[];a.object.traverse(o=>{if(o.isMesh)m.push(o)});return m;};
const mats=a=>surfaces(a).map(o=>o.matrixWorld.toArray());
const near=(a,b)=>{for(let i=0;i<a.length;i++)for(let k=0;k<16;k++)assert(Math.abs(a[i][k]-b[i][k])<1e-10,`${i} ${k}`);};
const state={position:[0,0,0],yaw:0,skill:{name:'R_Cast',time:.3}};
test('stationary R opt-in remains exact; default moving actor remains authored; opt-in gait responds to real travel',()=>{
 authored.update(0,state);game.update(0,state,{rLocomotion:true});near(mats(authored),mats(game));const base=mats(authored);
 for(let i=0;i<30;i++){const s={...state,locomotion:{deltaZ:-.08}};authored.update(1/60,s);game.update(1/60,s,{rLocomotion:true});}
 near(mats(authored),base);assert.notDeepEqual(mats(game),base);
 for(let i=0;i<120;i++)game.update(1/60,state,{rLocomotion:true});near(mats(game),base);
 const before=mats(game);for(let i=0;i<8;i++)game.update(0,state,{rLocomotion:true,deferWorldMatrices:true});game.object.updateMatrixWorld(true);near(mats(game),before);
});
test('R opt-in exits cleanly across E, W and Q; source clips immutable',()=>{
 const source=JSON.stringify(model);
 for(const name of ['E_Hold','R_Cast','E_Strike','W_Loop','R_Cast']){for(let i=0;i<5;i++)game.update(1/60,{...state,skill:{name,time:.2},locomotion:{deltaX:.07}},{rLocomotion:true});assert(surfaces(game).every(m=>m.matrixWorld.elements.every(Number.isFinite)));}
 authored.reset();game.reset();const q={position:[1,0,2],yaw:.2,hook:{phase:'outbound',phaseTime:.1,position:[1,2,-7]}};authored.update(0,q);game.update(0,q,{rLocomotion:true});near(mats(authored),mats(game));assert.equal(JSON.stringify(model),source);
});
