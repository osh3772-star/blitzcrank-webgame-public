import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {poseStateDigest} from './helpers/duel-human-pose-harness.js';
const runner=fileURLToPath(new URL('./helpers/duel-human-pose-case.mjs',import.meta.url));
const cases=[['active',20],['active',60],['active',120],['humanQ',60],['botQ',60],['unsafe',20],['humanResult',20],['botResult',60]];
for(const [kind,hz]of cases)test(`actual ${kind} ${hz}Hz retains every final pose while only redundant live refreshes disappear`,()=>{
 const run=mode=>JSON.parse(execFileSync(process.execPath,['--max-old-space-size=512',runner,mode,kind,String(hz)],{encoding:'utf8',maxBuffer:8*1024*1024}));
 const a=run('baseline'),b=run('candidate');assert.equal(a.frames.length,b.frames.length);assert.deepEqual(a.frames.map(f=>[f.hash,f.mirror,f.restored,f.state,f.phase]),b.frames.map(f=>[f.hash,f.mirror,f.restored,f.state,f.phase]));assert.equal(a.final,b.final);assert.deepEqual(a.skills,b.skills);assert.deepEqual(a.phases,b.phases);
 let removed=0;for(let i=0;i<a.frames.length;i++){const x=a.frames[i].trace,y=b.frames[i].trace;assert.equal(x.outer,y.outer);assert.equal(x.requiredInner,y.requiredInner);const saved=x.inner-y.inner;assert(saved===0||saved>=1);assert.equal(x.calls-y.calls,saved);if(saved)assert(y.outer>0);if(x.outer===0)assert.equal(y.inner,x.inner);removed+=saved;}
 assert(removed>0);console.log('DUEL_POSE_EQUIVALENCE '+JSON.stringify({kind,hz,frames:a.frames.length,removedCalls:removed}));
});

test('state digest preserves exact numeric boundaries, missing data and typed-array identity',()=>{
 const values=[0,-0,NaN,Infinity,-Infinity,undefined,null,'0','-0','NaN','Infinity',new Float32Array([1,-0]),new Float64Array([1,-0]),new Uint8Array([1,0]),new DataView(new Uint8Array([1,0]).buffer),new Uint8Array([1,0]).buffer];
 const hashes=values.map(poseStateDigest);assert.equal(new Set(hashes).size,values.length);assert.notEqual(poseStateDigest({a:undefined}),poseStateDigest({}));assert.notEqual(poseStateDigest(new Float32Array([1])),poseStateDigest(new Float32Array([1,0])));assert.equal(poseStateDigest([1,.25,-0]),poseStateDigest([1,.25,-0]));
});
