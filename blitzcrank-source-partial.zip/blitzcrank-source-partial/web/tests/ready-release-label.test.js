import test from 'node:test';
import assert from 'node:assert/strict';
import {createRuntimeHarness} from './helpers/deferred-runtime-harness.js';
test('natural desktop menu preserves release version before loading gameplay',async()=>{
 const h=await createRuntimeHarness();assert.equal(h.qa.state,'menu');assert.equal(h.requests.length,3);assert.match(h.element('loadstatus').textContent,/v0\.24\.87 ·/);assert.equal(h.qa.assets.parts,0);
});
test('canceled first choice keeps release version when pending assets finish',async()=>{
 const h=await createRuntimeHarness();h.element('practice').onclick();h.element('mainmenu').onclick();await h.loading.pending;
 assert.equal(h.qa.state,'menu');assert.equal(h.qa.playing,false);assert.equal(h.requests.length,10);assert.match(h.element('loadstatus').textContent,/준비 완료 · v0\.24\.87 ·/);
});
