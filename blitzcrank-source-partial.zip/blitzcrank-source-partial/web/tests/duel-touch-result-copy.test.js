import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
// One actual game runtime, mock DOM/audio/renderer and a fixed 50 ms clock.
// These checks validate displayed strings and rules, not font layout or GPU.
const writes=[],h=await createGameplayHarness({sourcePath:process.env.DUEL_RESULT_COPY_SOURCE||new URL('../main.js',import.meta.url),delta:()=>.05,storage:{getItem:()=>null,setItem:(...args)=>writes.push(args)}});
const until=condition=>{for(let i=0;i<200&&!condition();i++)h.frames(1);assert(condition(),'expected phase transition');};
function start(touch){h.docListeners.pointerdown({pointerType:touch?'touch':'mouse'});h.element('duelmode').click();h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});}
function finish(winner){
 for(let i=0;i<3;i++){
  until(()=>h.qa.duel.active);h.game.data.duelBot.position.set(0,1.7,5);
  if(winner==='human'){h.key('KeyR');h.release('KeyR');}else assert(h.game.data.duel.getSkills('bot').castR());
  until(()=>h.qa.duel.match.history.length===i+1);
  assert.equal(h.qa.duel.match.history.at(-1).winnerId,winner);
  h.frames(59);assert.equal(h.qa.state,'running');
  h.frames(1);assert.equal(h.qa.state,i===2?'results':'running');
 }
 assert.equal(h.qa.duel.match.winnerId,winner);
 assert.equal(h.qa.duel.match.history.length,3);
 assert.deepEqual(h.qa.duel.match.scores.map(s=>s.points),winner==='human'?[3,0]:[0,3]);
 assert.equal(h.qa.session.score,0);assert.deepEqual(writes,[]);
 assert(h.element('hud').classList.s.has('hidden')===false,'results retain HUD node, overlay handles visibility');
 assert(h.element('results').innerHTML.includes('<b>3</b><small>ROUNDS</small>'));
 assert.equal(h.element('start').innerHTML,'다시 대전 <span>▶</span>');
}
for(const touch of [false,true])for(const winner of ['human','bot'])test(`${touch?'touch':'desktop'} ${winner} victory: result skill wording and rules remain consistent`,()=>{
 start(touch);finish(winner);
 const intro=h.element('intro').textContent;
 assert(intro.includes(winner==='human'?'3 : 0':'0 : 3'));
 assert(intro.includes('개인 훈련 기록에는 저장하지 않아요.'));
 if(touch){assert(intro.includes('그랩 · 강철 주먹 · 전기장 명중 득점'));assert.doesNotMatch(intro,/\b[QER]\b/);}
 else assert(intro.includes('Q / E 펀치 / R 명중 득점'));
 h.element('start').click();assert.equal(h.qa.duel.match.history.length,0);assert.deepEqual(h.qa.duel.match.scores.map(s=>s.points),[0,0]);
 h.game.pause();h.element('practice').click();assert(h.qa.duel,'paused restart keeps duel mode');
 h.game.pause();h.element('mainmenu').click();assert.equal(h.qa.state,'menu');assert.equal(h.qa.duel,null);
 assert.equal(h.element('intro').innerHTML,'수정 마법사 · 중갑 수호자 · 대포 전차를 끌어오세요.<br>포탑의 경고선을 피하면서 90초 동안 포획하세요.');
});
