import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import {createModeRecords,MODE_RECORD_KEYS} from '../mode-records.js';
const h=await createGameplayHarness();
function fresh(){h.game.begin(true);for(const t of h.game.data.targets){t.active=t.group.visible=false;t.respawn=Infinity;}h.frames(1);}
const mouse=(button,extra={})=>h.element('game').listeners.pointerdown({pointerType:'mouse',button,preventDefault(){},...extra});

test('F is only Flash, G is no action, right click does not punch and left click does',()=>{
 fresh();const z=h.qa.player.z;h.key('KeyG');mouse(2);assert.equal(h.qa.flashAbility.casts,0);assert.equal(h.game.data.punchCooldown,0);
 h.key('KeyF');assert.equal(h.qa.flashAbility.casts,1);assert(Math.abs(h.qa.player.z-(z-4))<1e-6);assert.equal(h.game.data.punchCooldown,0);
 mouse(0);assert(h.game.data.punchCooldown>0);assert.equal(h.qa.flashAbility.casts,1);const cd=h.game.data.punchCooldown;mouse(0);assert.equal(h.game.data.punchCooldown,cd);
});
test('accepted Flash shows 15s and becomes available after 900 playing frames, not 899',()=>{
 fresh();h.key('KeyF');assert.equal(h.element('flashstatus').textContent,'15초');assert.equal(h.qa.flashAbility.cooldown,15);h.frames(899);assert(h.qa.flashAbility.remaining>0);h.key('KeyF');assert.equal(h.qa.flashAbility.casts,1);h.frames(1);assert.equal(h.qa.flashAbility.remaining,0);assert.equal(h.element('flashstatus').textContent,'준비');assert.equal(h.element('flashbutton').attributes['aria-disabled'],'false');
 h.dispatchKey({code:'KeyF',repeat:true});assert.equal(h.qa.flashAbility.casts,1);h.key('KeyF');assert.equal(h.qa.flashAbility.casts,2);assert.equal(h.element('flashstatus').textContent,'15초');
});
test('right click suppresses canvas browser menu without a second hit and never attacks while capture is pending',()=>{
 fresh();let prevented=0;h.element('game').listeners.contextmenu({preventDefault(){prevented++;}});assert.equal(prevented,1);assert.equal(h.game.data.punchCooldown,0);
 document.pointerLockElement=null;const canvas=h.element('game'),request=canvas.requestPointerLock;canvas.requestPointerLock=()=>new Promise(()=>{});mouse(0);assert.equal(h.game.data.punchCooldown,0);assert.equal(h.qa.flashAbility.casts,0);canvas.requestPointerLock=request;
 document.pointerLockElement=canvas;h.docListeners.pointerlockchange();mouse(0);const cd=h.game.data.punchCooldown;assert(cd>0);canvas.listeners.contextmenu({preventDefault(){prevented++;}});assert.equal(h.game.data.punchCooldown,cd);
});
test('E remains armed through F Flash, right click cannot consume it, left click strikes once',()=>{
 fresh();h.key('KeyE');h.frames(53);assert.equal(h.qa.skills.phase,'E_Hold');h.key('KeyF');assert.equal(h.qa.skills.phase,'E_Hold');mouse(2);assert.equal(h.qa.skills.phase,'E_Hold');mouse(0);assert.equal(h.qa.skills.phase,'E_Strike');const cooldown=h.game.data.punchCooldown;mouse(0);assert.equal(h.game.data.punchCooldown,cooldown);assert.equal(h.qa.flashAbility.casts,1);
});
test('15-second Flash records never read or overwrite previous 300-second record keys',()=>{
 const old={
  'rocket-hand-record-challenge90-flash-v1':' {"version":1,"mode":"challenge90-flash","rules":"challenge90-flash-v1","score":2000} ',
  'rocket-hand-record-combo-flash-v1':' {"version":1,"mode":"combo-flash","rules":"q-e-r-v1+flash-v1","seconds":1.2} ',
  'rocket-hand-record-combo-er-flash-v1':' {"version":1,"mode":"combo-er-flash","rules":"e-r-v1+flash-v1","seconds":1} '
 };
 const data=new Map(Object.entries(old)),reads=[];const records=createModeRecords({getStorage:()=>({getItem(k){reads.push(k);return data.get(k)??null;},setItem(k,v){data.set(k,v);}})});
 assert.equal(records.snapshot().challengeFlash.best,null);assert(records.recordChallenge({practice:false,done:true,score:2200,flashAssisted:true}));for(const route of ['qer','er'])assert(records.recordCombo({success:true,route,elapsed:2,flashAssisted:true}));
 for(const [k,v] of Object.entries(old)){assert.equal(data.get(k),v);assert(!reads.includes(k));}assert.equal(JSON.parse(data.get(MODE_RECORD_KEYS.challengeFlash)).score,2200);assert.match(MODE_RECORD_KEYS.comboFlash,/flash15-v1/);
});


test('touch punch stays independent and Flash screen-reader label does not mention keyboard',()=>{
 fresh();h.element('skillE').onpointerdown({pointerType:'touch',button:0,preventDefault(){}});h.frames(53);assert.equal(h.qa.skills.phase,'E_Hold');h.element('touchpunch').onpointerdown({pointerType:'touch',button:0,preventDefault(){}});assert.equal(h.qa.skills.phase,'E_Strike');assert.equal(h.qa.flashAbility.casts,0);assert(!/F|G|키/.test(h.element('flashbutton').attributes['aria-label']));
});
