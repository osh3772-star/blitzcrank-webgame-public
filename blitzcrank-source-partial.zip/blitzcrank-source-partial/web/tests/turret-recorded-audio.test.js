import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';import {TURRET_AUDIO_CUES,TURRET_AUDIO_EVENTS} from '../audio-cues.js';
const manifest=JSON.parse(fs.readFileSync(new URL('../assets/audio/turrets/source-manifest.json',import.meta.url)));
for(const row of manifest)test(`${row.id} keeps validated source bytes and bounded PCM playback`,()=>{
 const b=fs.readFileSync(new URL('../assets/audio/turrets/'+row.file,import.meta.url));assert.equal(crypto.createHash('sha256').update(b).digest('hex'),row.sha256);assert.equal(b.toString('ascii',0,4),'RIFF');assert.equal(b.toString('ascii',8,12),'WAVE');let format,pcm;
 for(let o=12;o+8<=b.length;){const size=b.readUInt32LE(o+4);assert(o+8+size<=b.length);const id=b.toString('ascii',o,o+4);if(id==='fmt ')format={type:b.readUInt16LE(o+8),channels:b.readUInt16LE(o+10),rate:b.readUInt32LE(o+12),bits:b.readUInt16LE(o+22)};if(id==='data')pcm=b.subarray(o+8,o+8+size);o+=8+size+(size%2);}
 assert.deepEqual(format,{type:1,channels:1,rate:48000,bits:16});assert.equal(pcm.length/2/48000,row.duration_seconds);let peak=0;for(let i=0;i<pcm.length;i+=2)peak=Math.max(peak,Math.abs(pcm.readInt16LE(i)));assert(peak/32768<=10**(-5.99/20));assert(peak>0);const cue=Object.values(TURRET_AUDIO_CUES).find(c=>c.url.endsWith('/'+row.file));assert(cue);assert.equal(cue.maxDuration,row.duration_seconds);assert.equal(row.synthesized,false);assert.equal(row.direct_listening_verified,false);assert.equal(row.game_use_license_verified,false);
});
test('turret source mappings are limited to three distinct semantic groups',()=>{
 assert.deepEqual(TURRET_AUDIO_EVENTS,{turretAcquired:'turretTarget',turretShot:'turretShot',turretImpact:'turretImpact'});assert.equal(new Set(Object.values(TURRET_AUDIO_CUES).map(c=>c.group)).size,3);
});
