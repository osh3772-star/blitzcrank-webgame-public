import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createSkillController} from '../skill-controller.js';
// Keep the frozen fixture and every exact comparison. Align only its known
// timer residue policy so this remains a presentation regression on one clock.
let baselineSource=fs.readFileSync(new URL('./fixtures/skill-controller-v2431.js',import.meta.url),'utf8');
for(const [before,after] of [
 ["from '../../skill-timeline.js'",`from '${new URL('../skill-timeline.js',import.meta.url).href}'`],
 ['cooldown[key]=Math.max(0,cooldown[key]-dt);','{cooldown[key]=Math.max(0,cooldown[key]-dt);if(cooldown[key]<1e-12)cooldown[key]=0;}'],
 ['boost=Math.max(0,boost-dt);','boost=Math.max(0,boost-dt);if(boost<1e-12)boost=0;'],
 ['slow=Math.max(0,slow-dt);','slow=Math.max(0,slow-dt);if(slow<1e-12)slow=0;'],
]){assert.equal(baselineSource.split(before).length,2,'Unknown frozen timer site: '+before);baselineSource=baselineSource.replace(before,after);}
const {createSkillController:createBaseline}=await import('data:text/javascript;base64,'+Buffer.from(baselineSource).toString('base64'));

import {SKILL_ASSET} from '../skill-animation-manifest.js';
import {bindSkillClips,clipFramePair,createFullbodyPoseApplicator} from '../skill-animation.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import {rig,THREE,minY} from './helpers/locomotion-rig.js';
const asset=JSON.parse(fs.readFileSync(new URL('../'+SKILL_ASSET.raw,import.meta.url))),clips=asset.models.fullbody.clips.filter(c=>c.name!=='W_Loop_Slow');
const withoutPresentation=x=>JSON.parse(JSON.stringify(x,(k,v)=>k==='presentation'?undefined:v));

test('seven-clip fallback presentation preserves exact v0.24.31 statuses, multipliers, events and deadlines on the corrected timer clock',()=>{
 for(const dts of [[1/20],[1/30],[1/60],[1/120],[1/144],[.008,.025,.014,.05,.016]])for(const mask of ['none','E','R']){
  const ae=[],be=[],a=createSkillController(clips,{onEvent:e=>ae.push(e)}),b=createBaseline(clips,{onEvent:e=>be.push(e)});assert.equal(a.castW(),b.castW());let time=0,f=0,masked=false,struck=false;
  while(time<15){const dt=dts[f++%dts.length];if(time>3.8&&!masked){masked=true;if(mask==='E')assert.equal(a.castE(),b.castE());if(mask==='R')assert.equal(a.castR(),b.castR());}if(time>5&&!struck){struck=true;assert.equal(a.strikeE(),b.strikeE());}
   a.step(dt);b.step(dt);time+=dt;assert.deepEqual(withoutPresentation(a.status),b.status);assert.equal(a.moveMultiplier,b.moveMultiplier);assert.equal(a.attackMultiplier,b.attackMultiplier);assert.equal(a.blocksAttack,b.blocksAttack);assert.deepEqual(ae,be);
   if(mask!=='none'&&a.animation?.name.startsWith(mask+'_'))assert.equal(a.animation.presentation,undefined);
  }a.reset();b.reset();assert.deepEqual(a.status,b.status);assert.equal(a.castW(),b.castW());assert.deepEqual(a.animation,b.animation);
 }
});

test('seven-clip fallback: every supported outgoing W phase is exactly retained, follows authored loop zero, then reaches the unchanged end deadline',()=>{
 for(const dts of [[1/20],[1/30],[1/60],[1/120],[1/144],[.008,.025,.014,.05,.016]]){
  const c=createSkillController(clips);c.castW();let previous=c.animation,frame=0,entry=null,seenEnd=false,lastTime=-1;
  while(frame<1500){c.step(dts[frame++%dts.length]);const now=c.animation;if(!now)break;
   if(previous.name==='W_Loop'&&now.name==='W_End'){assert.deepEqual(now.presentation,{name:previous.name,time:previous.time});entry=previous;}
   if(now.name==='W_End'){const p=now.presentation||now;if(p.name==='W_Loop'){assert(p.time>=entry.time&&p.time<entry.duration+1e-12);assert(!seenEnd);}else{seenEnd=true;assert(p.time>=lastTime);assert(p.time<=now.duration+1e-12);lastTime=p.time;}}
   previous=now;
  }assert(entry);assert(seenEnd);assert.equal(c.animation,null);
 }
});

let frameDt=1/60;
const h=await createGameplayHarness({delta:()=>frameDt}),r=rig(),surfaces=[...r.meshes.values()],bodyClips=Object.fromEntries(bindSkillClips(asset.models.fullbody,surfaces).map(c=>[c.name,c])),viewClips=Object.fromEntries(bindSkillClips(asset.models.viewmodel,h.game.data.parts).map(c=>[c.name,c])),apply=createFullbodyPoseApplicator(THREE);
function fresh(){frameDt=1/60;for(const key of ['KeyW','Space'])h.release(key);h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}}
function snapshot(){return [...h.game.data.parts,...h.game.data.fullbodyMeshes.values()].map(m=>{m.updateWorldMatrix(true,false);return m.matrixWorld.toArray();});}
function near(a,b,t=1e-11){assert.equal(a.length,b.length);for(let i=0;i<a.length;i++)for(let k=0;k<a[i].length;k++)assert(Math.abs(a[i][k]-b[i][k])<t,`entry ${i}/${k}`);}
function lowerSegment(mesh){for(let node=mesh;node;node=node.parent){if(node.name.startsWith('BC_Pivot_Ankle.'))return 2;if(node.name.startsWith('BC_Knee.'))return 1;if(node.name.startsWith('BC_Pivot_Hip.'))return 0;}return -1;}
const anchors=['L','R'].map(side=>({side,h:r.body.worldToLocal(r.nodes.get('BC_Pivot_Hip.'+side).getWorldPosition(new THREE.Vector3())),k:new THREE.Vector3(...r.motion.inspect().legs.find(l=>l.side===side).kneeCenter),a:new THREE.Vector3(side==='L'?.4575999677181244:-.4575999677181244,.1649997684954814,-.07430302635537339)}));
function delta(mesh){const rest=mesh.userData.skillRestPoint;return new THREE.Matrix4().makeTranslation(...rest).multiply(mesh.matrix).multiply(new THREE.Matrix4().makeTranslation(...rest.map(v=>-v)));}
function plantedLegs(){
 // Independent geometric expectations, not a second call to the W layer:
 // unchanged authored hip anchors, connected rigid leg segments, and a level
 // foot at its original source anchor. Reach-clamp residual is bounded to 0.1 mm.
 for(const {side,h:hip,k:knee,a:ankle}of anchors){
  const names=['BC_Thigh.','BC_Shin.','BC_Foot.'].map(name=>name+side),actual=names.map(name=>h.game.data.fullbodyMeshes.get(name)),reference=names.map(name=>r.meshes.get(name)),posed=actual.map(delta),authored=reference.map(delta);
  const point=(p,m)=>p.clone().applyMatrix4(m).toArray();
  near([point(hip,posed[0])],[point(hip,authored[0])]);
  near([point(knee,posed[0])],[point(knee,posed[1])]);
  near([point(ankle,posed[1])],[point(ankle,posed[2])]);
  near([point(ankle,posed[2])],[ankle.toArray()],.0001);
  near([new THREE.Vector3(0,1,0).transformDirection(posed[2]).toArray()],[[0,1,0]]);
  const corrections=posed.map((m,i)=>m.clone().multiply(authored[i].clone().invert()));
  let checked=0;
  for(const [name,m]of h.game.data.fullbodyMeshes){const segment=lowerSegment(m);if(segment<0||!name.endsWith('.'+side)&&!m.userData.sourcePart.endsWith('.'+side))continue;const ref=r.meshes.get(name);near([delta(m).elements],[corrections[segment].clone().multiply(delta(ref)).elements]);assert.equal(m.matrixAutoUpdate,false);assert.deepEqual(m.position.toArray(),ref.position.toArray());assert.deepEqual(m.quaternion.toArray(),ref.quaternion.toArray());assert.deepEqual(m.scale.toArray(),ref.scale.toArray());assert.deepEqual(m.userData.skillRestPoint,ref.userData.skillRestPoint);checked++;}
  assert(checked>=4,'all lower surfaces, including material splits, must be checked');
  const sole=h.game.data.fullbodyMeshes.get('BC_FootSole.'+side);sole.updateWorldMatrix(true,false);const floor=minY(sole)-(h.game.data.player.y-1.7);assert(floor>-.000001&&floor<.0001,'stationary sole must be planted: '+floor);
 }
}
function exactAuthored({stationary=false}={}){const status=h.qa.skills.animation,p=status.presentation||status,c=bodyClips[p.name];r.body.position.copy(h.game.data.fullbody.position);r.body.quaternion.copy(h.game.data.fullbody.quaternion);apply(c,p.time,surfaces);r.body.updateMatrixWorld(true);for(const [name,m]of r.meshes){const actual=h.game.data.fullbodyMeshes.get(name);actual.updateWorldMatrix(true,false);if(stationary&&lowerSegment(actual)>=0)continue;near([m.matrixWorld.toArray()],[actual.matrixWorld.toArray()]);}
 if(stationary)plantedLegs();
 const vc=viewClips[p.name],pair=clipFramePair(vc,p.time),q=new THREE.Quaternion(),q2=new THREE.Quaternion();for(let i=0;i<h.game.data.parts.length;i++){const m=h.game.data.parts[i],x=vc.frames[pair.a].poses[i],y=vc.frames[pair.b].poses[i],u=pair.u;near([m.position.toArray()],[x.p.map((v,k)=>(v+(y.p[k]-v)*u)*(k===2?-1:1))]);q.set(-x.q[0],-x.q[1],x.q[2],x.q[3]);q2.set(-y.q[0],-y.q[1],y.q[2],y.q[3]);q.slerp(q2,u);near([m.quaternion.toArray()],[q.toArray()]);near([m.scale.toArray()],[x.s.map((v,k)=>v+(y.s[k]-v)*u)]);}}

test('stationary W in both views preserves authored upper/viewmodel poses, planted legs and zero-jump exit boundaries at varied dt',()=>{
 for(const third of [false,true])for(const dts of [[1/20],[1/30],[1/60],[1/120],[1/144],[.008,.025,.014,.05,.016]]){fresh();if((h.qa.view==='third')!==third)h.element('viewtoggle').onclick();assert.equal(h.qa.view,third?'third':'first');h.game.castW();let previous=h.qa.skills.animation,seen=false;for(let frame=0;frame<1500;frame++){frameDt=dts[frame%dts.length];const prior=snapshot();h.frames(1);const now=h.qa.skills.animation;if(!now)break;if(previous.name==='W_Loop'&&now.name==='W_Loop_Slow'){near(snapshot(),prior);seen=true;}exactAuthored({stationary:true});previous=now;}assert(seen);}
});

test('W exit presentation freezes on pause and view changes, then resets without stale samples',()=>{
 for(const f of [321,325,333]){fresh();h.game.castW();h.frames(f);assert.equal(h.qa.skills.animation.name,'W_End');h.game.pause();const before=snapshot(),status=h.qa.skills;h.frames(50);for(let i=0;i<4;i++)h.element('viewtoggle').onclick();assert.deepEqual(h.qa.skills,status);near(snapshot(),before);h.game.resume();h.frames(1);assert(h.qa.skills.animation.time>status.animation.time);h.game.begin(true);assert.equal(h.qa.skills.animation,null);h.game.castW();assert.equal(h.qa.skills.animation.presentation,undefined);h.frames(1);exactAuthored({stationary:true});}
});

test('E, R, Q and punch mask the W presentation without stale exit pose leakage',()=>{
 for(const action of ['E','R','Q','punch']){fresh();h.game.castW();h.frames(234);if(action==='punch')h.punch();else{h.key('Key'+action);h.release('Key'+action);}h.frames(10);assert.equal(h.qa.skills.slow>0,true);
  if(action==='E'||action==='R'){assert(h.qa.skills.animation.name.startsWith(action+'_'));assert.equal(h.qa.skills.animation.presentation,undefined);}
  if(action==='Q')assert(h.qa.hook);
  for(const a of snapshot())assert(a.every(Number.isFinite));h.frames(120);assert.notEqual(h.qa.skills.animation?.presentation?.name,'W_Loop');h.game.begin(true);assert.equal(h.qa.skills.animation,null);
 }
});


test('settled moving W keeps every authored body and viewmodel pose through natural exit at varied dt',()=>{
 for(const third of [false,true])for(const dts of [[1/20],[1/30],[1/60],[1/120],[1/144],[.008,.025,.014,.05,.016]]){
  fresh();if((h.qa.view==='third')!==third)h.element('viewtoggle').onclick();h.key('KeyW');h.frames(35);h.game.castW();const seen=new Set();
  for(let frame=0;frame<1500;frame++){frameDt=dts[frame%dts.length];h.game.data.player.set(0,1.7,7);h.frames(1);const now=h.qa.skills.animation;if(!now)break;assert.equal(h.qa.motion.locomotion.moving,true);seen.add(now.name);exactAuthored();}
  assert.deepEqual([...seen],['W_Start','W_Loop','W_Loop_Slow','W_End']);assert.equal(h.qa.skills.animation,null);h.release('KeyW');
 }
});
test('stationary W airborne fade reaches the full authored pose without acquiring a new leg correction in flight',()=>{
 fresh();h.game.castW();h.frames(35);exactAuthored({stationary:true});h.key('Space');h.release('Space');h.frames(9);assert.equal(h.qa.motion.locomotion.grounded,false);let checked=0;
 for(let frame=0;frame<25;frame++){if(!h.qa.motion.locomotion.grounded){exactAuthored();checked++;}h.frames(1);}assert(checked>0);h.frames(60);assert.equal(h.qa.motion.locomotion.grounded,true);exactAuthored({stationary:true});
});
