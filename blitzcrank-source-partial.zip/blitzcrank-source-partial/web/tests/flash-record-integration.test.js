import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import {MODE_RECORD_KEYS as keys} from '../mode-records.js';
const raws={
 [keys.challenge]:' {"version":1,"mode":"challenge90","score":700} ',
 [keys.combo]:' {"version":1,"mode":"combo","rules":"q-e-r-v1","seconds":8} ',
 [keys.comboER]:' {"version":1,"mode":"combo-er","rules":"e-r-v1","seconds":8} ',
 'rocket-hand-best':'older mixed bytes'
};
const storage={data:new Map(Object.entries(raws)),writes:[],getItem(k){return this.data.get(k)??null;},setItem(k,v){this.data.set(k,v);this.writes.push([k,v]);}};
const h=await createGameplayHarness({storage});
function until(fn,max=500){for(let i=0;i<max&&!fn();i++)h.frames(1);assert(fn());}
function fresh(combo=false){h.game.begin(combo,combo);for(const t of h.game.data.targets){t.active=t.group.visible=false;t.respawn=Infinity;}}
function target(distance=2){const t=h.game.data.targets[0];t.anchor.set(0,1.7,h.qa.player.z-distance);t.group.position.copy(t.anchor);t.amplitude=t.speed=t.phase=0;t.active=t.group.visible=true;t.respawn=0;return t;}
function arm(){h.key('KeyE');until(()=>h.qa.skills.phase==='E_Hold');}
function strike(){h.punch();until(()=>h.qa.comboPractice.phase==='r');until(()=>!h.qa.skills.phase);}
function end(){h.key('KeyR');until(()=>h.qa.comboPractice.phase==='success');}
function unchanged(){for(const [k,v] of Object.entries(raws))assert.equal(storage.data.get(k),v,k);}

test('Flash-assisted completed challenge saves distinct record even after controller resets',()=>{
 fresh();h.key('KeyF');h.game.setScore(900);h.game.setElapsed(89.999);h.frames(1);assert.equal(h.qa.state,'results');assert.equal(h.qa.flashAbility.casts,0);unchanged();assert.equal(h.qa.records.challenge.best,700);assert.equal(h.qa.records.challengeFlash.best,900);assert.equal(JSON.parse(storage.data.get(keys.challengeFlash)).score,900);assert.match(h.element('best').textContent,/90초 최고 700점 · 점멸 900점/);
});
test('challenge defeat routes assisted record too; restart never inherits assisted eligibility',()=>{
 fresh();h.key('KeyF');h.game.setScore(1000);h.game.damagePlayer(100);assert.equal(h.qa.records.challengeFlash.best,1000);unchanged();fresh();assert.equal(h.element('scorelabel').textContent,'SCORE');h.game.setScore(600);h.game.damagePlayer(100);assert.equal(h.qa.records.challenge.best,700);assert.equal(h.qa.records.challengeFlash.best,1000);unchanged();
});
for(const route of ['qer','er'])test(`${route} accepted Flash during a timed attempt changes only assisted best`,()=>{
 fresh(true);const t=target(6);
 if(route==='qer'){h.key('KeyQ');h.key('KeyF');until(()=>!h.qa.hook);assert.equal(h.qa.comboPractice.phase,'e');arm();}else{arm();h.key('KeyF');}
 assert.equal(h.qa.comboPractice.flashAssisted,true);assert.equal(h.element('timerlabel').textContent,'점멸 연계');strike();end();
 assert(h.qa.comboPractice.last.flashAssisted);assert.equal(h.qa.comboPractice.bests[route],null);assert(h.qa.comboPractice.bestsFlash[route]>0);const key=route==='er'?'comboERFlash':'comboFlash';assert.equal(h.qa.records[key].best,h.qa.comboPractice.last.elapsed);assert.match(h.element('comborecord').textContent,/점멸/);unchanged();
 until(()=>h.qa.comboPractice.phase==='ready',180);assert.equal(h.qa.comboPractice.flashAssisted,false);assert(h.qa.flashAbility.remaining>0,'auto retry does not reset flash cooldown');
 // Same session next attempt, no new Flash. The old assisted result must not taint it.
 target(2);arm();strike();end();assert.equal(h.qa.comboPractice.last.flashAssisted,false);assert(h.qa.comboPractice.bests.er>0);assert(h.qa.comboPractice.bestsFlash[route]>0);
 // Restore seeded regular ER bytes to test each path independently.
 storage.data.set(keys.comboER,raws[keys.comboER]);
});
test('Flash before combo clock starts, cooldown-rejected Flash, and paused input do not taint an attempt',()=>{
 fresh(true);h.key('KeyF');target(2);arm();assert.equal(h.qa.comboPractice.flashAssisted,false);h.key('KeyF');assert.equal(h.qa.comboPractice.flashAssisted,false);h.game.pause();h.key('KeyF');h.game.resume();strike();end();assert.equal(h.qa.comboPractice.last.flashAssisted,false);
});
test('Flash assisted E miss never updates either route record',()=>{
 fresh(true);target(20);arm();h.key('KeyF');const writes=storage.writes.length;h.punch();until(()=>h.qa.comboPractice.phase==='failed');assert(h.qa.comboPractice.last.flashAssisted);assert.equal(storage.writes.length,writes);
});
test('changing to assisted rules mid-attempt updates personal best instead of showing regular fastest',()=>{
 fresh(true);target(6);arm();assert.match(h.element('comborecord').textContent,/개인 최단/);h.key('KeyF');assert.equal(h.qa.comboPractice.flashAssisted,true);assert.match(h.element('comborecord').textContent,/점멸 최단/);assert.equal(h.qa.comboPractice.best,null);
});
test('unchanged assisted HUD does not access storage, lookup elements or write DOM',()=>{
 h.game.updateHud();const writes=storage.writes.length;h.resetMetrics();for(let i=0;i<100;i++)h.game.updateHud();assert.equal(h.metrics.lookups,0);assert.equal(h.metrics.writes,0);assert.equal(storage.writes.length,writes);
});
