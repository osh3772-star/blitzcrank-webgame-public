import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {createTurretSimulation} from '../turret-core.js';
import {offscreenTurretDirection,turretDirectionWarnings,turretDirectionText} from '../turret-direction.js';
const camera=(aspect=1)=>{const c=new THREE.PerspectiveCamera(64,aspect,.1,200);c.position.set(0,1.7,0);return c;};
test('actual camera projection suppresses visible sources; rear sides are not mirrored',()=>{
 const c=camera();assert.equal(offscreenTurretDirection({x:0,y:1.7,z:-5},c),null);
 assert.equal(offscreenTurretDirection({x:10,y:1.7,z:-2},c).sector,0);
 assert.equal(offscreenTurretDirection({x:-10,y:1.7,z:-2},c).sector,4);
 assert.equal(offscreenTurretDirection({x:0,y:1.7,z:5},c).label,'뒤쪽');
 assert.ok(offscreenTurretDirection({x:5,y:1.7,z:5},c).sector<3);
 assert.ok(offscreenTurretDirection({x:-5,y:1.7,z:5},c).sector>2);
 c.rotation.y=Math.PI;assert.equal(offscreenTurretDirection({x:0,y:1.7,z:5},c),null);
});
test('portrait, landscape, pitched and shoulder-offset cameras use real frustum',()=>{
 for(const aspect of [.45,.75,1,1.8,2.5])for(const shoulder of [0,3])for(const pitch of [-.8,0,.5]){
  const c=camera(aspect);c.position.z=shoulder;c.rotation.x=pitch;c.updateMatrixWorld();
  const p=new THREE.Vector3(0,0,-8).applyMatrix4(c.matrixWorld);
  assert.equal(offscreenTurretDirection(p,c),null);
  const outside=new THREE.Vector3(50,0,-2).applyMatrix4(c.matrixWorld);
  assert.equal(offscreenTurretDirection(outside,c).sector,0);
 }
});
test('real simulation acquisition, cover, shot, death, reset and mode gates',()=>{
 const sim=createTurretSimulation({turrets:[{id:'rear',position:{x:0,y:0,z:5}}]});const p={x:0,y:1.7,z:0},torso={...p,y:1.15},c=camera();
 const warnings=(options={})=>turretDirectionWarnings(sim,c,p,{active:true,...options});
 sim.step(.01,{position:torso});assert.equal(warnings().length,1);assert.equal(warnings()[0].phase,'조준');
 for(const options of [{active:false},{duel:true},{combo:true}])assert.deepEqual(warnings(options),[]);
 sim.step(.01,{position:torso},{isVisible:()=>false});assert.deepEqual(warnings(),[]);
 sim.step(.75,{position:torso});assert.equal(warnings()[0].phase,'발사');
 sim.step(.01,{position:torso},{isVisible:()=>false});assert.deepEqual(warnings(),[]);
 sim.step(.01,{position:torso,alive:false});assert.deepEqual(warnings(),[]);
 sim.reset();assert.deepEqual(warnings(),[]);
});
test('cooldown without a threatening live projectile cannot show phantom fire',()=>{
 const sim=createTurretSimulation({turrets:[{position:{x:0,y:0,z:5}}]});sim.turrets[0].acquired=true;sim.turrets[0].state='cooldown';
 const p={x:0,y:1.7,z:0};assert.deepEqual(turretDirectionWarnings(sim,camera(),p,{active:true}),[]);
 sim.bullets.push({turretId:0,active:true,age:0,position:{x:0,y:1.15,z:5},velocity:{x:0,y:0,z:18}});
 assert.deepEqual(turretDirectionWarnings(sim,camera(),p,{active:true}),[]);
});
test('banner text is compact, grouped, fire-prioritized and bounded',()=>{
 const w={sector:1,behind:false,phase:'조준'};
 assert.equal(turretDirectionText([]),'');
 assert.equal(turretDirectionText([w,w,{...w,phase:'발사'}]),'포탑 ↘우하:발사');
 const all=Array.from({length:8},(_,sector)=>({...w,sector}));all.push({...w,behind:true});
 assert.equal(turretDirectionText(all),'포탑 →우:조준 ↘우하:조준 +7');
 assert(turretDirectionText(all).length<=20);
 assert.equal(turretDirectionText([{...w,behind:true}]),'포탑 ↘뒤:조준');
});
