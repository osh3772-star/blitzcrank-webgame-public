import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import {MODE_RECORD_KEYS as keys} from '../mode-records.js';
import {COMBO_PRACTICE_RULES as rules} from '../combo-practice.js';
const legacy='  {untouched legacy bytes';
const storage={data:new Map([['rocket-hand-best',legacy]]),reads:0,writes:[],getItem(key){this.reads++;return this.data.get(key)??null;},setItem(key,value){this.writes.push([key,value]);this.data.set(key,value);}};
let h=await createGameplayHarness({storage});
const until=(predicate,max=300)=>{for(let i=0;i<max&&!predicate();i++)h.frames(1);assert(predicate());};
function fresh(){h.game.begin(true,true);for(const t of h.game.data.targets){t.active=t.group.visible=false;t.respawn=Infinity;}const t=h.game.data.targets[0];t.anchor.set(0,1.7,2);t.group.position.copy(t.anchor);t.amplitude=t.speed=t.phase=0;t.active=t.group.visible=true;t.respawn=0;}
function pull(){h.key('KeyQ');until(()=>!h.qa.hook);assert.equal(h.qa.comboPractice.phase,'e');}
function empower(){h.key('KeyE');until(()=>h.qa.skills.phase==='E_Hold');h.punch();until(()=>h.qa.comboPractice.phase==='r');until(()=>!h.qa.skills.phase);}
function discharge(){h.key('KeyR');until(()=>h.qa.comboPractice.phase==='success');}

test('legacy mixed record is omitted; new menu has separate challenge, Q-first and E-first records',()=>{
 assert.equal(h.qa.state,'menu');assert.equal(h.element('best').textContent,'90초 최고 —');assert.equal(h.element('combobest').textContent,'그랩 연계 —');assert.match(h.element('recordstatus').textContent,/브라우저에만 저장.*통합 기록.*변경하지 않아요/);assert.equal(storage.writes.length,0);
});
test('abandoned challenge restart/menu and completed free practice never update challenge record',()=>{
 h.game.begin(false);h.game.setScore(1000);h.game.begin(false);assert.equal(storage.writes.length,0);
 h.game.setScore(2000);h.game.pause();h.element('mainmenu').onclick();assert.equal(storage.writes.length,0);
 h.game.begin(true);h.game.setScore(99999);h.game.damagePlayer(100);assert.equal(h.qa.state,'results');assert.equal(h.qa.session.done,true);assert.equal(storage.writes.length,0);
});
test('real timeout and lethal-damage finish save legitimate challenge best, not lower repeats',()=>{
 h.game.begin(false);h.game.setScore(600);h.game.setElapsed(89.999);h.frames(1);assert.equal(h.qa.state,'results');assert.equal(h.qa.records.challenge.best,600);assert.equal(JSON.parse(storage.data.get(keys.challenge)).score,600);
 h.game.begin(false);h.game.setScore(800);h.game.damagePlayer(100);assert.equal(h.qa.state,'results');assert.equal(h.qa.session.done,true);assert.equal(h.qa.records.challenge.best,800);
 const writes=storage.writes.length;h.game.finish(true);h.game.begin(false);h.game.setScore(200);h.game.damagePlayer(100);assert.equal(storage.writes.length,writes);assert.equal(h.element('best').textContent,'90초 최고 800점');
});
test('combo persists only at actual successful same-target R discharge, before retry/menu/finish',()=>{
 fresh();pull();empower();assert.equal(storage.data.has(keys.combo),false);const writes=storage.writes.length;h.key('KeyR');assert.equal(h.qa.skills.phase,'R_Cast');assert.equal(storage.writes.length,writes);assert.equal(h.qa.records.combo.best,null);
 until(()=>h.qa.comboPractice.phase==='success');const elapsed=h.qa.comboPractice.last.elapsed,stored=JSON.parse(storage.data.get(keys.combo));assert.equal(stored.seconds,elapsed);assert.equal(stored.rules,rules);assert.equal(h.qa.records.combo.saved,true);assert.equal(storage.writes.length,writes+1);assert.equal(h.qa.records.challenge.best,800);assert.match(h.element('comborecord').textContent,/개인 최단 .* · 이번 연습 /);
 h.frames(10);assert.equal(storage.writes.length,writes+1);h.game.finish();assert.equal(storage.writes.length,writes+1);
});
test('a new failed early R cannot resave the previous successful elapsed time',()=>{
 fresh();pull();empower();discharge();until(()=>h.qa.comboPractice.phase==='ready');const best=h.qa.records.combo.best,raw=storage.data.get(keys.combo),writes=storage.writes.length;
 pull();h.key('KeyR');until(()=>h.qa.comboPractice.phase==='failed');assert.equal(h.qa.comboPractice.last.success,false);assert.equal(h.qa.records.combo.best,best);assert.equal(storage.data.get(keys.combo),raw);assert.equal(storage.writes.length,writes);
});
test('slower valid attempt and restart retain saved best but reset this-round best only',()=>{
 const raw=storage.data.get(keys.combo),best=h.qa.records.combo.best,writes=storage.writes.length;fresh();assert.equal(h.qa.comboPractice.best,null);assert.equal(h.qa.records.combo.best,best);pull();h.frames(60);empower();discharge();assert(h.qa.comboPractice.best>best);assert.equal(storage.data.get(keys.combo),raw);assert.equal(storage.writes.length,writes);
 h.game.pause();h.element('practice').onclick();assert(h.qa.comboPractice.enabled);assert.equal(h.qa.comboPractice.best,null);assert.equal(h.qa.records.combo.best,best);assert.match(h.element('comborecord').textContent,/이번 연습 —/);
});
test('unchanged combo HUD causes no storage access, repeated DOM writes or lookups',()=>{
 fresh();h.game.updateHud();const reads=storage.reads,writes=storage.writes.length;h.resetMetrics();for(let i=0;i<120;i++)h.game.updateHud();assert.equal(h.metrics.writes,0);assert.equal(h.metrics.lookups,0);assert.equal(storage.reads,reads);assert.equal(storage.writes.length,writes);
});
test('page reconstruction reloads both personal bests while new combo session starts empty',async()=>{
 const previous=h.qa.records,writes=storage.writes.length;h=await createGameplayHarness({storage});assert.equal(h.qa.state,'menu');assert.deepEqual(h.qa.records,previous);assert.equal(h.qa.comboPractice.best,null);assert.equal(storage.writes.length,writes);assert.equal(storage.data.get('rocket-hand-best'),legacy);
 assert.equal(h.element('best').textContent,'90초 최고 800점');assert.equal(h.element('combobest').textContent,'그랩 연계 '+previous.combo.best.toFixed(2)+'초');fresh();assert.equal(h.qa.records.combo.best,previous.combo.best);assert.equal(h.qa.comboPractice.best,null);
});
test('touch combo HUD stays two lines and identifies page-only best when storage getter is blocked',async()=>{
 h=await createGameplayHarness({storageGetter(){throw Error('SecurityError');}});assert.equal(h.qa.state,'menu');assert.match(h.element('recordstatus').textContent,/저장할 수 없/);fresh();pull();empower();discharge();assert.equal(h.qa.records.combo.saved,false);assert.equal(h.qa.records.combo.issue,'unavailable');assert.match(h.element('combobest').textContent,/\(임시\)/);
 h.element('skillW').onpointerdown({pointerType:'touch',button:0,preventDefault(){}});const text=h.element('comborecord').textContent;assert.match(text,/^그랩 임시 \d+\.\d{2}초\n이번 \d+\.\d{2}초$/);assert.equal(text.split('\n').length,2);
 h.game.begin(false);h.game.setScore(400);h.game.damagePlayer(100);assert.equal(h.qa.state,'results');assert.equal(h.qa.records.challenge.saved,false);assert.equal(h.element('best').textContent,'90초 최고 400점 (임시)');assert.match(h.element('recordstatus').textContent,/새로고침하면 사라질/);
});
test('corrupt browser records remain unchanged through actual challenge and combo finishes',async()=>{
 const rawChallenge=' {"version":7} ',rawCombo='not-json';storage.data.set(keys.challenge,rawChallenge);storage.data.set(keys.combo,rawCombo);const writes=storage.writes.length;h=await createGameplayHarness({storage});assert.equal(h.qa.state,'menu');assert.match(h.element('recordstatus').textContent,/기존 기록은 그대로 보존/);
 h.game.begin(false);h.game.setScore(400);h.game.damagePlayer(100);fresh();pull();empower();discharge();assert.equal(storage.writes.length,writes);assert.equal(storage.data.get(keys.challenge),rawChallenge);assert.equal(storage.data.get(keys.combo),rawCombo);assert.equal(h.qa.records.combo.saved,false);assert.equal(h.qa.records.combo.issue,'invalid');
});
test('longest valid challenge score and temporary suffix remain text inside a wrapping menu item',async()=>{
 const score=Number.MAX_SAFE_INTEGER;storage.data.set(keys.challenge,JSON.stringify({version:1,mode:'challenge90',score}));storage.data.delete(keys.combo);h=await createGameplayHarness({storage});assert.equal(h.element('best').textContent,'90초 최고 '+score+'점');
 h=await createGameplayHarness({storageGetter(){throw Error('SecurityError');}});h.game.begin(false);h.game.setScore(score);h.game.damagePlayer(100);assert.equal(h.element('best').textContent,'90초 최고 '+score+'점 (임시)');
 const css=fs.readFileSync(new URL('../combo-practice.css',import.meta.url),'utf8');assert(css.includes('.mode-records>span{min-width:0;max-width:100%;overflow-wrap:anywhere}'));assert(css.includes('.mode-records #best{margin-left:0;font-size:inherit}'));
});
test('record status is separate from mobile-hidden notes and shipped dependency is release-matched',()=>{
 const read=path=>fs.readFileSync(new URL('../'+path,import.meta.url),'utf8'),html=read('index.html');assert.match(html,/<div class="mode-records"[^>]*><span id="best">[^<]*<\/span><span id="combobest">/);assert.match(html,/<p id="recordstatus" role="status">/);assert(!/<p class="note"[^>]*id="recordstatus"/.test(html));
 assert(read('combo-practice.css').includes('.mode-records{display:flex;flex-wrap:wrap;'));assert(read('mobile-interface.css').includes('body.touch-ui #recordstatus {font-size:9px;line-height:14px;}'));assert(read('build.mjs').includes("'mode-records.js'"));
 const main=read('main.js').match(/from '\.\/combo-practice\.js([^']+)'/)[1],dependency=read('mode-records.js').match(/from '\.\/combo-practice\.js([^']+)'/)[1];assert.equal(main,dependency);
});
