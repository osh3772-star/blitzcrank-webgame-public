import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

// Portable into tests/. The override permits isolated baseline/candidate runs.
// Actual main.js and Three.js scene graph run with the existing mocked DOM/GPU.
const root=process.env.VIEW_VFX_APP_ROOT||fileURLToPath(new URL('../',import.meta.url));
const {createGameplayHarness}=await import(pathToFileURL(path.join(root,'tests/helpers/runtime-harness.js')));
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'paused-view-runtime-'));
const sourcePath=path.join(temporary,'main.mjs');
fs.writeFileSync(sourcePath,fs.readFileSync(path.join(root,'main.js'),'utf8')+'\nwindow.__PAUSED_VIEW_TEST__={get data(){return {viewScene,skillVfx,flashFrameVfx};}};\n');
const h=await createGameplayHarness({sourcePath});
const extra=globalThis.__PAUSED_VIEW_TEST__;
const wView=()=>extra.data.viewScene.getObjectByName('W_FPS_peripheral_adaptation');
const flashReplay=()=>extra.data.viewScene.getObjectByName('Flash_selected_departure_FPS_replay');
const toggle=()=>h.element('viewtoggle').onclick();
const hash=data=>createHash('sha256').update(JSON.stringify(data)).digest('hex');
function authoritative(){
 const {vfx,effects,...skills}=h.qa.skills;
 return structuredClone({session:h.qa.session,skills,flash:h.qa.flashAbility,player:h.qa.player,
  health:h.qa.health,targets:h.qa.targets,hook:h.qa.hook,duel:h.qa.duel,records:h.qa.records,
  shotCooldown:h.game.data.shotCooldown,punchCooldown:h.game.data.punchCooldown});
}
function frozenEffects(){
 const flash={...h.qa.flashFrames};delete flash.fpsReplay;
 const meshes=[];
 for(const root of [h.game.data.scene,extra.data.viewScene])root.traverse(o=>{
  if(!/^(W_|E_|R_)/.test(o.name)||!o.geometry)return;
  meshes.push({name:o.name,drawRange:{...o.geometry.drawRange},
   attributes:Object.fromEntries(Object.entries(o.geometry.attributes).map(([key,a])=>[key,{version:a.version,array:[...a.array]}])),
   opacity:o.material.opacity,uniformOpacity:o.material.uniforms?.uOpacity?.value});
 });
 return {flash,skill:h.qa.skills.vfx,geometry:hash(meshes),atlas:flashReplay().material.map.offset.toArray()};
}
function fresh(view,effect,mode='practice'){
 h.game.begin(true,false,mode==='duel');
 if(h.qa.view!==view)toggle();h.frames(1);
 if(mode==='duel'){
  h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});
  for(let i=0;i<120&&!h.qa.duel.active;i++)h.frames(1);
  assert.equal(h.qa.duel.active,true,'duel countdown must finish before skill input');
 }
 if(effect==='W')h.game.castW();else h.game.castFlash();h.frames(8);
 assert.equal(effect==='W'?h.qa.skills.vfx.wVisible:h.qa.flashFrames.active,true);
 assert.equal(h.qa.view,view);
}
function checkView(effect){
 assert.equal(wView().visible,effect==='W'&&h.qa.view==='first','W FPS visibility must match view immediately');
 assert.equal(flashReplay().visible,effect==='Flash'&&h.qa.view==='first','Flash FPS visibility must match view immediately');
 assert.equal(h.game.data.fullbody.visible,h.qa.view==='third');
}
for(const mode of ['practice','duel'])for(const effect of ['W','Flash'])for(const view of ['first','third'])for(const flow of ['paused','running-before-frame']){
 test(`${mode} ${effect}: ${view} view switches immediately while ${flow} without advancing simulation`,()=>{
  fresh(view,effect,mode);if(flow==='paused')h.game.pause();
  const before=authoritative(),effects=frozenEffects();
  toggle();checkView(effect);
  assert.deepEqual(authoritative(),before);assert.deepEqual(frozenEffects(),effects);
  if(flow==='running-before-frame')h.game.pause();
  const paused=authoritative();h.frames(3);checkView(effect);
  assert.deepEqual(authoritative(),paused);assert.deepEqual(frozenEffects(),effects);
  toggle();checkView(effect);toggle();checkView(effect);
  assert.deepEqual(authoritative(),paused);assert.deepEqual(frozenEffects(),effects);
  h.game.resume();h.frames(1);checkView(effect);
 });
}
test('capture-blocked running frames refresh the view but freeze W and Flash ages',()=>{
 for(const effect of ['W','Flash']){
  fresh('third',effect);document.pointerLockElement=null;
  assert.equal(h.qa.playing,false);const before=authoritative(),effects=frozenEffects();
  toggle();checkView(effect);h.frames(3);checkView(effect);
  assert.deepEqual(authoritative(),before);assert.deepEqual(frozenEffects(),effects);
 }
});
test('skillVfx.update(0) remains a strict no-op, distinct from view refresh',()=>{
 fresh('third','W');h.game.pause();const before=frozenEffects(),visibility=wView().visible;
 extra.data.skillVfx.update(0,{status:h.game.data.skills.status,position:h.game.data.player,thirdPerson:false});
 assert.equal(wView().visible,visibility);assert.deepEqual(frozenEffects(),before);
});
test('Flash zero-time view refresh preserves departure origin, source pixels and cursor',()=>{
 fresh('third','Flash');h.game.pause();const before=frozenEffects(),sprite=h.game.data.scene.getObjectByName('Flash_selected_video_departure');
 const replay=flashReplay(),material=replay.material,map=material.map;
 assert.equal(sprite.material,material);
 extra.data.flashFrameVfx.update(0,{firstPerson:true});assert.equal(replay.visible,true);
 assert.deepEqual(frozenEffects(),before);assert.equal(replay.material,material);assert.equal(replay.material.map,map);
});
test('reset effects never revive when a paused view changes',()=>{
 for(const effect of ['W','Flash']){
  fresh('third',effect);if(effect==='W')extra.data.skillVfx.reset();else extra.data.flashFrameVfx.reset();
  h.game.pause();const before=frozenEffects();toggle();
  assert.equal(effect==='W'?wView().visible:flashReplay().visible,false);assert.deepEqual(frozenEffects(),before);
 }
});
