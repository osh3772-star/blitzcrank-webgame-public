import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';
import {loadBlitzTextures,createBlitzMaterial} from '../blitz-materials.js';
const legacy='./assets/blitz-materials/aged-yellow-basecolor.46f000102005e744.png',replacement='./assets/blitz-materials/aged-yellow-basecolor.934272f6b63ea94b.png';
const roughLegacy='./assets/blitz-materials/aged-yellow-roughness.de1e87c13e16d312.png',roughReplacement='./assets/blitz-materials/aged-yellow-roughness.5ab56dca175fc5e2.png';
const part={color:[1,1,1],material:{baseColorTexture:legacy,roughnessTexture:'./assets/blitz-materials/aged-yellow-roughness.de1e87c13e16d312.png'}},data={parts:[part,structuredClone(part)]};
test('one exact transport alias preserves original model, shared bank, material identity and sampling',async()=>{
 const requests=[],bank=new Map(),loader={async loadAsync(p){requests.push(p);return new THREE.Texture();}};
 await Promise.all([loadBlitzTextures(THREE,data,bank,loader),loadBlitzTextures(THREE,data,bank,loader)]);
 assert.deepEqual(requests,[replacement,roughReplacement]);assert.equal(part.material.baseColorTexture,legacy);
 const mat=createBlitzMaterial(THREE,part,undefined,bank);assert.equal(mat.map,bank.get('color:'+legacy));assert.equal(mat.map.colorSpace,THREE.SRGBColorSpace);assert.equal(mat.roughnessMap.colorSpace,THREE.NoColorSpace);assert.equal(mat.map.anisotropy,4);assert.equal(mat.map.wrapS,THREE.RepeatWrapping);assert.equal(mat.map.wrapT,THREE.RepeatWrapping);
 const bytes=fs.readFileSync(new URL('../'+replacement,import.meta.url));assert.equal(bytes.length,1182360);assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),'934272f6b63ea94b1480738a57153797e5f44f32fcd06b03cbba4bd3aaaa167e');
});
test('replacement failure clears original bank key and retries same transport exactly once',async()=>{
 const bank=new Map(),requests=[],one={parts:[{material:{baseColorTexture:legacy}}]};
 await assert.rejects(loadBlitzTextures(THREE,one,bank,{async loadAsync(p){requests.push(p);throw Error('fixture missing');}}),/fixture missing/);assert.equal(bank.size,0);
 await loadBlitzTextures(THREE,one,bank,{async loadAsync(p){requests.push(p);return new THREE.Texture();}});assert.deepEqual(requests,[replacement,replacement]);assert.equal(bank.size,1);
});
test('other legal paths remain unchanged and external or traversal paths stay denied',async()=>{
 for(const p of ['./assets/blitz-materials/other.png',replacement]){const requests=[];await loadBlitzTextures(THREE,{parts:[{material:{baseColorTexture:p}}]},new Map(),{async loadAsync(path){requests.push(path);return new THREE.Texture();}});assert.deepEqual(requests,[p]);}
 for(const p of ['https://example.com/a.png','./assets/blitz-materials/../evil.png',legacy+'?x=1'])await assert.rejects(loadBlitzTextures(THREE,{parts:[{material:{baseColorTexture:p}}]},new Map(),{loadAsync(){assert.fail('should not request');}}),/Invalid player texture path/);
});

test('roughness exact transport retains linear sampling and legacy cache key; failure permits retry',async()=>{
 const bank=new Map(),requests=[],one={parts:[{material:{roughnessTexture:roughLegacy}}]};
 await assert.rejects(loadBlitzTextures(THREE,one,bank,{async loadAsync(p){requests.push(p);throw Error('rough missing');}}),/rough missing/);assert.equal(bank.size,0);
 await loadBlitzTextures(THREE,one,bank,{async loadAsync(p){requests.push(p);return new THREE.Texture();}});
 assert.deepEqual(requests,[roughReplacement,roughReplacement]);assert.equal(bank.size,1);
 const texture=bank.get('roughness:'+roughLegacy),mat=createBlitzMaterial(THREE,one.parts[0],undefined,bank);assert.equal(mat.roughnessMap,texture);assert.equal(texture.colorSpace,THREE.NoColorSpace);assert.equal(texture.wrapS,THREE.RepeatWrapping);assert.equal(texture.wrapT,THREE.RepeatWrapping);assert.equal(texture.anisotropy,4);
 const bytes=fs.readFileSync(new URL('../'+roughReplacement,import.meta.url));assert.equal(bytes.length,180148);assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),'5ab56dca175fc5e209049c0b6a62156a82283256cb9c937831c1b5136a624d3d');
});
test('roughness direct hashed paths remain direct, and unsafe roughness paths remain denied',async()=>{
 const requests=[];await loadBlitzTextures(THREE,{parts:[{material:{roughnessTexture:roughReplacement}}]},new Map(),{async loadAsync(p){requests.push(p);return new THREE.Texture();}});assert.deepEqual(requests,[roughReplacement]);
 for(const p of ['https://example.com/a.png','./assets/blitz-materials/../evil.png',roughLegacy+'?x=1'])await assert.rejects(loadBlitzTextures(THREE,{parts:[{material:{roughnessTexture:p}}]},new Map(),{loadAsync(){assert.fail('should not request');}}),/Invalid player texture path/);
});
