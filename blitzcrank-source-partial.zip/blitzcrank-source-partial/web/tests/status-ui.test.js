import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/status-runtime-harness.js';

// Real game source and real Three scene graph. Renderer, DOM, pointer lock and
// clock are controlled test doubles; this does not claim GPU/browser coverage.
const h=await createGameplayHarness(),el=h.element;
const hidden=id=>el(id).classList.s.has('hidden');
const aimed=()=>el('crosshair').classList.s.has('aimed');
const alpha=()=>Number(el('damageflash').style.opacity);
const note=()=>el('hitnotice').textContent;
const name=()=>el('targetname').textContent;
function begin(practice=true){
 h.setPointerLockMode('immediate');h.setDelta(1/60);
 h.docEvent('pointerdown',{pointerType:'mouse'});h.game.begin(practice);
 assert.equal(h.qa.state,'running');assert.equal(h.qa.playing,true);
}
function warn(){h.game.data.player.set(-12,1.7,-9);h.frames(1);assert.equal(h.qa.turrets.warning,true);assert.equal(hidden('threatwarning'),false);}
function assertFrozen(previous){assert.equal(note(),previous.note);assert.equal(name(),previous.name);assert.equal(aimed(),previous.aimed);assert.equal(hidden('threatwarning'),previous.hidden);assert.equal(h.game.data.noticeTime,previous.noticeTime);assert.equal(h.qa.session.elapsed,previous.elapsed);}
function frozen(){return{note:note(),name:name(),aimed:aimed(),hidden:hidden('threatwarning'),noticeTime:h.game.data.noticeTime,elapsed:h.qa.session.elapsed};}
function affectedWrites(){return h.statusWrites.filter(x=>!(x.id==='crosshair'&&x.property==='class.hidden'));}

test('notice expiry clears its cached value so the identical notice can display again',()=>{
 begin();h.game.notice('+100  CAPTURE');assert.equal(note(),'+100  CAPTURE');h.frames(61);assert.equal(note(),'');assert.equal(h.game.data.noticeTime,0);
 h.game.notice('+100  CAPTURE');assert.equal(note(),'+100  CAPTURE');assert.equal(h.game.data.noticeTime,1);h.frames(1);assert.equal(note(),'+100  CAPTURE');
});

test('repeating a still-visible notice refreshes its timer and repeats the live-region text mutation',()=>{
 begin();h.game.notice('MISSED');h.frames(40);assert(h.game.data.noticeTime<.4);h.resetMetrics();h.game.notice('MISSED');assert.equal(h.game.data.noticeTime,1);assert.deepEqual(h.statusWrites.filter(x=>x.id==='hitnotice'),[{id:'hitnotice',property:'textContent',value:'MISSED'}]);h.frames(40);assert.equal(note(),'MISSED');h.frames(21);assert.equal(note(),'');
});

test('begin clears notice immediately and the same notice can return before any frame',()=>{
 begin();h.game.notice('BLOCKED');begin();assert.equal(note(),'');assert.equal(h.game.data.noticeTime,0);h.game.notice('BLOCKED');assert.equal(note(),'BLOCKED');
});

test('damage reset followed by identical damage/frame alpha never leaves a stale zero',()=>{
 begin();h.game.damagePlayer(1);h.frames(1);const prior=alpha();assert.equal(prior,h.game.data.damageFlash);assert(prior>0);
 begin();assert.equal(alpha(),0);assert.equal(h.game.data.damageFlash,0);
 h.game.damagePlayer(1);assert.equal(alpha(),0,'damage appears on the next tick, not in the event handler');h.frames(1);assert.equal(alpha(),prior);assert.equal(alpha(),h.game.data.damageFlash);
});

test('damage opacity preserves full precision and decays every rendered tick',()=>{
 begin();h.game.damagePlayer(1);h.setDelta(.00001);h.frames(1);const first=alpha();assert.equal(first,.28-.00001);h.frames(1);assert.notEqual(alpha(),first);assert.equal(alpha(),h.game.data.damageFlash);
 h.game.pause();h.setDelta(1/60);h.frames(20);assert.equal(alpha(),0);assert.equal(h.game.data.damageFlash,0);h.game.damagePlayer(1);assert.equal(h.game.data.damageFlash,0,'paused damage is ignored');
});

for(const action of ['finish','returnToMenu','begin'])test(`warning -> ${action} -> begin -> same turret reacquisition is visible`,()=>{
 begin();warn();
 if(action==='begin')begin();else h.game[action]();
 assert.equal(hidden('threatwarning'),true,'reset hides warning immediately');assert.equal(h.qa.turrets.warning,false);
 if(action!=='begin')begin();
 assert.equal(hidden('threatwarning'),true);warn();
});

test('warning cancellation and same-turret reacquisition track actual simulation state',()=>{
 begin();warn();h.game.data.player.set(0,1.7,7);h.frames(1);assert.equal(h.qa.turrets.warning,false);assert.equal(hidden('threatwarning'),true);warn();
});

test('aimed target -> miss -> same target restores both independent fields',()=>{
 begin();h.frames(1);const label=name();assert(label);assert.equal(aimed(),true);
 h.game.aim(1000,0);h.frames(1);assert.equal(aimed(),false);assert.equal(name(),'');
 h.game.aim(-1000,0);h.frames(1);assert.equal(aimed(),true);assert.equal(name(),label);
});

test('aimed state is based on target existence and text cache is based on label, not target identity',()=>{
 begin();h.frames(1);const target=h.game.data.targets[0],label=target.label;
 try{target.label='';h.frames(1);assert.equal(aimed(),true);assert.equal(name(),'');target.label='SAME TARGET / NEW LABEL';h.frames(1);assert.equal(aimed(),true);assert.equal(name(),'SAME TARGET / NEW LABEL');}
 finally{target.label=label;}
});

test('restart and capture-hidden changes do not conflate hidden and aimed classes',()=>{
 begin();h.frames(1);const label=name();assert.equal(aimed(),true);assert.equal(hidden('crosshair'),false);
 h.game.pause();assert.equal(hidden('crosshair'),true);assert.equal(aimed(),true);assert.equal(name(),label);
 begin();assert.equal(aimed(),true);assert.equal(name(),label);assert.equal(hidden('crosshair'),false);h.frames(1);assert.equal(aimed(),true);assert.equal(name(),label);
 h.game.aim(1000,0);h.frames(1);assert.equal(aimed(),false);begin();assert.equal(aimed(),false,'baseline only recalculates aim on the next playable frame');assert.equal(name(),'');h.frames(1);assert.equal(aimed(),true);assert.equal(name(),label);
});

test('pause freezes notice/target/threat but damage fades; resume continues remaining time',()=>{
 begin();warn();h.game.notice('PAUSE CHECK');h.game.damagePlayer(1);h.frames(1);h.game.pause();const before=frozen();h.frames(90);assertFrozen(before);assert.equal(alpha(),0);assert.equal(hidden('crosshair'),true);
 h.game.resume();h.frames(1);assert.equal(note(),'PAUSE CHECK');assert(h.game.data.noticeTime<before.noticeTime);assert.equal(hidden('crosshair'),false);assert.equal(hidden('threatwarning'),!h.qa.turrets.warning);
});

test('running while waiting for pointer capture freezes gameplay statuses; acquisition resumes them',()=>{
 begin();warn();h.game.notice('WAIT CHECK');h.game.damagePlayer(1);h.frames(1);h.game.pause();h.setPointerLockMode('pending');h.game.resume();assert.equal(h.qa.state,'running');assert.equal(h.qa.playing,false);assert.equal(hidden('crosshair'),true);assert.equal(hidden('captureprompt'),false);const before=frozen();h.frames(90);assertFrozen(before);assert.equal(alpha(),0);
 h.acquirePointer();assert.equal(h.qa.playing,true);assert.equal(hidden('crosshair'),false);h.frames(1);assert(h.game.data.noticeTime<before.noticeTime);assert.equal(note(),'WAIT CHECK');h.setPointerLockMode('immediate');
});

test('pointer-lock loss, blur and document hiding freeze gameplay without stale recapture',()=>{
 for(const interrupt of [()=>h.releasePointer(),()=>h.winEvent('blur'),()=>{document.hidden=true;h.docEvent('visibilitychange');document.hidden=false;}]){
  begin();h.frames(1);h.game.notice('INTERRUPT');interrupt();assert.equal(h.qa.state,'paused');const before=frozen();h.frames(61);assertFrozen(before);h.game.resume();h.frames(1);assert.equal(note(),'INTERRUPT');assert.equal(aimed(),true);assert.equal(hidden('crosshair'),false);
 }
});

test('context loss freezes gameplay, blocks restart/resume, and restoration requires explicit resume',()=>{
 begin();warn();h.game.notice('CONTEXT CHECK');h.game.damagePlayer(1);h.frames(1);let prevented=false;h.canvasEvent('webglcontextlost',{preventDefault(){prevented=true;}});assert.equal(prevented,true);assert.equal(h.qa.state,'paused');assert.equal(el('start').disabled,true);const before=frozen();h.frames(90);assertFrozen(before);assert.equal(alpha(),0);
 h.game.resume();h.game.begin();assert.equal(h.qa.state,'paused');assertFrozen(before);
 h.canvasEvent('webglcontextrestored');assert.equal(h.qa.state,'paused');assert.equal(el('start').disabled,false);assertFrozen(before);h.game.resume();h.frames(1);assert(h.game.data.noticeTime<before.noticeTime);assert.equal(note(),'CONTEXT CHECK');assert.equal(hidden('threatwarning'),!h.qa.turrets.warning);
});

test('timeout results freeze notice/target, hide warning, and continue fading damage',()=>{
 begin(false);warn();h.game.notice('RESULT CHECK');h.game.damagePlayer(1);const label=name(),wasAimed=aimed();h.game.setElapsed(89.999);h.frames(1);assert.equal(h.qa.state,'results');assert.equal(note(),'RESULT CHECK');assert.equal(h.game.data.noticeTime,1);assert.equal(name(),label);assert.equal(aimed(),wasAimed);assert.equal(hidden('threatwarning'),true);assert.equal(hidden('crosshair'),true);h.frames(30);assert.equal(alpha(),0);assert.equal(note(),'RESULT CHECK');
 h.game.returnToMenu();h.frames(61);assert.equal(note(),'RESULT CHECK');assert.equal(hidden('threatwarning'),true);begin();assert.equal(note(),'');assert.equal(alpha(),0);warn();
});

test('lethal turret-step callback cannot leave warning visible after reset/results',()=>{
 begin();warn();h.game.setHealth(1);let i=0;while(h.qa.state==='running'&&i++<180)h.frames(1);
 assert.equal(h.qa.state,'results');assert.equal(h.qa.health,0);assert.equal(h.qa.turrets.warning,false);assert.equal(hidden('threatwarning'),true);h.frames(30);assert.equal(alpha(),0);begin();warn();
});

test('touch play recomputes statuses without pointer capture and pause still freezes them',()=>{
 begin();h.game.pause();h.docEvent('pointerdown',{pointerType:'touch'});h.game.resume();assert.equal(document.pointerLockElement,null);assert.equal(h.qa.playing,true);h.frames(1);assert.equal(aimed(),true);assert.equal(hidden('crosshair'),false);h.game.notice('TOUCH CHECK');h.game.pause();const before=frozen();h.frames(61);assertFrozen(before);h.game.resume();h.frames(1);assert(h.game.data.noticeTime<before.noticeTime);begin();
});

test('settled status frames issue no redundant targeted DOM writes in running, paused, menu or results',()=>{
 begin();h.frames(1);h.resetMetrics();h.frames(20);assert.deepEqual(affectedWrites(),[],'stable playing statuses');
 for(const change of [()=>h.game.pause(),()=>h.game.returnToMenu(),()=>h.game.finish()]){change();h.frames(1);h.resetMetrics();h.frames(20);assert.deepEqual(affectedWrites(),[]);}
});
