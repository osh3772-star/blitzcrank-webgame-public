import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

function snapshot(r) {
  return {duel:r.qa.duel,player:r.qa.player,session:r.qa.session,skills:r.qa.skills,
    hook:r.qa.hook,flash:r.qa.flashAbility,velocity:r.game.data.duelBot.velocity.toArray()};
}
async function start({quiet=false}={}) {
  let dt=.05;
  const r=await createGameplayHarness({delta:()=>dt});
  r.element('duelmode').click();
  if(quiet)r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,jump:false})});
  r.frames(33);
  assert.equal(r.qa.duel.match.phase,'active');
  return {r,setDelta(value){dt=value;}};
}
test('zero-time active frame preserves finite bot motion and the full match snapshot',async()=>{
  const {r,setDelta}=await start();
  const before=snapshot(r),brain=r.game.data.duelBrain.snapshot();
  setDelta(0);
  assert.doesNotThrow(()=>r.frames(1));
  assert.deepEqual(snapshot(r),before);
  assert.deepEqual(r.game.data.duelBrain.snapshot(),brain);
  setDelta(.05);r.frames(1);
  assert(r.game.data.duelBot.velocity.toArray().every(Number.isFinite));
  assert(r.qa.session.elapsed>before.session.elapsed);
});
test('repeated zero-time frames after pause/resume preserve an airborne player and flying Q',async()=>{
  const {r,setDelta}=await start({quiet:true});
  r.key('Space');r.key('KeyQ');r.frames(6);
  assert(r.qa.player.y>1.7);assert.equal(r.qa.hook.phase,'outbound');
  r.game.pause();setDelta(0);r.game.resume();
  const before=snapshot(r);
  assert.doesNotThrow(()=>r.frames(3));
  assert.deepEqual(snapshot(r),before);
  setDelta(.05);r.frames(1);
  assert(r.qa.hook.travel>before.hook.travel);
  assert(r.game.data.duelBot.velocity.toArray().every(Number.isFinite));
});
test('zero-time frame during retained E knockup does not alter the reaction or score',async()=>{
  const {r,setDelta}=await start({quiet:true});
  r.game.data.duelBot.position.set(0,1.7,5);
  r.key('KeyE');r.frames(20);r.punch();r.frames(10);
  assert(r.game.data.duelBot.knockup);assert(r.game.data.duelBot.position.y>1.7);
  const before=snapshot(r);
  setDelta(0);assert.doesNotThrow(()=>r.frames(1));
  assert.deepEqual(snapshot(r),before);
  setDelta(.05);r.frames(30);
  assert.equal(r.game.data.duelBot.knockup,null);
  assert.equal(r.game.data.duelBot.position.y,1.7);
  assert.equal(r.qa.duel.match.history.length,1);
});

test('zero-time refresh keeps the current walking viewmodel rather than switching to idle',async()=>{
 const {r,setDelta}=await start({quiet:true});r.key('KeyW');r.frames(20);assert(r.qa.motion.locomotion.moving);
 const pose=()=>r.game.data.parts.map(p=>({position:p.position.toArray(),quaternion:p.quaternion.toArray()}));
 const before=pose(),motion=r.qa.motion;setDelta(0);r.frames(1);assert.deepEqual(pose(),before);assert.deepEqual(r.qa.motion,motion);
});
