import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// CPU-only integration: real main.js handlers and simulation, mocked DOM/GPU.
// Optional relative override runs the exact same assertions on a saved baseline.
const sourcePath=new URL(process.env.DUEL_MOVEMENT_SOURCE||'../main.js',import.meta.url);
const r=await createGameplayHarness({sourcePath,delta:()=>.05});
const codes=['KeyW','KeyA','KeyS','KeyD'];
const actions=['KeyQ','KeyE','KeyR','KeyF','Space','ShiftLeft','ShiftRight'];
const xy=()=>[r.qa.player.x,r.qa.player.z];
function until(predicate,message='phase transition timed out'){
 for(let n=0;n<250&&!predicate();n++)r.frames(1);
 assert(predicate(),message);
}
function start(active=false){
 document.hidden=false;
 r.docListeners.pointerdown({pointerType:'mouse'});
 r.element('duelmode').click();
 r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});
 assert.equal(r.qa.playing,true);
 assert.equal(r.qa.duel.match.phase,'countdown');
 assert.equal(r.game.data.keys.size,0);
 if(active)until(()=>r.qa.duel.active);
}
function repeat(code){r.dispatchKey({code,repeat:true});}
function score(skill='R',{held=null}={}){
 const n=r.qa.duel.match.history.length,d=r.game.data;
 // Deterministic geometric fixture only; scoring still uses real commands/contacts.
 d.duelBot.position.set(d.player.x,1.7,d.player.z-2);
 if(skill==='E'){r.key('KeyE');until(()=>r.qa.skills.phase==='E_Hold');}
 if(held)r.key(held);
 if(skill==='Q')r.key('KeyQ');
 if(skill==='R')r.key('KeyR');
 if(skill==='E')r.punch();
 if(skill==='Q'){
  until(()=>!!r.qa.duel.pendingGrab);
  assert.equal(r.qa.duel.match.history.length,n,'Q must not award at first contact');
  const frozen=xy();
  while(r.qa.duel.pendingGrab){repeat(held||'KeyD');r.frames(1);assert.deepEqual(xy(),frozen,'attacker cannot walk while pulling');}
 }
 until(()=>r.qa.duel.match.history.length===n+1);
 assert.equal(r.qa.duel.match.history.at(-1).winnerId,'human');
 assert.equal(r.game.data.duel.contact.skill,skill);
}
function resetAfterScore(){
 const frozen=xy();
 r.frames(59);
 assert.equal(r.qa.duel.match.phase,'roundReset','score presentation must last three seconds');
 assert.deepEqual(xy(),frozen,'held movement stays frozen during the score hold');
 r.frames(1);
 assert.equal(r.qa.duel.match.phase,'countdown');
 assert.equal(r.qa.duel.match.remainingMs,1600);
 assert.deepEqual(xy(),[0,7]);
 until(()=>r.qa.duel.active);
 assert.deepEqual(xy(),[0,7],'countdown must not move either axis');
}

for(const [code,expected] of [['KeyW',[0,6.68]],['KeyA',[-.32,7]],['KeyS',[0,7.32]],['KeyD',[.32,7]]])test(`${code} held from countdown starts on first active frame without a repeat`,()=>{
 start();r.key(code);repeat(code);
 until(()=>r.qa.duel.active);assert.deepEqual(xy(),[0,7]);
 r.frames(1);
 for(const [i,value]of xy().entries())assert(Math.abs(value-expected[i])<1e-9,`${code} did not move on first active frame`);
 r.release(code);const released=xy();r.frames(4);assert.deepEqual(xy(),released);
});
test('opposing held keys cancel, diagonal input remains normalized, and keyup keeps the remaining direction',()=>{
 start();for(const code of codes)r.key(code);until(()=>r.qa.duel.active);r.frames(1);assert.deepEqual(xy(),[0,7]);
 r.release('KeyA');r.release('KeyS');r.frames(1);
 assert(Math.abs(Math.hypot(r.qa.player.x,r.qa.player.z-7)-.32)<1e-9);
 assert(r.qa.player.x>0&&r.qa.player.z<7);
 const before=xy();r.release('KeyW');r.frames(1);assert(Math.abs(r.qa.player.x-before[0]-.32)<1e-9);assert.equal(r.qa.player.z,before[1]);
});
for(const skill of ['Q','E','R'])test(`held W survives actual ${skill} contact, score, reset and next countdown without an early step`,()=>{
 start(true);score(skill,{held:'KeyW'});resetAfterScore();
 repeat('KeyW');r.frames(1);assert(Math.abs(r.qa.player.z-6.68)<1e-9,'held key was lost at a round boundary');
 assert.equal(r.qa.duel.match.history.length,1);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[1,0]);
 assert.equal(r.game.data.keys.has('KeyQ'),false);assert.equal(r.game.data.keys.has('KeyE'),false);assert.equal(r.game.data.keys.has('KeyR'),false);
});
test('R simultaneous replay preserves held movement without awarding a point or walking during its hold',()=>{
 start(true);const d=r.game.data;d.duelBot.position.set(0,1.7,5);
 r.key('KeyW');r.key('KeyR');assert(d.duel.getSkills('bot').castR());until(()=>r.qa.duel.tieRemaining>0);
 const frozen=xy();r.frames(59);assert(r.qa.duel.tieRemaining>0);assert.deepEqual(xy(),frozen);assert.equal(r.qa.duel.match.history.length,0);
 until(()=>r.qa.duel.match.phase==='countdown');assert.deepEqual(xy(),[0,7]);until(()=>r.qa.duel.active);assert.deepEqual(xy(),[0,7]);
 r.frames(1);assert(r.qa.player.z<7);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[0,0]);assert.equal(r.qa.duel.match.roundNumber,1);
});
for(const phase of ['countdown','pull','score','next-countdown'])test(`keyup during ${phase} removes movement before live play resumes`,()=>{
 start(phase!=='countdown');
 if(phase==='countdown'){r.key('KeyD');r.release('KeyD');until(()=>r.qa.duel.active);}
 if(phase==='pull'){
  const d=r.game.data;d.duelBot.position.set(0,1.7,5);r.key('KeyW');r.key('KeyQ');until(()=>!!r.qa.duel.pendingGrab);r.release('KeyW');
  until(()=>r.qa.duel.match.phase==='roundReset');until(()=>r.qa.duel.match.phase==='countdown');until(()=>r.qa.duel.active);
 }
 if(phase==='score'||phase==='next-countdown'){
  score('R',{held:'KeyW'});
  if(phase==='next-countdown')until(()=>r.qa.duel.match.phase==='countdown');
  r.release('KeyW');until(()=>r.qa.duel.active);
 }
 const before=xy();r.frames(4);assert.deepEqual(xy(),before);assert.equal(r.game.data.keys.size,0);
});
for(const phase of ['countdown','score'])test(`new movement during ${phase} is live intent, but Q/E/R/F/Space/Shift never queue or revive from repeat`,()=>{
 start(phase==='score');if(phase==='score')score();
 const frozen=xy();r.key('KeyD');for(const code of actions){r.key(code);repeat(code);}r.punch();
 r.frames(1);assert.deepEqual(xy(),frozen);
 if(phase==='score')until(()=>r.qa.duel.match.phase==='countdown');
 until(()=>r.qa.duel.active);for(const code of actions)repeat(code);repeat('KeyD');r.frames(4);
 assert(Math.abs(r.qa.player.x-1.28)<1e-9,'held D must move after freeze without release/repress');
 assert.equal(r.qa.player.y,1.7);assert.equal(r.qa.player.z,7);assert.equal(r.qa.hook,null);
 assert.equal(r.qa.skills.phase,null);assert.equal(r.qa.skills.boost,0);assert.equal(r.qa.skills.slow,0);assert.equal(r.qa.skills.armed,0);assert.deepEqual(r.qa.skills.cooldown,{W:0,E:0,R:0});assert.equal(r.qa.flashAbility.casts,0);assert.equal(r.game.data.punchCooldown,0);
 assert.deepEqual([...r.game.data.keys],['KeyD']);
 r.release('KeyD');r.release('KeyQ');r.key('KeyQ');assert.equal(r.qa.hook.phase,'windup','fresh action press still works');
});
for(const interruption of ['pause','blur','hidden','capture','graphics','menu','restart'])test(`${interruption} clears held movement; OS repeat after resume cannot resurrect it`,()=>{
 start(true);r.key('KeyD');r.frames(1);
 if(interruption==='pause')r.game.pause();
 if(interruption==='blur')r.winListeners.blur();
 if(interruption==='hidden'){document.hidden=true;r.docListeners.visibilitychange();}
 if(interruption==='capture'){document.pointerLockElement=null;r.docListeners.pointerlockchange();}
 if(interruption==='graphics')r.element('game').listeners.webglcontextlost({preventDefault(){}});
 if(interruption==='menu'){r.game.pause();r.element('mainmenu').click();}
 if(interruption==='restart')r.element('duelmode').click();
 assert.equal(r.game.data.keys.size,0);
 if(interruption!=='restart'){r.key('KeyA');repeat('KeyD');assert.equal(r.game.data.keys.size,0);}
 if(interruption==='hidden')document.hidden=false;
 if(interruption==='graphics')r.element('game').listeners.webglcontextrestored();
 if(interruption==='menu')r.element('duelmode').click();else if(interruption!=='restart')r.game.resume();
 repeat('KeyD');until(()=>r.qa.duel.active);repeat('KeyD');const before=xy();r.frames(4);assert.deepEqual(xy(),before);assert.equal(r.game.data.keys.size,0);
 r.release('KeyD');r.key('KeyD');r.frames(1);assert(r.qa.player.x>before[0]);
});
test('editable targets and uncaptured countdown do not establish held movement intent',()=>{
 start();for(const target of [{tagName:'INPUT'},{tagName:'SELECT'},{tagName:'TEXTAREA'},{isContentEditable:true}])r.dispatchKey({code:'KeyD',target});
 assert.equal(r.game.data.keys.size,0);
 document.pointerLockElement=null;r.key('KeyW');repeat('KeyW');assert.equal(r.game.data.keys.size,0);
 r.element('mousecapture').click();until(()=>r.qa.duel.active);repeat('KeyD');repeat('KeyW');r.frames(4);assert.deepEqual(xy(),[0,7]);
});
test('first to three still gives a full final hold, clears held intent at results, and requires explicit rematch',()=>{
 start(true);
 for(let point=1;point<=3;point++){
  score('R',{held:'KeyW'});assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[point,0]);
  if(point<3){resetAfterScore();r.frames(1);assert(r.qa.player.z<7);}
 }
 assert.equal(r.qa.duel.match.phase,'matchComplete');const frozen=xy();r.frames(59);assert.equal(r.qa.state,'running');assert.deepEqual(xy(),frozen);r.frames(1);assert.equal(r.qa.state,'results');assert.equal(r.game.data.keys.size,0);
 repeat('KeyW');r.frames(20);assert.equal(r.qa.state,'results');r.key('Enter');repeat('KeyW');until(()=>r.qa.duel.active);r.frames(4);assert.deepEqual(xy(),[0,7]);assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[0,0]);
});
test('solo keyboard behavior remains unchanged',()=>{
 r.element('practice').click();r.key('KeyD');r.frames(1);assert(Math.abs(r.qa.player.x-.32)<1e-9);repeat('KeyD');r.frames(1);assert(Math.abs(r.qa.player.x-.64)<1e-9);r.release('KeyD');r.frames(1);assert(Math.abs(r.qa.player.x-.64)<1e-9);
});
test('live touch survives round reset but cancelled ownership cannot revive from stale events',()=>{
 start();const stick=r.element('joystick'),e={pointerId:2,pointerType:'touch',clientX:55,clientY:17};
 r.docListeners.pointerdown(e);stick.onpointerdown(e);assert.deepEqual(r.game.data.joystick,{x:0,y:-1});until(()=>r.qa.duel.active);assert.deepEqual(xy(),[0,7]);
 r.frames(1);assert(r.qa.player.z<7);stick.onpointerdown({...e,pointerId:3,clientY:93});stick.onpointerup({...e,pointerId:3});assert.equal(r.game.data.joystick.y,-1);
 score();assert.equal(r.game.data.joystick.y,-1);resetAfterScore();r.frames(1);assert(r.qa.player.z<7,'continuously captured owner should resume without retouch');
 for(const end of ['onpointercancel','onlostpointercapture']){stick[end](e);assert.deepEqual(r.game.data.joystick,{x:0,y:0});stick.onpointermove(e);const before=xy();r.frames(1);assert.deepEqual(xy(),before,'cancelled owner must not revive');stick.onpointerdown(e);}
 stick.onpointercancel(e);score();until(()=>r.qa.duel.active);stick.onpointermove(e);const before=xy();r.frames(1);assert.deepEqual(xy(),before,'round reset must not revive a cancelled owner');
 stick.onpointerdown(e);r.frames(1);assert(r.qa.player.z<before[1]);stick.onpointerup(e);
});
test('third-person held countdown movement stays camera-relative after yaw rotation without a fresh press',()=>{
 start();if(r.qa.view!=='third')r.element('viewtoggle').click();
 for(let n=0;n<3;n++)r.docListeners.mousemove({target:r.element('game'),movementX:Math.PI/(6*.0021),movementY:0,buttons:0});
 assert(Math.abs(r.qa.player.yaw+Math.PI/2)<1e-9);r.key('KeyW');until(()=>r.qa.duel.active);assert.deepEqual(xy(),[0,7]);
 r.frames(1);assert(Math.abs(r.qa.player.x-.32)<1e-9);assert(Math.abs(r.qa.player.z-7)<1e-9);assert.equal(r.qa.view,'third');
 r.release('KeyW');const stopped=xy();r.frames(1);assert.deepEqual(xy(),stopped);
});
