import test from 'node:test';import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {collectStaticTriangles,auditSupport} from '../rift-v39-support-audit.js';
function plane({width=4,depth=4,y=0,x=0,z=0,name='floor',slope=0}={}){
 const geometry=new THREE.PlaneGeometry(width,depth);geometry.rotateX(-Math.PI/2);geometry.rotateZ(slope);
 const mesh=new THREE.Mesh(geometry);mesh.name=name;mesh.position.set(x,y,z);return mesh;
}
function audit(objects,options={}){const scene=new THREE.Scene();scene.add(...objects);return auditSupport(THREE,collectStaticTriangles(THREE,scene),{position:[0,0],supportNames:['floor'],...options});}
test('flat floor checks all 81 footprint samples and whole body box',()=>{
 const a=audit([plane()]);assert.equal(a.supportedSamples,81);assert(a.bodySurfaceClear);assert(a.sampleCheckPassed);assert(Math.abs(a.footY)<1e-7);assert.equal(a.continuousFootprintCoverageVerified,false);
});
test('narrow support does not certify a full footprint',()=>{
 const a=audit([plane({width:.3})]);assert(a.missingSamples>0);assert.equal(a.sampleCheckPassed,false);
});
test('a thin overhead beam between vertical grid lines is still caught by full volume test',()=>{
 const beam=new THREE.Mesh(new THREE.BoxGeometry(.01,.01,.01));beam.name='thin-beam';beam.position.set(.08,1.9,.08);
 const a=audit([plane(),beam]);assert.equal(a.supportedSamples,81);assert.equal(a.bodySurfaceClear,false);assert(a.intersectionMeshes.includes('thin-beam'));
});
test('ceiling above the body remains clear, intersecting ceiling does not',()=>{
 assert(audit([plane(),plane({y:2.3,name:'ceiling'})]).bodySurfaceClear);
 assert.equal(audit([plane(),plane({y:2,name:'ceiling'})]).bodySurfaceClear,false);
});
test('footprint height spread and slope are independently rejected',()=>{
 assert.equal(audit([plane({slope:.3})]).sampleCheckPassed,false);
 assert.equal(audit([plane({slope:1})]).supportedSamples,0);
});
test('unknown surfaces and distant elevations are not silently adopted as floor',()=>{
 assert.equal(audit([plane({name:'roof'})]).supportedSamples,0);
 assert.equal(audit([plane({y:3})]).supportedSamples,0);
});
test('world transforms are applied to support and obstacles',()=>{
 const a=audit([plane({y:.25})]);assert(Math.abs(a.footY-.25)<1e-7);
});
test('nonzero Z sample origins follow the requested footprint rather than Z zero',()=>{
 const a=audit([plane({width:2,depth:2,x:8,z:-12,y:.1})],{position:[8,-12]});
 assert.equal(a.supportedSamples,81);assert(a.sampleCheckPassed);assert(Math.abs(a.footY-.1)<1e-6);
 const b=audit([plane({width:2,depth:.2,z:6.5})],{position:[0,6.5]});
 assert(b.supportedSamples>0&&b.missingSamples>0);
});
test('no floor cannot claim body clearance',()=>{
 const a=audit([]);assert.equal(a.bodySurfaceClear,false);assert.equal(a.footY,null);assert.equal(a.sampleCheckPassed,false);
});
test('invalid parameters fail before geometry scans',()=>{
 for(const options of [{position:[NaN,0]},{halfExtent:0},{height:0},{samplesPerAxis:1000},{skin:3},{maxSlopeDegrees:90},{supportNames:[]}])assert.throws(()=>audit([plane()],options));
});
test('instanced and morph geometry require a different extractor',()=>{
 const scene=new THREE.Scene();scene.add(new THREE.InstancedMesh(new THREE.BoxGeometry(),new THREE.MeshBasicMaterial(),1));assert.throws(()=>collectStaticTriangles(THREE,scene));
});
test('surface intersection is explicitly not an inside-solid occupancy certificate',()=>{
 const shell=new THREE.Mesh(new THREE.BoxGeometry(10,10,10));shell.name='enclosing-shell';
 const a=audit([plane(),shell]);assert(a.bodySurfaceClear);assert.equal(a.closedSolidContainmentVerified,false);
});
