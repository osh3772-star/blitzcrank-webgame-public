import test from 'node:test';
import assert from 'node:assert/strict';
import {createDuelSimulation,DUEL_SHAPE} from '../duel-simulation.js';
import {createDuelMatch,transitionDuel,getDuelScope} from '../duel-round-rules.js';
import {CONFIG} from '../core.js';
const clip=(name,duration=1,events=[])=>({name,duration,events});
const skillClips=[clip('W_Start'),clip('W_Loop'),clip('W_End'),clip('E_Charge'),clip('E_Hold'),clip('E_Strike',1.5,[{time:.4,type:'power_fist_hit'}]),clip('R_Cast',1.2,[{time:.3,type:'static_field_discharge'}])];
const p=(x,y=1.7,z=0)=>({x,y,z});
function fixture(range=2){
 const sim=createDuelSimulation({sessionId:'validation',config:CONFIG,countdownMs:0,skillClips});sim.prepare();
 const frame={actors:['human','bot'].map((playerId,i)=>({playerId,shape:DUEL_SHAPE,motion:{type:'linear',from:p(i*range),to:p(i*range)}})),obstacles:[],sockets:{human:{origin:p(0),home:p(0),direction:p(1,0)},bot:{origin:p(range),home:p(range),direction:p(-1,0)}}};
 const step=(n=1,dt=.05)=>{for(let i=0;i<n;i++)sim.step(dt,frame);};
 const arm=id=>{sim.getSkills(id).castE();step(20);assert.equal(sim.getSkills(id).status.phase,'E_Hold');};
 return {sim,frame,step,arm};
}
for(const id of ['human','bot'])for(const skill of ['E','R'])test(`${id} ${skill} rejects range misses and stale cancelled events`,()=>{
 const f=fixture(9),c=f.sim.getSkills(id);if(skill==='E'){f.arm(id);c.strikeE();}else c.castR();f.step(12);assert.equal(f.sim.state.history.length,0);
 const e=f.sim.drainEvents().filter(e=>e.type==='skill-impact');assert.equal(e.length,1);assert.equal(e[0].hit,false);
 f.sim.restart();f.sim.prepare();if(skill==='E'){f.arm(id);c.strikeE();}else c.castR();f.step(1);f.sim.cancel();f.step(20);assert.equal(f.sim.state.history.length,0);assert(!f.sim.drainEvents().some(e=>['round-scored','skill-impact'].includes(e.type)));
});
for(const id of ['human','bot'])test(`${id} E direction is validated instead of inventing an aimed hit`,()=>{const f=fixture();f.frame.sockets[id].aimDirection=p(0,0,1);f.arm(id);f.sim.getSkills(id).strikeE();f.step(12);assert.equal(f.sim.state.history.length,0);});
test('both actor origin and victim movement are interpolated at E impact',()=>{const f=fixture(6);f.arm('human');f.sim.getSkills('human').strikeE();f.step(7);f.step(1,.04);f.frame.actors[0].motion={type:'linear',from:p(0),to:p(4)};f.step();assert.equal(f.sim.state.history.length,0,'at .01/.05 player moved only .8, target is beyond3.4+.7');});
for(const id of ['human','bot'])test(`${id} authority enforces busy/cooldown and cannot reset them during live round`,()=>{
 const f=fixture(20),c=f.sim.getSkills(id);assert(c.castR());assert(!c.castR());assert(!c.castE());assert(!f.sim.cast(id));assert(!c.strikeE());c.reset();assert(c.status.cooldown.R>0);f.step(30);assert(!c.castR());assert(c.castE());assert(!f.sim.cast(id));assert(!c.castE());
});
test('countdown, tie replay and restart reject old skill scope and remove pending impacts',()=>{
 const f=fixture(),a=f.sim.getSkills('human'),b=f.sim.getSkills('bot');const old=getDuelScope(f.sim.state);a.castR();b.castR();f.step(6);assert(f.sim.tieRemaining>0);assert(!a.castE());assert(!a.castR());assert(!a.strikeE());f.sim.restart();f.sim.prepare();assert.equal(a.status.phase,null);assert.equal(a.status.cooldown.R,0);assert.equal(f.sim.drainEvents().filter(e=>e.type==='skill-impact').length,0);f.step(30);assert.equal(f.sim.state.history.length,0);assert.equal(transitionDuel(f.sim.state,{type:'confirmHit',scope:old,eventId:'old',attackerId:'human',targetId:'bot',skill:'R',validated:true,result:'success'}).reason,'stale_match');
});
test('pure round reducer only accepts confirmed Q/E/R results, never W/F/basic/casts',()=>{
 let state=createDuelMatch({sessionId:'rules',playerIds:['human','bot'],countdownMs:0}).state;state=transitionDuel(state,{type:'prepareRound',scope:getDuelScope(state)}).state;
 const cmd={type:'confirmHit',scope:getDuelScope(state),eventId:'hit',attackerId:'human',targetId:'bot',skill:'E',validated:true,result:'success'};
 for(const skill of ['W','F','punch','E_Charge',null])assert.equal(transitionDuel(state,{...cmd,skill}).reason,'non_scoring_skill');
 for(const result of ['cast','miss','blocked'])assert.equal(transitionDuel(state,{...cmd,result}).reason,'non_scoring_result');
 assert.equal(transitionDuel(state,{...cmd,validated:false}).reason,'unvalidated_hit');
 const result=transitionDuel(state,cmd);assert(result.accepted);assert.equal(result.effects.find(e=>e.type==='round-scored').skill,'E');assert.equal(transitionDuel(result.state,cmd).reason,'stale_phase');
});
for(const skill of ['E','R'])for(const attacker of ['human','bot'])test(`Q versus ${attacker} ${skill} exact impact tie replays, never pulls or scores`,()=>{
 const f=fixture(2.8),q=attacker==='human'?'bot':'human',c=f.sim.getSkills(attacker);
 if(skill==='E'){f.arm(attacker);c.strikeE();f.step(2);}else c.castR();
 f.sim.cast(q);f.step(6);assert.equal(f.sim.state.history.length,0);assert(f.sim.tieRemaining>0);assert.equal(f.sim.contact.kind,'tie');assert.equal(f.sim.getHook(q).hit,false);
});
for(const delay of [0,.04])for(const attacker of ['human','bot'])test(`Q versus ${attacker} E actual earlier impact wins with extra E headstart ${delay}`,()=>{
 const f=fixture(),q=attacker==='human'?'bot':'human',c=f.sim.getSkills(attacker);f.arm(attacker);c.strikeE();f.step(2);if(delay)f.step(1,delay);f.sim.cast(q);f.step(6);if(!delay){assert.equal(f.sim.state.history.length,0);assert(f.sim.pendingGrab);assert.equal(f.sim.active,false);for(let n=0;n<30&&f.sim.pendingGrab;n++)f.step(1);}assert.equal(f.sim.state.history.length,1);assert.equal(f.sim.state.history[0].winnerId,delay?attacker:q);assert.equal(f.sim.contact.skill,delay?'E':'Q');
});
