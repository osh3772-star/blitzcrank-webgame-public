import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const sourcePath=new URL('../main.js',import.meta.url);
const quiet=r=>r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});
function until(r,predicate){for(let i=0;i<500&&!predicate();i++)r.frames(1);assert(predicate());}
async function start(delta){const r=await createGameplayHarness({sourcePath,delta});r.element('duelmode').click();quiet(r);until(r,()=>r.qa.duel.active);return r;}
function score(r,skill='Q',winner='human'){
 const d=r.game.data,old=d.duel.state.history.length;d.duelBot.position.set(0,1.7,5);
 if(skill==='Q'){if(winner==='human')r.key('KeyQ');else assert(d.duel.cast('bot'));until(r,()=>!!d.duel.pendingGrab);assert.equal(d.duel.state.history.length,old);assert.equal(d.duel.active,false);}
 if(skill==='E'){const s=d.duel.getSkills(winner);assert(s.castE());until(r,()=>s.status.phase==='E_Hold');assert(s.strikeE());}
 if(skill==='R')assert(d.duel.getSkills(winner).castR());
 until(r,()=>d.duel.state.history.length===old+1);
 assert.equal(d.duel.state.history.at(-1).winnerId,winner);
}
const points=r=>r.qa.duel.match.scores.map(s=>s.points);
for(const winner of ['human','bot'])for(const skill of ['E','R'])test(`${winner} ${skill} presentation clocks follow each hold substep exactly once`,async()=>{
 const r=await start(()=>.2);score(r,skill,winner);const d=r.game.data;
 const before={human:r.qa.skills.vfx.time,bot:r.qa.duel.bot.vfx.time,voice:r.qa.voice.elapsed};
 const particles=d.scene.children.filter(o=>o.geometry?.parameters?.width===.055&&o.geometry?.parameters.height===.055&&o.geometry?.parameters.depth===.055);
 assert.equal(particles.length,16);const scale=particles[0].scale.x;
 r.frames(1);
 assert(Math.abs(r.qa.skills.vfx.time-before.human-.2)<1e-8);assert(Math.abs(r.qa.duel.bot.vfx.time-before.bot-.2)<1e-8);assert(Math.abs(r.qa.voice.elapsed-before.voice-.2)<1e-8);
 assert(Math.abs(particles[0].scale.x-(scale-.2/.65))<1e-8,'particles age once per substep, not again at render');
 r.frames(6);assert.equal(r.qa.duel.match.phase,'roundReset');assert.equal(r.qa.duel.humanKnockup,null);assert.equal(r.qa.duel.bot.knockup,null);assert.equal(d.player.y,1.7);assert.equal(d.duelBot.position.y,1.7);assert(particles.every(p=>!p.parent));assert.equal(r.qa.skills.vfx.fieldVisible,false);assert.equal(r.qa.duel.bot.vfx.fieldVisible,false);
});
