import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';
import {loadV49Inputs,MAP_V49} from '../rift-v49-offline-inputs.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
test('official v49 identity is pinned without changing runtime revision selection',()=>{
 const a=loadV49Inputs(root);assert.equal(a.layout.assetVersion,'sr-study-0.49');assert.equal(a.createProbe().revision,'0.49');
});
test('v39 and v49 collision contents differ only in the real version tag',()=>{
 const {layout}=loadV49Inputs(root),old=JSON.parse(fs.readFileSync(path.join(root,'assets/map-study-v39/collision.8e88cb3b81d9274a.json')));
 assert.deepEqual({...layout,assetVersion:old.assetVersion},old);assert.equal(layout.assetVersion,'sr-study-0.49');
});
test('mutated input bytes are rejected, even whitespace-only collision changes',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rift49-hash-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 for(const n of [MAP_V49.glb,MAP_V49.collision]){fs.mkdirSync(path.dirname(path.join(dir,n)),{recursive:true});fs.copyFileSync(path.join(root,n),path.join(dir,n));}
 fs.appendFileSync(path.join(dir,MAP_V49.collision),' ');assert.throws(()=>loadV49Inputs(dir),/hashes/);
});
test('original and candidate spawns retain explicit v49 planar outcomes',()=>{
 const p=loadV49Inputs(root).createProbe();assert.equal(p.probe([0,7]).blockedBy,'wall_poly_18');assert.equal(p.probe([0,-12]).blockedBy,'wall_poly_13');
 assert.equal(p.probe([-.25,6.5]).blockedBy,null);assert.equal(p.probe([1,-13.25]).blockedBy,null);
});
test('probe radius and coordinates fail closed',()=>{
 const a=loadV49Inputs(root);for(const radius of [NaN,0,3])assert.throws(()=>a.createProbe({radius}));
 const p=a.createProbe();for(const point of [[],[NaN,0],[0,0,0]])assert.throws(()=>p.probe(point));
});
test('caller mutations of the inspection layout cannot change the pinned probe',()=>{
 const inputs=loadV49Inputs(root);inputs.layout.walls=[];inputs.layout.propColliders=[];
 assert.equal(inputs.createProbe().probe([0,-12]).blockedBy,'wall_poly_13');
});
