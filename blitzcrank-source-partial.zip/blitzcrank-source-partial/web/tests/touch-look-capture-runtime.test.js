import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// Actual main.js handlers and Three.js CPU scene graph. DOM, clock, renderer and
// Pointer Capture APIs are mocked; not browser, GPU, mobile-device or FPS QA.
// Capture ownership is a Set. Refusal/throws and silent removal are injected;
// lostpointercapture is dispatched separately to model delayed event delivery.
const sourcePath=new URL(process.env.TOUCH_LOOK_SOURCE||'../main.js',import.meta.url);
const r=await createGameplayHarness({sourcePath,delta:()=>.05});
const canvas=r.element('game');
const ev=(pointerId=2,clientX=800,clientY=350)=>({pointerId,clientX,clientY,pointerType:'touch',button:0,preventDefault(){}});
const send=(name,e=ev())=>canvas.listeners[name](e);
const angle=()=>[r.qa.player.yaw,r.qa.player.pitch];
function fresh(duel=false){document.hidden=false;r.docListeners.pointerdown(ev());r.element(duel?'duelmode':'practice').click();canvas.pointerCaptures?.clear();}
function moved(id=2,x=810,y=350){const before=angle();send('pointermove',ev(id,x,y));assert(Math.abs(r.qa.player.yaw-before[0]+.021)<1e-10);}
for(const mode of ['throw','refuse'])test(`capture ${mode} leaves no stale owner and permits a fresh drag`,()=>{
 fresh();const capture=canvas.setPointerCapture;canvas.setPointerCapture=()=>{if(mode==='throw')throw Error('inactive pointer');};
 let failure;try{send('pointerdown');}catch(error){failure=error;}finally{canvas.setPointerCapture=capture;}
 const before=angle();send('pointermove',ev(2,900));assert.deepEqual(angle(),before,'failed capture must not rotate camera');
 assert.equal(failure,undefined,'capture exceptions must not escape input dispatch');
 send('pointerdown',ev(3));moved(3);
});
test('silent capture loss rejects stale delta and cannot revive without pointerdown',()=>{
 fresh();send('pointerdown');canvas.releasePointerCapture(2);const before=angle();send('pointermove',ev(2,900));assert.deepEqual(angle(),before);
 canvas.setPointerCapture(2);send('pointermove',ev(2,920));assert.deepEqual(angle(),before);send('pointerdown');moved();
});
test('fresh finger replaces lost owner before delayed old loss/up/cancel without a frame',()=>{
 fresh();send('pointerdown');canvas.releasePointerCapture(2);send('pointerdown',ev(3));
 for(const name of ['pointerup','pointercancel','lostpointercapture'])send(name,ev(2));
 const before=angle();send('pointermove',ev(2,900));assert.deepEqual(angle(),before);moved(3);
});
test('captured owner ignores extra look finger and joystick remains independent',()=>{
 fresh();send('pointerdown');send('pointerdown',ev(3,900));const before=angle();send('pointermove',ev(3,950));
 for(const name of ['pointerup','pointercancel','lostpointercapture'])send(name,ev(3));assert.deepEqual(angle(),before);
 const stick=r.element('joystick');stick.onpointerdown(ev(4,55,17));assert.deepEqual(r.game.data.joystick,{x:0,y:-1});moved();
 assert.deepEqual(r.game.data.joystick,{x:0,y:-1});stick.onpointerup(ev(4));
});
for(const name of ['pointerup','pointercancel','lostpointercapture'])test(`${name} clears owner and permits the next drag`,()=>{
 fresh();send('pointerdown');canvas.releasePointerCapture(2);send(name);const before=angle();send('pointermove',ev(2,900));assert.deepEqual(angle(),before);send('pointerdown',ev(3));moved(3);
});
for(const kind of ['pause','blur','hidden','resize','menu'])test(`${kind} reset rejects old look reference after returning`,()=>{
 fresh();send('pointerdown');
 if(kind==='pause')r.game.pause();if(kind==='blur')r.winListeners.blur();if(kind==='hidden'){document.hidden=true;r.docListeners.visibilitychange();}
 if(kind==='resize'){innerWidth=innerWidth===1280?720:1280;r.winListeners.resize();}
 if(kind==='menu'){r.game.pause();r.element('mainmenu').click();}
 document.hidden=false;if(kind==='menu')r.element('practice').click();else if(kind!=='resize')r.game.resume();
 const before=angle();send('pointermove',ev(2,900));assert.deepEqual(angle(),before);send('pointerdown',ev(3));moved(3);
});
test('normal drag still adjusts camera during frozen duel countdown',()=>{
 fresh(true);assert.equal(r.qa.duel.match.phase,'countdown');send('pointerdown');moved();assert.equal(r.qa.duel.match.phase,'countdown');
});
test('hybrid mouse capture wait stops stale touch look; new touch down recovers',()=>{
 fresh();r.docListeners.pointerlockchange?.();send('pointerdown');
 // Mouse activity outside the canvas changes the active input modality without
 // acquiring pointer lock. The game is now waiting for explicit mouse capture.
 r.docListeners.pointerdown({pointerType:'mouse',button:0});assert.equal(r.qa.playing,false);
 const before=angle();send('pointermove',ev(2,900));assert.deepEqual(angle(),before,'capture wait must not rotate stale touch look');
 r.docListeners.pointerdown(ev(3));send('pointerdown',ev(3));assert(r.qa.playing);moved(3);
});
