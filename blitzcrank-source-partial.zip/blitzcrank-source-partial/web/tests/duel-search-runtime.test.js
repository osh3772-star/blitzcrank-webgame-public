import test from 'node:test';
import assert from 'node:assert/strict';
import {startSearch,runSearch} from './helpers/duel-search-scenarios.js';
for(const hz of [20,30,60,120])test(`actual ${hz}Hz reproduction visits last seen point, explores and gains fresh delayed observations`,async()=>{
 const trace=await runSearch({hz});
 assert(trace.summary.firstForgetSeconds>0&&trace.summary.firstForgetSeconds<2);
 assert(trace.summary.firstFreshSeconds>0&&trace.summary.firstFreshSeconds<25);
 assert(trace.summary.freshUpdates>100);
 assert(trace.summary.minRange<2);
 assert.equal(trace.seen.seed,23320);assert.deepEqual(trace.seen.perceived.position,{x:-6,y:1.7,z:-8});
});
for(const hz of [20,30,60,120])test(`actual ${hz}Hz keyboard route goes around existing cover and reacquires without teleporting`,async()=>{
 const trace=await runSearch({hz,route:true});
 assert(trace.summary.firstHiddenSeconds>0);assert.equal(trace.routeEnd.brain.wasVisible,false);
 assert(trace.routeEnd.human[0]<-11.9&&trace.routeEnd.human[0]>-12.2);assert.equal(trace.routeEnd.human[1],1.7);assert(Math.abs(trace.routeEnd.human[2]+8)<1e-9);
 assert(trace.summary.firstForgetSeconds>trace.routeEnd.time);
 assert(trace.summary.firstFreshSeconds>trace.routeEnd.time&&trace.summary.firstFreshSeconds<25);
 assert(trace.summary.freshUpdates>100);
});
test('actual pause and zero-time refresh freeze hidden search; rematch starts a fresh brain',async()=>{
 const s=await startSearch(),{r,d,brain}=s;d.player.set(-12,1.7,-8);for(let n=0;n<5;n++)s.step();assert.equal(brain.snapshot().freshPerception,false);
 const before=brain.snapshot(),bot=d.duelBot.position.toArray(),human=d.player.toArray(),match=r.qa.duel.match;
 r.game.pause();r.frames(100);assert.deepEqual(brain.snapshot(),before);assert.deepEqual(d.duelBot.position.toArray(),bot);assert.deepEqual(d.player.toArray(),human);assert.equal(r.qa.duel.match,match);
 r.game.resume();s.setDelta(0);r.frames(30);assert.deepEqual(brain.snapshot(),before);assert.deepEqual(d.duelBot.position.toArray(),bot);
 s.setDelta(.05);s.step();assert(brain.snapshot().time>before.time);
 r.element('duelmode').click();const fresh=r.game.data.duelBrain.snapshot();assert.equal(fresh.time,0);assert.equal(fresh.perceived,null);assert.equal(fresh.freshPerception,false);assert.equal(fresh.queuedSamples,0);assert.equal(r.qa.duel.match.phase,'countdown');assert.deepEqual(r.qa.duel.match.scores.map(s=>s.points),[0,0]);
});
test('actual round score resets searched memory and both actors for the next countdown',async()=>{
 const s=await startSearch(),{r,d,brain}=s;d.player.set(-12,1.7,-8);for(let n=0;n<30;n++)s.step();assert.equal(brain.snapshot().perceived,null);
 // Deterministic geometric scoring arrangement isolates the round reset boundary.
 d.player.set(0,1.7,7);d.duelBot.position.set(0,1.7,5.3);r.game.setBotCommandSource({reset:()=>brain.reset(),step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,jump:false})});
 r.key('KeyQ');for(let n=0;n<30&&r.qa.duel.match.phase==='active';n++)r.frames(1);assert.equal(r.qa.duel.match.history.at(-1)?.winnerId,'human');
 for(let n=0;n<65&&r.qa.duel.match.phase!=='countdown';n++)r.frames(1);
 assert.equal(r.qa.duel.match.phase,'countdown');assert.equal(r.qa.duel.match.roundNumber,2);assert.equal(brain.snapshot().time,0);assert.equal(brain.snapshot().perceived,null);assert.equal(brain.snapshot().freshPerception,false);assert.equal(brain.snapshot().queuedSamples,0);assert.deepEqual(d.duelBot.position.toArray(),[0,1.7,-12]);assert.deepEqual(d.player.toArray(),[0,1.7,7]);
});

for(const hz of [20,30,60,120])test(`actual ${hz}Hz skill-enabled approach still reacquires through delayed sight`,async()=>{
 const trace=await runSearch({hz,skillMode:true});assert(trace.summary.firstHiddenSeconds>0);assert(trace.summary.firstFreshSeconds>0&&trace.summary.firstFreshSeconds<25);assert(trace.summary.freshUpdates>100);assert(trace.summary.minRange<2);
});
