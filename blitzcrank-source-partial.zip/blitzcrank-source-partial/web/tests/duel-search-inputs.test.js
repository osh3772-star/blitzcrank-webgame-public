import test from 'node:test';
import assert from 'node:assert/strict';
import {createDuelBotInputs as baseline} from './fixtures/duel-bot-inputs-v2436.js';
import {createDuelBotInputs} from '../duel-bot-inputs.js';
const tuning={playerSpeed:6.4,hookSpeed:42,maxRange:32,cooldown:2.2,windup:.25,bodyRadius:.7,eyeHeight:1.7};
const arena={min:{x:-23.4,z:-42.5},max:{x:23.4,z:15.5}};
const make=(seed=42)=>createDuelBotInputs({seed,tuning,arena});
const obs=(patch={})=>({dt:1/60,active:true,self:{position:{x:0,y:1.7,z:0},yaw:0,pitch:0,cooldown:0},opponent:{position:{x:0,y:1.7,z:-8},velocity:{x:0,y:0,z:0}},canSeeOpponent:true,...patch});
const warm=bot=>{for(let i=0;i<60;i++)bot.step(obs());assert(bot.snapshot().freshPerception);};
const bounded=out=>{assert(Math.hypot(out.move.x,out.move.z)<=1+1e-12);assert([out.move.x,out.move.z,out.yaw,out.pitch].every(Number.isFinite));};

test('lost sight pursues the last seen point even inside preferred fighting distance',()=>{
 const b=make();warm(b);const before=b.snapshot();assert(before.preferredDistance>8);
 const out=b.step(obs({canSeeOpponent:false}));assert(out.move.z<-.5);assert.equal(out.castQ,false);assert.equal(out.yaw,before.yaw);assert.deepEqual(b.snapshot().perceived.position,before.perceived.position);
});
test('repeated short LOS glimpses continue searching without bypassing reaction delay',()=>{
 const b=make();warm(b);const before=b.snapshot();
 for(let n=0;n<300;n++){
  const out=b.step(obs({canSeeOpponent:n%10<6}));
  // The first hidden frame starts the search; each subsequent .1s glimpse is too brief.
  if(n>=6){assert(out.move.z<-.5);assert.equal(out.castQ,false);assert.equal(out.yaw,before.yaw);assert.equal(b.snapshot().freshPerception,false);assert.deepEqual(b.snapshot().perceived.position,before.perceived.position);}
 }
});
test('sustained reacquisition uses the unchanged delayed sample and resumes combat only afterward',()=>{
 const b=make();warm(b);b.step(obs({canSeeOpponent:false}));const old=b.snapshot();let resumed=null;
 for(let n=0;n<60;n++){
  const out=b.step(obs());const state=b.snapshot();
  if(!state.freshPerception){assert(out.move.z<-.5);assert.equal(out.castQ,false);assert.equal(out.yaw,old.yaw);}
  else {resumed=(n+1)/60;assert(out.move.z>0,'visible target inside preferred range restores retreat');break;}
 }
 assert(resumed>=old.reactionDelay);assert(resumed<old.reactionDelay+2/60);
});
test('checked last seen area falls back to independent search, including exact arrival',()=>{
 for(const distance of [0,1.9]){
  const b=make();warm(b);const before=b.snapshot();
  const out=b.step(obs({canSeeOpponent:false,self:{position:{x:0,y:1.7,z:-8+distance},yaw:0,pitch:0,cooldown:0}}));
  assert.equal(b.snapshot().perceived,null);assert.equal(b.snapshot().freshPerception,false);assert.deepEqual(b.snapshot().searchPoint,before.searchPoint);assert(Math.hypot(out.move.x,out.move.z)>.5);assert.equal(out.castQ,false);bounded(out);
 }
});
test('hidden opponent coordinates and velocity cannot change pursuit or fallback exploration',()=>{
 const a=make(),b=make();warm(a);warm(b);let p={x:0,y:1.7,z:0},forgot=false;
 for(let n=0;n<60*30;n++){
  const self={position:p,yaw:0,pitch:0,cooldown:0};
  const one=a.step(obs({self,canSeeOpponent:false,opponent:{position:{x:-20+Math.sin(n),y:1.7,z:-38},velocity:{x:6.4,y:0,z:0}}}));
  const two=b.step(obs({self,canSeeOpponent:false,opponent:{position:{x:20,y:8,z:14-Math.cos(n)},velocity:{x:-6.4,y:2,z:2}}}));
  assert.deepEqual(one,two);assert.deepEqual(a.snapshot(),b.snapshot());assert.equal(one.castQ,false);bounded(one);forgot ||= !a.snapshot().perceived;
  p={x:p.x+one.move.x*tuning.playerSpeed/60,y:p.y,z:p.z+one.move.z*tuning.playerSpeed/60};
 }
 assert(forgot,'test must cover the independent search after checking memory');
});
test('pause, inactive and zero/invalid delta freeze search; reset exactly clears it',()=>{
 const b=make();warm(b);b.step(obs({canSeeOpponent:false}));const searching=b.snapshot();
 for(const patch of [{dt:0},{dt:-1},{dt:NaN},{dt:Infinity},{active:false}])for(let n=0;n<30;n++){
  const out=b.step(obs(patch));assert.deepEqual(out.move,{x:0,z:0});assert.equal(out.castQ,false);assert.deepEqual(b.snapshot(),searching);
 }
 b.reset();assert.deepEqual(b.snapshot(),make().snapshot());assert.equal(b.snapshot().perceived,null);
});
test('uninterrupted visible combat outputs and all state remain byte-for-byte baseline equivalent',()=>{
 for(const seed of [1,42,23320,4294967295,'visible-combat']){
  const a=make(seed),b=baseline({seed,tuning,arena});
  for(let n=0;n<1200;n++){
   const o=obs({dt:[1/20,1/30,1/60,1/120][n%4],self:{position:{x:Math.sin(n/80)*4,y:1.7,z:Math.cos(n/55)*2},yaw:0,pitch:0,cooldown:n%200<80?1:0},opponent:{position:{x:Math.sin(n/40)*12,y:1.7,z:-12+Math.cos(n/70)*8},velocity:{x:2*Math.cos(n/40),y:0,z:-Math.sin(n/70)}}});
   assert.deepEqual(a.step(o),b.step(o));assert.deepEqual(a.snapshot(),b.snapshot());
  }
 }
});
test('arrival during visible-but-pending reaction retains memory and queued delayed samples',()=>{
 const b=make();warm(b);b.step(obs({canSeeOpponent:false}));
 const near=obs({self:{position:{x:0,y:1.7,z:-8},yaw:0,pitch:0,cooldown:0},opponent:{position:{x:6,y:1.7,z:-8},velocity:{x:0,y:0,z:0}}});
 const out=b.step(near);assert.deepEqual(b.snapshot().perceived.position,{x:0,y:1.7,z:-8});assert.equal(b.snapshot().queuedSamples,1);assert.deepEqual(out.move,{x:0,z:0});assert.equal(out.castQ,false);
 for(let n=0;n<30;n++)b.step(near);assert.equal(b.snapshot().freshPerception,true);assert.deepEqual(b.snapshot().perceived.position,near.opponent.position);
});
