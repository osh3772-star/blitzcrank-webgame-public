import test from 'node:test';
import assert from 'node:assert/strict';
import { createDuelBotInputs } from '../duel-bot-inputs.js';

const tuning = Object.freeze({ playerSpeed: 6.4, hookSpeed: 42, maxRange: 32, cooldown: 2.2, windup: .25, bodyRadius: .7, eyeHeight: 1.7 });
const arena = { min: { x: -23.4, z: -42.5 }, max: { x: 23.4, z: 15.5 } };
const make = (options = {}) => createDuelBotInputs({ seed: 42, tuning, arena, ...options });
const input = (patch = {}) => ({ dt: 1 / 60, active: true,
  self: { position: { x: 0, y: 1.7, z: 6 }, velocity: { x: 0, y: 0, z: 0 }, yaw: 0, pitch: 0, cooldown: 0, ...patch.self },
  opponent: { position: { x: 0, y: 1.7, z: -10 }, velocity: { x: 0, y: 0, z: 0 }, ...patch.opponent },
  canSeeOpponent: true, ...Object.fromEntries(Object.entries(patch).filter(([k]) => !['self', 'opponent'].includes(k))) });
const bounded = out => {
  assert.ok(Number.isFinite(out.move.x) && Number.isFinite(out.move.z));
  assert.ok(Math.hypot(out.move.x, out.move.z) <= 1 + 1e-12);
  assert.ok(Number.isFinite(out.yaw) && Math.abs(out.yaw) <= Math.PI);
  assert.ok(Number.isFinite(out.pitch) && Math.abs(out.pitch) <= 1.2);
  assert.equal(typeof out.castQ, 'boolean'); assert.equal(out.jump, false);
};
const deepFreeze = o => { if (o && typeof o === 'object') { Object.freeze(o); Object.values(o).forEach(deepFreeze); } return o; };
const wrap = v => Math.atan2(Math.sin(v), Math.cos(v));

test('same seed and public observations reproduce outputs exactly; reset replays', () => {
  const a = make(), b = make(); const frames = [], first = [];
  for (let n = 0; n < 1200; n++) {
    const obs = input({ dt: [1/60,1/120,1/30][n%3], opponent: { position: { x: Math.sin(n/65)*5, y: 1.7, z: -10 }, velocity: { x: 1.2, y: 0, z: 0 } }, canSeeOpponent: n%400 < 330 });
    frames.push(obs); first.push(a.step(obs)); assert.deepEqual(first.at(-1), b.step(obs)); bounded(first.at(-1));
  }
  a.reset(); assert.deepEqual(frames.map(obs => a.step(obs)), first);
  assert.deepEqual(a.snapshot(), b.snapshot());
});

test('different seeds vary behavior without modifying caller data or escaped snapshots', () => {
  const observations = deepFreeze(input()); const a = make({seed:'left'}), b = make({seed:'right'});
  const aFrames=[], bFrames=[];
  for(let n=0;n<100;n++){aFrames.push(a.step(observations)); bFrames.push(b.step(observations));}
  assert.notDeepEqual(aFrames,bFrames);
  const state = a.snapshot(); state.move.x = 99; state.perceived.position.x = 999;
  assert.notEqual(a.snapshot().move.x,99); assert.notEqual(a.snapshot().perceived.position.x,999);
  a.reset({seed:'right'}); assert.deepEqual(Array.from({length:100},()=>a.step(observations)), bFrames);
});

test('pause, inactive, negative/invalid dt never advance time, RNG, or actions', () => {
  const bot=make(); for(let n=0;n<100;n++)bot.step(input()); const before=bot.snapshot();
  for (const patch of [{dt:0},{dt:-1},{dt:NaN},{dt:Infinity},{active:false},{active:undefined}]) {
    for(let n=0;n<20;n++){const out=bot.step(input(patch)); bounded(out); assert.deepEqual(out.move,{x:0,z:0}); assert.equal(out.castQ,false);}
    assert.deepEqual(bot.snapshot(),before);
  }
  bot.reset(); assert.equal(bot.snapshot().time,0); assert.equal(bot.snapshot().shots,0);
  assert.equal(bot.step(input()).castQ,false);
});

test('finite normalized output for malformed observations; invalid cooldown cannot fire', () => {
  const bot=make();
  for(const obs of [{},null, input({self:{position:{x:NaN,y:1,z:2}}}),input({opponent:{position:{x:0,y:Infinity,z:0}}}),input({self:{yaw:NaN,pitch:Infinity,cooldown:NaN}}),input({self:{position:{x:1e308,y:0,z:0}}})]) {
    bounded(bot.step(obs));
  }
  for(let n=0;n<600;n++)assert.equal(bot.step(input({self:{cooldown:NaN}})).castQ,false);
});

test('finite initial reaction and turn rate prevent instant perfect aim or first-frame cast', () => {
  const bot=make(); let previous=0, firstTurn=null, firstShot=null;
  for(let n=0;n<180;n++){
    const out=bot.step(input({opponent:{position:{x:15,y:4,z:6}}})); bounded(out);
    assert.ok(Math.abs(wrap(out.yaw-previous))<=2.6/60+1e-12); previous=out.yaw;
    if(firstTurn===null&&Math.abs(out.yaw)>.00001) firstTurn=(n+1)/60;
    if(out.castQ&&firstShot===null)firstShot=(n+1)/60;
    if(n<13){assert.equal(out.yaw,0);assert.equal(out.castQ,false);}
  }
  assert.ok(firstTurn>=.24&&firstTurn<.5, `firstTurn ${firstTurn}`);
  assert.ok(firstShot>firstTurn+.4&&firstShot<2,`firstShot ${firstShot}`);
  assert.notEqual(previous,-Math.PI/2,'persistent seeded angular error avoids exact tracking');
});

test('two player sides use the same yaw convention and require legal shot inputs', () => {
  for (const side of [1,-1]) {
    const bot=make(); let fired=false;
    for(let n=0;n<180;n++){
      const out=bot.step(input({self:{position:{x:0,y:1.7,z:side*8},yaw:side===1?0:Math.PI},opponent:{position:{x:0,y:1.7,z:-side*8}}}));
      bounded(out); fired ||= out.castQ;
      if(n>60)assert.ok(Math.abs(wrap(out.yaw-(side===1?0:Math.PI)))<.03);
    }
    assert.ok(fired,`side ${side} should have a legal cast`);
  }
});

test('cooldown, active hook, cast restriction, hidden opponent and range independently inhibit Q', () => {
  for(const patch of [{self:{cooldown:.001}},{self:{hookActive:true}},{self:{canCastQ:false}},{canSeeOpponent:false},{opponent:{position:{x:0,y:1.7,z:-40}}}]){
    const bot=make();for(let n=0;n<600;n++)assert.equal(bot.step(input(patch)).castQ,false);
  }
});

test('explicit geometry blocks current and predicted aim, including optimistic LOS flag', () => {
  const wall={min:{x:-3,y:0,z:-3},max:{x:3,y:6,z:-2}};
  const bot=make({obstacles:[wall]});
  for(let n=0;n<300;n++)assert.equal(bot.step(input()).castQ,false);
  assert.equal(bot.snapshot().perceived,null);
  const open=make({obstacles:[wall]});let fired=false;
  for(let n=0;n<300;n++)fired ||= open.step(input({self:{position:{x:6,y:1.7,z:6}},opponent:{position:{x:6,y:1.7,z:-10}}})).castQ;
  assert.ok(fired);
});

test('occlusion immediately suppresses Q and tracking, then reacquisition has a delay', () => {
  const bot=make();for(let n=0;n<120;n++)bot.step(input()); const last=bot.snapshot();
  for(let n=0;n<120;n++){
    const out=bot.step(input({canSeeOpponent:false,opponent:{position:{x:20,y:1.7,z:6}}}));
    assert.equal(out.castQ,false); assert.equal(out.yaw,last.yaw);
  }
  const hidden=bot.snapshot();assert.deepEqual(hidden.perceived.position,last.perceived.position);
  for(let n=0;n<13;n++){const out=bot.step(input({opponent:{position:{x:20,y:1.7,z:6}}}));assert.equal(out.yaw,last.yaw);assert.equal(out.castQ,false);}
});

test('shots are separated one-frame edges even when caller erroneously leaves cooldown zero', () => {
  const bot=make();const at=[];let previous=false;
  for(let n=0;n<1800;n++){const out=bot.step(input()); assert.ok(!(out.castQ&&previous)); previous=out.castQ; if(out.castQ)at.push((n+1)/60);}
  assert.ok(at.length>=8&&at.length<=14,`30 second cast count ${at.length}`);
  for(let n=1;n<at.length;n++)assert.ok(at[n]-at[n-1]>=tuning.cooldown+.11);
});

test('observed movement prediction is restrained and not immediate perfect interception', () => {
  const bot=make();let out;
  for(let n=0;n<60;n++)out=bot.step(input({opponent:{velocity:{x:6.4,y:0,z:0}}}));
  // Includes delayed sample age, then partial windup/travel, capped .7s total.
  assert.ok(Math.abs(out.yaw)<Math.atan2(4.48,16)+.019);
  assert.ok(Math.abs(out.yaw)>0.01);
  const old=out.yaw;
  for(let n=0;n<8;n++)out=bot.step(input({opponent:{velocity:{x:-6.4,y:0,z:0}}}));
  assert.ok(out.yaw < -.05 && old < -.05,'direction reversal is not visible before queued reaction delay');
});

test('60/30/120 Hz have bounded motion and comparable timing, cadence and aim', () => {
  const results=[];
  for(const hz of [60,30,120]){
    const bot=make();let prevYaw=0,firstShot=null,casts=0,moving=0;
    for(let n=0;n<hz*12;n++){
      const out=bot.step(input({dt:1/hz,opponent:{position:{x:12,y:2.5,z:-5},velocity:{x:.8,y:0,z:0}}}));bounded(out);
      assert.ok(Math.abs(wrap(out.yaw-prevYaw))<=2.6/hz+1e-12);prevYaw=out.yaw;
      if(Math.hypot(out.move.x,out.move.z)>.5)moving++;
      if(out.castQ){casts++;firstShot??=(n+1)/hz;}
    }
    results.push({hz,casts,firstShot,yaw:prevYaw});assert.ok(moving>hz*10);assert.ok(casts>=4&&casts<=6);
  }
  assert.ok(Math.max(...results.map(r=>r.firstShot))-Math.min(...results.map(r=>r.firstShot))<.09,JSON.stringify(results));
  assert.ok(Math.max(...results.map(r=>r.casts))-Math.min(...results.map(r=>r.casts))<=1);
  assert.ok(Math.max(...results.map(r=>r.yaw))-Math.min(...results.map(r=>r.yaw))<.04);
});

test('world movement stays inside legal arena bounds when consumed at 30/60/120 Hz', () => {
  for(const hz of [30,60,120]){
    const small={min:{x:-10,z:-10},max:{x:10,z:10}};const bot=make({arena:small});let p={x:9.8,y:1.7,z:9.8};
    for(let n=0;n<hz*40;n++){
      const out=bot.step(input({dt:1/hz,self:{position:p},opponent:{position:{x:0,y:1.7,z:0}}}));bounded(out);
      p={x:p.x+out.move.x*tuning.playerSpeed/hz,y:p.y,z:p.z+out.move.z*tuning.playerSpeed/hz};
      assert.ok(p.x>=-10&&p.x<=10&&p.z>=-10&&p.z<=10,JSON.stringify(p));
    }
  }
});

test('steering avoids entering static cover while simulation still owns all positions', () => {
  const wall={min:{x:-2,y:0,z:-4},max:{x:2,y:4,z:-1}};
  const bot=make({obstacles:[wall]});let p={x:0,y:1.7,z:5},walked=0;
  // See opponent once in front, then reposition toward remembered location.
  for(let n=0;n<60*20;n++){
    const out=bot.step(input({self:{position:p},opponent:{position:{x:7,y:1.7,z:-8}}}));
    const next={x:p.x+out.move.x*tuning.playerSpeed/60,y:p.y,z:p.z+out.move.z*tuning.playerSpeed/60};
    assert.ok(!(next.x>wall.min.x-.7&&next.x<wall.max.x+.7&&next.z>wall.min.z-.7&&next.z<wall.max.z+.7));
    walked+=Math.hypot(next.x-p.x,next.z-p.z);p=next;
  }
  assert.ok(walked>20);
});

test('configuration consumes supplied balance and rejects missing/invalid bounds/tuning', () => {
  assert.throws(()=>createDuelBotInputs(),/tuning/);
  assert.throws(()=>make({tuning:{...tuning,hookSpeed:0}}),/hookSpeed/);
  assert.throws(()=>make({arena:{min:{x:2,z:0},max:{x:1,z:10}}}),/arena/);
  assert.throws(()=>make({obstacles:[{min:{x:0,y:0,z:0},max:{x:-1,y:1,z:1}}]}),/obstacles/);
  const bot=make({tuning:{...tuning,maxRange:12}});
  for(let n=0;n<600;n++)assert.equal(bot.step(input()).castQ,false,'uses supplied short range');
});


test('unseen-start search movement does not read or track hidden opponent position', () => {
  const a=make(),b=make();let moved=false;
  for(let n=0;n<600;n++){
    const first=a.step(input({canSeeOpponent:false,opponent:{position:{x:-15,y:1.7,z:-30}}}));
    const second=b.step(input({canSeeOpponent:false,opponent:{position:{x:15,y:7,z:10}}}));
    assert.deepEqual(first,second); assert.equal(first.castQ,false); moved ||= Math.hypot(first.move.x,first.move.z)>.5;
  }
  assert.ok(moved);assert.equal(a.snapshot().perceived,null);
});

test('a collision-corrected actor inside planner padding can steer outward', () => {
  const wall={min:{x:-2,y:0,z:-4},max:{x:2,y:4,z:-1}};
  const bot=make({obstacles:[wall]});
  const out=bot.step(input({self:{position:{x:2.72,y:1.7,z:-2}},opponent:{position:{x:10,y:1.7,z:-2}},canSeeOpponent:false}));
  bounded(out);assert.ok(out.move.x>0,'must leave the extra 5cm planner margin');
});

test('large render hitch clamps bot advance instead of snapping aim or bursting shots', () => {
  const bot=make();for(let n=0;n<60;n++)bot.step(input());const before=bot.snapshot();
  const out=bot.step(input({dt:100,opponent:{position:{x:15,y:1.7,z:6}}}));
  bounded(out);assert.ok(Math.abs(wrap(out.yaw-before.yaw))<=.26+1e-12);
  assert.ok(Math.abs(bot.snapshot().time-before.time-.1)<1e-12);
});
