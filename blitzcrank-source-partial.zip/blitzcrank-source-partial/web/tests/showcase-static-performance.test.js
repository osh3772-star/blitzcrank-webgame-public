import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createShowcaseHarness,snapshot} from './helpers/showcase-runtime-harness.js';
const h=await createShowcaseHarness(),{THREE,showcase,showcaseScene,showcaseCamera}=h;
const reference=showcase.clone(true),referenceScene=new THREE.Scene();referenceScene.add(reference);reference.traverse(o=>o.matrixAutoUpdate=true);
const descendants=[];showcase.traverse(o=>{if(o!==showcase)descendants.push(o);});
const referenceNodes=[];reference.traverse(o=>referenceNodes.push(o));const actualNodes=[showcase,...descendants];
function same(){
 reference.position.copy(showcase.position);reference.quaternion.copy(showcase.quaternion);reference.scale.copy(showcase.scale);showcaseScene.updateMatrixWorld();referenceScene.updateMatrixWorld();
 for(let i=0;i<actualNodes.length;i++){const a=actualNodes[i],b=referenceNodes[i];assert.equal(a.name,b.name);assert.equal(a.visible,b.visible);assert.equal(a.matrixWorldNeedsUpdate,b.matrixWorldNeedsUpdate);for(let k=0;k<16;k++){assert(Object.is(a.matrix.elements[k],b.matrix.elements[k]));assert(Object.is(a.matrixWorld.elements[k],b.matrixWorld.elements[k]));}}
}
function composeCount(root){const compose=THREE.Matrix4.prototype.compose;let count=0;THREE.Matrix4.prototype.compose=function(...args){count++;return compose.apply(this,args);};try{root.updateMatrixWorld(true);}finally{THREE.Matrix4.prototype.compose=compose;}return count;}
function assetHash(){const hash=createHash('sha256'),seen=new Set();for(const o of h.game.data.fullbodyMeshes.values()){if(!o.geometry||seen.has(o.geometry))continue;seen.add(o.geometry);for(const a of Object.values(o.geometry.attributes)){hash.update(Buffer.from(a.array.buffer,a.array.byteOffset,a.array.byteLength));}if(o.geometry.index){const a=o.geometry.index.array;hash.update(Buffer.from(a.buffer,a.byteOffset,a.byteLength));}}return hash.digest('hex');}
const initialAssets=assetHash();
test('showcase baking retains the separately configured live rig, independent transforms and shared assets',()=>{
 assert(showcase.matrixAutoUpdate);assert(descendants.length>500);assert(descendants.every(o=>o.matrixAutoUpdate===false&&o.matrixWorldAutoUpdate===true));
 const original=[];h.game.data.fullbody.traverse(o=>original.push(o));
 // v64 explicitly bakes fixed live-rig Groups too. Menu cloning must still
 // leave the dynamic root/pivots/knees, every surface and attached effect alone.
 const sourceNodes=new Set(h.game.data.fullbodyNodes.values());
 const staticRig=o=>sourceNodes.has(o)&&o.isGroup&&!o.name.startsWith('BC_Pivot_')&&!o.name.startsWith('BC_QLaunch')&&!['BC_Knee.L','BC_Knee.R'].includes(o.name);
 assert.equal(original.filter(staticRig).length,278);
 for(const o of original){assert.equal(o.matrixAutoUpdate,!staticRig(o));assert(o.matrixWorldAutoUpdate);}
 const sourceMeshes=new Map(original.filter(o=>o.isMesh).map(o=>[o.name,o]));for(const o of descendants){const source=sourceMeshes.get(o.name);if(source){assert.notEqual(o,source);assert.notEqual(o.matrix,source.matrix);assert.notEqual(o.position,source.position);assert.equal(o.geometry,source.geometry);assert.equal(o.material,source.material);}}
 same();
});
test('each menu transform traversal composes only the animated root instead of every descendant',()=>{
 assert.equal(composeCount(reference),descendants.length+1);assert.equal(composeCount(showcase),1);same();
});
test('base and halo local transforms are baked before freezing',()=>{
 const base=showcase.children.find(o=>o.geometry?.type==='CylinderGeometry'),halo=showcase.children.find(o=>o.geometry?.type==='TorusGeometry');assert(base&&halo);assert.equal(base.position.y,-.1);assert.equal(halo.position.y,.01);assert.equal(halo.rotation.x,Math.PI/2);
 for(const o of [base,halo]){assert.equal(o.matrixAutoUpdate,false);assert.deepEqual(o.matrix.toArray(),new THREE.Matrix4().compose(o.position,o.quaternion,o.scale).toArray());}same();
});
test('720 spin states preserve every local and world matrix exactly, including parent transformations',()=>{
 for(let i=0;i<720;i++){showcase.rotation.y+=1/60*.35;if(i===240){showcaseScene.position.set(2,1,-4);showcaseScene.rotation.set(.2,-.5,.1);referenceScene.position.copy(showcaseScene.position);referenceScene.quaternion.copy(showcaseScene.quaternion);}same();}
 showcaseScene.position.set(0,0,0);showcaseScene.quaternion.identity();referenceScene.position.set(0,0,0);referenceScene.quaternion.identity();same();
});
test('portrait, landscape and zero-size resize retain live root layout and exact child world transforms',()=>{
 for(const [w,height] of [[390,844],[844,390],[1280,720],[256,1200]]){globalThis.innerWidth=w;globalThis.innerHeight=height;h.winListeners.resize();assert.equal(showcase.position.x,w/height<1?0:2);assert.equal(showcase.position.y,w/height<1?1.6:0);assert.equal(showcase.scale.x,w/height<1?.9:1);assert.equal(showcaseCamera.fov,w/height<1?44:40);assert.equal(showcaseCamera.aspect,w/height);assert(showcase.matrixAutoUpdate);same();}
 const before=snapshot(showcase);globalThis.innerWidth=0;h.winListeners.resize();assert.deepEqual(snapshot(showcase),before);globalThis.innerWidth=1280;globalThis.innerHeight=720;h.winListeners.resize();same();
});
test('playing W E R and returning to the menu never mutate frozen showcase descendants or original assets',()=>{
 const locals=descendants.map(o=>o.matrix.toArray());h.game.begin(true);h.key('KeyW');h.key('KeyQ');h.release('KeyQ');h.frames(90);h.release('KeyW');h.key('KeyV');h.release('KeyV');h.key('ShiftLeft');h.release('ShiftLeft');h.frames(30);h.key('KeyE');h.release('KeyE');h.frames(30);h.punch();h.frames(30);h.key('KeyR');h.release('KeyR');h.frames(30);
 assert.deepEqual(descendants.map(o=>o.matrix.toArray()),locals);assert.equal(assetHash(),initialAssets);h.element('mainmenu').click();assert.equal(h.qa.state,'menu');h.frames(20);same();assert(descendants.every(o=>!o.matrixAutoUpdate));
});
test('menu render updates and graphics loss/restore preserve the static clone and live root',()=>{
 const render=THREE.WebGLRenderer.prototype.render;THREE.WebGLRenderer.prototype.render=function(scene,camera){scene.updateMatrixWorld();if(camera.parent===null)camera.updateMatrixWorld();};
 try{const before=showcase.rotation.y;h.frames(60);assert(showcase.rotation.y>before);same();h.element('game').listeners.webglcontextlost({preventDefault(){}});h.frames(3);h.element('game').listeners.webglcontextrestored?.({});same();assert.equal(assetHash(),initialAssets);}finally{THREE.WebGLRenderer.prototype.render=render;}
});
