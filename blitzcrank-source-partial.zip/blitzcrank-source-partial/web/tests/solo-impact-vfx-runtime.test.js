import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';

// When copied into tests/, no environment configuration is needed. Optional
// paths permit an isolated source-oracle audit without editing the checkout.
const appRoot=process.env.SOLO_VFX_APP_ROOT||fileURLToPath(new URL('../',import.meta.url));
const helper=process.env.SOLO_VFX_CASE_PATH||fileURLToPath(new URL('./helpers/solo-impact-vfx-case.mjs',import.meta.url));
const source=process.env.SOLO_VFX_SOURCE_PATH||path.join(appRoot,'main.js');
function run(hz,sourcePath,expectation){
 const output=execFileSync(process.execPath,['--max-old-space-size=512',helper,appRoot,String(hz),sourcePath,expectation],{encoding:'utf8',timeout:120000,maxBuffer:1024*1024});
 return JSON.parse(output.trim().split('\n').at(-1));
}
for(const hz of [20,60,120])test(`solo E/R visual impact ages and lifecycle stay correct at ${hz} Hz`,()=>{
 const current=run(hz,source,'corrected');
 assert.equal(current.harnesses,1);
 assert.equal(current.observations.length,14);
 assert.equal(current.lifecycle.length,4);
 for(const event of current.observations)assert(Math.abs(event.actualAge-event.expectedAge)<1e-9);
 if(process.env.SOLO_VFX_BASELINE_SOURCE){
  const baseline=run(hz,process.env.SOLO_VFX_BASELINE_SOURCE,'baseline');
  assert.equal(current.sampledFrames,baseline.sampledFrames);
  assert.equal(current.authoritativeHash,baseline.authoritativeHash,'every sampled gameplay state remains byte-identical to the original');
  assert.deepEqual(current.storage,baseline.storage,'stored record bytes remain identical');
  assert.deepEqual(current.writes,baseline.writes,'record-write sequence remains identical');
 }
});
