import fs from 'node:fs';
import * as THREE from '../../vendor/three.module.js';
import {decodeModelBuffer} from '../../model-codec.js';
import {PLAYER_MODELS} from '../../player-model-manifest.js';
import {SKILL_ASSET} from '../../skill-animation-manifest.js';
import {bindSkillClips} from '../../skill-animation.js';
export {THREE};
export const data=decodeModelBuffer(fs.readFileSync(new URL('../../'+PLAYER_MODELS.fullbody.raw,import.meta.url)));
export const model=JSON.parse(fs.readFileSync(new URL('../../'+SKILL_ASSET.raw,import.meta.url))).models.fullbody;
// Actual asset order, parent/rest transforms and skill binding. Geometry is not
// involved in the pose applicator; Object3Ds avoid duplicate geometry allocation.
export function poseFixture(parts=data.parts) {
 const scene=new THREE.Scene(),body=new THREE.Group(),nodes=new Map(),records=new Map(data.nodes.map(n=>[n.name,n]));
 scene.add(body);body.position.set(4,1,-6);body.rotation.set(.1,.7,-.2);body.scale.setScalar(.78);
 for(const n of data.nodes){const node=new THREE.Group();node.name=n.name;nodes.set(n.name,node);}
 for(const n of data.nodes){const node=nodes.get(n.name),parent=nodes.get(n.parent);node.position.fromArray(n.position);if(parent){node.position.sub(new THREE.Vector3().fromArray(records.get(n.parent).position));parent.add(node);}else body.add(node);}
 const surfaces=parts.map(part=>{const mesh=new THREE.Object3D();mesh.name=part.name;mesh.userData.sourcePart=part.sourcePart||part.name;mesh.userData.skillRestPoint=records.get(part.name).position.slice();nodes.get(part.name).add(mesh);return mesh;});
 return {scene,body,nodes,surfaces,clips:bindSkillClips(model,surfaces)};
}
export function poseState(h,{world=false}={}) {
 if(world)h.scene.updateMatrixWorld();
 return h.surfaces.map(m=>({name:m.name,matrix:m.matrix.toArray(),world:world?m.matrixWorld.toArray():null,auto:m.matrixAutoUpdate,dirty:m.matrixWorldNeedsUpdate,position:m.position.toArray(),rotation:m.quaternion.toArray(),scale:m.scale.toArray()}));
}
