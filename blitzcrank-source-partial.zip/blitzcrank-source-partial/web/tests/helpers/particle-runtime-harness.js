import fs from 'node:fs';
import * as RealThree from '../../vendor/three.module.js';
globalThis.__PARTICLE_RANDOM__??=Math.random;

// Executes the real game and Three.js scene graph without a GPU or browser DOM.
// Counts attempted DOM writes, not layout/paint cost or displayed frames.
export async function createRuntimeHarness({readiness="menu",sourcePath=process.env.PARTICLE_SOURCE||new URL('../../main.js',import.meta.url)}={}) {
 const metrics={writes:0,lookups:0,hudCalls:0,geometryCreated:0,materialCreated:0,geometryDisposed:0,materialDisposed:0},elements=new Map(),docListeners={},winListeners={};
 let callback;
 class Classes {
  constructor(){this.s=new Set();}
  toggle(name,force){metrics.writes++;if(force===undefined)force=!this.s.has(name);force?this.s.add(name):this.s.delete(name);return force;}
  add(name){metrics.writes++;this.s.add(name);}
  remove(name){metrics.writes++;this.s.delete(name);}
 }
 const style=()=>new Proxy({},{set(object,key,value){metrics.writes++;object[key]=value;return true;}});
 class Element {
  constructor(){this.style=style();this.classList=new Classes();this.firstElementChild={style:style()};this.parentElement={classList:new Classes()};this.value='1';this.disabled=false;this.listeners={};this.attributes={};this.text='';this.html='';}
  get textContent(){return this.text;}
  set textContent(value){metrics.writes++;this.text=String(value);}
  get innerHTML(){return this.html;}
  set innerHTML(value){metrics.writes++;this.html=String(value);}
  addEventListener(name,fn){const previous=this.listeners[name];this.listeners[name]=event=>{previous?.(event);fn(event);};}
  setAttribute(name,value){metrics.writes++;this.attributes[name]=String(value);}
  querySelector(){return new Element();}
  getBoundingClientRect(){return{left:0,top:0,width:110,height:110};}
  setPointerCapture(){}
  requestPointerLock(){document.pointerLockElement=this;docListeners.pointerlockchange?.();return Promise.resolve();}
  click(){this.onclick?.();}
  getContext(){return{fillRect(){},fillText(){},fillStyle:'',textAlign:'',font:''};}
 }
 const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
 globalThis.document={getElementById:id=>{metrics.lookups++;return element(id);},querySelector:element,createElement:()=>new Element(),addEventListener:(name,fn)=>docListeners[name]=fn,pointerLockElement:null,exitPointerLock(){this.pointerLockElement=null;docListeners.pointerlockchange?.();}};
 Object.assign(globalThis,{window:globalThis,innerWidth:1280,innerHeight:720,devicePixelRatio:1,matchMedia:()=>({matches:false}),localStorage:{getItem:()=>null,setItem(){}},addEventListener:(name,fn)=>winListeners[name]=fn,requestAnimationFrame:fn=>{callback=fn;}});
 globalThis.fetch=async path=>({ok:true,arrayBuffer:async()=>{const bytes=fs.readFileSync(new URL('../../'+path.replace('./',''),import.meta.url));return bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);},json:async()=>JSON.parse(fs.readFileSync(new URL('../../'+path.replace('./',''),import.meta.url)))});
 class Renderer {constructor(){this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}render(){}clearDepth(){}}
 class Clock {getDelta(){return 1/60;}}
 class TextureLoader {async loadAsync(path){if(!fs.existsSync(new URL('../../'+path.replace('./',''),import.meta.url)))throw Error('Missing texture: '+path);return new RealThree.Texture();}}
 class BoxGeometry extends RealThree.BoxGeometry {constructor(...args){super(...args);metrics.geometryCreated++;}dispose(){metrics.geometryDisposed++;super.dispose();}}
 class MeshBasicMaterial extends RealThree.MeshBasicMaterial {constructor(...args){super(...args);metrics.materialCreated++;}dispose(){metrics.materialDisposed++;super.dispose();}}
 globalThis.__RUNTIME_HARNESS_THREE__={...RealThree,BoxGeometry,MeshBasicMaterial,WebGLRenderer:Renderer,Clock,TextureLoader};
 globalThis.__RUNTIME_HARNESS_METRICS__=metrics;
 let source=fs.readFileSync(sourcePath,'utf8').replaceAll('Math.random()', 'globalThis.__PARTICLE_RANDOM__()').replace("import * as THREE from './vendor/three.module.js';",'const THREE=globalThis.__RUNTIME_HARNESS_THREE__;').replace(/from '\.\/([^']+)'/g,(_,path)=>`from '${new URL('../../'+path,import.meta.url).href}'`);
 source=source.replace('function updateHud(){','function updateHud(){globalThis.__RUNTIME_HARNESS_METRICS__.hudCalls++;');
 source+='\nwindow.__RUNTIME_HARNESS__={particles,returnToMenu,updateHud,begin,pause,resume,finish,damagePlayer,castW,castE,castR,get particleData(){return{sparks,scene}},get data(){return{session,skills,targets,parts,fullbodyNodes,fullbodyMeshes,player,hook,shotCooldown,punchCooldown,health}},setElapsed(value){session.elapsed=value},setScore(value){session.score=value},setCombo(value){session.combo=value},setHealth(value){health=value},setCooldown(value){shotCooldown=value}};';
 // Explicit gameplay-ready boundary for legacy tests; natural startup has separate tests.
 if(!['menu','game'].includes(readiness))throw new Error('Unknown test readiness: '+readiness);
 if(readiness==='game')source+='\nif(typeof ensureGameplayAssets==="function")await ensureGameplayAssets();';
 await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
 return {element,elements,metrics,game:globalThis.__RUNTIME_HARNESS__,qa:globalThis.__HOOK_ARENA__,frames(count){for(let i=0;i<count;i++)callback();},punch(){element('game').listeners.pointerdown({pointerType:'mouse',button:0,preventDefault(){}});},key(code){winListeners.keydown({code,repeat:false,preventDefault(){}});},release(code){winListeners.keyup({code});},resetMetrics(){for(const key of Object.keys(metrics))metrics[key]=0;}};
}

// Gameplay fixtures opt in at their call site; menu fixtures never silently preload.
export function createGameplayHarness(options={}){return createRuntimeHarness({...options,readiness:"game"});}
