import * as THREE from '../../vendor/three.module.js';

// Actual vendored Three.js resources and all five palm anchors, without a
// renderer. This fixture makes no browser/GPU/FPS claims.
export function createSkillVfxHarness(createSkillVfx) {
  const scene = new THREE.Scene(), viewScene = new THREE.Scene(), fullbody = new THREE.Group();
  const vm = new THREE.Group(), detached = new THREE.Group();
  scene.add(fullbody, detached); viewScene.add(vm);
  fullbody.scale.setScalar(.78); fullbody.rotation.y = Math.PI;
  const worldHands = [], viewHands = [];
  for (const side of ['L', 'R']) for (const [root, list, prefix] of [[fullbody, worldHands, 'BC'], [vm, viewHands, 'VM']]) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(.4, .3, .48), new THREE.MeshBasicMaterial());
    mesh.name = `${prefix}_Palm.${side}`; mesh.geometry.translate(side === 'L' ? -.8 : .8, .4, -.5);
    root.add(mesh); list.push(mesh);
  }
  const clone = new THREE.Mesh(viewHands[1].geometry, viewHands[1].material);
  clone.name = 'VM_Palm.R_detached'; detached.add(clone); viewHands.push(clone);
  const vfx = createSkillVfx(THREE, {scene, viewScene, fullbody, worldHands, viewHands});
  const owned = [];
  for (const root of [scene, viewScene]) root.traverse(o => { if (/^(W_|E_|R_)/.test(o.name)) owned.push(o); });
  const geometries = [...new Set(owned.filter(o => !o.isSprite).map(o => o.geometry).filter(Boolean))];
  const materials = [...new Set(owned.map(o => o.material).filter(Boolean))];
  const textures = [...new Set(materials.map(m => m.map).filter(Boolean))];
  const arrays = geometries.flatMap(g => Object.values(g.attributes).map(a => a.array));
  return {vfx, scene, viewScene, fullbody, vm, detached, worldHands, viewHands, owned, geometries, materials, textures, arrays};
}

export function vfxStatus(phase = null, time = 0, rest = {}) {
  return {phase, boost: 0, slow: 0, armed: 0, animation: phase ? {name: phase, time} : null, ...rest};
}

export function vfxState(h) {
  h.scene.updateMatrixWorld(true); h.viewScene.updateMatrixWorld(true);
  return {
    inspect: h.vfx.inspect(),
    objects: h.owned.map(o => ({name: o.name, visible: o.visible, position: o.position.toArray(),
      rotation: o.rotation.toArray(), scale: o.scale.toArray(), matrix: [...o.matrix.elements], world: [...o.matrixWorld.elements],
      renderOrder: o.renderOrder, frustumCulled: o.frustumCulled, parent: o.parent?.name,
      geometry: h.geometries.indexOf(o.geometry), material: h.materials.indexOf(o.material)})),
    // Upload version counters deliberately differ for unchanged empty buffers.
    // Contents (including inactive tails), ranges, identity sharing, material
    // values, and every public inspect value must still match exactly.
    geometries: h.geometries.map(g => ({drawRange: {...g.drawRange}, attributes: Object.fromEntries(
      Object.entries(g.attributes).map(([key, a]) => [key, {itemSize: a.itemSize, normalized: a.normalized, usage: a.usage, array: a.array.slice()}]))})),
    materials: h.materials.map(m => ({type: m.type, color: m.color?.toArray(), opacity: m.opacity, visible: m.visible,
      transparent: m.transparent, blending: m.blending, depthWrite: m.depthWrite, depthTest: m.depthTest,
      toneMapped: m.toneMapped, side: m.side, vertexColors: m.vertexColors, vertexShader: m.vertexShader, fragmentShader: m.fragmentShader,
      map: h.textures.indexOf(m.map), uniforms: m.uniforms && Object.fromEntries(Object.entries(m.uniforms).map(([key, u]) => [key, u.value?.toArray ? u.value.toArray() : u.value]))})),
    textures: h.textures.map(t => ({data: t.image.data.slice(), width: t.image.width, height: t.image.height,
      magFilter: t.magFilter, minFilter: t.minFilter, generateMipmaps: t.generateMipmaps, format: t.format})),
  };
}

export function uploadVersions(h) {
  return h.geometries.map(g => Object.fromEntries(Object.entries(g.attributes).map(([key, a]) => [key, a.version])));
}
