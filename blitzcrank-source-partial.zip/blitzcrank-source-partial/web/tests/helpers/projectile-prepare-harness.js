import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {createGameplayHarness} from './runtime-harness.js';
// Frozen v0.24.44 implementations. Keep independent of the candidate source.
const reference=`
function legacyFpsHandPoint(){const conversion=viewToWorldMatrix();const palm=parts.find(p=>p.name==='VM_Palm.R');const point=palm.geometry.boundingBox.getCenter(new THREE.Vector3());return point.applyMatrix4(palm.matrixWorld).applyMatrix4(conversion);}
function legacyPrepareProjectile(place=true){
 const conversion=viewToWorldMatrix(),center=legacyFpsHandPoint(),inverse=new THREE.Matrix4().compose(center,camera.quaternion,new THREE.Vector3(1,1,1)).invert();
 for(let i=0;i<projectileParts.length;i++)fist.children[i].matrix.copy(inverse).multiply(conversion).multiply(projectileParts[i].matrixWorld);if(place){fist.position.copy(center);fist.quaternion.copy(camera.quaternion);}
}`;
export async function createProjectilePrepareHarness({sourcePath=new URL('../../main.js',import.meta.url),compare}={}){
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'projectile-prepare-harness-')),file=path.join(directory,'main.js');
 let source=fs.readFileSync(sourcePath,'utf8');
 source=source.replace('function prepareProjectile(place=true){','function candidatePrepareProjectile(place=true){');
 source+='\n'+reference+`
 function prepareProjectile(place=true){if(globalThis.__PROJECTILE_PREPARE_COMPARE__)return globalThis.__PROJECTILE_PREPARE_COMPARE__(candidatePrepareProjectile,legacyPrepareProjectile,place,()=>({fist,camera,viewCamera,viewmodel,parts,projectileParts,hook,thirdPerson}));return candidatePrepareProjectile(place);}
 window.__PROJECTILE_PREPARE_RUNTIME__={current:candidatePrepareProjectile,legacy:legacyPrepareProjectile,fpsHandPoint,legacyFpsHandPoint,aim,syncCamera,resize,prepareMirrorBody,restoreMirrorBody,get data(){return{fist,camera,viewCamera,viewmodel,parts,projectileParts,hook,thirdPerson,scene,viewScene,fullbody}}};`;
 fs.writeFileSync(file,source);globalThis.__PROJECTILE_PREPARE_COMPARE__=compare;
 try{const h=await createGameplayHarness({sourcePath:file});return {...h,projectile:globalThis.__PROJECTILE_PREPARE_RUNTIME__};}finally{fs.rmSync(directory,{recursive:true,force:true});}
}
