import fs from 'node:fs';import * as THREE from '../../vendor/three.module.js';import {loadTurretModel} from '../../turret-view.js';
export {THREE};
export const turretAsset=await loadTurretModel(async file=>{const bytes=fs.readFileSync(new URL('../../'+file.replace('./',''),import.meta.url));return{ok:true,arrayBuffer:async()=>bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)};});
export function turretFixture(create,resetOn=null){
 const scene=new THREE.Scene(),obstacles=[],events=[];let arena;
 const record=name=>(...args)=>{events.push([name,...structuredClone(args)]);if(name===resetOn)arena.reset();};
 arena=create(scene,turretAsset,obstacles,{onAcquired:record('acquired'),onLost:record('lost'),onWarning:record('warning'),onShot:record('shot'),onDamage:record('damage')});
 return{scene,obstacles,events,arena};
}
export function turretState(h){
 // This is the renderer's normal scene-matrix preparation, not a GPU render.
 h.scene.updateMatrixWorld();
 const object=o=>({name:o.name,position:o.position.toArray(),quaternion:o.quaternion.toArray(),scale:o.scale.toArray(),matrix:o.matrix.toArray(),world:o.matrixWorld.toArray(),visible:o.visible,auto:o.matrixAutoUpdate,dirty:o.matrixWorldNeedsUpdate});
 const visuals=[];for(const [id,v] of h.arena.visuals){const nodes=[];v.root.traverse(n=>nodes.push(object(n)));visuals.push({id,nodes,recoil:v.recoil,ring:{...object(v.ring),color:v.ring.material.color.toArray(),opacity:v.ring.material.opacity},line:{...object(v.line),positions:v.line.geometry.attributes.position.array.slice(),version:v.line.geometry.attributes.position.version},flare:object(v.flare)});}
 return{turrets:structuredClone(h.arena.sim.turrets),bullets:structuredClone(h.arena.sim.bullets),events:structuredClone(h.events),simEvents:structuredClone(h.arena.sim.events),warning:h.arena.warning,visuals,bulletMeshes:[...h.arena.bulletMeshes].map(([id,m])=>[id,object(m)]),obstacles:h.obstacles.map(o=>({min:o.min.toArray(),max:o.max.toArray(),turretId:o.turretId}))};
}
