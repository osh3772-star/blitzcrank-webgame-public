import fs from 'node:fs';
import * as RealThree from '../../vendor/three.module.js';

// Executes the real game and Three.js scene graph without a GPU or browser DOM.
// Counts attempted DOM writes, not layout/paint cost or displayed frames.
export async function createRuntimeHarness({readiness="menu",width=390,height=844,coarse=true,sourcePath=new URL('../../main.js',import.meta.url)}={}) {
 const metrics={writes:0,lookups:0,hudCalls:0},statusWrites=[],elements=new Map(),docListeners={},winListeners={};
 let callback,delta=1/60,pointerLockMode='immediate';
 const record=(id,property,value)=>{if(['crosshair','targetname','threatwarning','hitnotice','damageflash'].includes(id))statusWrites.push({id,property,value});};
 class Classes {
  constructor(id){this.id=id;this.s=new Set();}
  toggle(name,force){record(this.id,'class.'+name,force);metrics.writes++;if(force===undefined)force=!this.s.has(name);force?this.s.add(name):this.s.delete(name);return force;}
  add(name){record(this.id,'class.'+name,true);metrics.writes++;this.s.add(name);}
  remove(name){record(this.id,'class.'+name,false);metrics.writes++;this.s.delete(name);}
 }
 const style=id=>new Proxy({},{set(object,key,value){record(id,'style.'+key,String(value));metrics.writes++;object[key]=String(value);return true;}});
 class Element {
  constructor(id){this.id=id;this.style=style(id);this.classList=new Classes(id);this.firstElementChild={style:style()};this.parentElement={classList:new Classes()};this.value='1';this.disabled=false;this.listeners={};this.attributes={};this.text='';this.html='';}
  get textContent(){return this.text;}
  set textContent(value){record(this.id,'textContent',String(value));metrics.writes++;this.text=String(value);}
  get innerHTML(){return this.html;}
  set innerHTML(value){metrics.writes++;this.html=String(value);}
  addEventListener(name,fn){const previous=this.listeners[name];this.listeners[name]=event=>{previous?.(event);fn(event);};}
  setAttribute(name,value){metrics.writes++;this.attributes[name]=String(value);}
  querySelector(selector){return element(this.id+' '+selector);}
  getBoundingClientRect(){return{left:0,top:0,width:110,height:110};}
  setPointerCapture(id){(this.pointerCaptures??=new Set()).add(id);}hasPointerCapture(id){return this.pointerCaptures?.has(id)??false;}releasePointerCapture(id){this.pointerCaptures?.delete(id);}
  requestPointerLock(){if(pointerLockMode==='pending')return new Promise(()=>{});document.pointerLockElement=this;docListeners.pointerlockchange?.();return Promise.resolve();}
  click(){this.onclick?.();}
  getContext(){return{fillRect(){},fillText(){},fillStyle:'',textAlign:'',font:''};}
 }
 const element=id=>{if(!elements.has(id))elements.set(id,new Element(id));return elements.get(id);};
 globalThis.document={getElementById:id=>{metrics.lookups++;return element(id);},querySelector:element,createElement:()=>new Element(),addEventListener:(name,fn)=>docListeners[name]=fn,pointerLockElement:null,exitPointerLock(){this.pointerLockElement=null;docListeners.pointerlockchange?.();}};
 Object.assign(globalThis,{window:globalThis,innerWidth:width,innerHeight:height,devicePixelRatio:1,matchMedia:()=>({matches:coarse}),localStorage:{getItem:()=>null,setItem(){}},addEventListener:(name,fn)=>winListeners[name]=fn,requestAnimationFrame:fn=>{callback=fn;}});
 globalThis.fetch=async path=>({ok:true,arrayBuffer:async()=>{const bytes=fs.readFileSync(new URL('../../'+path.replace('./',''),import.meta.url));return bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);},json:async()=>JSON.parse(fs.readFileSync(new URL('../../'+path.replace('./',''),import.meta.url)))});
 class Renderer {constructor(){this.shadowMap={};}setPixelRatio(){}setSize(w,h){this.size={width:w,height:h};}clear(){}render(){}clearDepth(){}}
 class Clock {getDelta(){return delta;}}
 class TextureLoader {async loadAsync(path){if(!fs.existsSync(new URL('../../'+path.replace('./',''),import.meta.url)))throw Error('Missing texture: '+path);return new RealThree.Texture();}}
 globalThis.__RUNTIME_HARNESS_THREE__={...RealThree,WebGLRenderer:Renderer,Clock,TextureLoader};
 globalThis.__RUNTIME_HARNESS_METRICS__=metrics;
 let source=fs.readFileSync(sourcePath,'utf8').replace("import * as THREE from './vendor/three.module.js';",'const THREE=globalThis.__RUNTIME_HARNESS_THREE__;').replace(/from '\.\/([^']+)'/g,(_,path)=>`from '${new URL('../../'+path,import.meta.url).href}'`);
 source=source.replace('function updateHud(){','function updateHud(){globalThis.__RUNTIME_HARNESS_METRICS__.hudCalls++;');
 source+='\nwindow.__RUNTIME_HARNESS__={notice,aim,syncCamera,playing,returnToMenu,updateCaptureUI,updateHud,begin,pause,resume,finish,damagePlayer,castW,castE,castR,get data(){return{session,skills,targets,parts,fullbodyNodes,fullbodyMeshes,player,hook,shotCooldown,punchCooldown,health,noticeTime,damageFlash,turretArena,camera,viewCamera,renderer,isTouch,joystick}},setElapsed(value){session.elapsed=value},setScore(value){session.score=value},setCombo(value){session.combo=value},setHealth(value){health=value},setCooldown(value){shotCooldown=value}};';
 element('threatwarning').classList.s.add('hidden');
 source+='\n// Mobile harness '+width+'x'+height+' coarse '+coarse;
 // Explicit gameplay-ready boundary for legacy tests; natural startup has separate tests.
 if(!['menu','game'].includes(readiness))throw new Error('Unknown test readiness: '+readiness);
 if(readiness==='game')source+='\nif(typeof ensureGameplayAssets==="function")await ensureGameplayAssets();';
 await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
 return {resize(w,h){globalThis.innerWidth=w;globalThis.innerHeight=h;winListeners.resize();},element,elements,metrics,statusWrites,setDelta(value){delta=value;},setPointerLockMode(value){pointerLockMode=value;},acquirePointer(){document.pointerLockElement=element('game');docListeners.pointerlockchange?.();},releasePointer(){document.exitPointerLock();},docEvent(name,event={}){docListeners[name]?.(event);},winEvent(name,event={}){winListeners[name]?.(event);},canvasEvent(name,event={}){element('game').listeners[name]?.(event);},game:globalThis.__RUNTIME_HARNESS__,qa:globalThis.__HOOK_ARENA__,frames(count){for(let i=0;i<count;i++)callback();},key(code){winListeners.keydown({code,repeat:false,preventDefault(){}});},release(code){winListeners.keyup({code});},resetMetrics(){statusWrites.length=0;for(const key of Object.keys(metrics))metrics[key]=0;}};
}

// Gameplay fixtures opt in at their call site; menu fixtures never silently preload.
export function createGameplayHarness(options={}){return createRuntimeHarness({...options,readiness:"game"});}
