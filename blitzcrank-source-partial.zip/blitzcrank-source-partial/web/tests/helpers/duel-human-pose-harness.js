import {adaptHistoricalRPresentation} from './r-locomotion-policy.js';
import {adaptHistoricalWPresentation} from './w-stationary-policy.js';
import {duelAvatarCreatePolicy,setDuelAvatarCreatePolicy} from './duel-avatar-create-policy.js';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {performance} from 'node:perf_hooks';
import {createHash} from 'node:crypto';
import {createGameplayHarness} from './runtime-harness.js';
// V8 serialization is not canonical across equal packed numeric arrays. Keep
// exact numeric values, signed zero and typed-array identity in a stable form.
export function poseStateDigest(value){return createHash('sha256').update(JSON.stringify(value,(key,v)=>{
 if(typeof v==='number')return 'n:'+(Object.is(v,-0)?'-0':String(v));
 if(typeof v==='string')return 's:'+v;if(typeof v==='undefined')return 'u:';
 if(ArrayBuffer.isView(v))return v instanceof DataView?{__poseView:'DataView',bytes:Array.from(new Uint8Array(v.buffer,v.byteOffset,v.byteLength)),byteLength:v.byteLength}:{__poseView:v.constructor.name,length:v.length,values:Array.from(v)};
 if(v instanceof ArrayBuffer)return {__poseBuffer:true,bytes:Array.from(new Uint8Array(v)),byteLength:v.byteLength};return v;
})).digest('hex');}
export async function createPoseHarness({baseline=false,unsafe=false,dt=1/60,profile=false}={}){
 const current=fs.readFileSync(new URL('../../main.js',import.meta.url),'utf8');
 let source=baseline?fs.readFileSync(new URL('../fixtures/main-duel-pose-v0.24.60-baseline.txt',import.meta.url),'utf8'):current;
 const currentFactoryPolicy=duelAvatarCreatePolicy(current);duelAvatarCreatePolicy(source);
 // Keep the v61 final-pose-call comparison isolated: both sides use the later
 // explicitly enabled fixed-rig contract. The frozen v60 file stays untouched,
 // all numeric/flag snapshot checks remain, and v64 separately tests off/on.
 if(baseline&&current.includes('cacheStaticFullbodyNodeMatrices(fullbodyNodes);')){
  for(const [before,after]of [
   ['import {createDuelAvatarFactory}', 'import {createDuelAvatarFactory,cacheStaticFullbodyNodeMatrices}'],
   [' applyEWalkLayer=createFullbodyELocomotionLayer(THREE,{body:fullbody,nodes:fullbodyNodes,surfaces:fullbodySurfaces,locomotion});',' applyEWalkLayer=createFullbodyELocomotionLayer(THREE,{body:fullbody,nodes:fullbodyNodes,surfaces:fullbodySurfaces,locomotion});\n cacheStaticFullbodyNodeMatrices(fullbodyNodes);']
  ]){if(source.split(before).length!==2||current.split(after).length!==2)throw Error('Unknown historical/current static-rig opt-in site: '+before);source=source.replace(before,after);}
 }
 // Keep the v61 final-pose comparison independent of later factory policies.
 // The frozen historical file and all state/flag/trace assertions stay intact.
 if(baseline){
  const historicalFactoryPolicy=duelAvatarCreatePolicy(source);
  if(historicalFactoryPolicy.staticRestMatrices||historicalFactoryPolicy.reuseSkillSurfaceRestPose||historicalFactoryPolicy.stationaryW)throw Error('Historical factory already adapted');
  source=setDuelAvatarCreatePolicy(source,{staticRestMatrices:currentFactoryPolicy.staticRestMatrices,reuseSkillSurfaceRestPose:currentFactoryPolicy.reuseSkillSurfaceRestPose,stationaryW:currentFactoryPolicy.stationaryW});
  source=adaptHistoricalWPresentation(source,current);
  source=adaptHistoricalRPresentation(source,current);
 }
 // Align the independently approved positive-delta punch endpoint cleanup.
 // The frozen v60 fixture predates it; keeping its tiny positive residue would
 // compare different gameplay presentation contracts at 120 Hz. No tolerance
 // or snapshot field is removed, and the original fixture stays untouched.
 const punchOld="oneShot=Math.max(0,oneShot-dt);if(!oneShot&&state==='running')";
 const punchNew="oneShot=Math.max(0,oneShot-dt);if(dt>0&&clipName==='Basic_Punch'&&oneShot<1e-12)oneShot=0;if(!oneShot&&state==='running')";
 if(current.split(punchNew).length!==2)throw Error('Unknown approved punch endpoint contract');
 if(baseline){if(source.split(punchOld).length!==2)throw Error('Unknown historical punch endpoint contract');source=source.replace(punchOld,punchNew);}
 // Later hand-path optimization defers unrelated child matrices until render.
 // Keep the historical v61 call-count comparison independent of this contract.
 const handPathOld='q.quaternion.identity();if(!detached)fullbody.updateMatrixWorld(true);const center=';
 const handPathNew='q.quaternion.identity();const center=';
 const handPolicy=text=>{const begin='function updateFullbodyHand(){',end='\nfunction syncCamera(){';if(text.split(begin).length!==2||text.split(end).length!==2)throw Error('Unknown hand refresh function bounds');const body=text.slice(text.indexOf(begin),text.indexOf(end)),old=body.split(handPathOld).length-1,next=body.split(handPathNew).length-1;if(body.split('q.position.add(desired.sub(current));fullbody.updateMatrixWorld(true);').length!==2)throw Error('Detached full-tree refresh changed');if(old+next!==1||old>1||next>1)throw Error('Unknown hand refresh policy');return{body,deferred:next===1};};
 const deferredHandPath=handPolicy(current).deferred;
 if(deferredHandPath&&baseline){const before=handPolicy(source);if(before.deferred)throw Error('Historical hand refresh already adapted');source=source.replace(before.body,before.body.replace(handPathOld,handPathNew));if(!handPolicy(source).deferred)throw Error('Historical hand refresh adaptation failed');}
 if(unsafe){const match=source.match(/import \{planDuelPullPath,sampleDuelPullPath\} from '([^']+)';/);if(!match)throw Error('Missing route import');source=source.replace(match[0],`import {sampleDuelPullPath} from '${match[1]}'; const planDuelPullPath=()=>({ok:false,code:'TEST_UNSUPPORTED_ROUTE'});`);}
 const old='syncCamera();animateFullbody(0,walking);updateDuelAvatar(0);',guard='if(!playing()||duel.resultReady)animateFullbody(0,walking);';
 if(source.includes(old))source=source.replace(old,'syncCamera();globalThis.__DUEL_POSE_TRACE__.inner++;if(!playing()||duel.resultReady)globalThis.__DUEL_POSE_TRACE__.requiredInner++;animateFullbody(0,walking);updateDuelAvatar(0);');
 else if(source.includes(guard))source=source.replace(guard,'if(!playing()||duel.resultReady){globalThis.__DUEL_POSE_TRACE__.inner++;if(!playing()||duel.resultReady)globalThis.__DUEL_POSE_TRACE__.requiredInner++;animateFullbody(0,walking);}');
 else throw Error('Unknown final pose call shape');
 source=source.replace('if(playing()){animateFullbody(dt,walking);','if(playing()){globalThis.__DUEL_POSE_TRACE__.outer++;animateFullbody(dt,walking);');
 source=source.replace('function animateFullbody(dt,walking){','function animateFullbodyRaw(dt,walking){').replaceAll('performance.now()','globalThis.__DUEL_POSE_CLOCK__ * 1000');
 globalThis.__DUEL_POSE_TRACE__={calls:0,inner:0,requiredInner:0,outer:0,elapsed:0};globalThis.__DUEL_POSE_CLOCK__=0;globalThis.__DUEL_POSE_PROFILE__=profile;globalThis.__DUEL_POSE_NOW__=()=>performance.now();
 source+=`\nfunction animateFullbody(dt,walking){const s=globalThis.__DUEL_POSE_TRACE__;s.calls++;if(!globalThis.__DUEL_POSE_PROFILE__)return animateFullbodyRaw(dt,walking);const t=globalThis.__DUEL_POSE_NOW__();try{return animateFullbodyRaw(dt,walking);}finally{s.elapsed+=globalThis.__DUEL_POSE_NOW__()-t;}}\nwindow.__POSE_EXPOSE__={prepareMirrorBody,restoreMirrorBody,get state(){return{socket:fullbodySocket.toArray(),clipName,clipTime,oneShot,bodySkillActive,visibleSkill:visibleSkillAnimation()?.name??null}},get roots(){return[fullbody,fist,rope,duelAvatar.object,duelRope]}};`;
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'duel-human-pose-')),file=path.join(dir,'main.mjs');fs.writeFileSync(file,source);let h;
 try{h=await createGameplayHarness({sourcePath:file,delta:()=>{globalThis.__DUEL_POSE_CLOCK__+=dt;return dt;}});}finally{fs.unlinkSync(file);fs.rmdirSync(dir);}
 // Match Three's normal render boundary before full-tree matrix/flag snapshots.
 // No forced refresh and no numeric/flag assertions are removed.
 if(deferredHandPath)globalThis.__RUNTIME_HARNESS_THREE__.WebGLRenderer.prototype.render=function(scene,camera){if(scene.matrixWorldAutoUpdate===true)scene.updateMatrixWorld();if(camera.parent===null&&camera.matrixWorldAutoUpdate===true)camera.updateMatrixWorld();};
 const exposed=globalThis.__POSE_EXPOSE__,nodes=exposed.roots.map(root=>{const out=[];root.traverse(o=>out.push(o));return out;});
 const snapshot=()=>({state:h.qa.state,duel:h.qa.duel,session:h.qa.session,health:h.qa.health,player:h.qa.player,skills:h.qa.skills,pose:exposed.state,chains:[h.game.data.rope,h.game.data.duelRope].map(o=>({visible:o.visible,start:o.userData.start.toArray(),end:o.userData.end.toArray(),count:o.userData.linkCount,length:o.userData.length,arcLength:o.userData.arcLength,sag:o.userData.sag,matrices:o.links.instanceMatrix.array,matrixVersion:o.links.instanceMatrix.version})),roots:nodes.map(list=>list.map(o=>[o.name,o.visible,o.position.toArray(),o.quaternion.toArray(),o.rotation.toArray(),o.scale.toArray(),o.matrix.toArray(),o.matrixWorld.toArray(),o.matrixAutoUpdate,o.matrixWorldNeedsUpdate]))});
 return {...h,pose:exposed,THREE:globalThis.__RUNTIME_HARNESS_THREE__,setDelta(value){dt=value;},trace:globalThis.__DUEL_POSE_TRACE__,clearTrace(){Object.assign(globalThis.__DUEL_POSE_TRACE__,{calls:0,inner:0,requiredInner:0,outer:0,elapsed:0});},snapshot,hash(){return poseStateDigest(snapshot());}};
}
