import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createGameplayHarness} from './runtime-harness.js';

// Frozen v0.24.4 implementation: an independent oracle for the two redundant
// detached-hand traversals. Do not derive this reference from current main.js.
const reference = `function referenceUpdateFullbodyHand(){
 const q=fullbodyNodes.get('BC_QLaunch.R'),palm=fullbodyMeshes.get('BC_Palm.R');if(!q||!palm)return;
 q.position.fromArray(q.userData.base);q.quaternion.identity();fullbody.updateMatrixWorld(true);const center=palm.geometry.boundingBox.getCenter(new THREE.Vector3());palm.localToWorld(center);fullbodySocket.copy(center);
 if(hook&&['outbound','return'].includes(hook.phase)){
  const home=q.getWorldQuaternion(new THREE.Quaternion()),orientation=hook.bodyOrientation?.clone()||home.clone();
  if(hook.phase==='return')orientation.slerp(home,smooth(Math.min(1,hook.phaseTime/hook.returnDuration)));
  q.quaternion.copy(q.parent.getWorldQuaternion(new THREE.Quaternion()).invert()).multiply(orientation);fullbody.updateMatrixWorld(true);
  palm.geometry.boundingBox.getCenter(center);palm.localToWorld(center);const current=q.parent.worldToLocal(center.clone()),desired=q.parent.worldToLocal(hook.position.clone());q.position.add(desired.sub(current));fullbody.updateMatrixWorld(true);
 }
}`;

// Only the CPU test module is instrumented. Production exports and the existing
// shared runtime harness remain unchanged. No GPU rendering is simulated here.
export async function createHookMatrixHarness({sourcePath=new URL('../../main.js',import.meta.url),compare}={}) {
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'hook-matrix-harness-'));
 const sourceFile=path.join(directory,'main.js');
 let source=fs.readFileSync(sourcePath,'utf8');
 source=source.replace('function updateFullbodyHand(){','function candidateUpdateFullbodyHand(){');
 source+=`\n${reference}\nfunction updateFullbodyHand(){
  if(globalThis.__HOOK_MATRIX_COMPARE__)return globalThis.__HOOK_MATRIX_COMPARE__(candidateUpdateFullbodyHand,referenceUpdateFullbodyHand,()=>({fullbody,fullbodySocket,hook,scene,palm:fullbodyMeshes.get('BC_Palm.R')}));
  return candidateUpdateFullbodyHand();
 }
 window.__HOOK_MATRIX_RUNTIME__={updateFullbodyHand,aim,syncCamera,prepareMirrorBody,restoreMirrorBody,fullbodyCableSocket,fullbodyChainSocket,cableSocket,chainHandSocket,get data(){return{fullbody,fullbodySocket,hook,scene,fist,rope,fullbodyNodes,fullbodyMeshes,fullbodySurfaces,parts,projectileParts,player,camera,viewmodel,skills}}};`;
 fs.writeFileSync(sourceFile,source);
 globalThis.__HOOK_MATRIX_COMPARE__=compare;
 try {
  const harness=await createGameplayHarness({sourcePath:sourceFile});
  return {...harness,matrix:globalThis.__HOOK_MATRIX_RUNTIME__};
 } finally {fs.rmSync(directory,{recursive:true,force:true});}
}
