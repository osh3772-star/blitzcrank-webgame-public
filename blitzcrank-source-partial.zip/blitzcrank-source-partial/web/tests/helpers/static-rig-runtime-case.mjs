import assert from 'node:assert/strict';import {createStaticRigRuntime} from './static-rig-runtime-harness.js';
const baseline=process.argv[2]==='baseline',kind=process.argv[3],r=await createStaticRigRuntime({baseline}),frames=[],seen=new Set();let firstComposes=null;
const key=code=>{r.key(code);r.release(code)};
function step(mirror=false){if(firstComposes===null){firstComposes=0;const original=r.THREE.Matrix4.prototype.compose;r.THREE.Matrix4.prototype.compose=function(...args){firstComposes++;return original.apply(this,args)};try{r.frames(1)}finally{r.THREE.Matrix4.prototype.compose=original;}}else r.frames(1);const hash=r.hash();let prepared=null,restored=null;if(mirror){const token=r.pose.prepareMirrorBody();prepared=r.hash();r.pose.restoreMirrorBody(token);restored=r.hash();}frames.push([hash,prepared,restored]);const skill=kind==='bot'?r.qa.duel?.avatar.skill:(r.qa.skills?.animation?.presentation?.name??r.qa.skills?.animation?.name);if(skill)seen.add(skill);}
const duel=kind!=='solo';r.game.begin(true,false,duel);if(duel){r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});for(let n=0;n<200&&!r.qa.duel.active;n++)step();assert(r.qa.duel.active,'Duel countdown exceeded bound');r.game.data.duelBot.position.set(kind==='bot'?-18:18,1.7,kind==='bot'?-25:-20);}
if(kind==='solo'){r.game.aim(850,0);key('KeyQ');for(let i=0;i<180;i++){if(i===18)key('KeyV');if(i===45)key('Space');if(i===75)key('KeyV');if(i===90){r.game.pause();step(true);r.game.resume();r.setDelta(0);step(true);r.setDelta(1/60);}step(i%15===0||!!r.qa.hook);}assert(!r.qa.hook);}
else{
 const skills=kind==='bot'?r.game.data.duel.getSkills('bot'):r.game.data.skills;assert(skills.castW());r.key('KeyW');
 for(let i=0;i<420;i++){
  if(i===15)assert(skills.castE());if(i===30)key('Space');if(i===75)assert(skills.strikeE());if(i===105)r.release('KeyW');if(i===180)assert(skills.castR());if(i===260){if(kind==='bot')assert(r.game.data.duel.cast('bot'));else key('KeyQ');}if(i===275)key('KeyV');if(i===315)key('KeyV');if(i===360){r.game.pause();step(true);r.game.resume();}
  step(i%30===0||!!r.qa.hook||!!r.qa.duel.bot.hook);
 }
 for(const name of ['W_Loop','E_Charge','E_Hold','E_Strike','R_Cast'])assert(seen.has(name),'Missing '+name);
}
r.game.begin(true,false,duel);step(true);console.log(JSON.stringify({kind,frames,seen:[...seen],final:r.hash(),firstComposes}));
