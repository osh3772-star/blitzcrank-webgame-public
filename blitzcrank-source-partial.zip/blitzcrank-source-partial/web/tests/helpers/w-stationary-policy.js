import {normalizeRForWPresentation} from './r-locomotion-policy.js';
// Test-only adaptation: compare the historical unconditional final-pose call
// against the guarded current call under the SAME later W presentation policy.
// Frozen source bytes and every numeric/flag/trace assertion remain unchanged.
const declaration='const applyBodySkill=createFullbodyPoseApplicator(THREE),skillMetrics={powerHits:0,discharges:0,pulseHits:0};';
const initialize=' applyEWalkLayer=createFullbodyELocomotionLayer(THREE,{body:fullbody,nodes:fullbodyNodes,surfaces:fullbodySurfaces,locomotion});';
const apply=" const skill=visibleSkillAnimation();if(skill){applyBodySkill(skillClips.fullbody[skill.name],skill.time,fullbodySurfaces);if(skill.name.startsWith('E_'))applyEWalkLayer();bodySkillActive=true;updateFullbodyHand();return;}";
const sites=[
 [declaration,'let applyWStationaryLayer;\n'+declaration],
 [initialize,' applyWStationaryLayer=createFullbodyWStationaryLayer(THREE,{body:fullbody,nodes:fullbodyNodes,surfaces:fullbodySurfaces,locomotion});\n'+initialize],
 [apply,apply.replace('bodySkillActive=true;',"if(skill.name.startsWith('W_'))applyWStationaryLayer();bodySkillActive=true;")]
];
const count=(source,site)=>source.split(site).length-1;
export function stationaryWPresentationPolicy(source){
 source=normalizeRForWPresentation(source);
 const imports=[...source.matchAll(/^import \{createFullbodyWStationaryLayer\} from '(\.\/w-stationary-layer\.js(?:\?v=\d+\.\d+\.\d+)?)';$/gm)];
 if(!/createFullbodyWStationaryLayer|applyWStationaryLayer|w-stationary-layer\.js/.test(source)){
  for(const [before]of sites)if(count(source,before)!==1)throw Error('Unknown historical W presentation site');
  return {enabled:false,importSite:null};
 }
 if(imports.length!==1||count(source,'createFullbodyWStationaryLayer')!==2||count(source,'applyWStationaryLayer')!==3||count(source,'w-stationary-layer.js')!==1)throw Error('Unknown current W presentation policy');
 for(const [,after]of sites)if(count(source,after)!==1)throw Error('Unknown current W presentation site');
 return {enabled:true,importSite:imports[0][0]};
}
export function adaptHistoricalWPresentation(source,current){
 const target=stationaryWPresentationPolicy(current),before=stationaryWPresentationPolicy(source);
 if(before.enabled)throw Error('Historical W presentation already adapted');
 if(!target.enabled)return source;
 const firstImport='import {planDuelPullPath,sampleDuelPullPath}';
 if(!source.startsWith(firstImport)||count(source,firstImport)!==1)throw Error('Unknown historical first import');
 source=source.replace(firstImport,target.importSite+'\n'+firstImport);
 for(const [before,after]of sites){if(count(source,before)!==1)throw Error('Ambiguous historical W presentation site');source=source.replace(before,after);}
 const after=stationaryWPresentationPolicy(source);
 if(!after.enabled||after.importSite!==target.importSite)throw Error('Historical W presentation adaptation failed');
 return source;
}
