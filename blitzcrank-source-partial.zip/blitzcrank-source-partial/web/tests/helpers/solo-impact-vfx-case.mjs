import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

// One real main.js and Three.js scene graph per child process. Only the existing
// CPU harness supplies DOM/render stubs and a variable simulation frame delta.
const [appRoot, rawHz, suppliedSource, expectation = 'corrected'] = process.argv.slice(2);
const hz = Number(rawHz), nominalDt = 1 / hz;
assert([20, 60, 120].includes(hz));
assert(['baseline', 'corrected'].includes(expectation));
const {createGameplayHarness} = await import(pathToFileURL(path.join(appRoot, 'tests/helpers/runtime-harness.js')));
const storage = {data: new Map(), writes: [], getItem(key) {return this.data.get(key) ?? null;}, setItem(key,value) {this.data.set(key,value);this.writes.push([key,value]);}};
let dt = nominalDt;
const h = await createGameplayHarness({sourcePath: suppliedSource || path.join(appRoot,'main.js'), delta: () => dt, storage});
const hash = crypto.createHash('sha256'), observations = [], lifecycle = [];
let sampledFrames = 0;
const near = (actual, expected, label, tolerance = 1e-8) => assert(Math.abs(actual-expected) <= tolerance, `${label}: expected ${expected}, got ${actual}`);
function authority() {
 const {vfx, effects, ...skills} = h.qa.skills;
 return {state:h.qa.state,session:h.qa.session,health:h.qa.health,player:h.qa.player,skills,
   targets:h.game.data.targets.map(t=>({active:t.active,captured:t.captured,visible:t.group.visible,position:t.group.position.toArray(),respawn:t.respawn,knockup:t.knockup?{time:t.knockup.time,origin:t.knockup.origin.toArray()}:null,comboHold:t.comboHold?.toArray()??null})),
   combo:h.qa.comboPractice,records:h.qa.records,flash:h.qa.flashAbility,hook:h.qa.hook,
   cooldowns:[h.game.data.shotCooldown,h.game.data.punchCooldown],duel:h.game.data.duel?.state??null,storage:[...storage.data.entries()],writes:storage.writes};
}
function frame(count=1) {for(let n=0;n<count;n++){h.frames(1);hash.update(JSON.stringify(authority()));sampledFrames++;}}
function until(predicate, label, limit=hz*4) {for(let n=0;n<limit&&!predicate();n++)frame();assert(predicate(),label);}
function assertClear(label) {
 const v=h.qa.skills.vfx;
 assert.equal(v.fieldVisible,false,label+' field');assert.equal(v.fieldAge,null,label+' field age');
 assert.equal(v.impactVisible,false,label+' impact');assert.equal(v.targets,0,label+' coronas');
}
function begin(mode='free') {
 dt=nominalDt;h.game.begin(mode!=='challenge',mode==='combo');assertClear('fresh '+mode);
 assert.equal(h.qa.session.score,0);assert.equal(h.qa.skills.animation,null);
 for(const t of h.game.data.targets){t.active=t.group.visible=false;t.captured=false;t.respawn=Infinity;}
}
function place(index=0,distance=2) {
 const d=h.game.data,t=d.targets[index];t.anchor.set(d.player.x,1.7,d.player.z-distance);t.group.position.copy(t.anchor);
 t.amplitude=t.speed=t.phase=0;t.knockup=null;t.comboHold=null;t.active=t.group.visible=true;t.captured=false;t.respawn=0;return t;
}
function startE() {h.key('KeyE');until(()=>h.qa.skills.phase==='E_Hold','E must charge');h.punch();assert.equal(h.qa.skills.phase,'E_Strike');}
function spriteOpacity(skill) {
 const scene=h.game.data.scene;
 if(skill==='E')return scene.getObjectByName('E_reference_warm_contact_flash').children.find(o=>o.isSprite).material.opacity;
 const target=scene.getObjectByName('R_target_violet_coronas').children.find(o=>o.name==='R_target_corona'&&o.visible);
 assert(target,'R target corona must be visible');return target.children.filter(o=>o.isSprite)[1].material.opacity;
}
function checkAge(skill,age,label) {
 const lifetime=skill==='E'?.24:.65,power=skill==='E'?1.4:1.5;
 near(spriteOpacity(skill),Math.pow(1-age/lifetime,power),label+' opacity');
 if(skill==='E')assert(h.qa.skills.vfx.impactVisible,label+' E flash visible');
 else {assert(h.qa.skills.vfx.fieldVisible,label+' R field visible');near(h.qa.skills.vfx.fieldAge,age,label+' R field age');}
}
function observe(skill,mode,scenario) {
 const impact=skill==='E'?.4:.3,metric=skill==='E'?'powerHits':'discharges';
 const previous=h.qa.skills.metrics[metric];
 if(scenario==='fractional') {
  const targetTime=impact-nominalDt*.4;
  while(h.qa.skills.animation.time+nominalDt<targetTime-1e-9)frame();
  dt=targetTime-h.qa.skills.animation.time;assert(dt>0&&dt<=nominalDt);frame();dt=nominalDt;
  assert.equal(h.qa.skills.metrics[metric],previous,'no early event before authored time');
 }
 let before,frames=0;
 while(h.qa.skills.metrics[metric]===previous&&frames++<hz*2){before=h.qa.skills.animation;frame();}
 assert.equal(h.qa.skills.metrics[metric],previous+1,skill+' impact exactly once');
 let offset=impact-before.time;if(Math.abs(offset-dt)<1e-9)offset=dt;
 assert(offset>=0&&offset<=dt+1e-9,'authored impact is inside event frame');
 const correctAge=Math.max(0,dt-offset),actualAge=expectation==='corrected'?correctAge:dt;
 checkAge(skill,actualAge,`${mode}/${scenario} ${skill}`);
 const target=h.game.data.targets[0];
 const observation={mode,scenario,skill,dt,offset,expectedAge:correctAge,actualAge,opacity:spriteOpacity(skill),score:h.qa.session.score,combo:h.qa.comboPractice.last};
 if(skill==='E') {
  // Knockup is an existing gameplay-position clock, intentionally untouched by
  // the VFX-only correction. Its offset is recorded, not changed by this test.
  near(target.knockup.time,dt,'unchanged target knockup time');
  observation.knockupAge=target.knockup.time;observation.knockupRise=target.group.position.y-target.knockup.origin.y;
  near(observation.knockupRise,Math.sin(dt/1.1*Math.PI)*2.2,'unchanged target knockup height');
 }
 observations.push(observation);
 const frozenAuthority=authority(),frozenVfx=h.qa.skills.vfx,frozenOpacity=spriteOpacity(skill);
 h.game.pause();const paused=authority();frame(3);assert.deepEqual(authority(),paused,'pause freezes all authority');assert.deepEqual(h.qa.skills.vfx,frozenVfx,'pause freezes all VFX');near(spriteOpacity(skill),frozenOpacity,'pause freezes opacity');
 h.game.resume();assert.deepEqual(authority(),frozenAuthority,'resume preserves prior state');frame();checkAge(skill,actualAge+nominalDt,'resumed '+skill);
 return observation;
}
for(const mode of ['free','challenge','combo'])for(const scenario of ['boundary','fractional']) {
 begin(mode);place();startE();observe('E',mode,scenario);
 assert.equal(h.qa.session.score,80);assert.equal(h.qa.skills.metrics.powerHits,1);
 until(()=>!h.qa.skills.phase,'E strike completes');
 if(mode!=='combo')place(1,4);
 h.key('KeyR');assert.equal(h.qa.skills.phase,'R_Cast');observe('R',mode,scenario);
 assert.equal(h.qa.session.score,140,'unchanged E/R point totals');assert.equal(h.qa.skills.metrics.pulseHits,1);
 if(mode==='combo'){assert.equal(h.qa.comboPractice.successes,1);assert.equal(h.qa.comboPractice.last.route,'er');assert(h.qa.records.comboER.best<=h.qa.comboPractice.best,'stored combo record retains fastest actual attempt');}
 // The full tails expire normally, and a fresh same-mode start clears all age.
 frame(Math.ceil(hz*1.1));assert.equal(h.qa.skills.vfx.fieldVisible,false);assert.equal(h.qa.skills.vfx.impactVisible,false);assert.equal(h.qa.skills.vfx.targets,0);
 begin(mode);frame();assertClear('restart '+mode);
}
lifecycle.push('free/challenge/combo boundary and fractional impacts; E→R scores; combo records; pause/resume; expiry; same-mode restart');

// Cancellation before the authored event must never create stale VFX later.
begin();place();startE();frame(Math.floor(hz*.2));h.game.pause();h.element('mainmenu').click();assert.equal(h.qa.state,'menu');frame(4);assertClear('menu cancel');
begin();frame(hz);assertClear('menu restart');assert.equal(h.qa.session.score,0);assert.equal(h.qa.skills.metrics.powerHits,0);
begin();place();h.key('KeyR');frame(Math.floor(hz*.1));h.game.damagePlayer(100);assert.equal(h.qa.state,'results');frame(4);assertClear('death cancel');begin();frame(hz);assertClear('death restart');
begin('challenge');place();h.key('KeyR');h.game.setElapsed(89.99);dt=.05;frame();assert.equal(h.qa.state,'results');assertClear('challenge timeout');assert.equal(h.qa.session.score,0);
lifecycle.push('pending E canceled by menu; pending R canceled by death/90-second timeout; clean restart');

// Context loss freezes a newly created field. Restoration/resume cannot replay
// the consumed impact offset or skip another frame.
begin();place(0,4);h.key('KeyR');const contextImpact=observe('R','free','boundary');
const frozen=h.qa.skills.vfx,op=spriteOpacity('R');h.element('game').listeners.webglcontextlost({preventDefault(){}});frame(4);assert.deepEqual(h.qa.skills.vfx,frozen);near(spriteOpacity('R'),op,'context loss opacity');
h.element('game').listeners.webglcontextrestored();h.game.resume();frame();checkAge('R',contextImpact.actualAge+2*nominalDt,'context restored');lifecycle.push('WebGL context pause/restoration');

// Solo → duel → solo reuses the player VFX object. Duel must keep the already
// corrected authority offset and cannot leak points into the solo score.
h.element('duelmode').click();h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});assertClear('enter duel');
until(()=>h.game.data.duel.active,'duel countdown');h.game.data.duelBot.position.set(0,1.7,5);h.key('KeyR');until(()=>h.game.data.duel.state.history.length===1,'duel impact');
checkAge('R',0,'duel boundary remains corrected');assert.deepEqual(h.game.data.duel.state.scores.map(s=>s.points),[1,0]);assert.equal(h.qa.session.score,0);
begin('combo');place();startE();observe('E','combo-after-duel','boundary');assert.equal(h.qa.session.score,80);assert.equal(h.qa.duel,null);lifecycle.push('solo → duel → combo VFX isolation and unchanged duel scoring');

console.log(JSON.stringify({hz,expectation,harnesses:1,sampledFrames,authoritativeHash:hash.digest('hex'),observations,lifecycle,storage:[...storage.data.entries()],writes:storage.writes}));
