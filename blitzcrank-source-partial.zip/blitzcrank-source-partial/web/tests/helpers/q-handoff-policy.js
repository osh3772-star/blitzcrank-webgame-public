// Align this later, narrow presentation correction on both sides of historical
// E/W comparisons. Do not alter gameplay clocks, frozen fixtures or snapshots.
export const qOldHandoff="if(h.phase==='recover'){if(h.phaseTime>=.26){hook=null;oneShot=0;clipName='Idle';clipTime=0;applyAnimation(0);updateHud();}return;}";
export const qNewHandoff="if(h.phase==='recover'){if(h.phaseTime>=.26){hook=null;oneShot=0;clipName='Idle';clipTime=0;applyAnimation(0);animateFullbody(0,false);updateHud();}return;}";
const count=(s,x)=>s.split(x).length-1;
export function qHandoffPolicy(source){
 const start='function advanceHook(dt){',end='\nfunction syncHookVisuals(){';
 if(count(source,start)!==1||count(source,end)!==1||source.indexOf(start)>=source.indexOf(end))throw Error('Unknown Q handoff function bounds');
 const region=source.slice(source.indexOf(start),source.indexOf(end)),matches=[qOldHandoff,qNewHandoff].filter(s=>count(region,s)===1&&count(source,s)===1);
 if(matches.length!==1||count(region,"if(h.phase==='recover')")!==1)throw Error('Unknown Q handoff policy');
 return {enabled:matches[0]===qNewHandoff,clause:matches[0]};
}
export function adaptHistoricalQHandoff(source,current){
 const before=qHandoffPolicy(source),target=qHandoffPolicy(current);if(before.enabled)throw Error('Historical Q handoff already adapted');
 return target.enabled?source.replace(qOldHandoff,qNewHandoff):source;
}
