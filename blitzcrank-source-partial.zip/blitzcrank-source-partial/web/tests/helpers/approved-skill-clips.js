import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {SKILL_ASSET} from '../../skill-animation-manifest.js';
// Approved slow-W companion: seven authored clips remain byte-equivalent;
// only the separately named W_Loop_Slow retimes the original W_Loop frames.
const bytes=fs.readFileSync(new URL('../../'+SKILL_ASSET.raw,import.meta.url));
assert.equal(createHash('sha256').update(bytes).digest('hex'),'403e90667511be4b3ed7aa7d09423223059c9b0d200b8104d652f4e06e7498ce');
const current=JSON.parse(bytes),original=JSON.parse(fs.readFileSync(new URL('../../assets/skill-animations/skills.9b293d06ddb21614.json',import.meta.url)));
export const APPROVED_CLIPS=Object.freeze([
 ['W_Start',9,30],['W_Loop',14,30],['W_End',21,30],['E_Charge',27,30],
 ['E_Hold',25,30],['E_Strike',45,30],['R_Cast',35,30],['W_Loop_Slow',14,19.5],
]);
export function assertApprovedSkillClips(clips){
 const list=Array.isArray(clips)?clips:Object.values(clips);
 assert.deepEqual(list.map(c=>[c.name,c.frames.length,c.fps]),APPROVED_CLIPS);
 for(const c of list)assert.equal(c.duration,(c.frames.length-1)/c.fps);
}
for(const name of ['fullbody','viewmodel']){
 const clips=current.models[name].clips;assertApprovedSkillClips(clips);
 assert.deepEqual(clips.slice(0,7),original.models[name].clips);
 assert.deepEqual(clips[7].frames,clips[1].frames);
}
export const AUTHORED_MIDPOINT_COUNT=APPROVED_CLIPS.reduce((n,[,frames])=>n+2*frames-1,0);
export const POSE_BOUNDARY_REPLAY_COUNT=APPROVED_CLIPS.reduce((n,[,frames])=>n+2*frames+8,0);
