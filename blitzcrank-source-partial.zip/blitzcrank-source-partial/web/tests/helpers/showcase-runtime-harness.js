import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createGameplayHarness} from './runtime-harness.js';
export async function createShowcaseHarness(){
 const source=fs.readFileSync(new URL('../../main.js',import.meta.url),'utf8')+'\nglobalThis.__SHOWCASE_TEST__={showcase,showcaseScene,showcaseCamera};';
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'showcase-harness-')),file=path.join(dir,'main.mjs');fs.writeFileSync(file,source);
 let h;try{h=await createGameplayHarness({sourcePath:file});}finally{fs.unlinkSync(file);fs.rmdirSync(dir);}
 return {...h,...globalThis.__SHOWCASE_TEST__,THREE:globalThis.__RUNTIME_HARNESS_THREE__};
}
export function snapshot(root){const rows=[];root.traverse(o=>rows.push({name:o.name,type:o.type,position:o.position.toArray(),rotation:o.rotation.toArray(),quaternion:o.quaternion.toArray(),scale:o.scale.toArray(),local:o.matrix.toArray(),world:o.matrixWorld.toArray(),visible:o.visible,dirty:o.matrixWorldNeedsUpdate}));return rows;}
