import {duelAvatarCreatePolicy,setDuelAvatarCreatePolicy} from './duel-avatar-create-policy.js';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import assert from 'node:assert/strict';
import {createGameplayHarness} from './runtime-harness.js';import {poseStateDigest} from './duel-human-pose-harness.js';
const mutable=name=>name.startsWith('BC_Pivot_')||name.startsWith('BC_QLaunch')||name==='BC_Knee.L'||name==='BC_Knee.R';
export function staticRigBaselineSource(source){
 assert.equal(duelAvatarCreatePolicy(source).staticRestMatrices,true,'Expected current static-rig opt-in');
 source=setDuelAvatarCreatePolicy(source,{staticRestMatrices:false});
 for(const [a,b]of [
  ['import {createDuelAvatarFactory,cacheStaticFullbodyNodeMatrices}', 'import {createDuelAvatarFactory}'],
  ['\n cacheStaticFullbodyNodeMatrices(fullbodyNodes);','']
 ]){assert.equal(source.split(a).length,2,'Expected one opt-in site: '+a);source=source.replace(a,b);}return source;
}
export async function createStaticRigRuntime({baseline=false,dt=1/60}={}){
 let source=fs.readFileSync(new URL('../../main.js',import.meta.url),'utf8');if(baseline)source=staticRigBaselineSource(source);
 source=source.replaceAll('performance.now()','globalThis.__STATIC_RIG_CLOCK__ * 1000');globalThis.__STATIC_RIG_CLOCK__=0;
 source+='\nwindow.__STATIC_RIG_EXPOSE__={prepareMirrorBody,restoreMirrorBody,get pose(){return{socket:fullbodySocket.toArray(),clipName,clipTime,oneShot,bodySkillActive}},get nodeNames(){return [...fullbodyNodes.keys()]},get roots(){return[fullbody,viewmodel,fist,rope,duelAvatar.object,duelRope]}};';
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'static-rig-')),file=path.join(dir,'main.mjs');fs.writeFileSync(file,source);let h;try{h=await createGameplayHarness({sourcePath:file,delta:()=>{globalThis.__STATIC_RIG_CLOCK__+=dt;return dt;}});}finally{fs.unlinkSync(file);fs.rmdirSync(dir);}
 // v76 deferred unrelated child refreshes until Three's normal render boundary.
 // Model that boundary on both sides; retain every state/flag and count assertion.
 globalThis.__RUNTIME_HARNESS_THREE__.WebGLRenderer.prototype.render=function(scene,camera){if(scene.matrixWorldAutoUpdate===true)scene.updateMatrixWorld();if(camera.parent===null&&camera.matrixWorldAutoUpdate===true)camera.updateMatrixWorld();};
 const exposed=globalThis.__STATIC_RIG_EXPOSE__,staticNames=new Set(exposed.nodeNames.filter(n=>!mutable(n))),collect=()=>exposed.roots.map(root=>{const a=[];root.traverse(o=>a.push(o));return a;}),initialBotNodes=collect()[4].length;
 const collectCurrent=()=>{const nodes=collect();if(h.qa.duel)assert(nodes[4].length>=initialBotNodes+8,'Late bot effects must be captured');return nodes;};
 const snapshot=()=>({state:h.qa.state,view:h.qa.view,duel:h.qa.duel,session:h.qa.session,health:h.qa.health,player:h.qa.player,skills:h.qa.skills,motion:h.qa.motion,pose:exposed.pose,chains:[h.game.data.rope,h.game.data.duelRope].map(o=>({visible:o.visible,start:o.userData.start.toArray(),end:o.userData.end.toArray(),count:o.userData.linkCount,length:o.userData.length,arcLength:o.userData.arcLength,sag:o.userData.sag,matrices:o.links.instanceMatrix.array,version:o.links.instanceMatrix.version})),roots:collectCurrent().map((list,index)=>list.map(o=>{
  const cached=(index===0||index===4)&&o.isGroup&&staticNames.has(o.name);if(cached){assert.equal(o.matrixAutoUpdate,baseline);assert(o.matrixWorldAutoUpdate);}
  return[o.name,o.visible,o.position.toArray(),o.quaternion.toArray(),o.rotation.toArray(),o.scale.toArray(),o.matrix.toArray(),o.matrixWorld.toArray(),cached?'intentional static local mode':o.matrixAutoUpdate,o.matrixWorldAutoUpdate,cached?'intentional static dirty flag':o.matrixWorldNeedsUpdate];
 })),botSockets:h.qa.duel?h.game.data.duelAvatar.getSockets():null});
 return {...h,pose:exposed,THREE:globalThis.__RUNTIME_HARNESS_THREE__,setDelta(value){dt=value;},snapshot,hash:()=>poseStateDigest(snapshot())};
}
