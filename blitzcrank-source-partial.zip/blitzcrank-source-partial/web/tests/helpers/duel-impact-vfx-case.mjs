import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

// One real main.js/Three.js runtime per process. Rendering and the DOM are the
// existing CPU harness stubs. No game source, clocks, or hit results are patched.
const [appRoot, rawHz, skill, winner, scenario = 'boundary'] = process.argv.slice(2);
assert(appRoot && ['E', 'R'].includes(skill) && ['human', 'bot'].includes(winner));
const hz = Number(rawHz), nominalDt = 1 / hz;
assert([20, 60, 120].includes(hz));
const {createGameplayHarness} = await import(pathToFileURL(path.join(appRoot, 'tests/helpers/runtime-harness.js')));
let dt = nominalDt;
const r = await createGameplayHarness({delta: () => dt});
r.element('duelmode').click();
r.game.setBotCommandSource({reset() {}, step: () => ({move: {x: 0, z: 0}, yaw: Math.PI, pitch: 0, castQ: false, castE: false, strikeE: false, castR: false})});
const d = r.game.data;
const near = (actual, expected, label, eps = 1e-9) => assert(Math.abs(actual - expected) <= eps, `${label}: expected ${expected}, got ${actual}`);
function until(predicate, label, limit = hz * 3) {
  for (let frame = 0; frame < limit && !predicate(); frame++) r.frames(1);
  assert(predicate(), label);
}
until(() => d.duel.active, 'initial countdown must finish');
let observed = null;
const drain = d.duel.drainEvents;
d.duel.drainEvents = function () {
  const events = drain();
  for (const event of events) if (event.type === 'skill-impact' && event.playerId === winner) observed = event;
  return events;
};
const currentVfx = () => winner === 'human' ? r.qa.skills.vfx : r.qa.duel.bot.vfx;
const effectIndex = winner === 'human' ? 0 : 1;
const effectRoot = name => d.scene.children.filter(object => object.name === name)[effectIndex];
function checkEffectAge(age, label) {
  if (skill === 'E') {
    const flash = effectRoot('E_reference_warm_contact_flash');
    assert(flash?.visible, `${label}: E contact flash must be visible`);
    const opacity = flash.children.find(object => object.isSprite).material.opacity;
    near(opacity, Math.pow(1 - age / .24, 1.4), `${label}: E opacity follows authoritative impact age`);
  } else {
    const vfx = currentVfx();
    assert(vfx.fieldVisible, `${label}: R field must be visible`);
    near(vfx.fieldAge, age, `${label}: R age follows authoritative impact age`);
    const corona = effectRoot('R_target_violet_coronas').children.find(object => object.name === 'R_target_corona' && object.visible);
    assert(corona, `${label}: R contact corona must be visible`);
    const core = corona.children.filter(object => object.isSprite)[1];
    near(core.material.opacity, Math.pow(1 - age / .65, 1.5), `${label}: R target opacity follows authoritative impact age`);
  }
}
function castAndObserve() {
  observed = null;
  dt = nominalDt;
  d.duelBot.position.set(0, 1.7, 5);
  if (skill === 'E') {
    if (winner === 'human') r.key('KeyE');
    else assert(d.duel.getSkills(winner).castE());
    until(() => d.duel.getSkills(winner).status.phase === 'E_Hold', 'E must finish charging');
    if (winner === 'human') r.punch();
    else assert(d.duel.getSkills(winner).strikeE());
  } else {
    if (winner === 'human') r.key('KeyR');
    else assert(d.duel.getSkills(winner).castR());
  }
  if (scenario === 'fractional') {
    assert.equal(hz, 20);
    r.frames(skill === 'E' ? 7 : 5);
    dt = .03; r.frames(1);
    assert.equal(observed, null, 'no early effect/score before the authored impact');
    dt = .05; r.frames(1);
    assert(observed, 'impact falls inside the final 50 ms frame');
    near(observed.offset, .02, 'partial-frame impact offset');
  } else {
    until(() => observed !== null, 'authored impact event must arrive');
    near(observed.offset, nominalDt, 'exact-boundary impact offset');
  }
  assert.equal(observed.hit, true, 'actual authority geometry must hit');
  assert.equal(observed.skill, skill);
  const age = Math.max(0, dt - observed.offset);
  checkEffectAge(age, 'first presented frame');
  return age;
}
const firstAge = castAndObserve();
assert.deepEqual(d.duel.state.scores.map(score => score.points), winner === 'human' ? [1, 0] : [0, 1]);
assert.equal(d.duel.state.history.length, 1);
assert.equal(d.duel.state.history[0].winnerId, winner);
assert.equal(d.duel.state.phase, 'roundReset');
assert.equal(d.duel.state.remainingMs, 3000);
assert.equal(r.qa.session.score, 0, 'duel hit cannot leak into solo score');

// Pause must not consume an extra effect step or change the scoring/reset clock.
r.game.pause();
const frozenVfx = structuredClone(currentVfx()), frozenMatch = d.duel.state;
r.frames(5);
assert.deepEqual(currentVfx(), frozenVfx);
assert.deepEqual(d.duel.state, frozenMatch);
checkEffectAge(firstAge, 'paused frame');
r.game.resume();
dt = nominalDt; r.frames(1);
checkEffectAge(firstAge + nominalDt, 'first resumed frame');
near(d.duel.state.remainingMs, 3000 - nominalDt * 1000, 'resume reset timer');

// Hold all effect lifetimes and reset timing to the unchanged three-second rule.
r.frames(hz * 3 - 2);
assert.equal(d.duel.state.phase, 'roundReset');
assert.equal(d.duel.state.roundNumber, 1);
near(d.duel.state.remainingMs, nominalDt * 1000, 'one remaining frame before reset', 1e-7);
r.frames(1);
assert.equal(d.duel.state.phase, 'countdown');
assert.equal(d.duel.state.roundNumber, 2);
assert.equal(d.duel.state.history.length, 1);
assert.equal(currentVfx().fieldAge, null, 'round reset must clear the old R field age');
assert.equal(currentVfx().fieldVisible, false);
assert.equal(currentVfx().impactVisible, false);
assert.equal(currentVfx().targets, 0);

// Reuse this one harness in the next round: the old event offset must not leak.
until(() => d.duel.active, 'next countdown must finish');
const secondAge = castAndObserve();
near(secondAge, firstAge, 'repeat impact starts with the same fresh age');
assert.equal(d.duel.state.history.length, 2);
assert.deepEqual(d.duel.state.scores.map(score => score.points), winner === 'human' ? [2, 0] : [0, 2]);
assert.equal(d.duel.state.remainingMs, 3000);
assert.equal(r.qa.session.score, 0);
console.log(JSON.stringify({hz, skill, winner, scenario, firstAge, secondAge, points: d.duel.state.scores.map(score => score.points), pauseFrozen: true, resetAfterSeconds: 3, harnesses: 1}));
