import assert from 'node:assert/strict';
import fs from 'node:fs';
import {rig,THREE} from './locomotion-rig.js';
import {bindSkillClips,createFullbodyPoseApplicator,clearFullbodySkillPose} from '../../skill-animation.js';
import {SKILL_ASSET} from '../../skill-animation-manifest.js';

// Integration oracle: two independent decoded rigs, accepted movement inputs,
// and direct model-space endpoint composition. It never calls the production
// E/R layer or main.animateFullbody, reads actual mesh transforms for expected
// values, or imports the production recovery-weight function.
export function createRRuntimeOracle(){
 const authored=rig(),gait=rig(),surfaces=[...authored.meshes.values()];
 const model=JSON.parse(fs.readFileSync(new URL('../../'+SKILL_ASSET.raw,import.meta.url))).models.fullbody;
 const clips=Object.fromEntries(bindSkillClips(model,surfaces).map(c=>[c.name,c]));
 const gaitClips=Object.fromEntries(bindSkillClips(model,[...gait.meshes.values()]).map(c=>[c.name,c]));
 const apply=createFullbodyPoseApplicator(THREE),duration=clips.R_Cast.duration;
 authored.body.updateMatrixWorld(true);
 const anchors=new Map();
 for(const side of ['L','R']){
  for(const name of ['BC_Pivot_Hip.','BC_Pivot_Ankle.']){
   const node=authored.nodes.get(name+side);anchors.set(node,authored.body.worldToLocal(node.getWorldPosition(new THREE.Vector3())));
  }
  const knee=authored.nodes.get('BC_Knee.'+side),mesh=authored.meshes.get('BC_Knee.'+side);
  anchors.set(knee,authored.body.worldToLocal(mesh.localToWorld(mesh.geometry.boundingBox.getCenter(new THREE.Vector3()))));
 }
 const lower=new Map();
 for(const [name,mesh] of authored.meshes){
  let isLower=false;for(let n=mesh;n;n=n.parent){if(n===authored.nodes.get('BC_Torso'))break;if(n===authored.nodes.get('BC_Pelvis')){isLower=true;break;}}
  if(!isLower)continue;
  const pivot=new THREE.Vector3();for(let n=mesh.parent;n&&n!==authored.nodes.get('BC_Pelvis');n=n.parent)if(anchors.has(n)){pivot.copy(anchors.get(n)).sub(new THREE.Vector3(...mesh.userData.skillRestPoint));break;}
  lower.set(name,pivot);
 }
 let vertical=0,height=0,castFrames=null,checked=0,upperAuthored=0,recovery=0,exit=0;
 function reset(){gait.motion.reset();authored.motion.reset();vertical=height=0;castFrames=null;}
 function jump(){assert.equal(height,0);vertical=7;}
 function cast(){castFrames=0;}
 function step(h){
  const before={...h.qa.player};h.frames(1);
  vertical-=20/60;height+=vertical/60;if(height<=0){height=0;vertical=0;}
  const after=h.qa.player;assert(Math.abs(after.y-1.7-height)<1e-12,'independent vertical integration');
  gait.motion.advance(1/60,{deltaX:after.x-before.x,deltaZ:after.z-before.z,yaw:after.yaw,grounded:height===0,height:after.y-1.7,velocityY:vertical});
  if(castFrames!==null)castFrames++;
 }
 function check(h,label){
  const time=castFrames/60,active=castFrames!==null&&time<duration-1e-12;
  assert.equal(h.qa.skills.phase,active?'R_Cast':null,label+' phase');
  const player=h.qa.player;
  for(const r of [authored,gait]){r.motion.restorePose();clearFullbodySkillPose([...r.meshes.values()]);r.body.position.set(player.x,player.y-1.7,player.z);r.body.rotation.set(0,player.yaw+Math.PI,0);}
  let weight=0,offset=0;
  if(active){
   apply(clips.R_Cast,time,surfaces);apply(gaitClips.R_Cast,time,[...gait.meshes.values()]);
   const u=Math.max(0,Math.min(1,(time-.7)/(duration-.7)));weight=u*u*(3-2*u);
   if(gait.motion.poseBlend)offset=gait.motion.applyPose({armSwing:weight>0,armSwingWeight:weight});
   if(weight>0)recovery++;else upperAuthored++;
  }else{offset=gait.motion.applyPose();exit++;}
  gait.body.position.y+=offset;authored.body.updateMatrixWorld(true);gait.body.updateMatrixWorld(true);
  const invA=authored.body.matrixWorld.clone().invert(),invG=gait.body.matrixWorld.clone().invert(),blend=gait.motion.poseBlend;
  for(const [name,mesh] of gait.meshes){
   let expected=mesh.matrixWorld.clone();
   if(active&&blend&&lower.has(name)){
    const pivot=lower.get(name),a=invA.clone().multiply(authored.meshes.get(name).matrixWorld),b=invG.clone().multiply(mesh.parent.matrixWorld);
    const ap=new THREE.Vector3(),aq=new THREE.Quaternion(),as=new THREE.Vector3(),bp=new THREE.Vector3(),bq=new THREE.Quaternion(),bs=new THREE.Vector3();a.decompose(ap,aq,as);b.decompose(bp,bq,bs);
    const anchorA=pivot.clone().applyMatrix4(a);anchorA.y-=offset/gait.body.scale.y;
    const anchor=anchorA.lerp(pivot.clone().applyMatrix4(b),blend);
    // T(interpolated joint) * R(slerp) * S(lerp) * T(-local joint).
    const composed=new THREE.Matrix4().makeTranslation(anchor.x,anchor.y,anchor.z)
     .multiply(new THREE.Matrix4().makeRotationFromQuaternion(aq.slerp(bq,blend)))
     .multiply(new THREE.Matrix4().makeScale(...as.lerp(bs,blend).toArray()))
     .multiply(new THREE.Matrix4().makeTranslation(-pivot.x,-pivot.y,-pivot.z));
    expected=gait.body.matrixWorld.clone().multiply(composed);
   }
   const actual=h.game.data.fullbodyMeshes.get(name);actual.updateWorldMatrix(true,false);
   for(let k=0;k<16;k++)assert(Math.abs(actual.matrixWorld.elements[k]-expected.elements[k])<1e-10,`${label} ${name}[${k}] ${actual.matrixWorld.elements[k]} != ${expected.elements[k]}`);
   if(active&&!weight&&!lower.has(name)){
    const upper=authored.meshes.get(name).matrixWorld.clone();upper.elements[13]+=offset;
    for(let k=0;k<16;k++)assert(Math.abs(actual.matrixWorld.elements[k]-upper.elements[k])<1e-10,`${label} authored upper ${name}[${k}]`);
   }
  }
  checked++;
 }
 return{reset,jump,cast,step,check,summary:()=>({checked,upperAuthored,recovery,exit,surfaces:surfaces.length,duration})};
}
