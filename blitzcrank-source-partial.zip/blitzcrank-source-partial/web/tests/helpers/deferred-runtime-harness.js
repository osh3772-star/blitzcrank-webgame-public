import fs from 'node:fs';
import * as RealThree from '../../vendor/three.module.js';

let runtimeInstance=0;

// Executes the real game and Three.js scene graph without a GPU or browser DOM.
// Counts attempted DOM writes, not layout/paint cost or displayed frames.
export async function createRuntimeHarness({sourcePath=new URL('../../main.js',import.meta.url),storage={getItem:()=>null,setItem(){}},storageGetter=()=>storage,delta=()=>1/60,beforeAsset=async()=>{},coarse=false,rendererFailure=false}={}) {
 const metrics={writes:0,lookups:0,hudCalls:0},elements=new Map(),docListeners={},winListeners={};
 let callback;const requests=[];let captureRequests=0;
 class Classes {
  constructor(){this.s=new Set();}
  toggle(name,force){metrics.writes++;if(force===undefined)force=!this.s.has(name);force?this.s.add(name):this.s.delete(name);return force;}
  add(name){metrics.writes++;this.s.add(name);}
  remove(name){metrics.writes++;this.s.delete(name);}
 }
 const style=()=>new Proxy({},{set(object,key,value){metrics.writes++;object[key]=value;return true;}});
 class Element {
  constructor(){this.style=style();this.classList=new Classes();this.firstElementChild={style:style()};this.parentElement={classList:new Classes()};this.value='1';this.disabled=false;this.listeners={};this.attributes={};this.text='';this.html='';}
  get textContent(){return this.text;}
  set textContent(value){metrics.writes++;this.text=String(value);}
  get innerHTML(){return this.html;}
  set innerHTML(value){metrics.writes++;this.html=String(value);}
  addEventListener(name,fn){const previous=this.listeners[name];this.listeners[name]=event=>{previous?.(event);fn(event);};}
  setAttribute(name,value){metrics.writes++;this.attributes[name]=String(value);}
  querySelector(){return new Element();}
  getBoundingClientRect(){return{left:0,top:0,width:110,height:110};}
  setPointerCapture(id){(this.pointerCaptures??=new Set()).add(id);}hasPointerCapture(id){return this.pointerCaptures?.has(id)??false;}releasePointerCapture(id){this.pointerCaptures?.delete(id);}
  requestPointerLock(){captureRequests++;document.pointerLockElement=this;docListeners.pointerlockchange?.();return Promise.resolve();}
  click(){this.onclick?.();}
  getContext(){return{fillRect(){},fillText(){},fillStyle:'',textAlign:'',font:''};}
 }
 const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
 globalThis.document={getElementById:id=>{metrics.lookups++;return element(id);},querySelector:element,createElement:()=>new Element(),addEventListener:(name,fn)=>docListeners[name]=fn,pointerLockElement:null,exitPointerLock(){this.pointerLockElement=null;docListeners.pointerlockchange?.();}};
 Object.assign(globalThis,{window:globalThis,innerWidth:1280,innerHeight:720,devicePixelRatio:1,matchMedia:()=>({matches:coarse}),addEventListener:(name,fn)=>winListeners[name]=fn,requestAnimationFrame:fn=>{callback=fn;}});
 Object.defineProperty(globalThis,'localStorage',{configurable:true,get:storageGetter});
 globalThis.fetch=async path=>{requests.push({kind:'fetch',path,bytes:fs.statSync(new URL('../../'+path.replace('./',''),import.meta.url)).size});await beforeAsset(path);return{ok:true,arrayBuffer:async()=>{const bytes=fs.readFileSync(new URL('../../'+path.replace('./',''),import.meta.url));return bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);}};};
 class Renderer {constructor(){if(rendererFailure)throw Error('renderer fixture failure');this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}render(){}clearDepth(){}}
 class Clock {getDelta(){return delta();}}
 class TextureLoader {async loadAsync(path){requests.push({kind:'texture',path,bytes:fs.statSync(new URL('../../'+path.replace('./',''),import.meta.url)).size});await beforeAsset(path);if(!fs.existsSync(new URL('../../'+path.replace('./',''),import.meta.url)))throw Error('Missing texture: '+path);return new RealThree.Texture();}}
 globalThis.__RUNTIME_HARNESS_THREE__={...RealThree,WebGLRenderer:Renderer,Clock,TextureLoader};
 globalThis.__RUNTIME_HARNESS_METRICS__=metrics;
 let source=fs.readFileSync(sourcePath,'utf8').replace("import * as THREE from './vendor/three.module.js';",'const THREE=globalThis.__RUNTIME_HARNESS_THREE__;').replace(/from '\.\/([^']+)'/g,(_,path)=>`from '${new URL('../../'+path,import.meta.url).href}'`);
 source=source.replace('function updateHud(){','function updateHud(){globalThis.__RUNTIME_HARNESS_METRICS__.hudCalls++;');
 source+='\nwindow.__LOADING_TEST__={get pending(){return gameplayPending},get intent(){return pendingStart},get ready(){return loaded},warm:ensureGameplayAssets};';
 source+='\n// Harness instance '+(++runtimeInstance)+'\n';
 source+='\nwindow.__RUNTIME_HARNESS__={setBotCommandSource(source){duelBrain=source},updateHud,begin,pause,resume,finish,aim,damagePlayer,castW,castE,castR,castFlash,get data(){return{duel,duelBot,duelAvatar,duelRope,duelBrain,duelTarget,scene,keys,joystick,session,skills,targets,parts,fullbodyNodes,fullbodyMeshes,player,hook,shotCooldown,punchCooldown,health,obstacles,flashAbility,turretArena,camera,rope,fist,fullbody}},setElapsed(value){session.elapsed=value},setScore(value){session.score=value},setCombo(value){session.combo=value},setHealth(value){health=value},setCooldown(value){shotCooldown=value}};';
 await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
 return {requests,get captureRequests(){return captureRequests},loading:globalThis.__LOADING_TEST__,element,elements,metrics,game:globalThis.__RUNTIME_HARNESS__,qa:globalThis.__HOOK_ARENA__,frames(count){for(let i=0;i<count;i++)callback();},punch(){element('game').listeners.pointerdown({pointerType:'mouse',button:0,preventDefault(){}});},key(code){winListeners.keydown({code,repeat:false,preventDefault(){}});},release(code){winListeners.keyup({code});},dispatchKey(event){winListeners.keydown({repeat:false,preventDefault(){},...event});},docListeners,winListeners,resetMetrics(){for(const key of Object.keys(metrics))metrics[key]=0;}};
}
