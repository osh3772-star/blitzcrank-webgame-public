import assert from 'node:assert/strict';
import {createGameplayHarness} from './runtime-harness.js';
import {CONFIG} from '../../core.js';
export async function startSearch(hz=20, casts=false, skillMode=false){
 let dt=1/hz;
 const r=await createGameplayHarness({delta:()=>dt});
 r.element('duelmode').click();const d=r.game.data,brain=d.duelBrain,commands=[],observations=[];
 // Freeze this historical search fixture independently of randomized rounds.
 brain.reset({seed:23320});
 r.game.setBotCommandSource({reset:()=>brain.reset(),step:obs=>{// Keep the original Q-distance regression reproducible; separate traces
 // below enable the new skill approach policy. Both use actual movement.
 const sensed=skillMode?obs:{...obs,self:{...obs.self,skills:undefined}};const out=brain.step(sensed);commands.push(out);observations.push(obs);return casts?out:{...out,castQ:false,castE:false,strikeE:false,castR:false};}});
 r.frames(Math.round(1.65*hz));assert(d.duel.active);
 d.player.set(-6,1.7,-8);d.duelBot.position.set(0,1.7,-8);
 const covers=d.obstacles.filter(o=>!o.turretId&&!o.arenaSurface);
 let frame=0;
 function step(){
  const beforeBot=d.duelBot.position.clone(),beforeHuman=d.player.clone();r.frames(1);frame++;
  for(const [label,p,before] of [['bot',d.duelBot.position,beforeBot],['human',d.player,beforeHuman]]){
   assert(p.toArray().every(Number.isFinite),label+' position finite');
   assert(Math.hypot(p.x-before.x,p.z-before.z)<=CONFIG.playerSpeed*dt+1e-8,label+' speed unchanged');
   assert(Math.abs(p.x)<=23.4&&p.z>=-42.5&&p.z<=15.5,label+' arena bounds');
   for(const o of covers)assert(!(p.x>o.min.x-.42&&p.x<o.max.x+.42&&p.z>o.min.z-.42&&p.z<o.max.z+.42&&p.y-1.7<o.max.y),label+' cannot enter existing cover');
  }
  return brain.snapshot();
 }
 for(let n=0;n<Math.ceil(.5*hz);n++)step();
 assert(brain.snapshot().perceived,'warmup must perceive human');
 return {r,d,brain,step,commands,observations,hz,setDelta(value){dt=value;},get frame(){return frame;}};
}
export async function runSearch({hz=20,route=false,seconds=60,skillMode=false}={}){
 const s=await startSearch(hz,false,skillMode),{r,d,brain,step}=s,seen=brain.snapshot(),rows=[];
 let visibleFrames=0,freshUpdates=0,firstFreshSeconds=null,firstHiddenSeconds=null,firstForgetSeconds=null,minRange=Infinity,lastSample=seen.perceived.sampledAt,hiddenFrames=0,maxHiddenFrames=0;
 const routeActions=route?[['KeyS',Math.round(.4*hz)],['KeyA',Math.round(.95*hz)],['KeyW',Math.round(.4*hz)]]:[];
 let frame=0,previousYaw=brain.snapshot().yaw;
 const tick=()=>{
  const b=step();frame++; const t=frame/hz;
  if(!b.freshPerception){assert.equal(s.commands.at(-1).castQ,false);for(const key of ['castE','strikeE','castR'])assert(!s.commands.at(-1)[key]);assert.equal(b.yaw,previousYaw,'no aim update without fresh delayed observation');}
  previousYaw=b.yaw;
  if(b.perceived&&b.perceived.sampledAt!==lastSample){assert(b.wasVisible);assert(b.visibleTime+1e-9>=b.reactionDelay);assert(b.perceived.available<=b.time+1e-9);}
  if(b.wasVisible){visibleFrames++;hiddenFrames=0;}else{firstHiddenSeconds??=t;hiddenFrames++;maxHiddenFrames=Math.max(maxHiddenFrames,hiddenFrames);}
  if(b.perceived&&b.perceived.sampledAt!==lastSample){freshUpdates++;lastSample=b.perceived.sampledAt;if(firstHiddenSeconds!==null)firstFreshSeconds??=t;}
  if(!b.perceived)firstForgetSeconds??=t;
  minRange=Math.min(minRange,Math.hypot(d.duelBot.position.x-seen.perceived.position.x,d.duelBot.position.z-seen.perceived.position.z));
  if(frame%hz===0)rows.push({time:t,bot:d.duelBot.position.toArray(),human:d.player.toArray(),visible:b.wasVisible,perceived:b.perceived?.position??null,sampledAt:b.perceived?.sampledAt??null});
 };
 if(route){for(const[key,frames]of routeActions){r.key(key);for(let n=0;n<frames;n++)tick();r.release(key);}}else d.player.set(-12,1.7,-8);
 const routeEnd={time:frame/hz,human:d.player.toArray(),bot:d.duelBot.position.toArray(),brain:brain.snapshot()};
 for(;frame<seconds*hz;)tick();
 return {hz,route,seen,routeEnd,summary:{visibleFrames,freshUpdates,firstHiddenSeconds,firstFreshSeconds,firstForgetSeconds,minRange,maxHiddenSeconds:maxHiddenFrames/hz,totalSeconds:seconds},rows};
}
