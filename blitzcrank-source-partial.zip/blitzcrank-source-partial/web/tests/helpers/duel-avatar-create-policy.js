// Fail closed: historical comparisons may toggle known independent options,
// but must retain every other opt-in and never silently rewrite a new shape.
const prefix='duelAvatar=duelFactory.create(';
const call=(staticRestMatrices,reuseSkillSurfaceRestPose,stationaryW)=>prefix+'{parent:scene'+(staticRestMatrices?',staticRestMatrices:true':'')+(reuseSkillSurfaceRestPose?',reuseSkillSurfaceRestPose:true':'')+(stationaryW?',stationaryW:true':'')+'});';
export function duelAvatarCreatePolicy(source){
 if(source.split(prefix).length!==2)throw Error('Expected exactly one duel avatar factory call');
 const matches=[];
 for(const staticRestMatrices of [false,true])for(const reuseSkillSurfaceRestPose of [false,true])for(const stationaryW of [false,true]){
  const site=call(staticRestMatrices,reuseSkillSurfaceRestPose,stationaryW);
  if(source.includes(site))matches.push({site,staticRestMatrices,reuseSkillSurfaceRestPose,stationaryW});
 }
 if(matches.length!==1)throw Error('Unknown duel avatar factory call shape');
 return matches[0];
}
export function setDuelAvatarCreatePolicy(source,options){
 const before=duelAvatarCreatePolicy(source),next={...before,...options};
 for(const key of Object.keys(options))if(!['staticRestMatrices','reuseSkillSurfaceRestPose','stationaryW'].includes(key)||typeof options[key]!=='boolean')throw Error('Unknown duel avatar factory policy');
 const result=source.replace(before.site,call(next.staticRestMatrices,next.reuseSkillSurfaceRestPose,next.stationaryW));
 const after=duelAvatarCreatePolicy(result);
 if(after.staticRestMatrices!==next.staticRestMatrices||after.reuseSkillSurfaceRestPose!==next.reuseSkillSurfaceRestPose||after.stationaryW!==next.stationaryW)throw Error('Duel avatar policy adaptation failed');
 return result;
}
