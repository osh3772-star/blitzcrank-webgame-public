import assert from 'node:assert/strict';
import {vfxState} from './skill-vfx-harness.js';
// Test-only adapter for verbatim historical fixtures. Only proved unused
// capacity is removed; all common bytes, drawn counts and other state remain.
export function capacityComparableVfxState(h){
 const state=vfxState(h);
 assert([2636,1946].includes(state.inspect.capacity),'known total capacity only');
 const bounds={E_lavender_fist_lightning_A:[144,108],E_lavender_fist_lightning_B:[144,108],R_ivory_branched_web:[1728,1206],R_target_sparks:[480,384]};
 const seen=new Set();
 for(const o of state.objects){
  if(!bounds[o.name]||seen.has(o.geometry))continue;
  seen.add(o.geometry);const[old,next]=bounds[o.name],g=state.geometries[o.geometry];
  assert(g.drawRange.start===0&&g.drawRange.count<=next*6,'draw fits proved bound');
  for(const[key,a]of Object.entries(g.attributes)){
   const n=next*6*a.itemSize;assert([old*6*a.itemSize,n].includes(a.array.length),'known attribute length only');
   if(key!=='uv')assert(a.array.subarray(n).every(v=>v===0),'removed dynamic suffix must be untouched');
   a.array=a.array.slice(0,n);
  }
 }
 assert.equal(seen.size,4);state.inspect.capacity=1946;return state;
}
