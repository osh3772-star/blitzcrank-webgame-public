import assert from'node:assert/strict';import{make}from'./hand-path-harness.js';
assert.equal(typeof global.gc,'function','Run correctness only with --expose-gc');
const variant=process.argv[2],kind=process.argv[3],r=await make(variant),frames=[],phases=new Set(),skills=new Set();
function key(k){r.key(k);r.release(k)}
function snap(label,mirror=false){const rec={label,hash:r.hash({pose:true}),socket:r.probe.socket,state:r.qa.state,phase:r.qa.hook?.phase??null};if(mirror){const token=r.probe.prepareMirrorBody();r.game.data.scene.updateMatrixWorld();rec.mirror=r.hash({pose:true});r.probe.restoreMirrorBody(token);r.game.data.scene.updateMatrixWorld();rec.restored=r.hash({pose:true});}frames.push(rec);if(frames.length%16===0){global.gc();console.error(JSON.stringify({checkpoint:frames.length,memory:process.memoryUsage()}));}}
function step(n=1){for(let i=0;i<n;i++){r.frames(1);if(r.qa.hook?.phase)phases.add(r.qa.hook.phase);if(r.qa.skills?.phase)skills.add(r.qa.skills.phase);}snap('frame-'+frames.length,kind==='soloQ');}
function until(fn,max=300){for(let i=0;i<max&&!fn();i++)step();assert(fn(),'bounded condition '+kind)}
function quiet(){r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})})}
if(kind==='soloMove'){
 r.game.begin(true);step();key('ShiftLeft');r.key('KeyW');for(let i=0;i<65;i++)step(4);r.release('KeyW');key('KeyV');for(let i=0;i<20;i++){r.game.aim(.5,-.2);step(2)}key('Space');step(50);r.game.pause();step(2);key('KeyV');step();r.game.resume();step();r.element('mainmenu').click();step();r.game.begin(true);step();
}else if(kind==='soloE'){
 r.game.begin(true);key('KeyE');r.key('KeyA');until(()=>r.qa.skills.phase==='E_Hold',80);key('KeyV');step(4);r.punch();until(()=>r.qa.skills.phase!=='E_Strike',120);r.release('KeyA');step();key('KeyR');until(()=>r.qa.skills.phase!=='R_Cast',80);r.game.pause();key('KeyV');step();r.game.resume();step(2);
}else if(kind==='soloQ'){
 r.game.begin(true);for(let round=0;round<4;round++){if(round%2)key('KeyV');key('KeyQ');const h=r.game.data.hook;assert(h);frames.push({label:'immediateQ'+round,position:h.position.toArray(),socket:r.probe.socket});until(()=>!r.qa.hook,200);step(150)}assert(phases.has('outbound'));assert(phases.has('return'));assert(phases.has('recover'));
}else if(kind==='duel'){
 r.game.begin(true,false,true);quiet();until(()=>r.qa.duel.active);r.game.data.duelBot.position.set(18,1.7,-20);key('ShiftLeft');r.key('KeyW');for(let i=0;i<180;i++){if(i===10)key('KeyE');if(i===60)r.punch();if(i===90)key('KeyR');if(i===120)key('KeyV');if(i===140)r.release('KeyW');step()}r.game.pause();step(2);r.game.resume();if(r.qa.view==='third')key('KeyV');assert.equal(r.qa.view,'first');r.game.data.duelBot.position.set(r.game.data.player.x,1.7,r.game.data.player.z-6);key('KeyQ');until(()=>r.qa.duel.match.history.length>0,250);step(80);r.game.pause();step();
}else throw Error('Unknown case');
console.log(JSON.stringify({variant,kind,frames,phases:[...phases],skills:[...skills],final:r.hash({pose:true}),note:'Normal renderer-equivalent scene/camera update before transform snapshots. Mirror prepare/restore exercised as CPU scene path, not GPU.'}));
