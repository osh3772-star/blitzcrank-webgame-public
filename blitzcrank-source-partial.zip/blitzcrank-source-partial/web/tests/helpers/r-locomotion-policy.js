import {normalizeERecovery,adaptHistoricalERecovery} from './e-recovery-policy.js';
// Test-only policy alignment. Validate before normalizing the copy passed to
// older W parsing; never change frozen fixtures or final-pose call policies.
const clause="if(skill.name==='R_Cast')applyEWalkLayer();";
export const rArmClause="if(skill.name==='R_Cast'){const st=skills.status;applyEWalkLayer({armRecoveryWeight:st.armed||st.boost||st.slow?0:rRecoveryArmWeight(skill.time,skill.duration)});}";
export const rBotArmOption=',rArmRecovery:!(duelBotSkills?.status.armed||duelBotSkills?.status.boost||duelBotSkills?.status.slow)';
export const rArmImport='createFullbodyELocomotionLayer,rRecoveryArmWeight,clearFullbodySkillPose';
const oldImport='createFullbodyELocomotionLayer,clearFullbodySkillPose';
const eClause="if(skill.name.startsWith('E_'))applyEWalkLayer();";
const botCall='duelAvatar.update(dt,{position:[duelBot.position.x,height,duelBot.position.z],yaw:duelBot.yaw,pitch:duelBot.pitch,skill:duelBotSkills?.animation,locomotion:{deltaX,deltaZ,grounded:height<=0,height,velocityY:duelBot.velocity.y},hook:h?{...h,position:[h.position.x,h.position.y,h.position.z]}:null}';
const count=(source,site)=>source.split(site).length-1;
function region(source,start,end){
 if(count(source,start)!==1||count(source,end)!==1||source.indexOf(start)>=source.indexOf(end))throw Error('Unknown R policy function bounds');
 return source.slice(source.indexOf(start),source.indexOf(end));
}
export function rLocomotionPresentationPolicy(source){
 source=normalizeERecovery(source);
 const player=region(source,'function animateFullbody(dt,walking){','\nfunction updateFullbodyHand(){');
 const bot=region(source,'function updateDuelAvatar(dt,deltaX=0,deltaZ=0){','\nfunction duelSockets(){');
 if(count(source,botCall)!==1||count(bot,'duelAvatar.update(')!==1)throw Error('Unknown R bot presentation call');
 const sites=[[');',false,false],[',{deferWorldMatrices:true});',false,false],[',{rLocomotion:true});',true,false],[',{deferWorldMatrices:true,rLocomotion:true});',true,false],[',{rLocomotion:true'+rBotArmOption+'});',true,true],[',{deferWorldMatrices:true,rLocomotion:true'+rBotArmOption+'});',true,true]];
 const matches=sites.filter(([suffix])=>bot.includes(botCall+suffix));
 if(matches.length!==1)throw Error('Unknown R bot presentation options');
 const [suffix,botEnabled,botRecovery]=matches[0],recovery=count(player,rArmClause)===1,playerClause=recovery?rArmClause:clause,enabled=count(player,playerClause)===1;
 if(count(player,'R_Cast')!==(enabled?1:0)||count(source,playerClause)!==(enabled?1:0)||count(player,eClause)!==1||(enabled&&!player.includes(eClause+playerClause))||count(source,'rLocomotion')!==(botEnabled?1:0)||enabled!==botEnabled)throw Error('Unknown or mismatched R presentation policy');
 if(recovery!==botRecovery||count(source,'rArmRecovery')!==(recovery?1:0)||count(source,'rRecoveryArmWeight')!==(recovery?2:0)||(recovery&&count(source,rArmImport)!==1))throw Error('Unknown or mismatched R arm recovery');
 return {enabled,recovery,playerClause,botSite:botCall+suffix};
}
export function normalizeRForWPresentation(source){
 source=normalizeERecovery(source);
 const policy=rLocomotionPresentationPolicy(source);return policy.enabled?source.replace(policy.playerClause,''):source;
}
export function adaptHistoricalRPresentation(source,current){
 const target=rLocomotionPresentationPolicy(current),before=rLocomotionPresentationPolicy(source);
 if(before.enabled)throw Error('Historical R presentation already adapted');
 if(!target.enabled)return source;
 const defer=before.botSite.endsWith(',{deferWorldMatrices:true});'),options=(defer?'deferWorldMatrices:true,':'')+'rLocomotion:true'+(target.recovery?rBotArmOption:'');
 const nextBot=botCall+',{'+options+'});';
 if(target.recovery){if(count(source,oldImport)!==1)throw Error('Unknown R recovery import');source=source.replace(oldImport,rArmImport);}
 source=source.replace(eClause,eClause+target.playerClause).replace(before.botSite,nextBot);
 if(!rLocomotionPresentationPolicy(source).enabled)throw Error('Historical R adaptation failed');
 return adaptHistoricalERecovery(source,current);
}
