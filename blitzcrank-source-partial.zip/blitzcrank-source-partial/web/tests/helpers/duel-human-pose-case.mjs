import assert from 'node:assert/strict';
import {createPoseHarness} from './duel-human-pose-harness.js';
const mode=process.argv[2],kind=process.argv[3],hz=Number(process.argv[4]||60),r=await createPoseHarness({baseline:mode==='baseline',unsafe:kind==='unsafe',dt:1/hz}),frames=[],skills=new Set(),phases=new Set();
function step(dt){if(dt!==undefined)r.setDelta(dt);r.clearTrace();r.frames(1);const trace={calls:r.trace.calls,inner:r.trace.inner,requiredInner:r.trace.requiredInner,outer:r.trace.outer};if(r.pose.state.visibleSkill)skills.add(r.pose.state.visibleSkill);const phase=r.qa.hook?.phase??r.qa.duel?.bot.hook?.phase;if(phase)phases.add(phase);const hash=r.hash();let mirror=null,restored=null;if(kind==='humanQ'||kind==='botQ'){const token=r.pose.prepareMirrorBody();mirror=r.hash();r.pose.restoreMirrorBody(token);restored=r.hash();}frames.push({hash,mirror,restored,trace,state:r.qa.state,phase:r.qa.duel?.match.phase??null});}
function until(fn,max=700,dt){for(let i=0;i<max&&!fn();i++)step(dt);assert(fn(),'bounded scenario condition not reached: '+kind);}
function quiet(){r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});}
function start(){r.game.begin(true,false,true);quiet();until(()=>r.qa.duel.active);}
function key(code){r.key(code);r.release(code);}
start();
if(kind==='active'){
 r.game.data.duelBot.position.set(18,1.7,-20);key('ShiftLeft');r.key('KeyW');
 for(let i=0;i<Math.round(6*hz);i++){
  if(i===Math.round(.15*hz))key('Space');if(i===Math.round(.3*hz))r.release('KeyW');if(i===Math.round(.5*hz))key('KeyE');if(i===Math.round(1.5*hz))r.punch();if(i===Math.round(3*hz))key('KeyR');if(i===Math.round(4*hz))key('KeyV');if(i===Math.round(5*hz))r.punch();step();
 }
 for(const name of ['W_Loop','E_Charge','E_Hold','E_Strike','R_Cast'])assert(skills.has(name),'missing actual skill '+name);
 step(0);assert.equal(frames.at(-1).trace.inner,0);assert.equal(frames.at(-1).trace.outer,1);r.game.pause();step(1/hz);r.game.resume();step(.5);
}else if(kind==='humanQ'||kind==='botQ'||kind==='unsafe'){
 r.game.data.duelBot.position.set(0,1.7,1);if(kind==='botQ'){key('Space');step();step();assert(r.game.data.duel.cast('bot'));}else key('KeyQ');
 if(kind==='humanQ'||kind==='botQ'){until(()=>(kind==='humanQ'?r.qa.hook:r.qa.duel.bot.hook)?.phase==='outbound',60);key('KeyV');assert.equal(r.qa.view,'third');}
 if(kind==='unsafe'){until(()=>r.qa.state==='paused',100);assert.equal(r.qa.duel.match.history.length,0);assert(r.qa.duel.pendingGrab);const boundary=frames.at(-1);assert.equal(boundary.trace.inner,1);assert.equal(boundary.trace.outer,0);for(let i=0;i<3;i++)step();}
 else{until(()=>r.qa.duel.match.history.length===1,180);assert.equal(r.qa.duel.match.history[0].winnerId,kind==='botQ'?'bot':'human');for(let i=0;i<40;i++)step(.1);}
}else if(kind==='humanResult'||kind==='botResult'){
 const winner=kind==='humanResult'?'human':'bot';for(let round=0;round<3;round++){until(()=>r.qa.duel.active,160,.5);r.game.data.duelBot.position.set(0,1.7,5);assert(r.game.data.duel.getSkills(winner).castR());until(()=>r.qa.duel.match.history.length===round+1,100,.5);assert.equal(r.qa.duel.match.history.at(-1).winnerId,winner);}
 until(()=>r.qa.state==='results',30,.5);assert.equal(frames.at(-1).trace.requiredInner,1);if(mode==='candidate')assert.equal(frames.at(-1).trace.inner,1);assert.equal(r.qa.duel.match.history.length,3);for(let i=0;i<3;i++)step(.5);
}else throw Error('Unknown case');
console.log(JSON.stringify({mode,kind,hz,frames,skills:[...skills],phases:[...phases],final:r.hash()}));
