import fs from 'node:fs';
import * as THREE from '../../vendor/three.module.js';
import {decodeModelBuffer} from '../../model-codec.js';
import {PLAYER_MODELS} from '../../player-model-manifest.js';
import {SKILL_ASSET} from '../../skill-animation-manifest.js';
import {bindSkillClips} from '../../skill-animation.js';
export {THREE};
export const model=decodeModelBuffer(fs.readFileSync(new URL('../../'+PLAYER_MODELS.viewmodel.raw,import.meta.url)));
export const skillModel=JSON.parse(fs.readFileSync(new URL('../../'+SKILL_ASSET.raw,import.meta.url))).models.viewmodel;
export function animationSource(sourcePath=new URL('../../main.js',import.meta.url)){
 const raw=fs.readFileSync(sourcePath,'utf8');if(String(sourcePath).endsWith('.txt'))return raw;
 const begin=raw.indexOf('function playClip('),end=raw.indexOf('\nfunction audio(',begin);if(begin<0||end<0)throw Error('Animation source boundary missing');return raw.slice(begin,end);
}
// Execute the unchanged source function and actual bound pose data with real
// Object3D transforms. Geometry/rendering is not part of the interpolation path.
export function createViewmodelAnimationHarness({sourcePath,unique=false}={}){
 const selected=unique?model.parts.map((p,i)=>[p,i]).filter(([p,i])=>i===0||(p.sourcePart||p.name)!==(model.parts[i-1].sourcePart||model.parts[i-1].name)):model.parts.map((p,i)=>[p,i]);
 const parts=selected.map(([p])=>{const o=new THREE.Object3D();o.name=p.name;o.userData.sourcePart=p.sourcePart||p.name;return o;});
 const clips=Object.fromEntries(model.clips.map(c=>[c.name,unique?{...c,frames:c.frames.map(f=>({poses:selected.map(([,i])=>f.poses[i])}))}:c]));
 const skillClips={viewmodel:Object.fromEntries(bindSkillClips(skillModel,parts).map(c=>[c.name,c]))};
 const code=`let viewmodel=new THREE.Group(),hook=null,clipName='Idle',oneShot=0,clipTime=0,state='paused',punchPlaybackRate=1,skills={animation:null};viewmodel.add(...parts);viewmodel.position.set(0,-.13,.18);
 const projectileParts=parts.filter(m=>m.name.endsWith('.R')&&/ElbowForearmLink|Forearm|Wrist|Palm|KnucklePlate|Finger|Thumb/.test(m.name));
 function visibleSkillAnimation(){if(hook||oneShot>0)return null;const skill=skills?.animation;return skill?.presentation?{...skill,...skill.presentation}:skill;}
 ${animationSource(sourcePath)}
 return {apply:applyAnimation,parts,clips,skillClips,projectileParts,viewmodel,configure(v){if('clipName'in v)clipName=v.clipName;if('clipTime'in v)clipTime=v.clipTime;if('oneShot'in v)oneShot=v.oneShot;if('state'in v)state=v.state;if('hook'in v)hook=v.hook;if('skill'in v)skills.animation=v.skill;if('punchPlaybackRate'in v)punchPlaybackRate=v.punchPlaybackRate;},get status(){return {clipName,clipTime,oneShot,hook:hook?{...hook}:null,skill:skills.animation?{...skills.animation}:null,state,punchPlaybackRate,qa:qa.toArray(),qb:qb.toArray()};}};`;
 return new Function('THREE','parts','clips','skillClips',code)(THREE,parts,clips,skillClips);
}
export function animationState(h){h.viewmodel.updateMatrixWorld(true);return {status:h.status,parts:h.parts.map(p=>({name:p.name,position:p.position.toArray(),quaternion:p.quaternion.toArray(),rotation:p.rotation.toArray(),scale:p.scale.toArray(),matrix:p.matrix.toArray(),world:p.matrixWorld.toArray(),visible:p.visible,auto:p.matrixAutoUpdate,dirty:p.matrixWorldNeedsUpdate}))};}
