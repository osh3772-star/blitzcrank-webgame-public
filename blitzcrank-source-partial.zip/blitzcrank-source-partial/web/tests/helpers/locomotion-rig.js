import fs from 'node:fs';
import * as THREE from '../../vendor/three.module.js';
import {decodeModelBuffer} from '../../model-codec.js';
import {PLAYER_MODELS} from '../../player-model-manifest.js';
import {createFullbodyLocomotion,WALK_TUNING} from '../../fullbody-locomotion.js';
export {THREE};
const buffer=fs.readFileSync(new URL('../../'+PLAYER_MODELS.fullbody.raw,import.meta.url));
export function rig({tuning=WALK_TUNING,createMotion=createFullbodyLocomotion}={}){
 const data=decodeModelBuffer(buffer),body=new THREE.Group(),scene=new THREE.Scene(),nodes=new Map(),meshes=new Map(),records=new Map(data.nodes.map(n=>[n.name,n]));
 for(const n of data.nodes){const o=new THREE.Group();o.name=n.name;nodes.set(n.name,o);}
 for(const n of data.nodes){const o=nodes.get(n.name),p=nodes.get(n.parent);o.position.fromArray(n.position);if(p){o.position.sub(new THREE.Vector3().fromArray(records.get(n.parent).position));p.add(o);}else body.add(o);o.userData.base=o.position.toArray();}
 for(const p of data.parts){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(p.vertices),3));g.translate(...records.get(p.name).position.map(v=>-v));g.computeBoundingBox();const m=new THREE.Mesh(g);m.name=p.name;m.userData.sourcePart=p.sourcePart||p.name;m.userData.skillRestPoint=records.get(p.name).position.slice();nodes.get(p.name).add(m);meshes.set(p.name,m);}
 body.scale.setScalar(.78);scene.add(body);const motion=createMotion(THREE,{nodes,meshes,scale:.78,tuning});
 const fingers=[...meshes].filter(([name])=>/Finger|Thumb/.test(name)).map(([,mesh])=>mesh);
 return{body,nodes,meshes,motion,fingers};
}
const vertex=new THREE.Vector3();
export function minY(mesh){const p=mesh.geometry.attributes.position;let min=Infinity;for(let i=0;i<p.count;i++){vertex.fromBufferAttribute(p,i).applyMatrix4(mesh.matrixWorld);min=Math.min(min,vertex.y);}return min;}
export function fingerMinimum(fingers){let min=Infinity;for(const m of fingers)min=Math.min(min,minY(m));return min;}
