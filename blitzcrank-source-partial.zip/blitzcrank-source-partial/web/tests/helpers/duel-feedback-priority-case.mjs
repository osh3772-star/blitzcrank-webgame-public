import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const [rootArg,hzArg='20',scenario='R',view='first',input='mouse']=process.argv.slice(2);
const root=path.resolve(rootArg),hz=Number(hzArg),dt=1/hz;
const {createGameplayHarness}=await import(pathToFileURL(path.join(root,'tests/helpers/runtime-harness.js')));
const sourcePath=pathToFileURL(process.env.DUEL_MAIN_SOURCE||path.join(root,'main.js'));
const r=await createGameplayHarness({sourcePath,delta:()=>dt});
if(input==='touch')r.docListeners.pointerdown({pointerType:'touch'});
let frameEvents=[],totalFrames=0;
function frame(n=1){for(let i=0;i<n;i++){frameEvents=[];r.frames(1);totalFrames++;}}
function until(predicate){for(let i=0;i<500&&!predicate();i++)frame();assert(predicate(),'bounded runtime condition');}
function start(){
 r.game.begin(true,false,true);
 r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI/2,pitch:0})});
 until(()=>r.game.data.duel.active);
 const d=r.game.data;d.player.set(-9,1.7,-4.5);d.duelBot.position.set(-6.3,1.7,-4.5);r.game.aim(0,0);frame();
 if((view==='third')!==(r.qa.view==='third'))r.key('KeyV');
 const drain=d.duel.drainEvents;d.duel.drainEvents=()=>{const e=drain();frameEvents.push(...e);return e;};
 return d;
}
const q=()=>input==='touch'?r.element('touchhook').onpointerdown({button:0,pointerType:'touch',preventDefault(){}}):r.key('KeyQ');
let d=start();q();let blockedFrames=0;
do{frame();blockedFrames++;assert(blockedFrames<80);}while(!frameEvents.some(e=>e.type==='hook-blocked'));
assert.equal(r.element('hitnotice').textContent,input==='touch'?'막힘 · 득점 없음':'BLOCKED · 득점 없음');
assert.equal(d.duel.active,true);assert.equal(d.duel.state.history.length,0);
let expected,atBoundary;
if(scenario==='block'){
 expected=input==='touch'?'막힘 · 득점 없음':'BLOCKED · 득점 없음';
}else{
 d=start();
 if(scenario==='Q'){
  q();assert(d.duel.cast('bot'));until(()=>!!d.duel.pendingGrab);expected='그랩 · 끌어오는 중';
  assert(frameEvents.some(e=>e.type==='hook-blocked'&&e.playerId==='human'),'must reproduce competing same-frame block');
 }else if(scenario==='tie'){
  assert(d.duel.getSkills('human').castR());assert(d.duel.getSkills('bot').castR());until(()=>d.duel.tieRemaining>0);
  expected=input==='touch'?'동시 명중 · 재시도':'동시 명중 · 득점 없이 같은 라운드 재시도';assert.equal(d.duel.state.history.length,0);
 }else{
  const s=d.duel.getSkills('bot');
  if(scenario==='E'){assert(s.castE());until(()=>s.status.phase==='E_Hold');}
  const strike=()=>assert(scenario==='E'?s.strikeE():s.castR());
  const impactFrames=Math.round((scenario==='E'?.4:.3)*hz);
  if(impactFrames>=blockedFrames){strike();frame(impactFrames-blockedFrames);q();}else{q();frame(blockedFrames-impactFrames);strike();}
  until(()=>d.duel.state.history.length===1);
  assert(frameEvents.some(e=>e.type==='hook-blocked'&&e.playerId==='human'),'must reproduce competing same-frame block');
  assert.deepEqual(d.duel.state.scores.map(s=>s.points),[0,1]);
  expected='BOT +1 · '+(scenario==='E'?'강철 주먹':'전기장')+' 명중';
 }
}
atBoundary={hz,scenario,view,input,blockedFrames,notice:r.element('hitnotice').textContent,expected,phase:d.duel.state.phase,pendingGrab:!!d.duel.pendingGrab,points:d.duel.state.scores.map(s=>s.points),events:frameEvents.map(e=>({type:e.type,playerId:e.playerId,skill:e.skill,hit:e.hit}))};
console.log(JSON.stringify({boundary:atBoundary}));
assert.equal(atBoundary.notice,expected,'round result/pull feedback must outrank simultaneous wall feedback');
const snapshot=JSON.stringify({duel:r.qa.duel,player:r.qa.player,skills:r.qa.skills,notice:r.element('hitnotice').textContent});
r.game.pause();frame(2);assert.equal(JSON.stringify({duel:r.qa.duel,player:r.qa.player,skills:r.qa.skills,notice:r.element('hitnotice').textContent}),snapshot);r.game.resume();
let holdSeconds=null;
if(['E','R','Q'].includes(scenario)){
 if(scenario==='Q'){assert.equal(d.duel.state.history.length,0);until(()=>d.duel.state.history.length===1);assert.equal(r.element('hitnotice').textContent,'BOT +1 · 그랩 명중');}
 const scoredAt=d.session.elapsed;until(()=>d.duel.state.phase==='countdown');holdSeconds=d.session.elapsed-scoredAt;assert(Math.abs(holdSeconds-3)<1e-8);assert.deepEqual(d.duel.state.scores.map(s=>s.points),[0,1]);assert.deepEqual(d.player.toArray(),[0,1.7,7]);
}else if(scenario==='tie'){
 until(()=>d.duel.state.phase==='countdown');assert.equal(d.duel.state.roundNumber,1);assert.equal(d.duel.state.history.length,0);
}
d=start();assert.deepEqual(d.duel.state.scores.map(s=>s.points),[0,0]);assert.equal(d.duel.getHook('human'),null);assert.equal(d.duel.cooldown('human'),0);assert.deepEqual(d.skills.status.cooldown,{W:0,E:0,R:0});frame(hz);assert.equal(d.duel.state.history.length,0);
console.log(JSON.stringify({pass:true,hz,scenario,view,input,holdSeconds,totalFrames,pausedStatePreserved:true,restartClean:true,harnesses:1}));
