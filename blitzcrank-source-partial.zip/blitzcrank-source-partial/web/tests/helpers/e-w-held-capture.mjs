import {baseline,runReplay,createGameplayHarness,fresh,snapshot,assert} from './e-w-held-replay.js';
const sourcePath=process.argv[2]==='baseline'?baseline:undefined,options=JSON.parse(process.argv[3]);
let result;
if(options.entry){const h=await createGameplayHarness({sourcePath});fresh(h);h.key('KeyW');if(options.entry==='W-first'){h.key('ShiftLeft');h.frames(30);h.key('KeyE');}else{h.key('KeyE');h.frames(10);h.key('ShiftLeft');}result=[];for(let i=0;i<100;i++){h.frames(1);assert(h.qa.skills.boost>0);result.push(snapshot(h));}}
else if(options.phase){const h=await createGameplayHarness({sourcePath});fresh(h);h.key('KeyE');if(options.phase==='E_Strike'){h.frames(53);h.punch();}h.key('ShiftLeft');h.key('KeyW');result=[];for(let i=0;i<20;i++){h.frames(1);assert.equal(h.qa.skills.phase,options.phase);assert(h.qa.skills.boost>0);result.push(snapshot(h));}}
else result=await runReplay(sourcePath,options);
process.stdout.write(JSON.stringify(result));
