import fs from 'node:fs';
import assert from 'node:assert/strict';
// An explicit rectangle contract for the actual stylesheet, not browser layout.
export const read=p=>fs.readFileSync(new URL('../../'+p,import.meta.url),'utf8');
export const scope='body:has(#mobile:not(.hidden))',ui='body.touch-ui';
export function rules(text,media=[]){
 text=text.replace(/\/\*[\s\S]*?\*\//g,'');const out=[];let start=0;
 while(start<text.length){const open=text.indexOf('{',start);if(open<0)break;let depth=1,end=open+1;while(depth&&end<text.length){if(text[end]==='{')depth++;if(text[end]==='}')depth--;end++;}assert.equal(depth,0,'balanced CSS');const head=text.slice(start,open).trim(),body=text.slice(open+1,end-1);
  if(head.startsWith('@media'))out.push(...rules(body,[...media,head.slice(6).trim()]));
  else{const declarations=Object.fromEntries(body.split(';').filter(x=>x.trim()).map(x=>{const i=x.indexOf(':');assert(i>0);return[x.slice(0,i).trim(),x.slice(i+1).trim()];}));out.push({selector:head,media,declarations});}start=end;
 }return out;
}
export const parsed=rules(read('touch-layout.css')),interfaceRules=rules(read('mobile-interface.css'));
const matches=(media,c)=>media.every(m=>m.split(/\s+and\s+/).every(part=>{let a=part.match(/^\(max-width:\s*(\d+)px\)$/);if(a)return c.width<=+a[1];a=part.match(/^\(orientation:\s*(portrait|landscape)\)$/);assert(a,'supported media contract: '+part);return a[1]===(c.width>c.height?'landscape':'portrait');}));
export function style(selector,c,list=parsed){const out={};if(c.mobile===false)return out;for(const r of list)if(r.selector===selector&&matches(r.media,c))Object.assign(out,r.declarations);return out;}
function splitArgs(s){const out=[];let depth=0,start=0;for(let i=0;i<s.length;i++){if(s[i]==='(')depth++;if(s[i]===')')depth--;if(s[i]===','&&depth===0){out.push(s.slice(start,i));start=i+1;}}out.push(s.slice(start));return out;}
export function value(s,c,vars){s=s.trim();if(s.startsWith('var('))return value(vars[s.slice(4,-1)],c,vars);if(s.startsWith('env('))return c.safe?.[s.slice(4,-1)]??0;if(s.startsWith('max('))return Math.max(...splitArgs(s.slice(4,-1)).map(x=>value(x,c,vars)));if(s.startsWith('calc('))return s.slice(5,-1).split(' + ').reduce((n,x)=>n+value(x,c,vars),0);assert(/^[-\d.]+(?:px)?$/.test(s),'supported length: '+s);return parseFloat(s);}
export function layout(c,{header=false}={}){
 const vars=style(scope,c),decl=s=>style(scope+' '+s,c),num=s=>value(s,c,vars),box=(x,y,w,h)=>({x,y,w,h});
 const card=decl('#skillbar button'),row=decl('#skillbar'),width=num(card.width),height=num(card.height),gap=num(row.gap),rowWidth=3*width+2*gap;
 const rowX=row.left==='50%'?(c.width-rowWidth)/2:c.width-num(row.right)-rowWidth,rowY=c.height-num(row.bottom)-height;
 const out={W:box(rowX,rowY,width,height),E:box(rowX+width+gap,rowY,width,height),R:box(rowX+2*(width+gap),rowY,width,height)};
 const stick=decl('#joystick');out.joystick=box(num(stick.left),c.height-num(stick.bottom)-num(stick.height),num(stick.width),num(stick.height));
 const group=decl('.touch-actions'),gx=c.width-num(group.right)-num(group.width),gy=c.height-num(group.bottom)-num(group.height),button=decl('.touch-actions button');
 for(const [name,id] of [['jump','#touchjump'],['punch','#touchpunch'],['Q','#touchhook']]){const d={...button,...decl(id)},w=num(d.width),h=num(d.height),x=d.left==='auto'?gx+num(group.width)-num(d.right)-w:gx+num(d.left),y=d.top==='auto'?gy+num(group.height)-num(d.bottom)-h:gy+num(d.top);out[name]=box(x,y,w,h);}
 out.reticle=box(c.width/2-16.9,c.height/2-16.9,33.8,33.8);
 if(header){
  const iv=style(ui,c,interfaceRules),d=s=>style(ui+' '+s,c,interfaceRules),n=s=>value(s,c,iv),top=d('#top'),left=n(top.left),right=n(top.right),y=n(top.top),gap=n(top.gap),pause=d('#pause'),view=d('.view-button');
  out.brand=box(left,y,44,44);out.pause=box(c.width-right-n(pause.width),y,n(pause.width),n(pause.height));out.view=box(out.pause.x-gap-n(view.width),y,n(view.width),n(view.height));
  const timer=d('#hud .time-block'),score=d('#hud .score-block'),health=d('#healthblock'),caught=d('#hud .caught');
  out.timer=box(timer.left?n(timer.left):(c.width-n(timer.width))/2,n(timer.top),n(timer.width),n(timer.height));
  out.score=box(n(score.left),n(score.top),n(score.width),n(score.height));out.health=box(c.width-n(health.right)-n(health.width),n(health.top),n(health.width),n(health.height));out.caught=box((c.width-n(caught.width))/2,n(caught.top),n(caught.width),n(caught.height));
 }
 return out;
}
export const overlap=(a,b)=>Math.max(0,Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x))*Math.max(0,Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y));
export const actionNames=['W','E','R','jump','punch','Q','joystick','brand','view','pause'];
export function verify(c,{header=true,pressed=0}={}){
 const boxes=layout(c,{header}),entries=Object.entries(boxes);['W','E','R','jump','punch','Q'].forEach((name,i)=>{if(pressed&(1<<i))boxes[name].y+=2;});
 const safe=c.safe??{};
 for(const [name,b] of entries){assert(b.x>=0&&b.y>=0&&b.x+b.w<=c.width&&b.y+b.h<=c.height,`${name} inside ${c.width}x${c.height}`);assert(b.x>=(safe['safe-area-inset-left']??0),`${name} left safe`);assert(b.x+b.w<=c.width-(safe['safe-area-inset-right']??0),`${name} right safe`);assert(b.y>=(safe['safe-area-inset-top']??0),`${name} top safe`);assert(b.y+b.h<=c.height-(safe['safe-area-inset-bottom']??0),`${name} bottom safe`);if(actionNames.includes(name))assert(b.w>=44&&b.h>=44,name+' minimum touch size');}
 for(let i=0;i<entries.length;i++)for(let j=i+1;j<entries.length;j++)assert.equal(overlap(entries[i][1],entries[j][1]),0,`${c.width}x${c.height} ${entries[i][0]} / ${entries[j][0]}`);return boxes;
}
