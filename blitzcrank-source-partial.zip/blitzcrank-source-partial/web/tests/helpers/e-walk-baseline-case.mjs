import {eRecoveryPolicy,eArmClause,eOldClause} from './e-recovery-policy.js';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {serialize} from 'node:v8';
import {createGameplayHarness} from './runtime-harness.js';
const source=fs.readFileSync(new URL('../../main.js',import.meta.url),'utf8'),call=eRecoveryPolicy(source).enabled?eArmClause:eOldClause;
assert(source.includes(call));
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'e-walk-baseline-'));
const original=path.join(temp,'no-e-layer.js');fs.writeFileSync(original,source.replace(call,''));
function fresh(h){h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}}
function sample(h){return {player:h.qa.player,session:h.qa.session,skill:{phase:h.qa.skills.phase,armed:h.qa.skills.armed,cooldown:h.qa.skills.cooldown,boost:h.qa.skills.boost,slow:h.qa.skills.slow,metrics:h.qa.skills.metrics},viewmodel:h.game.data.parts.map(p=>[p.position.toArray(),p.quaternion.toArray(),p.scale.toArray()])};}
function replay(h){fresh(h);const a=[];for(let i=0;i<430;i++){if(i===0)h.key('KeyW');if(i===10)h.key('KeyE');if(i===100)h.punch();if(i===130)h.release('KeyW');if(i===210)h.key('KeyR');if(i===310)h.key('ShiftLeft');h.frames(1);a.push(sample(h));}return a;}

try{const before=await createGameplayHarness({sourcePath:original});process.stdout.write(serialize(replay(before)));}finally{fs.rmSync(temp,{recursive:true,force:true});}
