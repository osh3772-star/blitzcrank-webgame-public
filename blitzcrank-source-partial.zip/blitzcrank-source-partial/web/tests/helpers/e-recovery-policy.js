// Test-only alignment of the explicitly changed E presentation on both sides
// of historical regressions. Exact sites; no fixture or snapshot relaxation.
export const eOldClause="if(skill.name.startsWith('E_'))applyEWalkLayer();";
export const eArmClause="if(skill.name.startsWith('E_')){const st=skills.status;applyEWalkLayer({armRecoveryWeight:skill.name==='E_Strike'&&!st.boost&&!st.slow?eRecoveryArmWeight(skill.time,skill.duration):0});}";
export const eBotArmOption=',eArmRecovery:!(duelBotSkills?.status.boost||duelBotSkills?.status.slow)';
const importBefore='createFullbodyELocomotionLayer,rRecoveryArmWeight,';
const importAfter='createFullbodyELocomotionLayer,eRecoveryArmWeight,rRecoveryArmWeight,';
const count=(s,x)=>s.split(x).length-1;
export function eRecoveryPolicy(source){
 const enabled=source.includes('eRecoveryArmWeight')||source.includes('eArmRecovery');
 const clause=enabled?eArmClause:eOldClause;
 const start='function animateFullbody(dt,walking){',end='\nfunction updateFullbodyHand(){';
 if(count(source,start)!==1||count(source,end)!==1||count(source,clause)!==1||!source.slice(source.indexOf(start),source.indexOf(end)).includes(clause))throw Error('Unknown E recovery player site');
 if(enabled){
  const begin=source.indexOf('function updateDuelAvatar(dt,deltaX=0,deltaZ=0){'),finish=source.indexOf('\nfunction duelSockets(){');
  if(begin<0||finish<=begin||count(source,'eRecoveryArmWeight')!==2||count(source,importAfter)!==1||count(source,'eArmRecovery')!==1||!source.slice(begin,finish).includes(eBotArmOption+',rArmRecovery:'))throw Error('Unknown E recovery import or bot policy');
 }
 return {enabled};
}
export function normalizeERecovery(source){return eRecoveryPolicy(source).enabled?source.replace(eArmClause,eOldClause).replace(eBotArmOption,'').replace(importAfter,importBefore):source;}
export function adaptHistoricalERecovery(source,current){
 const target=eRecoveryPolicy(current),old=eRecoveryPolicy(source);if(old.enabled)throw Error('Historical E recovery already adapted');if(!target.enabled)return source;
 if(count(source,importBefore)!==1||count(source,',rArmRecovery:')!==1)throw Error('Historical E recovery requires exact R policy');
 const next=source.replace(eOldClause,eArmClause).replace(importBefore,importAfter).replace(',rArmRecovery:',eBotArmOption+',rArmRecovery:');if(!eRecoveryPolicy(next).enabled)throw Error('E recovery alignment failed');return next;
}
