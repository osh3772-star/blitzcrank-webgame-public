import {adaptHistoricalQHandoff} from './q-handoff-policy.js';
import test from 'node:test';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import * as THREE from '../../vendor/three.module.js';
import {createGameplayHarness as createBaseRuntimeHarness} from './runtime-harness.js';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {adaptHistoricalRPresentation} from './r-locomotion-policy.js';
const baseline=new URL('../fixtures/e-w-baseline-v81.js',import.meta.url);
// Align only the later R presentation on both sides of the E/W regression.
async function createGameplayHarness(options={}){
 if(options.sourcePath!==baseline)return createBaseRuntimeHarness(options);
 const original=fs.readFileSync(baseline,'utf8'),current=fs.readFileSync(new URL('../../main.js',import.meta.url),'utf8');
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'e-w-r-policy-')),sourcePath=path.join(temp,'baseline.js');
 try{fs.writeFileSync(sourcePath,adaptHistoricalRPresentation(adaptHistoricalQHandoff(original,current),current));return await createBaseRuntimeHarness({...options,sourcePath});}
 finally{fs.rmSync(temp,{recursive:true,force:true});}
}
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
function fresh(h){h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}}
function snapshot(h){const d=h.game.data;return {game:{player:h.qa.player,session:h.qa.session,phase:h.qa.skills.phase,armed:h.qa.skills.armed,boost:h.qa.skills.boost,cooldown:h.qa.skills.cooldown,slow:h.qa.skills.slow,metrics:h.qa.skills.metrics,hook:h.qa.hook},body:hash([...d.fullbodyMeshes.values()].map(m=>{m.updateWorldMatrix(true,false);return m.matrixWorld.toArray();})),vm:d.parts.map(p=>{p.updateMatrix();return p.matrix.toArray();}),names:d.parts.map(p=>p.name)};}
async function runReplay(sourcePath,{moving=true,touch=false,script=false,blocked=false,expire=false,rOverride=false}={}){const h=await createGameplayHarness({sourcePath});fresh(h);if(touch){document.pointerLockElement=null;h.docListeners.pointerdown({pointerType:'touch'});}const tap=id=>h.element(id).onpointerdown({pointerType:'touch',button:0,preventDefault(){}});touch?tap('skillE'):h.key('KeyE');h.frames(53);if(blocked)h.game.data.player.x=23.39;touch?tap('skillW'):h.key('ShiftLeft');if(moving){if(touch)h.element('joystick').onpointerdown({pointerType:'touch',pointerId:3,clientX:55,clientY:17});else h.key(blocked?'KeyD':'KeyW');}const frames=[];for(let i=0;i<(script?420:expire||rOverride?300:35);i++){if(rOverride){if(i===35)h.key('KeyR');if(i===220)h.punch();}if(expire&&i>0&&i%60===0){h.release('KeyW');h.release('KeyS');h.key(i%120===0?'KeyW':'KeyS');}if(script){if(i===35){h.release('KeyW');h.key('Space');}if(i===50)h.release('Space');if(i===75){h.key('KeyD');h.key('KeyQ');}if(i===230)h.key('KeyR');if(i===290)h.punch();if(i===240)h.release('KeyD');}h.frames(1);frames.push(snapshot(h));}return frames;}

async function replay(sourcePath,options={}){const out=spawnSync(process.execPath,['--max-old-space-size=512',new URL('./e-w-held-capture.mjs',import.meta.url).pathname,sourcePath?'baseline':'fixed',JSON.stringify(options)],{encoding:'utf8',maxBuffer:120*1024*1024});assert.equal(out.status,0,out.stderr);return JSON.parse(out.stdout);}
export {runReplay,test,assert,THREE,baseline,fresh,snapshot,replay,createGameplayHarness};
