import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';import {poseStateDigest} from './duel-human-pose-harness.js';import {createRuntimeHarness,createGameplayHarness} from './runtime-harness.js';import {SKILL_ASSET} from '../../skill-animation-manifest.js';
const mode=process.argv[2]||'ready',src=new URL('../../main.js',import.meta.url);let source=fs.readFileSync(src,'utf8');
if(mode!=='ready'){
 const data=JSON.parse(fs.readFileSync(new URL('../../'+SKILL_ASSET.raw,import.meta.url)));
 if(mode==='pose')data.models.viewmodel.clips[0].frames[0].poses[0].s[0]=0;
 else if(mode==='view-binding')data.models.viewmodel.sourceParts[0]+='-mismatch';
 else if(mode==='body-binding')data.models.fullbody.sourceParts[0]+='-mismatch';
 else throw Error('Unknown startup mode');
 const bytes=new TextEncoder().encode(JSON.stringify(data));globalThis.__SKILL_TEST_BYTES__=bytes;
 const before='loadSkillAsset(SKILL_ASSET)';assert.equal(source.split(before).length,2);
 source=source.replace(before,"loadSkillAsset({...SKILL_ASSET,bytes:globalThis.__SKILL_TEST_BYTES__.length},{DecompressionStreamImpl:null,fetchImpl:async()=>({ok:true,arrayBuffer:async()=>globalThis.__SKILL_TEST_BYTES__.buffer})})");
}
source+='\nwindow.__SKILL_STARTUP_PROBE__={get data(){return {skillClips,duelSkillClips}}};\n';
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'skill-startup-case-')),file=path.join(temp,'main.js');fs.writeFileSync(file,source);
let h;const errors=[],originalError=console.error;console.error=e=>errors.push(e?.message||String(e));
try{h=await (mode==='ready'?createGameplayHarness:createRuntimeHarness)({sourcePath:file});if(mode!=='ready'){h.element('practice').onclick();await h.waitForGameplay().catch(()=>{});}}finally{console.error=originalError;fs.rmSync(temp,{recursive:true});}
if(mode!=='ready'){
 assert.equal(h.qa.state,'error');for(const id of ['start','practice','combopractice','duelmode'])assert.equal(h.element(id).disabled,true);
 assert.equal(h.element('startupretry').hidden,false);assert.equal(h.element('startupretry').disabled,false);assert.equal(errors.length,1);
 if(mode==='pose'){assert.match(errors[0],/Invalid skill quaternion\/scale/);assert.match(h.element('loadstatus').textContent,/게임 파일/);}
 else{assert.match(errors[0],new RegExp('Skill model mismatch: '+(mode==='view-binding'?'viewmodel':'fullbody')));assert.match(h.element('loadstatus').textContent,/모델/);}
 console.log(JSON.stringify({mode,state:h.qa.state,error:errors[0],status:h.element('loadstatus').textContent}));
}else{
 assert.equal(h.qa.state,'menu');assert.equal(errors.length,0);const bound=globalThis.__SKILL_STARTUP_PROBE__.data;
 for(const type of ['viewmodel','fullbody']){assert.equal(Object.keys(bound.skillClips[type]).length,8);assert(Object.hasOwn(bound.skillClips[type],'W_Loop_Slow'));}
 const hash=createHash('sha256');hash.update(poseStateDigest(bound));let frames=0;function snap(){const d=h.game.data;hash.update(poseStateDigest({state:h.qa.state,player:h.qa.player,skills:h.qa.skills,session:h.qa.session,duel:h.qa.duel}));for(const root of [d.fullbody,d.duelAvatar.object])root.traverse(n=>{hash.update(n.name);hash.update(Buffer.from(new Float64Array([...n.position.toArray(),...n.quaternion.toArray(),...n.scale.toArray(),...n.matrix.elements,...n.matrixWorld.elements]).buffer));hash.update(JSON.stringify([n.visible,n.matrixAutoUpdate,n.matrixWorldNeedsUpdate]));});for(const p of d.parts){hash.update(p.name);hash.update(Buffer.from(new Float64Array([...p.position.toArray(),...p.quaternion.toArray(),...p.scale.toArray()]).buffer));}frames++;}
 snap();h.game.begin(true);h.key('ShiftLeft');h.key('KeyW');for(let i=0;i<20;i++){h.frames(1);snap();}h.release('KeyW');h.key('KeyE');for(let i=0;i<54;i++){h.frames(1);snap();}assert.equal(h.qa.skills.phase,'E_Hold');h.punch();for(let i=0;i<90;i++){h.frames(1);snap();}h.key('KeyR');for(let i=0;i<75;i++){h.frames(1);snap();}assert.equal(h.qa.skills.metrics.discharges,1);
 h.game.begin(true,false,true);for(let i=0;i<120;i++){h.frames(1);snap();}assert(h.qa.duel.active);
 console.log(JSON.stringify({mode,frames,sha256:hash.digest('hex'),assets:h.qa.assets,bindings:Object.fromEntries(Object.entries(bound.skillClips).map(([k,v])=>[k,Object.keys(v)])),note:'Actual main/Three with mocked DOM/renderer/audio; no GPU or physical device.'}));
}
