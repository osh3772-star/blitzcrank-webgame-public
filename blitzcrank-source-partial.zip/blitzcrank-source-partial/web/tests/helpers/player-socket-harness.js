import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createGameplayHarness} from './runtime-harness.js';
// Frozen v0.24.43 socket queries. Do not derive the oracle from current main.js.
const reference = `
function legacyCableSocket(){if(thirdPerson){const elbow=fullbodyMeshes.get('BC_Elbow.R');fullbody.updateMatrixWorld(true);return elbow.localToWorld(elbow.geometry.boundingBox.getCenter(new THREE.Vector3()));}const conversion=viewToWorldMatrix(),elbow=parts.find(p=>p.name==='VM_Elbow.R');return elbow.geometry.boundingBox.getCenter(new THREE.Vector3()).applyMatrix4(elbow.matrixWorld).applyMatrix4(conversion);}
function legacyFullbodyCableSocket(){const elbow=fullbodyMeshes.get('BC_Elbow.R');fullbody.updateMatrixWorld(true);return elbow.localToWorld(elbow.geometry.boundingBox.getCenter(new THREE.Vector3()));}
function legacyFullbodyChainSocket(){fullbody.updateMatrixWorld(true);return fullbodyNodes.get('BC_QLaunch.R').getWorldPosition(new THREE.Vector3());}
function legacyChainHandSocket(){if(thirdPerson){fullbody.updateMatrixWorld(true);return fullbodyNodes.get('BC_QLaunch.R').getWorldPosition(new THREE.Vector3());}fist.updateMatrixWorld(true);const index=projectileParts.findIndex(p=>p.name==='VM_ElbowForearmLink.R'),mesh=fist.children[index];return mesh.geometry.boundingBox.getCenter(new THREE.Vector3()).applyMatrix4(mesh.matrixWorld);}
`;
export async function createPlayerSocketHarness({sourcePath=new URL('../../main.js',import.meta.url)}={}) {
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'player-socket-harness-')),instrumented=path.join(directory,'main.js');
 const source=fs.readFileSync(sourcePath,'utf8')+'\n'+reference+`
window.__PLAYER_SOCKET_RUNTIME__={
 current:{cableSocket,fullbodyCableSocket,fullbodyChainSocket,chainHandSocket},
 legacy:{cableSocket:legacyCableSocket,fullbodyCableSocket:legacyFullbodyCableSocket,fullbodyChainSocket:legacyFullbodyChainSocket,chainHandSocket:legacyChainHandSocket},
 aim,syncCamera,prepareMirrorBody,restoreMirrorBody,
 get data(){return{fullbody,fullbodySocket,hook,scene,fist,rope,fullbodyNodes,fullbodyMeshes,player,camera,viewmodel,skills}}};`;
 fs.writeFileSync(instrumented,source);
 try {const h=await createGameplayHarness({sourcePath:instrumented});return {...h,sockets:globalThis.__PLAYER_SOCKET_RUNTIME__};}
 finally {fs.rmSync(directory,{recursive:true,force:true});}
}
