import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import * as THREE from '../vendor/three.module.js';
import {createGameplayHarness} from './helpers/runtime-harness.js';

// Portable test: copy this file to tests/. No production export or harness change.
// Executes the real game/Three scene with the existing CPU-only renderer adapter.
const directory=fs.mkdtempSync(path.join(os.tmpdir(),'particle-lifetime-'));
const sourcePath=path.join(directory,'instrumented-main.js');
const original=process.env.PARTICLE_LIFETIME_SOURCE || new URL('../main.js',import.meta.url);
fs.writeFileSync(sourcePath,fs.readFileSync(original,'utf8')+`
window.__PARTICLE_LIFETIME__={particles,returnToMenu,get data(){return{sparks,scene,turretArena,fist,rope,projectileParts,clipName,clipTime,oneShot}}};`);
let h;
try {h=await createGameplayHarness({sourcePath});}
finally {fs.rmSync(directory,{recursive:true,force:true});}
const extra=window.__PARTICLE_LIFETIME__,records=new Map();
function observe(){
 for(const s of extra.data.sparks)for(const resource of [s.mesh.geometry,s.mesh.material]){
  if(records.has(resource))continue;
  const record={count:0};records.set(resource,record);
  resource.addEventListener('dispose',()=>{
   record.count++;
   assert.equal(record.count,1,'a resource is disposed only once');
   assert(!extra.data.sparks.some(p=>p.mesh.parent===extra.data.scene&&(p.mesh.geometry===resource||p.mesh.material===resource)),'never dispose a resource still attached through a live particle');
  });
 }
 for(const s of extra.data.sparks){
  assert.equal(s.mesh.parent,extra.data.scene);
  assert.equal(records.get(s.mesh.geometry).count,0);
  assert.equal(records.get(s.mesh.material).count,0);
 }
}
function frames(n){for(let i=0;i<n;i++){h.frames(1);observe();}}
function clean(){h.game.begin(true);assert.equal(extra.data.sparks.length,0);for(const r of records.values())assert.equal(r.count,1);records.clear();}
function burst(color=0x9affdc){const start=extra.data.sparks.length;extra.particles(new THREE.Vector3(1,2,3),color);observe();return extra.data.sparks.slice(start);}
function disposed(s){return [records.get(s.mesh.geometry).count,records.get(s.mesh.material).count];}
function snapshot(){return extra.data.sparks.map(s=>[s.life,...s.velocity.toArray(),...s.mesh.position.toArray(),...s.mesh.quaternion.toArray(),...s.mesh.scale.toArray(),...s.mesh.material.color.toArray(),s.mesh.material.opacity]);}
function score(){const s=h.qa.session;return{score:s.score,catches:s.catches,hits:s.hits,punches:s.punches,combo:s.combo};}
function assertQRestored(){
 assert.equal(h.qa.hook,null);assert.equal(extra.data.fist.visible,false);assert.equal(extra.data.rope.visible,false);
 assert(extra.data.projectileParts.every(p=>p.visible));
 assert.equal(extra.data.clipName,'Idle');assert.equal(extra.data.clipTime,0);assert.equal(extra.data.oneShot,0);
 assert(h.qa.targets.every(t=>!t.captured));
 const q=h.game.data.fullbodyNodes.get('BC_QLaunch.R');
 assert.deepEqual(q.position.toArray(),q.userData.base);assert.deepEqual(q.quaternion.toArray(),[0,0,0,1]);
}

test('one burst shares one geometry/material across sixteen independently transformed meshes',()=>{
 clean();const a=burst(),b=burst();
 assert.equal(a.length,16);assert.equal(new Set(a.map(s=>s.mesh)).size,16);assert.equal(new Set(a.map(s=>s.velocity)).size,16);
 assert.equal(new Set(a.map(s=>s.mesh.geometry)).size,1);assert.equal(new Set(a.map(s=>s.mesh.material)).size,1);
 assert.notEqual(a[0].mesh.geometry,b[0].mesh.geometry);assert.notEqual(a[0].mesh.material,b[0].mesh.material,'even equal-color calls have independent ownership');
 const geometry=Array.from(a[0].mesh.geometry.attributes.position.array),color=a[0].mesh.material.color.toArray();
 frames(10);assert.deepEqual(Array.from(a[0].mesh.geometry.attributes.position.array),geometry);assert.deepEqual(a[0].mesh.material.color.toArray(),color);
 a[0].mesh.scale.setScalar(.1);assert.notEqual(a[0].mesh.scale.x,a[1].mesh.scale.x);
 clean();
});

test('shortened single-particle lifetime leaves the other fifteen resources live; restart disposes once',()=>{
 clean();const a=burst();a[0].life=1/120;frames(1);
 assert.equal(extra.data.sparks.length,15);assert.equal(a[0].mesh.parent,null);assert.deepEqual(disposed(a[0]),[0,0]);
 assert.equal(a[1].batch.remaining,15);
 h.game.begin(true);assert.equal(extra.data.sparks.length,0);assert.deepEqual(disposed(a[0]),[1,1]);
 h.game.begin(true);assert.deepEqual(disposed(a[0]),[1,1]);clean();
});

test('the final natural expiry disposes shared resources after fifteen earlier expirations',()=>{
 clean();const a=burst();for(const s of a.slice(0,15))s.life=1/120;frames(1);
 assert.equal(extra.data.sparks.length,1);assert.equal(a[15].batch.remaining,1);assert.deepEqual(disposed(a[15]),[0,0]);
 a[15].life=1/120;frames(1);assert.equal(extra.data.sparks.length,0);assert.deepEqual(disposed(a[15]),[1,1]);
 frames(3);assert.deepEqual(disposed(a[15]),[1,1]);clean();
});

test('different-color overlapping bursts retain separate resources as the older burst expires',()=>{
 clean();const a=burst(0x9affdc),aColor=a[0].mesh.material.color.toArray();frames(25);
 const b=burst(0xf3ca65),bColor=b[0].mesh.material.color.toArray();
 assert.notDeepEqual(aColor,bColor);assert.notEqual(a[0].mesh.material,b[0].mesh.material);
 frames(16);assert(extra.data.sparks.every(s=>b.includes(s)));assert.equal(extra.data.sparks.length,16);
 assert.deepEqual(disposed(a[0]),[1,1]);assert.deepEqual(disposed(b[0]),[0,0]);
 assert.deepEqual(a[0].mesh.material.color.toArray(),aColor);assert.deepEqual(b[0].mesh.material.color.toArray(),bColor);
 clean();
});

test('pause freezes a partially expired burst and resume expires its remaining resources exactly once',()=>{
 clean();const a=burst();a[0].life=1/120;frames(1);h.game.pause();const before=snapshot();
 frames(90);assert.deepEqual(snapshot(),before);assert.deepEqual(disposed(a[0]),[0,0]);
 h.game.resume();frames(45);assert.equal(extra.data.sparks.length,0);assert.deepEqual(disposed(a[0]),[1,1]);clean();
});

test('results and menu preserve frozen particles until the next begin without re-disposal',()=>{
 for(const end of ['results','menu']){
  clean();const a=burst();a[0].life=1/120;frames(1);const b=burst(0xf3ca65);
  if(end==='results')h.game.finish();else{h.game.pause();extra.returnToMenu();}
  const before=snapshot();frames(90);assert.equal(h.qa.state,end);assert.deepEqual(snapshot(),before);
  assert.deepEqual(disposed(a[0]),[0,0]);assert.deepEqual(disposed(b[0]),[0,0]);
  h.game.begin(true);assert.equal(extra.data.sparks.length,0);assert.deepEqual(disposed(a[0]),[1,1]);assert.deepEqual(disposed(b[0]),[1,1]);
  h.game.begin(true);assert.deepEqual(disposed(a[0]),[1,1]);clean();
 }
});

test('pointer-lock wait and graphics-context interruption retain resources without advancing particles',()=>{
 clean();const a=burst();document.pointerLockElement=null;const before=snapshot();frames(15);assert.deepEqual(snapshot(),before);assert.deepEqual(disposed(a[0]),[0,0]);
 h.element('game').requestPointerLock();frames(1);assert.notDeepEqual(snapshot(),before);
 h.element('game').listeners.webglcontextlost({preventDefault(){}});const frozen=snapshot();frames(30);assert.deepEqual(snapshot(),frozen);assert.deepEqual(disposed(a[0]),[0,0]);
 h.element('game').listeners.webglcontextrestored({});frames(10);assert.deepEqual(snapshot(),frozen);
 h.game.resume();frames(45);assert.equal(extra.data.sparks.length,0);assert.deepEqual(disposed(a[0]),[1,1]);clean();
});

for(const third of [false,true])test(`${third?'third-person':'FPS'} actual lethal turret callback cancels Q and retains partial overlapping bursts until restart`,()=>{
 clean();if((h.qa.view==='third')!==third)h.key('KeyV');frames(1);h.key('KeyQ');
 for(let i=0;i<180&&h.qa.hook?.phase!=='return';i++)frames(1);
 assert.equal(h.qa.hook?.phase,'return');assert.equal(h.game.data.hook.target?.captured,true);
 const a=extra.data.sparks.slice();assert.equal(a.length,16);const b=burst(0xdfbd6b);
 a[0].life=1/120;frames(1);assert.equal(extra.data.sparks.length,31);assert.deepEqual(disposed(a[0]),[0,0]);
 const before=snapshot(),scored=score();h.game.setHealth(18);const {sim}=extra.data.turretArena,player=h.game.data.player;
 for(const id of [9001,9002])sim.bullets.push({id,turretId:'west',position:{x:player.x,y:player.y-.55,z:player.z},velocity:{x:0,y:0,z:0},age:0,active:true});
 frames(1);assert.equal(h.qa.state,'results');assert.equal(h.qa.health,0);assertQRestored();assert.deepEqual(score(),scored);
 assert.equal(sim.bullets.length,0);assert.equal(h.qa.turrets.warning,false);assert.deepEqual(snapshot(),before);
 frames(90);assert.deepEqual(snapshot(),before);assert.deepEqual(disposed(a[0]),[0,0]);assert.deepEqual(disposed(b[0]),[0,0]);
 h.game.begin(true);assert.equal(extra.data.sparks.length,0);assert.deepEqual(disposed(a[0]),[1,1]);assert.deepEqual(disposed(b[0]),[1,1]);
 h.key('KeyQ');frames(150);assert.equal(h.qa.session.catches,1);assert.equal(h.qa.session.score,100);assert.equal(h.qa.hook,null);clean();
});
