import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
let dt=1/60;const h=await createGameplayHarness({delta:()=>dt});
function fresh(mode,hz){
 dt=1/hz;h.game.begin(true);h.frames(1);
 if(mode==='duel'){
  h.element('duelmode').click();h.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,jump:false})});
  assert.equal(h.game.castFlash(),false);assert.equal(h.qa.flashAbility.casts,0);
  for(let i=0;i<2*hz&&h.qa.duel.match.phase!=='active';i++)h.frames(1);
  assert.equal(h.qa.duel.match.phase,'active');
 }else for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}
}
for(const mode of ['solo','duel'])for(const hz of [30,60,120])test(`${mode} Flash actual cast, exact 15s HUD and recast at ${hz}Hz`,()=>{
 fresh(mode,hz);h.key('KeyF');h.release('KeyF');assert.equal(h.qa.flashAbility.casts,1);
 h.frames(15*hz-1);assert(h.qa.flashAbility.remaining>0);assert.equal(h.game.castFlash(),false);h.frames(1);
 const status=h.qa.flashAbility,hud=h.element('flashstatus').textContent,disabled=h.element('flashbutton').attributes['aria-disabled'];
 h.key('KeyF');h.release('KeyF');const casts=h.qa.flashAbility.casts;
 console.log(JSON.stringify({scope:'runtime',mode,hz,frames:15*hz,status,hud,disabled,casts}));
 assert.equal(status.remaining,0);assert(status.ready);assert.equal(hud,'준비');assert.equal(disabled,'false');assert.equal(casts,2);
});
for(const mode of ['solo','duel'])test(`${mode} Flash pauses, capture waits, genuine early input and reset remain correct`,()=>{
 fresh(mode,60);assert(h.game.castFlash());h.frames(899);
 h.game.pause();const frozen=h.qa.flashAbility;h.frames(30);assert.deepEqual(h.qa.flashAbility,frozen);assert.equal(h.game.castFlash(),false);h.game.resume();
 document.pointerLockElement=null;h.game.updateHud();h.frames(30);assert.deepEqual(h.qa.flashAbility,frozen);
 document.pointerLockElement=h.element('game');h.docListeners.pointerlockchange();dt=frozen.remaining-1e-9;h.frames(1);
 assert(h.qa.flashAbility.remaining>9.9e-10);assert.equal(h.game.castFlash(),false);assert.equal(h.element('flashstatus').textContent,'1초');
 dt=1e-9+1e-14;h.frames(1);assert.equal(h.qa.flashAbility.remaining,0);assert.equal(h.element('flashstatus').textContent,'준비');assert(h.game.castFlash());
 h.game.begin(true);assert.equal(h.qa.flashAbility.remaining,0);assert.equal(h.qa.flashAbility.casts,0);
});
