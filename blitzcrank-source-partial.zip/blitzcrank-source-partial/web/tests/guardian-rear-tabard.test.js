import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import * as THREE from '../vendor/three.module.js';import {GLTFLoader} from '../vendor/GLTFLoader.js';import {TARGET_MODEL_FILES} from '../target-models.js';
const load=async path=>{const b=fs.readFileSync(new URL(path,import.meta.url));const json=JSON.parse(b.subarray(20,20+b.readUInt32LE(12)).toString());const gltf=await new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');gltf.scene.updateMatrixWorld(true);return{scene:gltf.scene,json};};
const before=await load('../validation/reference-models-v2423/guardian-v2422.glb'),after=await load('../assets/targets/'+TARGET_MODEL_FILES.guardian);
// Keep the preserved rear-tabard-only geometry contract; current face scope is tested separately.
const historicalRear=await load('../validation/recovered-assets/guardian.638195a23537033b.glb');
const hit=(model,origin,direction)=>new THREE.Raycaster(new THREE.Vector3(...origin),new THREE.Vector3(...direction)).intersectObject(model.scene,true)[0];
for(const [label,origin,expected] of [['lower gold',[0,.08,-3],'Ochre gold fabric'],['side gold',[.32,.35,-3],'Ochre gold fabric'],['stepped gold',[.25,.22,-3],'Ochre gold fabric'],['blue inset',[0,.42,-3],'Cobalt blue enamel']])test(`guardian rear reference ${label} is an actual visible surface`,()=>{
 const a=hit(before,origin,[0,0,1]),b=hit(after,origin,[0,0,1]);assert.equal(a.object.material.name,'Royal blue cloth');assert.equal(b.object.material.name,expected);assert(a.point.distanceTo(b.point)<.0001,'only tiny existing nonplanar-face re-triangulation tolerance');
});
for(const [label,origin,direction,material] of [['front tabard',[0,.4,3],[0,0,-1],'Cobalt blue enamel'],['rear shoulder',[.85,1.8,-3],[0,0,1],'Pale steel armor'],['side cloth',[-3,.4,0],[1,0,0],'Royal blue cloth']])test(`guardian ${label} keeps its exact first surface`,()=>{
 const a=hit(before,origin,direction),b=hit(after,origin,direction);assert.equal(b.object.material.name,material);assert.equal(a.object.material.name,material);assert.deepEqual(b.point.toArray(),a.point.toArray());
});
test('historical guardian material definitions, node transforms and six untouched material geometries remain identical',()=>{
 const after=historicalRear;
 assert.deepEqual(after.json.materials,before.json.materials);assert.deepEqual(after.json.nodes,before.json.nodes);assert.equal(after.json.meshes.length,1);assert.equal(after.json.meshes[0].primitives.length,9);
 const geometries=model=>{const result={};model.scene.traverse(n=>{if(n.isMesh)result[n.material.name]=n.geometry;});return result;},a=geometries(before),b=geometries(after);let count=0;
 for(const name of Object.keys(a))if(!['Royal blue cloth','Ochre gold fabric','Cobalt blue enamel'].includes(name)){
  assert.deepEqual(b[name].index.array,a[name].index.array,name+' indices');assert.deepEqual(Object.keys(b[name].attributes),Object.keys(a[name].attributes));
  for(const key of Object.keys(a[name].attributes))assert.deepEqual(b[name].attributes[key].array,a[name].attributes[key].array,name+' '+key);count++;
 }
 assert.equal(count,6);
});
test('historical guardian bounded rear detail adds 202 triangles without animations, textures or external resources',()=>{
 const after=historicalRear;
 const triangles=model=>{let count=0;model.scene.traverse(n=>{if(n.isMesh)count+=n.geometry.index.count/3;});return count;};assert.equal(triangles(before),4632);assert.equal(triangles(after),4834);assert.equal((after.json.animations||[]).length,0);assert.equal((after.json.images||[]).length,0);assert(after.json.buffers.every(buffer=>!buffer.uri));
});
