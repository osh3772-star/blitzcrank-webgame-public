import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import crypto from 'node:crypto';
import * as THREE from '../vendor/three.module.js';import {GLTFLoader} from '../vendor/GLTFLoader.js';import {TURRET_MODEL_FILE,createTurretArena} from '../turret-view.js';
const load=async name=>{const b=fs.readFileSync(new URL('../assets/turret/'+name,import.meta.url)),len=b.readUInt32LE(12),json=JSON.parse(b.subarray(20,20+len)),bin=b.subarray(28+len),{scene}=await new GLTFLoader().parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),'');scene.updateMatrixWorld(true);const meshes={};scene.traverse(n=>{if(n.isMesh)meshes[n.parent.name+'/'+n.material.name]=n;});return{b,json,bin,scene,meshes};};
const old=await load('turret.5a9fd4b0b1c143e9.glb'),next=await load(TURRET_MODEL_FILE),patches=JSON.parse(fs.readFileSync(new URL('../validation/turret-stone-weathering/patch-centers.json',import.meta.url))),slate=n=>n.startsWith('StaticTower_Geometry/Slate masonry '),moss='StaticTower_Geometry/Moss in stone joints';
test('current weathered model is content-addressed, aligned, embedded and uses the same draw batches',()=>{
 assert.equal(TURRET_MODEL_FILE,'turret.'+crypto.createHash('sha256').update(next.b).digest('hex').slice(0,16)+'.glb');assert.equal(next.b.length,502440);assert.equal(next.b.length%4,0);assert.equal(next.b.readUInt32LE(8),next.b.length);assert.equal(next.bin.length%4,0);assert.equal(next.json.buffers[0].byteLength,next.bin.length);
 assert(next.json.buffers.every(b=>!b.uri));for(const k of['images','textures','animations','skins'])assert.equal((next.json[k]||[]).length,0,k);assert.equal(next.json.meshes.length,3);assert.equal(Object.keys(next.meshes).length,22);assert.equal(next.json.materials.length,16);assert.equal(next.json.meshes.flatMap(m=>m.primitives).reduce((sum,p)=>sum+next.json.accessors[p.indices].count/3,0),6277);
});
test('original hierarchy, material factors and full model bounds are exact',()=>{
 for(const k of['nodes','materials','scenes','scene'])assert.deepEqual(next.json[k],old.json[k]);assert.deepEqual(new THREE.Box3().setFromObject(next.scene),new THREE.Box3().setFromObject(old.scene));
});
test('all original decoded triangles, positions, normals and UVs survive, and only stone color or moss is appended',()=>{
 let unchanged=0,addedVertices=0,addedIndices=0;
 for(const[n,a]of Object.entries(old.meshes)){
  const b=next.meshes[n],ag=a.geometry,bg=b.geometry;assert.deepEqual(bg.index.array.subarray(0,ag.index.count),ag.index.array,n);
  for(const[k,at]of Object.entries(ag.attributes))assert.deepEqual(bg.attributes[k].array.subarray(0,at.array.length),at.array,n+' '+k);
  if(slate(n)){addedVertices+=bg.attributes.position.count-ag.attributes.position.count;addedIndices+=bg.index.count-ag.index.count;assert.deepEqual(bg.boundingBox,ag.boundingBox);}
  else{assert.equal(bg.index.count,ag.index.count);assert.equal(bg.attributes.position.count,ag.attributes.position.count);}
  if(slate(n))assert.deepEqual(Object.keys(bg.attributes).sort(),[...Object.keys(ag.attributes),'color'].sort());else{assert.deepEqual(Object.keys(bg.attributes),Object.keys(ag.attributes));unchanged++;}
 }assert.equal(unchanged,18);assert.equal(addedVertices,256);assert.equal(addedIndices,672);
});
test('lower-course color is opaque and bounded; upper tower, gold, shield and staff remain unchanged',()=>{
 let changed=0,total=0;
 for(const[n,m]of Object.entries(next.meshes))if(slate(n)){
  const g=m.geometry,c=g.attributes.color;assert.equal(c.itemSize,4);assert.equal(c.normalized,true);assert.equal(m.material.vertexColors,true);total+=c.count;
  for(let i=0;i<c.count;i++){
   const p=new THREE.Vector3().fromBufferAttribute(g.attributes.position,i).applyMatrix4(m.matrixWorld),rgba=[c.getX(i),c.getY(i),c.getZ(i),c.getW(i)];assert.equal(rgba[3],1);assert(rgba.every(x=>x>=0&&x<=1));if(p.y>=1.1)assert.deepEqual(rgba,[1,1,1,1]);if(rgba.some(x=>x!==1)){changed++;assert(p.y<1.1);assert(rgba[1]>=rgba[0]&&rgba[1]>=rgba[2]);}
  }
 }assert.equal(total,5651);assert.equal(changed,2944);
});
test('32 irregular moss patches follow original stone faces within the unchanged collision bounds',()=>{
 assert.equal(patches.length,32);const bounds=new THREE.Box3().setFromObject(old.scene);
 for(const[n,m]of Object.entries(next.meshes))if(slate(n)){const geom=m.geometry,oldCount=old.meshes[n].geometry.attributes.position.count;for(let i=oldCount;i<geom.attributes.position.count;i++){const p=new THREE.Vector3().fromBufferAttribute(geom.attributes.position,i).applyMatrix4(m.matrixWorld);assert(bounds.containsPoint(p));}}
 let visible=0;const stone=Object.entries(old.meshes).filter(([n])=>slate(n)).map(([,m])=>m);
 for(const p of patches){const center=new THREE.Vector3().fromArray(p.centerWorld),normal=new THREE.Vector3().fromArray(p.normalWorld),r=new THREE.Raycaster(center.clone().addScaledVector(normal,.05),normal.clone().negate(),0,.08),a=r.intersectObjects(stone),mesh=next.meshes['StaticTower_Geometry/'+p.material],b=r.intersectObject(mesh);assert(a.some(h=>Math.abs(h.distance-.05)<2e-6));assert(b.some(h=>Math.abs(h.distance-.0485)<2e-6));const full=r.intersectObject(next.scene,true)[0];if(full?.object===mesh&&full.faceIndex>=old.meshes['StaticTower_Geometry/'+p.material].geometry.index.count/3&&Math.abs(full.distance-.0485)<2e-6)visible++;}
 assert(visible>20); // Occluded source faces are not misreported as visible detail.
});
test('appended moss triangles have finite unit normals and nonzero face area',()=>{
 for(const[name,mesh]of Object.entries(next.meshes))if(slate(name)){const g=mesh.geometry,start=old.meshes[name].geometry.index.count;
 for(let k=start;k<g.index.count;k+=3){const ids=[g.index.getX(k),g.index.getX(k+1),g.index.getX(k+2)],ps=ids.map(i=>new THREE.Vector3().fromBufferAttribute(g.attributes.position,i));assert(ps[1].clone().sub(ps[0]).cross(ps[2].clone().sub(ps[0])).length()>1e-8);for(const i of ids){const n=new THREE.Vector3().fromBufferAttribute(g.attributes.normal,i);assert(Math.abs(n.length()-1)<1e-6);}}}
});
test('weathering preserves moving-contact damage, aiming, range, recoil and cover across 1200 steps',()=>{
 const make=asset=>{const scene=new THREE.Scene(),obstacles=[],damage=[];return{scene,obstacles,damage,arena:createTurretArena(scene,asset,obstacles,{onDamage:(n,e)=>damage.push([n,e])})};};const a=make(old.scene),b=make(next.scene);assert.deepEqual(a.obstacles,b.obstacles);let previous={x:-8,y:1.7,z:-12},shots=0;
 for(let i=0;i<1200;i++){
  if(i===400)for(const h of[a,b])h.obstacles.push({min:new THREE.Vector3(-11,0,-16),max:new THREE.Vector3(-9,10,-13)});if(i===500)for(const h of[a,b])h.obstacles.pop();if(i===700)for(const h of[a,b])h.arena.reset();
  const p={x:-8+Math.sin(i*.01),y:1.7+Math.sin(i*.013)*.1,z:-12},dt=i%37===0?0:[1/120,1/60,1/30,.05][i%4],ae=a.arena.step(dt,p,true,previous),be=b.arena.step(dt,p,true,previous);assert.deepEqual(be,ae);shots+=ae.filter(e=>e.type==='shot').length;assert.deepEqual(b.arena.sim.bullets,a.arena.sim.bullets);
  for(const id of['west','east']){const av=a.arena.visuals.get(id),bv=b.arena.visuals.get(id);assert.deepEqual(bv.muzzle.matrixWorld.elements,av.muzzle.matrixWorld.elements);assert.deepEqual(bv.barrel.position,av.barrel.position);}previous=p;
 }assert(shots>3);assert(a.damage.length>0);assert.deepEqual(b.damage,a.damage);
});
test('parent transforms and repeated arena reset preserve identical world colliders and sockets',()=>{
 for(const yaw of[-.4,0,.7]){const create=asset=>{const s=new THREE.Scene();s.position.set(2,.4,-1);s.rotation.y=yaw;s.scale.set(1.2,.9,.8);const boxes=[],a=createTurretArena(s,asset,boxes);a.step(.1,{x:-8,y:1.7,z:-12});a.reset();a.step(.01,{x:-8,y:1.7,z:-12});return{boxes,m:[...a.visuals.values()].map(v=>v.muzzle.matrixWorld.elements)};};assert.deepEqual(create(next.scene),create(old.scene));}
});
