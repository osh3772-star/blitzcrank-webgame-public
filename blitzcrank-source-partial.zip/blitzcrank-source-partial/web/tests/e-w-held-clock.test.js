import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';

test('active E plus W zero-time refresh preserves acquisition ramp and pose across observed gait wrapping',async()=>{
 let dt=1/60;const h=await createGameplayHarness({delta:()=>dt});h.game.begin(true);h.frames(1);
 for(const target of h.game.data.targets){target.active=false;target.respawn=Infinity;target.group.visible=false;}
 h.key('ShiftLeft');h.key('KeyW');h.key('KeyE');
 while(h.qa.skills.phase==='E_Charge')h.frames(1);
 assert.equal(h.qa.skills.phase,'E_Hold');assert(h.qa.skills.boost>0);h.frames(3);
 const snap=()=>({skills:h.qa.skills,player:h.qa.player,motion:h.qa.motion.locomotion,parts:h.game.data.parts.map(p=>[p.position.toArray(),p.quaternion.toArray(),p.scale.toArray()])});
 const before=snap();dt=0;h.frames(12);assert.deepEqual(snap(),before);dt=1/60;
 let previous=h.qa.motion.locomotion.phase,wrapped=false;
 for(let i=0;i<40;i++){h.frames(1);const phase=h.qa.motion.locomotion.phase;wrapped||=phase<previous;previous=phase;for(const p of h.game.data.parts){p.updateMatrix();assert(p.matrix.elements.every(Number.isFinite));}}
 assert(wrapped,'actual collision-resolved gait must wrap during the moving E/W observation');
 assert.equal(h.qa.skills.phase,'E_Hold');assert(h.qa.skills.boost>0);
});
