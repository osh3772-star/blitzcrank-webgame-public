import test from 'node:test';import assert from 'node:assert/strict';import {createMouseLook} from '../mouse-look.js';
class Events{constructor(){this.handlers=new Map();}addEventListener(name,fn){const a=this.handlers.get(name)||[];a.push(fn);this.handlers.set(name,a);}removeEventListener(name,fn){this.handlers.set(name,(this.handlers.get(name)||[]).filter(x=>x!==fn));}dispatch(name,e={}){for(const fn of this.handlers.get(name)||[])fn(e);}}
function fixture(){const doc=new Events(),canvas=new Events();doc.pointerLockElement=null;canvas.style={};const q={running:true,looks:[],punches:0,losses:0,fallbacks:[],requests:0,activity:0};canvas.requestPointerLock=()=>{q.requests++;return Promise.resolve();};const input=createMouseLook({canvas,doc,isRunning:()=>q.running,onLook:(x,y)=>q.looks.push([x,y]),onPunch:()=>q.punches++,onLockLost:()=>q.losses++,onFallback:r=>q.fallbacks.push(r),onMouseActivity:()=>q.activity++});return{doc,canvas,q,input};}
test('unlocked hover never aims and keeps cursor visible',()=>{const{doc,canvas,q,input}=fixture();doc.dispatch('mousemove',{target:canvas,movementX:24,movementY:-9,buttons:0});assert.deepEqual(q.looks,[]);assert.equal(canvas.style.cursor,'');assert.equal(input.mode,'free');});
test('pointer lock uses relative motion once even when browser emits pointermove then mousemove',()=>{const{doc,canvas,q,input}=fixture();doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');assert.equal(input.mode,'locked');canvas.dispatch('pointermove',{pointerType:'mouse',movementX:30,movementY:10});doc.dispatch('mousemove',{target:doc,movementX:30,movementY:10,clientX:640,clientY:360});assert.deepEqual(q.looks,[[30,10]]);});
test('either first mouse button captures without punching; only captured left button punches',()=>{
 for(const button of [0,2]){const{doc,canvas,q}=fixture();canvas.dispatch('pointerdown',{pointerType:'mouse',button});assert.equal(q.requests,1);assert.equal(q.punches,0);doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');assert.equal(q.punches,0);canvas.dispatch('pointerdown',{pointerType:'mouse',button:2});assert.equal(q.punches,0);canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,1);}
});
test('synchronous capture completion still does not punch on the capture gesture',()=>{
 const{doc,canvas,q}=fixture();canvas.requestPointerLock=()=>{q.requests++;doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');};canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.requests,1);assert.equal(q.punches,0);canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,1);
});
test('waiting for a lock prevents duplicate requests and never queues a punch',async()=>{
 const{doc,canvas,q,input}=fixture();let grant;canvas.requestPointerLock=()=>{q.requests++;return new Promise(resolve=>{grant=resolve;});};
 for(const button of [2,0,2])canvas.dispatch('pointerdown',{pointerType:'mouse',button});assert.equal(input.pending,true);assert.equal(q.requests,1);assert.equal(q.punches,0);
 grant();await Promise.resolve();assert.equal(input.pending,false);assert.equal(q.punches,0);assert.equal(input.mode,'free');
 doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');assert.equal(q.punches,0);canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,1);
});
test('left button needs the actual canvas lock, not a stale mode or another element lock',()=>{
 const{doc,canvas,q,input}=fixture();doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,1);
 doc.pointerLockElement=null;assert.equal(input.mode,'locked');canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,1);doc.dispatch('pointerlockchange');assert.equal(q.losses,1);
 doc.pointerLockElement=new Events();doc.dispatch('pointerlockchange');canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,1);
});
test('inactive play ignores both mouse buttons before and after capture',()=>{
 const{doc,canvas,q}=fixture();q.running=false;for(const locked of [false,true]){doc.pointerLockElement=locked?canvas:null;for(const button of [0,2])canvas.dispatch('pointerdown',{pointerType:'mouse',button});}assert.equal(q.punches,0);assert.equal(q.requests,0);assert.equal(q.activity,0);
});
test('middle, other, missing buttons and touch events stay untouched in either lock state',()=>{
 const{doc,canvas,q}=fixture();let prevented=0;for(const locked of [false,true]){doc.pointerLockElement=locked?canvas:null;doc.dispatch('pointerlockchange');for(const button of [1,3,4,-1,undefined])canvas.dispatch('pointerdown',{pointerType:'mouse',button,preventDefault(){prevented++;}});for(const button of [0,2])canvas.dispatch('pointerdown',{pointerType:'touch',button,preventDefault(){prevented++;}});canvas.dispatch('pointerdown',{pointerType:'mouse',button:0,sourceCapabilities:{firesTouchEvents:true}});}assert.equal(q.punches,0);assert.equal(q.requests,0);assert.equal(q.activity,0);assert.equal(prevented,0);
});
test('mousedown, click, auxclick, and contextmenu cannot duplicate a left-button punch',()=>{
 const{doc,canvas,q}=fixture();doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});for(const name of ['mousedown','pointerup','mouseup','click','auxclick','contextmenu'])canvas.dispatch(name,{pointerType:'mouse',button:0});assert.equal(q.punches,1);
});
test('pointer input outside the canvas is not intercepted and disposal removes its handler',()=>{
 const{doc,canvas,q,input}=fixture();doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');doc.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,0);input.dispose();canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,0);
});
test('rejected capture never punches or retries without another explicit gesture',async()=>{
 const{canvas,q,input}=fixture();canvas.requestPointerLock=()=>{q.requests++;return Promise.reject(new Error('NotAllowedError'));};canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});await Promise.resolve();assert.equal(q.requests,1);assert.equal(q.punches,0);assert.equal(input.pending,false);assert.deepEqual(q.fallbacks,['denied']);canvas.dispatch('contextmenu',{button:0});canvas.dispatch('click',{button:0});assert.equal(q.requests,1);assert.equal(q.punches,0);
});
test('denied lock keeps cursor visible and does not accept FPS look',async()=>{const{doc,canvas,q,input}=fixture();canvas.requestPointerLock=()=>Promise.reject(new Error('NotAllowedError'));input.request();doc.dispatch('pointerlockerror');await Promise.resolve();assert.equal(input.mode,'free');assert.equal(canvas.style.cursor,'');assert.equal(q.losses,0);assert.equal(q.fallbacks.length,1);doc.dispatch('mousemove',{target:canvas,movementX:19,movementY:3});assert.deepEqual(q.looks,[]);delete canvas.requestPointerLock;input.request();assert.equal(input.mode,'free');});
test('only loss of a previously acquired lock pauses, once; intentional paused release does not',()=>{const{doc,canvas,q}=fixture();doc.dispatch('pointerlockchange');assert.equal(q.losses,0);doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');doc.pointerLockElement=null;doc.dispatch('pointerlockchange');doc.dispatch('pointerlockchange');assert.equal(q.losses,1);doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');q.running=false;doc.pointerLockElement=null;doc.dispatch('pointerlockchange');assert.equal(q.losses,1);});
test('cursor is hidden only for real active capture and restored on pause or release',()=>{const{doc,canvas,q,input}=fixture();doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');assert.equal(canvas.style.cursor,'none');q.running=false;input.refresh();assert.equal(canvas.style.cursor,'');q.running=true;input.refresh();assert.equal(canvas.style.cursor,'none');doc.pointerLockElement=null;doc.dispatch('pointerlockchange');assert.equal(canvas.style.cursor,'');});
test('touch compatibility mouse events never rotate a captured camera',()=>{const{doc,canvas,q}=fixture();doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');doc.dispatch('mousemove',{target:canvas,movementX:20,movementY:5,sourceCapabilities:{firesTouchEvents:true}});assert.equal(q.looks.length,0);});

test('a late lock grant after pause is immediately released instead of trapping the cursor',()=>{const{doc,canvas,q,input}=fixture();let released=0;doc.exitPointerLock=()=>{released++;doc.pointerLockElement=null;doc.dispatch('pointerlockchange');};input.request();q.running=false;doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');assert.equal(released,1);assert.equal(input.mode,'free');assert.equal(q.losses,0);});

test('actual new capture focuses canvas once without scrolling; pending and repeat notifications do not',()=>{
 const{doc,canvas,q,input}=fixture();const focuses=[];canvas.focus=options=>focuses.push(options);input.request();assert.equal(focuses.length,0);doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');assert.deepEqual(focuses,[{preventScroll:true}]);doc.dispatch('pointerlockchange');assert.equal(focuses.length,1);doc.pointerLockElement=null;doc.dispatch('pointerlockchange');assert.equal(focuses.length,1);q.running=true;doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');assert.equal(focuses.length,2);
});
test('late capture after pause never steals focus',()=>{
 const{doc,canvas,q}=fixture();let focuses=0;canvas.focus=()=>focuses++;doc.exitPointerLock=()=>{doc.pointerLockElement=null;doc.dispatch('pointerlockchange');};q.running=false;doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');assert.equal(focuses,0);
});
test('optional canvas focus failure cannot break pointer-lock state or left punch',()=>{
 const{doc,canvas,q,input}=fixture();canvas.focus=()=>{throw Error('focus unavailable');};doc.pointerLockElement=canvas;assert.doesNotThrow(()=>doc.dispatch('pointerlockchange'));assert.equal(input.mode,'locked');canvas.dispatch('pointerdown',{pointerType:'mouse',button:0});assert.equal(q.punches,1);
});

for(const exitMode of ['absent','throws'])test(`unavailable release ${exitMode} does not block a later user capture`,()=>{
 const{doc,canvas,q,input}=fixture();doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');
 if(exitMode==='throws')doc.exitPointerLock=()=>{throw Error('unavailable');};
 assert.doesNotThrow(()=>input.release());
 // The failed release was not marked intentional; ordinary external loss still pauses.
 doc.pointerLockElement=null;input.request();assert.equal(q.requests,1);doc.dispatch('pointerlockchange');assert.equal(q.losses,1);
});
test('duplicate intentional release calls queue only one exit and never automatically recapture',()=>{
 const{doc,canvas,q,input}=fixture();let exits=0;doc.exitPointerLock=()=>exits++;doc.pointerLockElement=canvas;doc.dispatch('pointerlockchange');
 input.release();input.release();assert.equal(exits,1);doc.pointerLockElement=null;input.request();assert.equal(q.requests,0);doc.dispatch('pointerlockchange');assert.equal(q.losses,0);assert.equal(q.requests,0);input.request();assert.equal(q.requests,1);
});
