import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {PLAYER_MODELS} from '../player-model-manifest.js';

// Guard the measured v0.22 loading budget when replacing visual assets.
test('refined player assets preserve the optimized payload and cache identity',()=>{
 const sources=['viewmodel','fullbody'].map(name=>JSON.parse(fs.readFileSync(new URL(`../assets/blitz-${name}.json`,import.meta.url))));
 assert(PLAYER_MODELS.viewmodel.gzipBytes+PLAYER_MODELS.fullbody.gzipBytes<=4541517);
 assert(PLAYER_MODELS.viewmodel.bytes+PLAYER_MODELS.fullbody.bytes<=12490640);
 const textures=new Set(sources.flatMap(d=>d.parts.flatMap(p=>[p.material?.baseColorTexture,p.material?.roughnessTexture].filter(Boolean))));
 let bytes=0;
 for(const path of textures){
  const match=path.match(/\.([a-f0-9]{16})\.png$/);assert(match,`Content-addressed player texture: ${path}`);
  const data=fs.readFileSync(new URL('../'+path.slice(2),import.meta.url));bytes+=data.length;
  assert.equal(crypto.createHash('sha256').update(data).digest('hex').slice(0,16),match[1]);
 }
 assert.equal(textures.size,2);assert(bytes<=2340000);
 const triangles=sources.map(d=>d.parts.reduce((sum,p)=>sum+p.triangles.length/3,0));
 assert(triangles[0]<=96520);assert(triangles[1]<=144980);
 assert.equal(new Set(sources[0].parts.map(p=>p.sourcePart||p.name)).size,84);
 assert.equal(new Set(sources[1].parts.map(p=>p.sourcePart||p.name)).size,163);
});
