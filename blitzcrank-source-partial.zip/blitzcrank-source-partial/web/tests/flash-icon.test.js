import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {read,rules,style,scope,ui,interfaceRules} from './helpers/mobile-layout-model.js';
const root=new URL('../',import.meta.url),html=read('index.html'),css=read('flash-controls.css');
const parsed=rules(css),context={width:390,height:844},d=selector=>style(selector,context,parsed);
const source=JSON.parse(read('assets/ui/skills/flash-source-manifest.json'));
const button=html.match(/<button id="flashbutton"([^>]+)>([\s\S]*?)<\/button>/);

test('Flash uses unchanged official Data Dragon pixels with separate, limited provenance',()=>{
 assert.equal(source.publisher,'Riot Games');assert.equal(source.distribution,'Data Dragon');assert.equal(source.version,'16.22.1');
 const a=source.asset,b=fs.readFileSync(new URL('assets/ui/skills/'+a.filename,root));
 assert.equal(a.ability_id,'SummonerFlash');assert.equal(a.filename,'SummonerFlash.png');assert.equal(a.input_key,'F');
 assert.equal(a.source_url,'https://ddragon.leagueoflegends.com/cdn/16.22.1/img/spell/SummonerFlash.png');
 assert.equal(a.sha256,'1272fe7b3275c0afc872a6aaa6b65e27d41572d57f9ce19b9ed81b79aa5eb2aa');
 assert.equal(createHash('sha256').update(b).digest('hex'),a.sha256);
 assert.equal(b.length,6403);assert.equal(b.length,a.bytes);
 assert.equal(b.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
 assert.equal(b.readUInt32BE(16),64);assert.equal(b.readUInt32BE(20),64);
 assert.equal(a.width,64);assert.equal(a.height,64);assert.equal(a.source_bytes_modified,false);
 assert.match(source.rights.license_status,/does not establish permission/);
 assert.match(source.rights.authorized_scope,/owner-only private prototype/);
 assert.equal(JSON.parse(read('assets/ui/skills/source-manifest.json')).assets.length,4,'existing QWER provenance is not repurposed');
});

test('Flash has one real icon, a separate name, F hint and described live cooldown',()=>{
 assert(button);assert.match(button[1],/type="button"/);assert.match(button[1],/aria-describedby="flashstatus"/);
 assert.match(button[1],/aria-label="점멸, F 키, 재사용 대기시간 15초,/);
 assert.match(button[1],/출발 영상 프레임과 선택 녹음 사용, 도착 효과 미연결/);
 const images=[...button[2].matchAll(/<img\b([^>]+)>/g)];assert.equal(images.length,1);
 for(const attr of ['class="flash-icon"','src="assets/ui/skills/SummonerFlash.png"','alt=""','width="64"','height="64"','draggable="false"'])assert(images[0][1].includes(attr),attr);
 assert.match(button[2],/<span class="flash-name">점멸<\/span>/);
 assert.match(button[2],/<small id="flashstatus">준비<\/small>/);
 assert.match(button[2],/<b class="keyboard-hint" aria-hidden="true">F<\/b>/);
 assert.equal((html.match(/src="assets\/ui\/skills\/SummonerFlash.png"/g)||[]).length,1);
});

test('original Flash artwork is contained and does not intercept interaction or change on cooldown',()=>{
 const art=d('#flashbutton .flash-icon');
 assert.equal(art.width,'32px');assert.equal(art.height,'32px');assert.equal(art['object-fit'],'contain');
 assert.equal(art['pointer-events'],'none');assert.equal(art['user-select'],'none');assert.equal(art['border-radius'],'0');
 assert.equal(d('#flashbutton')['touch-action'],'none');assert.equal(d('#flashbutton .flash-copy')['pointer-events'],'none');
 assert.equal(d('#flashbutton[aria-disabled="true"]').opacity,'1','cooldown never fades the icon or text');
 for(const r of parsed)for(const property of ['filter','clip-path','mask','mask-image','mix-blend-mode','animation'])assert(!(property in r.declarations),`${property} must not alter the art`);
 assert(!/object-fit\s*:\s*cover|data:|url\(/.test(css));
 assert.equal(d('#flashbutton:focus-visible').outline,'2px solid #f0cd83');
 assert.equal(d('#flashbutton:focus-visible')['outline-offset'],'2px');
});

test('Flash labels and cooldown retain strong contrast in ready and cooling states',()=>{
 const luminance=hex=>{const c=hex.slice(1).match(/../g).map(s=>parseInt(s,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return c[0]*.2126+c[1]*.7152+c[2]*.0722;};
 const contrast=(a,b)=>{const l=[luminance(a),luminance(b)].sort((x,y)=>y-x);return(l[0]+.05)/(l[1]+.05);};
 assert(contrast(d('#flashbutton').color,'#253637')>=7,'name over the brightest panel color');
 for(const selector of ['#flashbutton small','#flashbutton[aria-disabled="true"] small']){const s=d(selector);assert(contrast(s.color,s.background)>=7,selector);}
 assert.equal(d('#flashbutton small')['font-variant-numeric'],'tabular-nums');
 assert.equal(d('#flashbutton small')['white-space'],'nowrap');
});

test('desktop instructions consistently use F Flash and left-click punch while touch hides key hints',()=>{
 assert.match(html,/<kbd>LEFT CLICK<\/kbd><span>근접 펀치<\/span>/);
 assert.match(html,/<kbd>E → 좌클릭<\/kbd><span>강철 주먹<\/span>/);
 assert.match(html,/<kbd>F<\/kbd><span>점멸 · 15초<\/span>/);
 assert.match(html,/aria-label="E 강철 주먹, 충전 후 마우스 좌클릭"/);
 assert.match(html,/E 충전 후 좌클릭 · R 전기장 · F 점멸/);
 assert(!/CLICK \/ [FCG]|클릭\/[FCG]|[CG] 점멸|점멸, G 키|E → CLICK/.test(html));
 assert.equal(style(ui+' .keyboard-hint',context,interfaceRules).display,'none');
 assert.equal(style(ui+' .instructions',context,interfaceRules).display,'none');
 assert.equal(d(scope+' #flashbutton .keyboard-hint').display,'none');
 assert.match(html,/<button id="touchpunch" aria-label="펀치">/,'touch punch retains its existing semantics');
});
