import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameAudio} from '../game-audio.js';

const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => {resolve = yes; reject = no;});
  return {promise, resolve, reject};
};

// Scheduled stop is not immediate; suspended contexts freeze their audio clock.
// resume changes state asynchronously, like a browser, not inside the call.
function harness(options = {}) {
  const sources = [], gains = [], errors = [], listeners = new Set();
  let contexts = 0, resumes = 0;
  const node = () => ({connect(target) {this.target = target;}, disconnect() {this.disconnected = true;}});
  const param = () => ({events: [], setValueAtTime(...args) {this.events.push(['set', ...args]);}, exponentialRampToValueAtTime(...args) {this.events.push(['ramp', ...args]);}, cancelScheduledValues() {}});
  const context = {
    state: 'suspended', currentTime: 3, destination: {},
    addEventListener(type, listener) {if (type === 'statechange') listeners.add(listener);},
    removeEventListener(type, listener) {if (type === 'statechange') listeners.delete(listener);},
    setState(state, notify = true) {this.state = state; if (notify) for (const listener of listeners) listener();},
    resume() {resumes++; return Promise.resolve(this.resumeGate).then(() => {if (this.state !== 'closed') this.setState('running');});},
    close() {this.setState('closed'); return Promise.resolve();},
    advance(seconds) {if (this.state !== 'running') return; this.currentTime += seconds; for (const source of sources) if (source.started && !source.ended && source.stopAt <= this.currentTime) source.end();},
    createGain() {const gain = {...node(), gain: param()}; gains.push(gain); return gain;},
    createOscillator() {
      const ctx = this;
      const source = {...node(), frequency: param(), stopAt: Infinity,
        start(when) {this.started = true; this.startAt = when;},
        stop(when = ctx.currentTime) {this.stopAt = when; if (when <= ctx.currentTime) this.end();},
        end() {if (this.ended) return; this.ended = true; this.onended?.();},
        get audible() {return Boolean(ctx.state === 'running' && this.started && !this.ended && !this.disconnected && !this.target?.disconnected);},
      };
      sources.push(source); return source;
    },
  };
  const audio = createGameAudio({cues: {}, events: {}, createContext: () => {contexts++; return context;}, onError: (error, id) => errors.push({error, id}), ...options});
  return {audio, context, sources, gains, errors, listeners, get contexts() {return contexts;}, get resumes() {return resumes;}};
}

test('neutral playback never unlocks or queues an event, including during async resume', async () => {
  const h = harness();
  assert.equal(h.audio.playTone(220, 700, .2), false);
  assert.equal(h.contexts, 0);
  const unlocked = h.audio.unlock();
  assert.equal(h.context.state, 'suspended');
  assert.equal(h.audio.playTone(220, 700, .2), false);
  assert.equal(await unlocked, true);
  assert.equal(h.sources.length, 0);
  assert(h.audio.playTone(220, 700, .2));
  assert.equal(h.resumes, 1, 'playback itself must never call resume');
});

test('existing triangle waveform, frequencies, duration and absolute gain stay exact', async () => {
  const h = harness(); await h.audio.unlock(); h.audio.setVolume(.1);
  assert(h.audio.playTone(95, 40, .16));
  const source = h.sources[0], gain = source.target;
  assert.equal(source.type, 'triangle');
  assert.deepEqual(source.frequency.events, [['set', 95, 3], ['ramp', 40, 3.16]]);
  assert.deepEqual(gain.gain.events, [['set', .07, 3], ['ramp', .001, 3.16]]);
  assert.equal(gain.target, h.context.destination, 'sample master volume must not change legacy tone gain');
  assert.equal(source.startAt, 3); assert.equal(source.stopAt, 3.16); assert.equal(source.audible, true);
  h.audio.playTone(150, 0);
  assert.deepEqual(h.sources[1].frequency.events, [['set', 150, 3], ['ramp', 20, 3.16]]);
});

test('finite voice limit evicts oldest and natural onended disconnects both nodes', async () => {
  const h = harness({maxVoices: 2}); await h.audio.unlock();
  h.audio.playTone(100, 200); h.audio.playTone(200, 300); h.audio.playTone(300, 400);
  assert.equal(h.audio.status.activeTones, 2); assert.equal(h.sources[0].ended, true);
  assert.equal(h.sources[0].disconnected, true); assert.equal(h.sources[0].target.disconnected, true);
  assert.equal(h.sources[1].audible, true);
  const ended = h.sources[1].onended; h.context.advance(.2); ended();
  assert.equal(h.audio.status.activeTones, 0);
  assert(h.sources.every(source => source.disconnected && source.target.disconnected));
  assert(h.sources.every(source => source.onended === null));
});

test('mute, pause and stopAll cancel tones, and toggling them never replays', async () => {
  const h = harness(); await h.audio.unlock();
  for (const action of ['mute', 'pause', 'stopAll']) {
    h.audio.playTone(220, 700, .2); const source = h.sources.at(-1), count = h.sources.length;
    if (action === 'mute') h.audio.setMuted(true);
    if (action === 'pause') h.audio.setPaused(true);
    if (action === 'stopAll') h.audio.stopAll();
    assert.equal(source.audible, false); assert.equal(h.audio.status.activeTones, 0);
    if (action !== 'stopAll') assert.equal(h.audio.playTone(220, 700), false);
    h.audio.setMuted(false); h.audio.setPaused(false);
    assert.equal(h.sources.length, count); assert.equal(source.audible, false);
  }
});

test('a preserved final impact drains while new tones stay paused, independent of death voice', async () => {
  const h = harness(); await h.audio.unlock();
  h.audio.playTone(220, 700, .2); const impact = h.audio.playTone(95, 40, .16);
  h.audio.setPaused(false, {tonePaused: true, preserveTone: impact});
  assert.equal(h.sources[0].audible, false); assert.equal(h.sources[1].audible, true);
  assert.equal(h.audio.playTone(130, 430, .3), false);
  h.audio.setPaused(true, {preserveTone: impact});
  assert.equal(h.sources[1].audible, true, 'a short/unavailable death voice must not cut impact');
  h.context.advance(.17); assert.equal(h.audio.status.activeTones, 0);
  h.audio.setPaused(true, {preserveTone: impact});
  assert.equal(h.audio.status.activeTones, 0, 'an expired handle cannot resurrect a voice');
});

test('mute and interruption always override even a preserved final impact', async () => {
  const h = harness(); await h.audio.unlock();
  for (const action of ['mute', 'pause', 'stopAll']) {
    h.audio.setPaused(false); const impact = h.audio.playTone(95, 40, .16);
    h.audio.setPaused(true, {preserveTone: impact});
    if (action === 'mute') h.audio.setMuted(true);
    if (action === 'pause') h.audio.setPaused(true);
    if (action === 'stopAll') h.audio.stopAll();
    assert.equal(h.audio.status.activeTones, 0);
    h.audio.setMuted(false); h.audio.setPaused(true, {preserveTone: impact});
    assert.equal(h.audio.status.activeTones, 0);
  }
});

test('suspending context kills frozen tones even before another input, never replaying on automatic resume', async () => {
  const h = harness(); await h.audio.unlock(); h.audio.playTone(220, 700, .2);
  h.context.setState('suspended'); h.context.advance(30);
  assert.equal(h.context.currentTime, 3); assert.equal(h.audio.status.activeTones, 0);
  assert.equal(h.audio.playTone(130, 430, .3), false);
  h.context.setState('running'); assert.equal(h.sources[0].audible, false); assert.equal(h.sources.length, 1);
});

test('unlock and play also stop frozen tones before a delayed statechange notification', async () => {
  const h = harness(); await h.audio.unlock();
  for (const action of ['unlock', 'play']) {
    h.audio.playTone(220, 700, .2); const source = h.sources.at(-1);
    h.context.setState('suspended', false);
    if (action === 'unlock') await h.audio.unlock();
    else assert.equal(h.audio.playTone(130, 430, .3), false);
    h.context.setState('running'); assert.equal(source.audible, false); assert.equal(h.audio.status.activeTones, 0);
  }
});

test('rapid start, pause, resume and mute during delayed unlock cannot play a stale event', async () => {
  const h = harness(), gate = deferred(); h.context.resumeGate = gate.promise;
  const unlocked = h.audio.unlock();
  for (let i = 0; i < 40; i++) {
    h.audio.setPaused(false); h.audio.unlock(); assert.equal(h.audio.playTone(200, 480, .1), false);
    h.audio.setPaused(true); h.audio.setMuted(true); h.audio.stopAll(); h.audio.setMuted(false);
  }
  gate.resolve(); assert.equal(await unlocked, true);
  assert.equal(h.sources.length, 0); assert.equal(h.contexts, 1); assert.equal(h.resumes, 41, 'each explicit unlock retries resume in its own gesture stack');
  assert.equal(h.audio.playTone(200, 480, .1), false, 'unlock completion must not undo the final pause');
  for (let i = 0; i < 40; i++) {
    h.audio.setPaused(false); h.audio.playTone(220, 700, .2); h.audio.setMuted(true);
    h.audio.setMuted(false); h.audio.setPaused(true);
  }
  assert.equal(h.audio.status.activeTones, 0); assert(h.sources.every(source => !source.audible));
});

test('rejected unlock is handled and retry reuses one context without replaying a tone', async () => {
  const h = harness(), gate = deferred(); h.context.resumeGate = gate.promise;
  const unlocked = h.audio.unlock(); assert.equal(h.audio.playTone(220, 700), false);
  gate.reject(new Error('gesture required')); assert.equal(await unlocked, false);
  assert.equal(h.errors.length, 1); assert.equal(h.sources.length, 0);
  h.context.resumeGate = undefined; assert.equal(await h.audio.unlock(), true);
  assert.equal(h.sources.length, 0); assert.equal(h.contexts, 1);
  assert(h.audio.playTone(220, 700));
});

test('disposal during unlock closes context, removes listener and cannot restart voices', async () => {
  const h = harness(), gate = deferred(); h.context.resumeGate = gate.promise;
  const unlocked = h.audio.unlock(); h.audio.dispose(); h.audio.dispose(); gate.resolve();
  assert.equal(await unlocked, false); assert.equal(h.context.state, 'closed'); assert.equal(h.listeners.size, 0);
  assert.equal(h.audio.playTone(220, 700), false); assert.equal(await h.audio.unlock(), false);
  assert.equal(h.sources.length, 0);
});

test('disposal stops and disconnects every playing neutral source', async () => {
  const h = harness(); await h.audio.unlock(); h.audio.playTone(220, 700); h.audio.playTone(95, 40);
  h.audio.dispose(); assert.equal(h.audio.status.activeTones, 0); assert.equal(h.listeners.size, 0);
  assert(h.sources.every(source => source.ended && source.disconnected && source.target.disconnected));
});

for (const failure of ['oscillator', 'gain', 'connect', 'start', 'scheduled stop']) {
  test(`neutral ${failure} failure cleans up and reports without breaking gameplay`, async () => {
    const h = harness(); await h.audio.unlock();
    const oscillator = h.context.createOscillator.bind(h.context);
    h.context.createOscillator = () => {
      if (failure === 'oscillator') throw new Error(failure);
      const source = oscillator();
      if (failure === 'connect') source.connect = () => {throw new Error(failure);};
      if (failure === 'start') source.start = () => {throw new Error(failure);};
      if (failure === 'scheduled stop') {
        const stop = source.stop.bind(source);
        source.stop = when => {if (when !== undefined) throw new Error(failure); stop();};
      }
      return source;
    };
    if (failure === 'gain') h.context.createGain = () => {throw new Error(failure);};
    assert.equal(h.audio.playTone(220, 700), false); assert.equal(h.audio.status.activeTones, 0);
    if (failure !== 'oscillator') {assert.equal(h.sources[0].disconnected, true); assert.equal(h.sources[0].audible, false);}
    assert.equal(h.errors.length, 1); assert.equal(h.errors[0].id, 'neutral');
  });
}

test('stop or source disconnect errors do not prevent disconnecting the gain', async () => {
  const h = harness(); await h.audio.unlock(); h.audio.playTone(220, 700, .2);
  const source = h.sources[0];
  source.stop = () => {throw new Error('stop');};
  source.disconnect = () => {throw new Error('disconnect');};
  h.audio.setMuted(true);
  assert.equal(h.audio.status.activeTones, 0); assert.equal(source.onended, null);
  assert.equal(source.target.disconnected, true); assert.equal(source.audible, false);
});

test('a resolved resume that remains suspended is not treated as playable', async () => {
  const h = harness(); h.context.resume = () => Promise.resolve();
  assert.equal(await h.audio.unlock(), false);
  assert.equal(h.audio.playTone(220, 700, .2), false); assert.equal(h.sources.length, 0);
});

test('invalid tone parameters cannot allocate unbounded or unscheduled sources', async () => {
  const h = harness(); await h.audio.unlock();
  for (const args of [[NaN, 40, .2], [0, 40, .2], [-1, 40, .2], [220, Infinity, .2], [220, 40, NaN], [220, 40, 0], [220, 40, -1], [220, 40, 2]]) assert.equal(h.audio.playTone(...args), false);
  assert.equal(h.sources.length, 0); assert.equal(h.errors.length, 0);
});

test('invalid voice limits retain a finite safe bound', async () => {
  for (const [maxVoices, expected] of [[NaN, 6], [Infinity, 6], [-1, 1], [1000, 16], [2.9, 2]]) {
    const h = harness({maxVoices}); await h.audio.unlock();
    for (let i = 0; i < 20; i++) h.audio.playTone(220, 700);
    assert.equal(h.audio.status.activeTones, expected); h.audio.dispose();
  }
});
