import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=name=>fs.readFileSync(new URL('../'+name,import.meta.url),'utf8');
test('direction display adds no radial nodes, stylesheet or new geometry',()=>{
 assert.doesNotMatch(read('index.html'),/turretdirections|turret-direction\.css/);
 assert.equal((read('index.html').match(/id="threatwarning"/g)||[]).length,1);
 assert(!fs.existsSync(new URL('../turret-direction.css',import.meta.url)));
 assert.doesNotMatch(read('main.js')+read('turret-direction.js'),/turretdirections|createElement|replaceChildren|turret-direction-marker/);
 assert.match(read('main.js'),/statusUI.threatwarning.textContent=text/);
});
test('existing HUD positions and banner bounds are unchanged',()=>{
 assert.match(read('style.css'),/#hitnotice\{[^}]*top:57%/);
 assert.match(read('style.css'),/#targetname\{[^}]*top:54%/);
 assert.match(read('mobile-interface.css'),/#threatwarning \{[^}]*max-width:[^}]*white-space:normal/);
 assert.doesNotMatch(read('turret-direction.js'),/\.style\b|setProperty|innerHTML/);
});
