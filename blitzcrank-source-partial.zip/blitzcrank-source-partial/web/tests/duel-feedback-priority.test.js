import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=path.resolve(process.env.DUEL_APP_ROOT||fileURLToPath(new URL('../',import.meta.url)));
const worker=fileURLToPath(new URL('./helpers/duel-feedback-priority-case.mjs',import.meta.url));
const cases=[
 [20,'R','first','mouse'],[20,'E','first','mouse'],[20,'Q','first','mouse'],
 [60,'R','first','mouse'],[60,'E','first','mouse'],[120,'R','first','mouse'],[120,'E','first','mouse'],
 [20,'R','third','mouse'],[20,'E','third','mouse'],
 [20,'R','first','touch'],[20,'E','third','touch'],[20,'Q','first','touch'],
 [20,'block','first','mouse'],[60,'block','third','mouse'],[120,'block','third','touch'],
 [20,'tie','first','mouse'],[60,'tie','third','touch'],
];
for(const [hz,scenario,view,input] of cases)test(`${hz} Hz ${scenario}: ${view}-person ${input} feedback priority and lifecycle`,()=>{
 const out=execFileSync(process.execPath,['--max-old-space-size=512',worker,root,String(hz),scenario,view,input],{encoding:'utf8',maxBuffer:256*1024});
 const lines=out.trim().split('\n').map(l=>JSON.parse(l)),result=lines.at(-1);
 assert(result.pass);assert.equal(result.harnesses,1);assert(result.pausedStatePreserved);assert(result.restartClean);
 if(['Q','E','R'].includes(scenario))assert(Math.abs(result.holdSeconds-3)<1e-8);
});
