import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {rig,THREE} from './helpers/locomotion-rig.js';import {createFullbodyLocomotion} from '../fullbody-locomotion.js';
import {createDuelAvatarFactory,cacheStaticFullbodyNodeMatrices} from '../duel-avatar.js';
let oldSource=fs.readFileSync(new URL('./fixtures/duel-avatar-v0.24.62-baseline.txt',import.meta.url),'utf8').replace(/from '\.\/([^']+)'/g,(_,p)=>`from '${new URL('../'+p,import.meta.url).href}'`);
const legacy=await import('data:text/javascript;base64,'+Buffer.from(oldSource).toString('base64'));
const asset=JSON.parse(fs.readFileSync(new URL('../assets/skill-animations/skills.9b293d06ddb21614.json',import.meta.url))).models.fullbody;
const mutable=name=>name.startsWith('BC_Pivot_')||name.startsWith('BC_QLaunch')||name==='BC_Knee.L'||name==='BC_Knee.R';
const flags=actor=>{const a=[];actor.object.traverse(o=>a.push([o.name,o.matrixAutoUpdate,o.matrixWorldAutoUpdate,o.matrixWorldNeedsUpdate]));return a;};
const geometry=actor=>{const a=[];actor.object.traverse(o=>a.push([o.name,o.position.toArray(),o.quaternion.toArray(),o.scale.toArray(),o.matrix.toArray(),o.matrixWorld.toArray(),o.visible,o.matrixWorldAutoUpdate]));return{nodes:a,sockets:actor.getSockets(),state:actor.inspect()};};
function make(factory=createDuelAvatarFactory,options={}){const r=rig(),f=factory(THREE,{...r,createLocomotion:createFullbodyLocomotion}),a=f.create(options);a.configureSkills(asset);return a;}
test('only 278 immutable rig Groups are baked, leaving 12 mutable nodes, surfaces and roots automatic',()=>{
 const r=rig(),children=new THREE.Group();children.name='effect';r.nodes.get('BC_Palm.R').add(children);const meshes=[...r.meshes.values()];const cached=cacheStaticFullbodyNodeMatrices(r.nodes);assert.equal(cached.length,278);assert.equal(r.nodes.size-cached.length,12);assert(r.body.matrixAutoUpdate);assert(meshes.every(m=>m.matrixAutoUpdate));assert(children.matrixAutoUpdate);for(const [name,node]of r.nodes){assert.equal(node.matrixAutoUpdate,mutable(name));assert(node.matrixWorldAutoUpdate);}
 let calls=0;const original=THREE.Matrix4.prototype.compose;THREE.Matrix4.prototype.compose=function(...args){calls++;return original.apply(this,args)};try{r.body.updateMatrixWorld(true)}finally{THREE.Matrix4.prototype.compose=original;}assert.equal(calls,1+12+279+1);console.log('STATIC_RIG_COMPOSE '+JSON.stringify({cachedGroups:278,remainingComposes:calls,includingEffect:true}));
});
test('default factory keeps legacy automatic Group behavior and exact default actor state',()=>{
 const a=make(legacy.createDuelAvatarFactory),b=make();for(let i=0;i<20;i++){const state={position:[i*.03,0,1],yaw:.3,locomotion:{deltaX:.03,deltaZ:0}};a.update(1/60,state);b.update(1/60,state);assert.deepEqual(geometry(b),geometry(a));assert.deepEqual(flags(b),flags(a));}
 const find=actor=>{let x;actor.object.traverse(o=>{if(o.isGroup&&o.name==='BC_Foot.L')x=o});return x};for(const actor of [a,b]){const x=find(actor);assert(x.matrixAutoUpdate);x.position.x+=.37;actor.object.updateMatrixWorld(true);}assert.deepEqual(geometry(b),geometry(a));
});
test('opt-in actor matches every transform, socket and motion value through W/E/R, Q, jumps and moving parents',()=>{
 const parentA=new THREE.Group(),parentB=new THREE.Group();for(const p of [parentA,parentB]){p.position.set(3,2,-4);p.rotation.y=.43;p.scale.setScalar(1.3);p.updateMatrixWorld(true);}const a=make(createDuelAvatarFactory,{parent:parentA}),b=make(createDuelAvatarFactory,{parent:parentB,staticRestMatrices:true});
 const phases=['W_Start','W_Loop','W_End','E_Charge','E_Hold','E_Strike','R_Cast'];let compared=0;
 for(let i=0;i<240;i++){const name=phases[Math.floor(i/24)%phases.length],air=i>=30&&i<43,height=air?Math.sin((i-30)/13*Math.PI):0;const state={position:[Math.sin(i/31),height,Math.cos(i/37)],yaw:i/71,pitch:.2,skill:{name,time:(i%24)/60},locomotion:{deltaX:.02,deltaZ:-.05,grounded:!air,height,velocityY:air?(i<36?4:-4):0}};
  if(i>=180&&i<220){const j=i-180;state.hook={phase:j<8?'windup':j<22?'outbound':j<34?'return':'recover',phaseTime:(j%8)/60,position:[-2,3,-7],returnDuration:.4,bodyOrientation:[0,0,0,1]};}
  if(i===100)for(const p of [parentA,parentB]){p.position.x+=.4;p.rotation.y-=.21;p.updateMatrixWorld(true);}
  a.update(1/60,state);b.update(1/60,state);assert.deepEqual(geometry(b),geometry(a));compared++;
 }
 console.log('STATIC_RIG_ACTOR '+JSON.stringify({states:compared}));
});
test('opt-in reset rebakes restored static nodes and disposal keeps shared resources alive',()=>{
 const a=make(),b=make(createDuelAvatarFactory,{staticRestMatrices:true});const pick=actor=>{let found;actor.object.traverse(o=>{if(o.isGroup&&o.name==='BC_Foot.L')found=o});return found;};for(const actor of [a,b]){const n=pick(actor);n.position.set(4,5,6);n.quaternion.setFromAxisAngle(new THREE.Vector3(0,1,0),.7);n.scale.set(2,2,2);n.updateMatrix();actor.reset({position:[1,0,-2],yaw:.5,visible:true});}assert.deepEqual(geometry(b),geometry(a));assert.equal(pick(b).matrixAutoUpdate,false);let disposed=0;b.object.traverse(o=>{if(o.isMesh){o.geometry.addEventListener('dispose',()=>disposed++);o.material.addEventListener('dispose',()=>disposed++);}});b.dispose();assert.equal(disposed,0);assert(b.inspect().disposed);
});

test('opting one avatar in leaves the source, pristine template and later default avatars unchanged',()=>{
 const r=rig(),factory=createDuelAvatarFactory(THREE,{...r,createLocomotion:createFullbodyLocomotion}),baked=factory.create({staticRestMatrices:true}),plain=factory.create();assert([...r.nodes.values()].every(n=>n.matrixAutoUpdate));let bakedCount=0;for(const actor of [baked,plain])actor.object.traverse(o=>{if(o.isGroup&&o.name&&!mutable(o.name)){if(actor===baked){assert.equal(o.matrixAutoUpdate,false);bakedCount++;}else assert.equal(o.matrixAutoUpdate,true);}});assert.equal(bakedCount,278);factory.dispose();assert(!baked.inspect().disposed);assert(!plain.inspect().disposed);
});
