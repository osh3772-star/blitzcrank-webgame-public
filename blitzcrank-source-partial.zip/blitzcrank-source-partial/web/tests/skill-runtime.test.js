import {assertApprovedSkillClips} from './helpers/approved-skill-clips.js';
import test from 'node:test';import {rayBox} from '../core.js';import assert from 'node:assert/strict';import fs from 'node:fs';import * as RealThree from '../vendor/three.module.js';
// CPU-only smoke harness. It runs the actual game module and Three.js scene graph,
// but deliberately does not claim GPU rendering or physical-browser input coverage.
class Classes{constructor(){this.s=new Set();}toggle(x,force){if(force===undefined)force=!this.s.has(x);force?this.s.add(x):this.s.delete(x);}add(x){this.s.add(x);}remove(x){this.s.delete(x);}}
class Element{constructor(){this.style={};this.classList=new Classes();this.firstElementChild={style:{}};this.parentElement={classList:new Classes()};this.value='1';this.disabled=false;this.listeners={};this.textContent='';this.innerHTML='';}addEventListener(k,f){const previous=this.listeners[k];this.listeners[k]=e=>{previous?.(e);f(e);};}setAttribute(){}querySelector(){return new Element();}getBoundingClientRect(){return{left:0,top:0,width:110,height:110};}setPointerCapture(){}requestPointerLock(){document.pointerLockElement=this;docListeners.pointerlockchange?.();return Promise.resolve();}click(){this.onclick?.();}getContext(){return{fillRect(){},fillText(){},fillStyle:'',textAlign:'',font:''};}}
const elements=new Map(),docListeners={},winListeners={};let callback;
const element=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
globalThis.document={getElementById:element,querySelector:element,createElement:()=>new Element(),addEventListener:(n,f)=>docListeners[n]=f,pointerLockElement:null,exitPointerLock(){this.pointerLockElement=null;docListeners.pointerlockchange?.();}};globalThis.window=globalThis;globalThis.innerWidth=1280;globalThis.innerHeight=720;globalThis.devicePixelRatio=1;globalThis.matchMedia=()=>({matches:false});globalThis.localStorage={getItem:()=>null,setItem(){}};globalThis.addEventListener=(n,f)=>winListeners[n]=f;globalThis.requestAnimationFrame=f=>{callback=f;};globalThis.fetch=async(path)=>({ok:true,arrayBuffer:async()=>{const b=fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url));return b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);},json:async()=>JSON.parse(fs.readFileSync(new URL('../'+path.replace('./',''),import.meta.url)))});
class Renderer{constructor(){this.shadowMap={};}setPixelRatio(){}setSize(){}clear(){}render(){}clearDepth(){}}
class Clock{getDelta(){return 1/60;}}
class TextureLoader{async loadAsync(path){assert(fs.existsSync(new URL('../'+path.replace('./',''),import.meta.url)));return new RealThree.Texture();}}
globalThis.testThree={...RealThree,WebGLRenderer:Renderer,Clock,TextureLoader};
let source=fs.readFileSync(new URL('../main.js',import.meta.url),'utf8').replace("import * as THREE from './vendor/three.module.js';",'const THREE = globalThis.testThree;').replace("from './hook-chain.js'",`from '${new URL('../hook-chain.js',import.meta.url).href}'`).replace("from './training-mirror.js'",`from '${new URL('../training-mirror.js',import.meta.url).href}'`).replace("from './game-audio.js'",`from '${new URL('../game-audio.js',import.meta.url).href}'`).replace("from './audio-cues.js'",`from '${new URL('../audio-cues.js',import.meta.url).href}'`).replace("from './voice-cues.js'",`from '${new URL('../voice-cues.js',import.meta.url).href}'`).replace("from './voice-schedule.js'",`from '${new URL('../voice-schedule.js',import.meta.url).href}'`).replace("from './blitz-materials.js'",`from '${new URL('../blitz-materials.js',import.meta.url).href}'`).replace("from './core.js'",`from '${new URL('../core.js',import.meta.url).href}'`).replace("from './mouse-look.js'",`from '${new URL('../mouse-look.js',import.meta.url).href}'`).replace("from './target-models.js'",`from '${new URL('../target-models.js',import.meta.url).href}'`).replace("from './turret-view.js'",`from '${new URL('../turret-view.js',import.meta.url).href}'`);
globalThis.__TURRET_TONE_QA__=[];globalThis.__TURRET_SAMPLE_QA__=[];
const toneWrapper='function audio(freq,end,duration=.16){return gameAudio.playTone(freq,end,duration);}';
assert(source.includes(toneWrapper),'neutral audio wrapper must be instrumented for event-mapping assertions');
source=source.replace(toneWrapper,'function audio(freq,end,duration=.16){if(!muted)globalThis.__TURRET_TONE_QA__.push({freq,end,duration});return gameAudio.playTone(freq,end,duration);}');
source+=`\nwindow.__MOTION__={get data(){return{scene,viewScene,fullbody,hook,fist,rope,parts,projectileParts,camera,viewCamera,viewmodel,targets,obstacles,fullbodySocket,player,turretArena,fullbodyNodes,fullbodyMeshes,punchCooldown,clipName,clipTime,oneShot}},prepareMirrorBody,restoreMirrorBody,fullbodyCableSocket,fullbodyChainSocket,get mirror(){return trainingMirror},handPoint,cableSocket,chainHandSocket,nearestRay,begin,pause,resume,damagePlayer,finish,resetSkills,castW,castE,castR,get skillData(){return{skills,skillClips,fullbodySurfaces,skillVfx,skillMetrics}}};`;
source=source.replace("from './model-codec.js'",`from '${new URL('../model-codec.js',import.meta.url).href}'`).replace("from './player-model-manifest.js'",`from '${new URL('../player-model-manifest.js',import.meta.url).href}'`);
source=source.replace(/from '\.\/([^']+)'/g,(_,path)=>`from '${new URL('../'+path,import.meta.url).href}'`);
source+=`\nconst oldPlayEvent=gameAudio.playEvent;gameAudio.playEvent=event=>{globalThis.__TURRET_SAMPLE_QA__.push(event);return oldPlayEvent(event);};`;
// This fixture exercises initialized gameplay, not the natural first selection.
source+='\nif(typeof ensureGameplayAssets==="function")await ensureGameplayAssets();';
await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const punch=()=>element('game').listeners.pointerdown({pointerType:'mouse',button:0,preventDefault(){}});
const key=code=>winListeners.keydown({code,repeat:false,preventDefault(){}}),release=code=>winListeners.keyup({code});const frames=n=>{for(let i=0;i<n;i++)callback();};

const qa=window.__HOOK_ARENA__,motion=window.__MOTION__;
function fresh(third=false){motion.begin(true);if((qa.view==='third')!==third)key('KeyV');frames(1);}
function launch(){key('KeyQ');frames(16);assert.equal(motion.data.hook.phase,'outbound');}
const targetInFront=(distance=2)=>{const d=motion.data;for(const t of d.targets)t.active=false;const t=d.targets[0];t.active=true;t.group.visible=true;t.captured=false;t.anchor.set(d.player.x,1.7,d.player.z-distance);t.amplitude=0;t.phase=0;t.knockup=null;t.group.position.copy(t.anchor);return t;};
test('W remains forward, Shift casts W once and cannot restart an active run',()=>{fresh();const z=qa.player.z;key('KeyW');frames(30);release('KeyW');assert(qa.player.z<z);assert.equal(qa.skills.boost,0);const elapsed=qa.session.elapsed;key('ShiftLeft');assert.equal(qa.skills.moveMultiplier,1.55);key('ShiftLeft');assert.equal(qa.skills.cooldown.W,12);key('KeyR');assert.equal(qa.skills.phase,'R_Cast');assert.equal(qa.session.elapsed,elapsed);assert.equal(qa.session.practice,true);frames(19);assert.equal(qa.skills.metrics.discharges,1);key('KeyR');frames(60);assert.equal(qa.skills.metrics.discharges,1);});
test('W accelerates actual movement and basic attacks, then slowdown clears on restart',()=>{fresh();key('KeyW');frames(30);release('KeyW');const normal=7-qa.player.z;fresh();key('ShiftLeft');key('KeyW');frames(30);release('KeyW');assert(Math.abs((7-qa.player.z)/normal-1.55)<1e-8);punch();assert(Math.abs(motion.data.punchCooldown-.65/1.5)<1e-10);frames(27);assert.equal(motion.data.punchCooldown,0);punch();assert(motion.data.punchCooldown>0);assert.equal(qa.session.punches,0);assert.equal(motion.data.parts[0].visible,true);frames(220);assert.equal(qa.skills.moveMultiplier,.65);motion.begin(true);assert.equal(qa.skills.moveMultiplier,1);assert.equal(qa.skills.animation,null);});
test('E next punch hits at the authored frame, visibly knocks up once, scores once',()=>{fresh();const t=targetInFront();key('KeyE');punch();frames(53);assert.equal(qa.skills.phase,'E_Hold');assert.equal(qa.session.score,0);punch();assert.equal(qa.skills.phase,'E_Strike');frames(23);assert.equal(qa.session.score,0);frames(2);assert.equal(qa.skills.metrics.powerHits,1);assert.equal(qa.session.score,80);assert(t.knockup);assert(t.group.visible);frames(28);assert(t.group.position.y>t.anchor.y+1.5);punch();frames(50);assert.equal(qa.session.score,80);assert.equal(t.knockup,null);assert.equal(t.group.visible,false);});
test('E miss consumes charge; a pause freezes charge and cannot duplicate impact',()=>{fresh();for(const t of motion.data.targets){t.active=false;t.respawn=Infinity;}key('KeyE');frames(53);punch();frames(12);const saved=qa.skills;motion.pause();frames(100);assert.deepEqual(qa.skills,saved);motion.resume();frames(80);assert.equal(qa.skills.metrics.powerHits,0);assert.equal(qa.skills.phase,null);assert.equal(qa.session.score,0);});
test('R pulse uses range and cover, avoids captured targets, and emits once at frame 9',()=>{fresh();const inside=targetInFront(4),d=motion.data,outside=d.targets[1],captured=d.targets[2];outside.active=true;outside.captured=false;outside.anchor.set(0,1.7,-6);outside.amplitude=0;outside.group.position.copy(outside.anchor);captured.active=true;captured.captured=true;captured.group.position.set(0,1.7,4);key('KeyR');frames(17);assert.equal(qa.skills.metrics.discharges,0);frames(2);assert.equal(qa.skills.metrics.discharges,1);assert.equal(qa.skills.metrics.pulseHits,1);assert.equal(qa.session.score,60);assert.equal(inside.active,false);assert(outside.active&&captured.active);assert.equal(qa.skills.effects,1);frames(100);assert.equal(qa.skills.metrics.discharges,1);assert.equal(qa.skills.effects,0);fresh();const blocked=targetInFront(4);const obstacle={min:new RealThree.Vector3(-1,0,4.8),max:new RealThree.Vector3(1,4,5.2)};d.obstacles.push(obstacle);key('KeyR');frames(21);assert(blocked.active);assert.equal(qa.skills.metrics.pulseHits,0);d.obstacles.splice(d.obstacles.indexOf(obstacle),1);});
test('all eight approved animation clips bind finite mesh transforms in FPS and mirrored full body',()=>{fresh(true);const {skillClips,fullbodySurfaces}=motion.skillData;assertApprovedSkillClips(skillClips.fullbody);assertApprovedSkillClips(skillClips.viewmodel);for(const keyCode of ['ShiftLeft','KeyE']){key(keyCode);frames(10);for(const m of fullbodySurfaces){m.updateMatrixWorld(true);assert(m.matrix.elements.every(Number.isFinite));assert.equal(m.matrixAutoUpdate,false);}for(const p of motion.data.parts)assert(p.position.toArray().every(Number.isFinite));}frames(60);punch();frames(12);key('KeyV');const token=motion.prepareMirrorBody();assert(token.body.visible);motion.restoreMirrorBody(token);frames(100);key('KeyR');frames(20);for(const m of fullbodySurfaces)assert(m.matrix.elements.every(Number.isFinite));frames(80);motion.begin(true);frames(1);assert(fullbodySurfaces.every(m=>m.matrixAutoUpdate));});
test('Q interrupts only the E hold pose and preserves the armed next punch',()=>{fresh();key('KeyE');frames(53);key('KeyQ');assert(qa.hook);frames(150);assert.equal(qa.hook,null);assert.equal(qa.skills.phase,'E_Hold');punch();assert.equal(qa.skills.phase,'E_Strike');});
test('reset, menu and death cancel pending damage; R restarts only at results',()=>{fresh();key('KeyR');frames(8);motion.begin(true);frames(80);assert.equal(qa.skills.metrics.discharges,0);key('KeyE');frames(53);punch();motion.damagePlayer(100);assert.equal(qa.state,'results');frames(100);assert.equal(qa.skills.animation,null);assert.equal(qa.skills.metrics.powerHits,0);key('KeyR');assert.equal(qa.state,'running');assert.equal(qa.health,100);key('KeyR');frames(8);motion.pause();element('mainmenu').onclick();frames(100);assert.equal(qa.state,'menu');assert.equal(qa.skills.animation,null);assert.equal(qa.skills.metrics.discharges,0);});
test('touch skill controls do not fire again on synthetic physical click',()=>{fresh();element('skillE').onclick({detail:1});assert.equal(qa.skills.phase,null);element('skillE').onclick({detail:0});assert.equal(qa.skills.phase,'E_Charge');element('skillE').onclick({detail:0});assert.equal(qa.skills.cooldown.E,5);frames(53);element('touchpunch').onclick({detail:0});assert.equal(qa.skills.phase,'E_Strike');});
test('R preserves the remaining empowered E charge for the next punch',()=>{fresh();for(const t of motion.data.targets){t.active=false;t.respawn=Infinity;}key('KeyE');frames(53);const armed=qa.skills.armed;key('KeyR');assert.equal(qa.skills.phase,'R_Cast');frames(70);assert.equal(qa.skills.phase,'E_Hold');assert(qa.skills.armed>0&&qa.skills.armed<armed);targetInFront(2);punch();frames(25);assert.equal(qa.skills.metrics.powerHits,1);assert.equal(qa.session.score,80);assert.equal(qa.skills.armed,0);});

// Recorded targeting events occur on acquisition, not on every attack windup.
test('main routes one recorded lock event per acquisition and impact only for actual hits',()=>{
 fresh();const {player,turretArena}=motion.data;player.set(-8,1.7,-12);turretArena.reset();
 const tones=globalThis.__TURRET_TONE_QA__,samples=globalThis.__TURRET_SAMPLE_QA__;tones.length=0;samples.length=0;const events=[];
 for(let i=0;i<210;i++)events.push(...turretArena.step(1/60,player,true));
 const count=event=>samples.filter(e=>e===event).length;
 assert.equal(events.filter(e=>e.type==='acquired').length,1);
 assert(events.filter(e=>e.type==='windup').length>=2);
 assert.equal(count('turretAcquired'),1);
 const hits=events.filter(e=>e.type==='hit');assert(hits.length>=2);assert.equal(count('turretImpact'),hits.length);assert.equal(qa.health,100-hits.length*18);assert.equal(count('turretShot'),events.filter(e=>e.type==='shot').length);assert(!tones.some(t=>[480,270,95].includes(t.freq)));
 turretArena.step(.1,new RealThree.Vector3(0,1.7,7),true);
 turretArena.step(.1,player,true);assert.equal(count('turretAcquired'),2);
 const before=count('turretAcquired');motion.pause();frames(120);assert.equal(count('turretAcquired'),before);
 motion.begin(true);player.set(-8,1.7,-12);turretArena.step(.1,player,true);assert.equal(count('turretAcquired'),before+1);
});

// Model native button keyboard defaults after the actual global handler runs.
// This is CPU event-level coverage, not physical-browser keyboard coverage.
function actionButtonKey(id,code,repeat=false){
 const button=element(id);button.tagName='BUTTON';button.id=id;let prevented=false;
 winListeners.keydown({code,repeat,target:button,preventDefault(){prevented=true;}});
 return {button,prevented};
}
function enterAction(id,repeat=false){const {button,prevented}=actionButtonKey(id,'Enter',repeat);if(!prevented&&!button.disabled)button.onclick({detail:0});return prevented;}
function holdActionEnter(id,count){for(let i=0;i<count;i++){frames(1);if(i%2===0)enterAction(id,true);}}
test('held native Enter does not recast W after cooldown; a new press still works',()=>{
 fresh();assert.equal(enterAction('skillW'),false);assert.equal(qa.skills.boost,4);
 holdActionEnter('skillW',740);
 assert.equal(qa.skills.cooldown.W,0);assert.equal(qa.skills.boost,0);assert.equal(qa.skills.moveMultiplier,1);
 release('Enter');enterAction('skillW');assert.equal(qa.skills.boost,4);
});
test('held native Enter does not discharge R twice; a new press still works',()=>{
 fresh();enterAction('skillR');holdActionEnter('skillR',760);
 assert.equal(qa.skills.metrics.discharges,1);assert.equal(qa.skills.cooldown.R,0);
 release('Enter');enterAction('skillR');frames(19);assert.equal(qa.skills.metrics.discharges,2);
});
test('action buttons preserve native Space release, assistive clicks and pointer deduplication',()=>{
 fresh();const {button,prevented}=actionButtonKey('skillR','Space');assert.equal(prevented,false);
 for(let i=0;i<10;i++)assert.equal(actionButtonKey('skillR','Space',true).prevented,false);
 frames(30);assert.equal(qa.skills.phase,null);assert.equal(qa.skills.metrics.discharges,0);
 // Native Space clicks on release, not on repeated keydown.
 release('Space');button.onclick({detail:0});frames(19);assert.equal(qa.skills.metrics.discharges,1);
 fresh();element('skillW').onclick({detail:1});assert.equal(qa.skills.boost,0);
 element('skillW').onclick({detail:0});assert.equal(qa.skills.boost,4);
});
test('repeated Enter cancels every gameplay action button default, not ordinary buttons',()=>{
 for(const id of ['touchhook','touchpunch','touchjump','skillW','skillE','skillR']){
  fresh();assert.equal(enterAction(id,true),true,id+' must cancel repeated native activation');
  assert.equal(qa.hook,null);assert.equal(qa.skills.boost,0);assert.equal(qa.skills.phase,null);assert.equal(motion.data.punchCooldown,0);
  frames(3);assert.equal(qa.player.y,1.7);
 }
 assert.equal(actionButtonKey('start','Enter',true).prevented,false);
});

test('reference W streaks follow the body, pause freezes them, slow traces clear on reset',()=>{
 fresh();key('ShiftLeft');key('KeyW');frames(10);release('KeyW');assert(qa.skills.vfx.wVisible);assert(qa.skills.vfx.segments>0);const world=motion.data.fullbody.getObjectByName('W_reference_speed_streaks');assert.equal(world.parent,motion.data.fullbody);
 motion.pause();const frozen=qa.skills.vfx;frames(100);assert.deepEqual(qa.skills.vfx,frozen);motion.resume();frames(235);assert(qa.skills.vfx.groundVisible);motion.begin(true);assert.equal(qa.skills.vfx.wVisible,false);assert.equal(qa.skills.vfx.groundVisible,false);assert.equal(qa.skills.vfx.segments,0);
});
test('E electricity uses actual animated palms including detached Q clone and mirror body',()=>{
 fresh();key('KeyE');frames(53);assert.equal(qa.skills.vfx.eStrength,1);
 const palm=motion.data.fullbodyMeshes.get('BC_Palm.R'),g=palm.children.find(c=>c.name.startsWith('E_charged_fist_'));assert(g?.visible);palm.updateWorldMatrix(true,true);
 assert(g.getWorldPosition(new RealThree.Vector3()).distanceTo(palm.localToWorld(palm.geometry.boundingBox.getCenter(new RealThree.Vector3())))<1e-9);
 launch();const index=motion.data.projectileParts.findIndex(p=>p.name==='VM_Palm.R'),flyingPalm=motion.data.fist.children[index],electricity=flyingPalm.children.find(c=>c.name.startsWith('E_charged_fist_'));assert(electricity?.visible);assert(motion.data.fist.visible);assert.equal(motion.data.parts.find(p=>p.name==='VM_Palm.R').visible,false);
 const token=motion.prepareMirrorBody();assert(token.body.visible);assert(g.visible);assert.equal(motion.data.fist.visible,false);motion.restoreMirrorBody(token);assert.equal(motion.data.fist.visible,true);assert.equal(token.body.visible,false);
 frames(150);punch();frames(25);assert.equal(qa.skills.vfx.eStrength,0);motion.begin(true);assert.equal(g.visible,false);assert.equal(electricity.visible,false);
});
test('R world field remains at discharge location while moving, has branching geometry and independent tail',()=>{
 fresh();key('KeyR');frames(19);const field=motion.data.scene.getObjectByName('R_reference_branching_electrical_field'),origin=field.position.clone();assert(field.visible);assert(qa.skills.vfx.fieldSegments>1000);assert(field.getObjectByName('R_ivory_branched_web').material.isShaderMaterial);
 key('KeyW');frames(21);release('KeyW');assert(field.position.equals(origin));assert.notEqual(qa.player.z,origin.z);assert(qa.skills.vfx.fieldVisible);frames(31);assert.equal(qa.skills.vfx.fieldVisible,false);
 key('KeyE');frames(53);motion.finish();assert.equal(qa.skills.vfx.eStrength,0);assert.equal(qa.skills.vfx.segments,0);assert.equal(qa.skills.vfx.targets,0);
});
