import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {webcrypto} from 'node:crypto';
import {createStudyLoader} from '../rift-v39-loader.js';import {MAP_STUDY_V36,MAP_STUDY_V39} from '../rift-v39-revisions.js';
test('v39 late parse cannot replace newer different-version v36 handle',async()=>{
 let enter,release,count=0;const entered=new Promise(r=>enter=r),gate=new Promise(r=>release=r),old={},fresh={},disposed=[];
 const loader=createStudyLoader({cryptoImpl:webcrypto,fetchImpl:async u=>{const b=fs.readFileSync(u);return{ok:true,arrayBuffer:async()=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)};},parse:async()=>{if(++count===1){enter();await gate;return{scene:old};}return{scene:fresh};},dispose:s=>disposed.push(s)});
 const first=loader.load(MAP_STUDY_V39);await entered;const second=await loader.load(MAP_STUDY_V36);release();assert.equal(await first,null);assert.equal(second.gltf.scene,fresh);assert.equal(second.record.sourceVersion,'0.36');assert.deepEqual(disposed,[old]);loader.cancel();
});
