import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
const sourcePath=new URL('../main.js',import.meta.url);
const quiet=r=>r.game.setBotCommandSource({reset(){},step:()=>({move:{x:0,z:0},yaw:Math.PI,pitch:0,castQ:false,castE:false,strikeE:false,castR:false})});
function until(r,predicate){for(let i=0;i<500&&!predicate();i++)r.frames(1);assert(predicate());}
async function start(delta){const r=await createGameplayHarness({sourcePath,delta});r.element('duelmode').click();quiet(r);until(r,()=>r.qa.duel.active);return r;}
function score(r,skill='Q',winner='human'){
 const d=r.game.data,old=d.duel.state.history.length;d.duelBot.position.set(0,1.7,5);
 if(skill==='Q'){if(winner==='human')r.key('KeyQ');else assert(d.duel.cast('bot'));until(r,()=>!!d.duel.pendingGrab);assert.equal(d.duel.state.history.length,old);assert.equal(d.duel.active,false);}
 if(skill==='E'){const s=d.duel.getSkills(winner);assert(s.castE());until(r,()=>s.status.phase==='E_Hold');assert(s.strikeE());}
 if(skill==='R')assert(d.duel.getSkills(winner).castR());
 until(r,()=>d.duel.state.history.length===old+1);
 assert.equal(d.duel.state.history.at(-1).winnerId,winner);
}
const points=r=>r.qa.duel.match.scores.map(s=>s.points);
for(const intervals of [[.1,.2,1/60,.04,.35],[.5,.25,.1],[.4,.4,.4,.4,.4,.4,.4,.5]])test(`irregular result frames preserve time and stop at reset: ${intervals}`,async()=>{
 let delta=.05;const r=await start(()=>delta);score(r);let wall=0,frames=0;const d=r.game.data;
 while(d.duel.state.roundNumber===1){delta=intervals[frames++%intervals.length];wall+=delta;r.frames(1);assert(frames<100);}
 assert(wall>=3-1e-8);assert(wall<3+Math.max(...intervals)+1e-8);assert.equal(d.duel.state.phase,'countdown');assert.equal(d.duel.state.remainingMs,1600);assert.deepEqual(d.player.toArray(),[0,1.7,7]);assert.deepEqual(d.duelBot.position.toArray(),[0,1.7,-12]);
});
test('long foreground stall consumes at most 500ms and carries no debt',async()=>{
 let delta=.05;const r=await start(()=>delta);score(r);delta=12;r.frames(1);assert(Math.abs(r.qa.duel.match.remainingMs-2500)<1e-8);delta=0;r.frames(10);assert(Math.abs(r.qa.duel.match.remainingMs-2500)<1e-8);delta=.2;r.frames(1);assert(Math.abs(r.qa.duel.match.remainingMs-2300)<1e-8);
});
for(const interruption of ['pause','blur','hidden','capture'])test(`${interruption} stops the result clock, resume does not bank time`,async()=>{
 let delta=.2;const r=await start(()=>delta);score(r,'E','bot');r.frames(2);const before=r.qa.duel.match.remainingMs,y=r.qa.player.y;
 if(interruption==='pause')r.game.pause();if(interruption==='blur')r.winListeners.blur();if(interruption==='hidden'){document.hidden=true;r.docListeners.visibilitychange();}if(interruption==='capture'){document.pointerLockElement=null;r.docListeners.pointerlockchange();}
 delta=9;r.frames(3);assert.equal(r.qa.duel.match.remainingMs,before);assert.equal(r.qa.player.y,y);document.hidden=false;delta=.2;r.game.resume();r.frames(1);assert(Math.abs(r.qa.duel.match.remainingMs-(before-200))<1e-8);
});
test('restart clears the pending result hold without catch-up debt',async()=>{
 let delta=.2;const r=await start(()=>delta);score(r);r.frames(3);r.element('duelmode').click();quiet(r);delta=.5;r.frames(1);assert.deepEqual(points(r),[0,0]);assert.equal(r.qa.duel.match.roundNumber,1);assert.equal(r.qa.duel.match.remainingMs,1550);
});
for(const hz of [10,5])for(const skill of ['Q','E','R'])test(`${skill} third win holds three seconds at ${hz}Hz, then explicit rematch`,async()=>{
 const r=await start(()=>1/hz);for(let point=1;point<=3;point++){score(r,skill);if(point<3)until(r,()=>r.qa.duel.active);}
 assert.equal(r.qa.duel.match.phase,'matchComplete');r.frames(hz*3-1);assert.equal(r.qa.state,'running');r.frames(1);assert.equal(r.qa.state,'results');r.frames(30);assert.equal(r.qa.state,'results');assert.deepEqual(points(r),[3,0]);r.key('Enter');assert.deepEqual(points(r),[0,0]);assert.equal(r.qa.duel.match.phase,'countdown');
});
test('slow active, pending pull and solo frames retain the original 50ms simulation cap',async()=>{
 let delta=.2;const r=await start(()=>delta),d=r.game.data;
 const before=d.session.elapsed;r.frames(1);assert(Math.abs(d.session.elapsed-before-.05)<1e-8);
 d.duelBot.position.set(0,1.7,0);r.key('KeyQ');until(r,()=>!!d.duel.pendingGrab);const time=d.session.elapsed;r.frames(1);assert(Math.abs(d.session.elapsed-time-.05)<1e-8);assert.equal(d.duel.state.history.length,0);
 r.element('practice').click();const solo=r.qa.session.elapsed;r.frames(1);assert(Math.abs(r.qa.session.elapsed-solo-.05)<1e-8);
});
