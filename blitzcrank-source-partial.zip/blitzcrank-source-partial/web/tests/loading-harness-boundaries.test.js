import test from 'node:test';
import assert from 'node:assert/strict';
import {createRuntimeHarness,createGameplayHarness} from './helpers/runtime-harness.js';
test('menu readiness never silently preloads, even with the retired environment opt-in',async()=>{
 const previous=process.env.TEST_PRELOAD_GAMEPLAY;process.env.TEST_PRELOAD_GAMEPLAY='1';
 try {const h=await createRuntimeHarness();assert.equal(h.qa.state,'menu');assert.equal(h.qa.assets.parts,0);assert.equal(h.qa.assets.targetCount,0);assert.equal(h.qa.playing,false);await h.waitForGameplay();assert.equal(h.qa.state,'menu');assert.equal(h.qa.assets.parts,168);assert.equal(h.qa.playing,false);}
 finally {if(previous===undefined)delete process.env.TEST_PRELOAD_GAMEPLAY;else process.env.TEST_PRELOAD_GAMEPLAY=previous;}
});
test('explicit gameplay harness waits for initialized assets without beginning play',async()=>{
 const h=await createGameplayHarness();assert.equal(h.qa.state,'menu');assert.equal(h.qa.assets.parts,168);assert.equal(h.qa.assets.fullbodyParts,279);assert.equal(h.qa.playing,false);
});
