import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createSkillVfx,SKILL_VFX_LIMITS} from '../skill-vfx.js';
import {createSkillVfxHarness,vfxStatus} from './helpers/skill-vfx-harness.js';
const position={x:1,y:1.7,z:2};
const find=(h,n)=>(h.scene.getObjectByName(n)||h.viewScene.getObjectByName(n)).geometry;
test('capacities equal proven emission bounds and retain all eight fixed batches',()=>{
 assert.equal(SKILL_VFX_LIMITS.eSegments,12*(7+2));
 assert.equal(SKILL_VFX_LIMITS.rSegments,22*(27+2*8)+13*20);
 assert.equal(SKILL_VFX_LIMITS.rTargetSegments,SKILL_VFX_LIMITS.rTargets*8*4);
 const h=createSkillVfxHarness(createSkillVfx);
 assert.equal(h.geometries.length,8);assert.equal(h.vfx.inspect().capacity,1946);
 assert.equal(h.arrays.reduce((s,a)=>s+a.byteLength,0),560448);h.vfx.dispose();
});
test('maximum E, R and target population fill capacity without truncation',()=>{
 const h=createSkillVfxHarness(createSkillVfx);
 h.vfx.event('static_field_discharge',{position,targets:Array.from({length:100},()=>position)});
 h.vfx.update(.01,{position,status:vfxStatus('E_Hold',.2,{armed:5})});
 for(const n of ['E_lavender_fist_lightning_A','E_lavender_fist_lightning_B','R_ivory_branched_web','R_target_sparks']){
  const g=find(h,n);assert.equal(g.drawRange.count,g.attributes.position.count,n);
  for(const [key,a]of Object.entries(g.attributes)){assert(a.array.every(Number.isFinite));if(key!=='uv')assert.equal(a.updateRanges.length,0,'full capacity uses full upload');}
 }
 h.vfx.dispose();
});
test('instrumented emitter rejects any overflow throughout event saturation, gaps and reset',async()=>{
 let source=fs.readFileSync(new URL('../skill-vfx.js',import.meta.url),'utf8');
 const guard='if (this.count >= capacity) return false;';assert.equal(source.split(guard).length,2);
 source=source.replace(guard,"if (this.count >= capacity) throw new Error('VFX emission exceeded proved capacity');");
 const checked=(await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'))).createSkillVfx;
 for(const radius of [.01,7,30,1e100]){
  const h=createSkillVfxHarness((T,o)=>checked(T,{...o,rRadius:radius,wDuration:.01,wSlowDuration:1e100}));
  for(let f=0;f<300;f++){
   if(f%31===0)h.vfx.event('static_field_discharge',{position,groundY:-4,frameOffset:f%3*.01,targets:Array.from({length:30},(_,i)=>({x:i,y:1,z:0}))});
   if(f%7===0)for(let i=0;i<30;i++)h.vfx.event('static_field_target',{position});
   if(f%11===0)h.vfx.event('power_fist_hit',{position});
   h.vfx.update([1/120,1/60,1/30,.1,.5,0,NaN,-1,Infinity][f%9],{position,status:vfxStatus(f%2?'E_Charge':'E_Hold',f/60,{armed:3,boost:f%5?2:0,slow:1}),thirdPerson:!!(f%2),moving:true});
   if(f%73===0)h.vfx.reset();
  }
  h.vfx.dispose();
 }
});
test('overflow oracle fails when target emission is deliberately expanded',async()=>{
 let source=fs.readFileSync(new URL('../skill-vfx.js',import.meta.url),'utf8');
 source=source.replace('if (this.count >= capacity) return false;',"if (this.count >= capacity) throw new Error('VFX emission exceeded proved capacity');");
 const targetLoop='for (let bolt = 0; bolt < 8; bolt++)';assert.equal(source.split(targetLoop).length,2);
 source=source.replace(targetLoop,'for (let bolt = 0; bolt < 9; bolt++)');
 const checked=(await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'))).createSkillVfx;
 const h=createSkillVfxHarness(checked);
 assert.throws(()=>h.vfx.event('static_field_discharge',{position,targets:Array.from({length:12},()=>position)}),/exceeded proved capacity/);
 h.vfx.dispose();
});
