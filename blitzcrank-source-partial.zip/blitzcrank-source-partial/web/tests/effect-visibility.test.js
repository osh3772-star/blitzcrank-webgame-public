import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from '../vendor/three.module.js';
import {FLASH_FRAMES as manifest} from '../flash-frame-manifest.js';
import {createFlashFrameVfx} from '../flash-frame-vfx.js';
import {SKILL_VFX_PALETTE as palette} from '../skill-vfx.js';
test('forward Flash departure is behind FPS camera; source replay projects visibly in landscape and portrait',()=>{
 for(const aspect of [16/9,9/16]){
  const scene=new THREE.Scene(),viewScene=new THREE.Scene(),texture=new THREE.Texture();
  const vfx=createFlashFrameVfx(THREE,{scene,viewScene,texture,manifest});
  vfx.play({x:0,y:1.7,z:7},{firstPerson:true});
  const camera=new THREE.PerspectiveCamera(70,aspect,.03,200);camera.position.set(0,1.7,3);camera.updateMatrixWorld(true);
  const departure=scene.children[0].position.clone().applyMatrix4(camera.matrixWorldInverse);
  assert(departure.z>0,'real departure lies behind camera');
  const viewCamera=new THREE.PerspectiveCamera(aspect<1?72:54,aspect,.03,20);viewCamera.updateMatrixWorld(true);
  const replay=viewScene.children[0];const ndc=replay.position.clone().project(viewCamera);
  assert(Math.abs(ndc.x)<1&&Math.abs(ndc.y)<1&&ndc.z<1&&ndc.z>-1);
  assert.equal(replay.material,scene.children[0].material);assert.equal(replay.material.map,texture);
  assert(vfx.inspect().fpsReplay);assert.equal(vfx.inspect().arrival,false);
  vfx.update(.1,{firstPerson:false});assert.equal(vfx.inspect().fpsReplay,false);assert(vfx.inspect().active);
  vfx.update(.1,{firstPerson:true});assert(vfx.inspect().fpsReplay);assert.equal(vfx.inspect().sourceFrame,28);
  vfx.update(.4);assert.equal(replay.visible,false);vfx.dispose();assert.equal(viewScene.children.length,0);
 }
});
test('R-only calibrated palette retains W cyan but reduces R yellow/cyan chroma',()=>{
 assert.equal(palette.fieldIvory,0xfffee6);assert.equal(palette.fieldCool,0xf0ffe8);assert.equal(palette.fieldBlue,0xbfeaff);
});
