import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {createAuditedHookCollider} from '../rift-v49-hook-collider.js';import {createAuditedHookTrial} from '../rift-v49-audited-hook.js';
import {createMapHookTrial} from '../rift-v39-hook.js';import {createMapProbe} from '../rift-v39-study.js';import {MAP_STUDY_V39 as study} from '../rift-v39-revisions.js';
const clear=()=>({pass:true});
test('continuous clipping stops just before a thin obstacle, not beyond it',()=>{
 const c=createAuditedHookCollider({auditSegment:(a,b)=>({pass:Math.max(a[0],b[0])<2,reason:'thin-wall'})});const a=c.sweep([0,0],[10,0]);assert(a.position[0]<2&&a.position[0]>1.999);assert.equal(a.blockedBy,'thin-wall');assert(a.resolution<1e-9);
});
test('the collision reason identifies the first contact rather than a later obstacle',()=>{
 const c=createAuditedHookCollider({auditSegment:(a,b)=>({pass:b[0]<2,reason:b[0]>=4?'later-wall':'first-wall'})});assert.equal(c.sweep([0,0],[10,0]).blockedBy,'first-wall');
});
test('blocked initial volume rejects cast without creating live hook state',()=>{
 const c=createAuditedHookTrial({collider:createAuditedHookCollider({auditSegment:()=>({pass:false,reason:'wall'})})});assert.equal(c.cast({origin:[0,0],aim:[4,0]}).accepted,false);assert.equal(c.snapshot().phase,'idle');
});
test('target in front of wall is hit; target behind wall is not',()=>{
 for(const [x,expected] of [[1,'target'],[4,null]]){const c=createAuditedHookTrial({collider:createAuditedHookCollider({auditSegment:(a,b)=>({pass:Math.max(a[0],b[0])<2,reason:'wall'})})});c.cast({origin:[0,0],aim:[5,0],targets:[{id:'target',center:[x,0],radius:.2}]});for(let i=0;i<100&&c.snapshot().phase!=='idle';i++)c.step(.05);assert.equal(c.snapshot().hit,expected);}
});
test('a blocked moving-home return cannot cut through the new wall',()=>{
 let blocked=false;const c=createAuditedHookTrial({collider:createAuditedHookCollider({auditSegment:(a,b)=>({pass:!blocked||a[1]===b[1],reason:'return-wall'})})});c.cast({origin:[0,0],aim:[2,0],targets:[{id:'target',center:[2,0],radius:.2}]});while(c.snapshot().phase==='outbound')c.step(.05);blocked=true;const a=c.step(.05,{home:[0,2]});assert.equal(a.phase,'blocked');assert.match(a.reason,/return-blocked/);
});
test('cancel and malformed inputs cannot leave an advancing ghost hook',()=>{
 const c=createAuditedHookTrial({collider:createAuditedHookCollider({auditSegment:clear})});c.cast({origin:[0,0],aim:[4,0]});c.cancel();assert.equal(c.step(.05).phase,'idle');assert.throws(()=>c.step(NaN));assert.throws(()=>c.cast({origin:[NaN,0],aim:[1,0]}));
});
test('state machine matches original diagnostic hook with equivalent planar audit',()=>{
 const layout=JSON.parse(fs.readFileSync(new URL('../'+study.collision,import.meta.url))),probe=createMapProbe(layout,{radius:.12,study});
 const a=createMapHookTrial(layout,{study}),b=createAuditedHookTrial({collider:createAuditedHookCollider({auditSegment:(x,y)=>{const reason=probe.probe(x,y).blockedBy;return {pass:!reason,reason};}})});
 for(const aim of [[8,0],[0,-15],[80,0]]){const input={origin:[-8,0],aim,targets:[{id:'target',center:aim,radius:.7}]};assert.deepEqual(a.cast(input),b.cast(input));for(let i=0;i<500;i++){const x=a.step(1/60),y=b.step(1/60);assert.deepEqual(y,x);if(x.phase==='idle'||x.phase==='blocked')break;}a.cancel();b.cancel();}
});
