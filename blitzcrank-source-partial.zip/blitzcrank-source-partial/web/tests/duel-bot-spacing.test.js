import test from 'node:test';
import assert from 'node:assert/strict';
import {createDuelBotInputs} from '../duel-bot-inputs.js';
const tuning={playerSpeed:6.4,hookSpeed:42,maxRange:32,cooldown:2.2,windup:.25};
const arena={min:{x:-23.4,z:-42.5},max:{x:23.4,z:15.5}};
const make=(seed='round-1',options={})=>createDuelBotInputs({seed,tuning,arena,...options});
const observation=(patch={})=>({active:true,dt:1/60,canSeeOpponent:true,self:{position:{x:0,y:1.7,z:0},yaw:0,pitch:0,cooldown:0,skills:{phase:null,cooldown:{E:0,R:0},armed:0},...patch.self},opponent:{position:{x:0,y:1.7,z:-12},velocity:{x:0,y:0,z:0},...patch.opponent},...Object.fromEntries(Object.entries(patch).filter(([k])=>!['self','opponent'].includes(k)))});
const advance=(bot,obs,frames=60)=>Array.from({length:frames},()=>bot.step(obs));
function trace(seed,hz=60,seconds=60,options={}){
 const bot=make(seed,options), stats={modes:new Set(),close:0,spaced:0,total:0,inward:0,outward:0,left:0,right:0,casts:0,transitions:[],frames:[]};let p={x:0,y:1.7,z:7},previous=null;
 for(let i=0;i<hz*seconds;i++){
  const dx=-p.x,dz=-12-p.z,d=Math.hypot(dx,dz),out=bot.step(observation({dt:1/hz,self:{position:p}})),state=bot.snapshot();
  assert.ok(Math.hypot(out.move.x,out.move.z)<=1+1e-12);assert.ok([out.move.x,out.move.z,out.yaw,out.pitch].every(Number.isFinite));
  if(state.tactics){stats.modes.add(state.tactics.mode);if(previous!==state.tactics.started){stats.transitions.push({...state.tactics});previous=state.tactics.started;}}
  if(i>hz){stats.total++;if(d<5)stats.close++;if(d>=8)stats.spaced++;const radial=(dx*out.move.x+dz*out.move.z)/d,side=(-dz*out.move.x+dx*out.move.z)/d;if(radial>.2)stats.inward++;if(radial<-.2)stats.outward++;if(side>.2)stats.left++;if(side<-.2)stats.right++;}
  stats.casts+=out.castQ;stats.frames.push(out);
  p={x:p.x+out.move.x*tuning.playerSpeed/hz,y:1.7,z:p.z+out.move.z*tuning.playerSpeed/hz};
  assert.ok(p.x>=arena.min.x&&p.x<=arena.max.x&&p.z>=arena.min.z&&p.z<=arena.max.z);
 }
 return stats;
}

test('skill-enabled duels spend most time spaced, move in/out and both ways, and still try Q',()=>{
 for(const hz of [30,60,120])for(const seed of [1,42,23320,'round-1','round-2','round-3']){
  const s=trace(seed,hz);assert.ok(s.spaced/s.total>.65,`${seed}@${hz}: spaced ${s.spaced/s.total}`);assert.ok(s.close/s.total<.2);
  for(const direction of ['inward','outward','left','right'])assert.ok(s[direction]>hz*4,`${seed}@${hz} ${direction}`);
  assert.ok(s.casts>=18&&s.casts<=27);assert.deepEqual([...s.modes].sort(),['feint','pressure','retreat','spacing']);
 }
});

test('pressure is brief and always followed by retreat instead of endless melee pursuit',()=>{
 const s=trace('round-2');let pressure=0;
 for(let i=0;i<s.transitions.length;i++){const p=s.transitions[i];assert.ok(p.until-p.started>=1.8);if(p.mode==='pressure'){pressure++;assert.ok(p.until-p.started<2.7);if(s.transitions[i+1])assert.equal(s.transitions[i+1].mode,'retreat');}}
 assert.ok(pressure>=2);
});

test('different round seeds mix patterns; same seed and reset reproduce exactly',()=>{
 const a=trace('round-1',30,15),b=trace('round-2',30,15),again=trace('round-1',30,15);
 assert.notDeepEqual(a.frames,b.frames);assert.deepEqual(a.frames,again.frames);
 const bot=make(),obs=observation();const before=advance(bot,obs,800);bot.reset();assert.deepEqual(advance(bot,obs,800),before);
 const snap=bot.snapshot();snap.tactics.distance=999;assert.notEqual(bot.snapshot().tactics.distance,999);
});

test('spacing retreats from a close opponent even when E/R are ready',()=>{
 const bot=make('round-1'),out=advance(bot,observation({opponent:{position:{x:0,y:1.7,z:-3}}}),30).at(-1);
 assert.equal(bot.snapshot().tactics.mode,'spacing');assert.ok(out.move.z>.5);
});

test('a feint has a readable inward phase and outward phase without frame-wise rerolls',()=>{
 const bot=make(1);advance(bot,observation(),30);const plan=bot.snapshot().tactics;assert.equal(plan.mode,'feint');
 const obs=observation({opponent:{position:{x:0,y:1.7,z:-plan.distance}}});
 let inwards=false,outwards=false;
 while(bot.snapshot().time<plan.until-.05){const out=bot.step(obs);const state=bot.snapshot();assert.equal(state.tactics.started,plan.started);if((state.time-plan.started)/(plan.until-plan.started)<.44)inwards ||= out.move.z<-.2;else outwards ||=out.move.z>.2;}
 assert.ok(inwards&&outwards);
});

test('an active hook reopens distance even during a pressure tactic',()=>{
 const bot=make(23320);advance(bot,observation({opponent:{position:{x:0,y:1.7,z:-3}}}),25);assert.equal(bot.snapshot().tactics.mode,'pressure');
 const out=bot.step(observation({self:{hookActive:true},opponent:{position:{x:0,y:1.7,z:-3}}}));assert.ok(out.move.z>.5);assert.equal(out.castQ,false);assert.equal(out.castE,false);assert.equal(out.strikeE,false);assert.equal(out.castR,false);
});

test('unavailable close attacks cannot select pressure and E is not charged while circling at 6m',()=>{
 const bot=make(23320),obs=observation({self:{canCastE:false,canCastR:false,skills:{phase:null,cooldown:{E:3,R:9},armed:0}}});
 for(let i=0;i<3600;i++){bot.step(obs);assert.notEqual(bot.snapshot().tactics?.mode,'pressure');}
 const spaced=make('round-1'),frames=advance(spaced,observation({self:{canCastQ:false},opponent:{position:{x:0,y:1.7,z:-6}}}),120);
 assert.ok(frames.every(out=>!out.castE));
});

test('pause and invalid deltas freeze tactics, and hidden coordinates never select tactics',()=>{
 const a=make(),b=make();advance(a,observation());advance(b,observation());const before=a.snapshot();
 for(const patch of [{active:false},{dt:0},{dt:-1},{dt:NaN},{dt:Infinity}])for(let i=0;i<10;i++){assert.deepEqual(a.step(observation(patch)).move,{x:0,z:0});assert.deepEqual(a.snapshot(),before);}
 for(let i=0;i<600;i++){
  const one=a.step(observation({canSeeOpponent:false,opponent:{position:{x:20,y:9,z:15}}}));
  const two=b.step(observation({canSeeOpponent:false,opponent:{position:{x:-20,y:1.7,z:-40}}}));
  assert.deepEqual(one,two);assert.deepEqual(a.snapshot(),b.snapshot());assert.deepEqual(a.snapshot().tactics,before.tactics);
 }
 for(let i=0;i<13;i++){assert.equal(a.step(observation()).castQ,false);assert.deepEqual(a.snapshot().tactics,before.tactics);}
});

test('tactical movement also avoids static cover and bounds at 30/60/120Hz',()=>{
 const cover={min:{x:-2,y:0,z:-4},max:{x:2,y:4,z:-1}};
 for(const hz of [30,60,120]){
  const bot=make('cover',{obstacles:[cover]});let position={x:5,y:1.7,z:5};
  for(let i=0;i<hz*30;i++){
   const out=bot.step(observation({dt:1/hz,self:{position},opponent:{position:{x:7,y:1.7,z:-8}}}));
   position={x:position.x+out.move.x*6.4/hz,y:1.7,z:position.z+out.move.z*6.4/hz};
   assert.ok(!(position.x>cover.min.x-.7&&position.x<cover.max.x+.7&&position.z>cover.min.z-.7&&position.z<cover.max.z+.7));
   assert.ok(position.x>=arena.min.x&&position.x<=arena.max.x&&position.z>=arena.min.z&&position.z<=arena.max.z);
  }
 }
});
