import test from 'node:test';
import assert from 'node:assert/strict';
import {createGameplayHarness} from './helpers/runtime-harness.js';
import * as THREE from '../vendor/three.module.js';
const h=await createGameplayHarness(),motion=()=>h.qa.motion.locomotion;
function fresh(){h.game.begin(true);h.frames(1);for(const t of h.game.data.targets){t.active=false;t.respawn=Infinity;t.group.visible=false;}}
function matrices(){return [...h.game.data.fullbodyMeshes.values()].map(m=>{m.updateWorldMatrix(true,false);return m.matrixWorld.toArray();});}
function foot(){const m=h.game.data.fullbodyMeshes.get('BC_FootSole.L');m.updateWorldMatrix(true,false);return m.geometry.boundingBox.getCenter(new THREE.Vector3()).applyMatrix4(m.matrixWorld).sub(h.game.data.player);}
function floor(){for(const side of ['L','R']){const m=h.game.data.fullbodyMeshes.get('BC_FootSole.'+side),p=m.geometry.attributes.position,v=new THREE.Vector3();m.updateWorldMatrix(true,false);for(let i=0;i<p.count;i++)assert(v.fromBufferAttribute(p,i).applyMatrix4(m.matrixWorld).y>-1e-5);}for(const l of motion().legs)assert.equal(l.clamped,false);}
test('actual R_Cast player feet gait while moving in first/third person, safely stop and respect collision',()=>{
 for(const third of [false,true]){fresh();if((h.qa.view==='third')!==third)h.key('KeyV');h.key('KeyR');h.key('KeyW');const positions=[];for(let f=0;f<20;f++){h.frames(1);assert.equal(h.qa.skills.phase,'R_Cast');positions.push(foot());floor();}assert(positions.some(p=>p.distanceTo(positions[0])>.1));const blend=motion().blend;h.release('KeyW');h.frames(45);assert.equal(h.qa.skills.phase,'R_Cast');assert.equal(motion().moving,false);assert(Math.abs(motion().blend-blend*Math.exp(-13*45/60))<1e-12);floor();h.frames(10);assert.equal(motion().blend,0);floor();}
 fresh();h.game.data.player.x=23.39;h.key('KeyD');h.frames(30);h.key('KeyR');h.frames(30);assert.equal(h.qa.skills.phase,'R_Cast');assert.equal(motion().blend,0);assert.equal(motion().phase,0);floor();h.release('KeyD');
});
test('R jump freezes grounded phase; pause and zero-dt view refresh preserve full pose',()=>{
 fresh();h.key('KeyW');h.frames(15);h.key('KeyR');h.frames(4);h.key('Space');const phase=motion().phase;h.frames(12);assert.equal(h.qa.skills.phase,'R_Cast');assert(h.qa.player.y>1.7);assert.equal(motion().phase,phase);const state=motion(),before=matrices();h.game.pause();h.frames(20);for(let i=0;i<4;i++)h.element('viewtoggle').onclick();assert.deepEqual(motion(),state);const after=matrices();for(let i=0;i<before.length;i++)for(let k=0;k<16;k++)assert(Math.abs(after[i][k]-before[i][k])<1e-11);h.game.resume();h.release('KeyW');h.release('Space');h.frames(90);floor();
});
test('R returns to held E and then Q clears blended surfaces without a stale transform',()=>{
 fresh();h.key('KeyE');h.frames(53);h.key('KeyW');h.frames(15);h.key('KeyR');h.frames(12);assert.equal(h.qa.skills.phase,'R_Cast');h.frames(60);assert.equal(h.qa.skills.phase,'E_Hold');floor();h.key('KeyQ');h.frames(5);assert(h.qa.hook);for(const m of h.game.data.fullbodyMeshes.values())assert(m.matrixAutoUpdate);h.release('KeyW');
});
