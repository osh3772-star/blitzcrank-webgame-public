// Narrow, version-pinned experimental semantic policy, never a name-only global rule.
import {createHash} from 'node:crypto';import {MAP_V49} from './rift-v49-offline-inputs.mjs';
export function createHookFoliagePolicy({glbBytes,collisionBytes}={}){
 const hash=b=>createHash('sha256').update(b).digest('hex');
 if(!Buffer.isBuffer(glbBytes)||!Buffer.isBuffer(collisionBytes)||hash(glbBytes)!==MAP_V49.glbSHA||hash(collisionBytes)!==MAP_V49.collisionSHA)
  throw Error('Exact official v49 files required for foliage policy');
 const layout=JSON.parse(collisionBytes);
 if(layout.decorativeFoliageUsesCliffFootprint!==true||layout.assetVersion!=='sr-study-0.49')throw Error('Required foliage footprint evidence missing');
 const gltf=JSON.parse(glbBytes.subarray(20,20+glbBytes.readUInt32LE(12))),name='Batched_Grass_And_Reeds',nodes=gltf.nodes.filter(n=>n.name===name);
 if(nodes.length!==1||!Number.isInteger(nodes[0].mesh))throw Error('Unique verified foliage node required');
 const mesh=gltf.meshes[nodes[0].mesh];if(mesh.name!=='Batched_Forest_And_Reeds.001'||mesh.primitives.length!==1)throw Error('Unexpected foliage mesh identity');
 return Object.freeze({revision:'0.49',excludedMeshNames:Object.freeze([name]),
  evidence:Object.freeze({collisionFlag:'decorativeFoliageUsesCliffFootprint=true',node:name,mesh:mesh.name,glbSHA:MAP_V49.glbSHA,collisionSHA:MAP_V49.collisionSHA}),
  blocksSurface(triangle){return triangle.mesh!==name;},
  planarCliffAndBoundaryChecksRequired:true,otherFoliageExcluded:false,adopted:false,
  limitation:'Evidence supports a narrow diagnostic candidate, not an authoritative game collision schema.'});
}
