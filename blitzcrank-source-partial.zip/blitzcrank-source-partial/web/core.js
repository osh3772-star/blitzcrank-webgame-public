export const CONFIG = Object.freeze({duration:90,hookSpeed:42,returnSpeed:34,maxRange:32,cooldown:2.2,playerSpeed:6.4,targetRadius:.68});
export function raySphere(origin,dir,center,radius,maxDistance=Infinity){const x=origin.x-center.x,y=origin.y-center.y,z=origin.z-center.z;const b=x*dir.x+y*dir.y+z*dir.z,c=x*x+y*y+z*z-radius*radius;if(c<=0)return 0;const d=b*b-c;if(d<0)return null;const t=-b-Math.sqrt(d);return t>=0&&t<=maxDistance?t:null;}
export function rayBox(origin,dir,min,max,range=Infinity){let near=0,far=range;for(const k of ['x','y','z']){if(Math.abs(dir[k])<1e-8){if(origin[k]<min[k]||origin[k]>max[k])return null;}else{let a=(min[k]-origin[k])/dir[k],b=(max[k]-origin[k])/dir[k];if(a>b)[a,b]=[b,a];near=Math.max(near,a);far=Math.min(far,b);if(near>far)return null;}}return near;}
export function formatTime(seconds){const n=Math.max(0,Math.ceil(seconds));return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;}
export class Session{constructor(){this.reset(false);}reset(practice){this.practice=practice;this.elapsed=0;this.score=0;this.catches=0;this.shots=0;this.hits=0;this.combo=0;this.bestCombo=0;this.punches=0;this.done=false;}tick(dt){if(this.done)return;this.elapsed+=dt;if(!this.practice&&this.elapsed>=CONFIG.duration){this.elapsed=CONFIG.duration;this.done=true;}}shot(){this.shots++;}hit(){this.hits++;}miss(){this.combo=0;}capture(){this.combo++;this.bestCombo=Math.max(this.bestCombo,this.combo);const points=100*Math.min(this.combo,5);this.score+=points;this.catches++;return points;}punch(){this.punches++;this.score+=40;return 40;}get accuracy(){return this.shots?Math.round(this.hits/this.shots*100):0;}}

// A shoulder boom rotates around the actor in both axes; the camera optics use
// the same YXZ rotation. Inflate cover by the lens radius before sweeping it.
export function thirdPersonCameraPosition(pivot,yaw,pitch,obstacles=[]){
 const sy=Math.sin(yaw),cy=Math.cos(yaw),sp=Math.sin(pitch),cp=Math.cos(pitch),vertical=.8*cp-4.6*sp,back=.8*sp+4.6*cp;
 const offset={x:.9*cy+back*sy,y:vertical,z:-.9*sy+back*cy},length=Math.hypot(offset.x,offset.y,offset.z),dir={x:offset.x/length,y:offset.y/length,z:offset.z/length};let distance=length;
 for(const [axis,min,max] of [['x',-24.7,24.7],['z',-44.7,20.5]]){if(dir[axis]>1e-8)distance=Math.min(distance,(max-pivot[axis])/dir[axis]);else if(dir[axis]<-1e-8)distance=Math.min(distance,(min-pivot[axis])/dir[axis]);}
 distance=Math.max(0,distance);
 for(const o of obstacles){const radius=.18,min={x:o.min.x-radius,y:o.min.y-radius,z:o.min.z-radius},max={x:o.max.x+radius,y:o.max.y+radius,z:o.max.z+radius},hit=rayBox(pivot,dir,min,max,distance);if(hit!==null)distance=Math.min(distance,Math.max(0,hit-.02));}
 return{x:pivot.x+dir.x*distance,y:pivot.y+dir.y*distance,z:pivot.z+dir.z*distance,distance};
}
