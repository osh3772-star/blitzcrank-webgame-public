// Continuous planar coverage and conservative straight-corridor evidence only.
const cross=(a,b,p)=>(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);
export const polygonArea=p=>Math.abs(p.reduce((sum,a,i)=>{const b=p[(i+1)%p.length];return sum+a[0]*b[1]-a[1]*b[0];},0))/2;
function signedArea(p){return p.reduce((sum,a,i)=>{const b=p[(i+1)%p.length];return sum+a[0]*b[1]-a[1]*b[0];},0)/2;}
const ccw=p=>signedArea(p)<0?p.slice().reverse():p.slice();
function halfPlane(poly,a,b,inside){
 const out=[];
 for(let i=0;i<poly.length;i++){
  const p=poly[i],q=poly[(i+1)%poly.length],dp=cross(a,b,p),dq=cross(a,b,q);
  const ip=inside?dp>=0:dp<=0,iq=inside?dq>=0:dq<=0;
  if(ip)out.push(p);
  if(ip!==iq){const t=dp/(dp-dq);out.push([p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1])]);}
 }
 return out;
}
function subtractTriangle(subject,triangle){
 let remaining=subject;const outside=[];
 for(let i=0;i<3&&remaining.length>=3;i++){
  const a=triangle[i],b=triangle[(i+1)%3],cut=halfPlane(remaining,a,b,false);
  if(cut.length>=3&&polygonArea(cut)>0)outside.push(cut);
  remaining=halfPlane(remaining,a,b,true);
 }
 return outside;
}
export function convexHull(points){
 const p=[...new Map(points.map(v=>[v.join(','),v.slice()])).values()].sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
 if(p.length<3)throw Error('Nondegenerate polygon required');
 const lower=[],upper=[];
 for(const v of p){while(lower.length>=2&&cross(lower.at(-2),lower.at(-1),v)<=0)lower.pop();lower.push(v);}
 for(const v of p.slice().reverse()){while(upper.length>=2&&cross(upper.at(-2),upper.at(-1),v)<=0)upper.pop();upper.push(v);}
 return lower.slice(0,-1).concat(upper.slice(0,-1));
}
export function sweptFootprint(from,to,halfExtent=.7){
 if(![from,to].every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))||!Number.isFinite(halfExtent)||halfExtent<=0||halfExtent>2)
  throw Error('Finite endpoints and bounded positive half extent required');
 return convexHull([from,to].flatMap(([x,z])=>[[-1,-1],[-1,1],[1,-1],[1,1]].map(([a,b])=>[x+a*halfExtent,z+b*halfExtent])));
}
export function planarCoverage(triangles,polygon,{planeY=0,supportNames=['Continuous_Terrain_Base_1'],heightTolerance=1e-7,areaTolerance=1e-9,maxPieces=20000}={}){
 if(!Array.isArray(polygon)||polygon.length<3||polygon.length>32||!polygon.every(p=>Array.isArray(p)&&p.length===2&&p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024))||
 ![planeY,heightTolerance,areaTolerance].every(Number.isFinite)||heightTolerance<0||heightTolerance>1e-4||areaTolerance<0||areaTolerance>1e-6||
 !Number.isInteger(maxPieces)||maxPieces<1||maxPieces>100000||!Array.isArray(supportNames)||!supportNames.length)throw Error('Invalid bounded coverage options');
 const target=ccw(polygon);if(polygonArea(target)<=areaTolerance)throw Error('Nondegenerate coverage polygon required');
 for(let i=0;i<target.length;i++)if(cross(target[i],target[(i+1)%target.length],target[(i+2)%target.length])<0)throw Error('Convex coverage polygon required');
 const xs=target.map(p=>p[0]),zs=target.map(p=>p[1]),minX=Math.min(...xs),maxX=Math.max(...xs),minZ=Math.min(...zs),maxZ=Math.max(...zs);
 let uncovered=[target],used=0;
 for(const t of triangles){
  if(!supportNames.includes(t.mesh)||t.normal.y<=0||t.bounds.max.x<minX||t.bounds.min.x>maxX||t.bounds.max.z<minZ||t.bounds.min.z>maxZ)continue;
  const vertices=[t.triangle.a,t.triangle.b,t.triangle.c];
  if(!vertices.every(v=>Math.abs(v.y-planeY)<=heightTolerance))continue;
  const clip=ccw(vertices.map(v=>[v.x,v.z]));if(polygonArea(clip)===0)continue;
  uncovered=uncovered.flatMap(p=>subtractTriangle(p,clip));used++;
  if(uncovered.length>maxPieces)throw Error('Coverage fragment budget exceeded');
  if(!uncovered.length)break;
 }
 const missingArea=uncovered.reduce((sum,p)=>sum+polygonArea(p),0),targetArea=polygonArea(target);
 return {planeY,targetArea,missingArea,covered:missingArea<=areaTolerance,heightTolerance,areaTolerance,
  supportTrianglesUsed:used,uncoveredPolygons:uncovered,continuousPlanarCoverage:true,
  numericalMethod:'Convex polygon subtraction from coplanar upward support-triangle union; floating point with explicit tolerances.'};
}
export function triangleIntersectsPrism(triangle,footprint,minY,maxY){
 let poly=[triangle.a,triangle.b,triangle.c].map(v=>[v.x,v.y,v.z]);
 const planes=[p=>p[1]-minY,p=>maxY-p[1],...footprint.map((a,i)=>{const b=footprint[(i+1)%footprint.length];return p=>cross(a,b,[p[0],p[2]]);})];
 for(const distance of planes){
  const next=[];
  for(let i=0;i<poly.length;i++){
   const a=poly[i],b=poly[(i+1)%poly.length],da=distance(a),db=distance(b),ia=da>=0,ib=db>=0;
   if(ia)next.push(a);
   if(ia!==ib){const t=da/(da-db);next.push(a.map((v,j)=>v+t*(b[j]-v)));}
  }
  poly=next;if(!poly.length)return false;
 }
 return poly.length>0;
}
export function auditStraightCorridor(THREE,triangles,probe,{from,to,halfExtent=.7,height=2.1,planeY=0,skin=.01}={}){
 if(![height,planeY,skin].every(Number.isFinite)||height<=0||height>5||skin<=0||skin>=height)throw Error('Invalid body dimensions');
 const footprint=sweptFootprint(from,to,halfExtent),coverage=planarCoverage(triangles,footprint,{planeY});
 const blockedBy=probe.probe(from,to).blockedBy;
 const xs=footprint.map(p=>p[0]),zs=footprint.map(p=>p[1]);
 const box=new THREE.Box3(new THREE.Vector3(Math.min(...xs),planeY+skin,Math.min(...zs)),new THREE.Vector3(Math.max(...xs),planeY+height,Math.max(...zs)));
 const intersections=triangles.filter(t=>t.bounds.intersectsBox(box)&&triangleIntersectsPrism(t.triangle,footprint,planeY+skin,planeY+height));
 return {from:from.slice(),to:to.slice(),footprint,coverage,blockedBy,
  sweptBodySurfaceClear:intersections.length===0,intersectionCount:intersections.length,
  intersectionMeshes:[...new Set(intersections.map(t=>t.mesh))].sort(),
  conservativeChecksPassed:coverage.covered&&!blockedBy&&!intersections.length,
  sweptShape:'Convex swept horizontal AABB footprint extruded through body height',closedSolidContainmentVerified:false,
  adopted:false,physicsIntegrated:false,browserGpuVerified:false};
}
