const movement=new Set(['KeyW','KeyA','KeyS','KeyD']);
function editable(target){
 return !!(target?.isContentEditable||target?.closest?.('input,textarea,select,[role="textbox"]'));
}
// Event-shaped inputs allow deterministic policy tests without claiming DOM QA.
export function createKeyboardInput({keys,canMove,hook,flash,interrupt}){
 return Object.freeze({
  keydown(event){
   if(event.ctrlKey||event.metaKey||event.altKey||event.isComposing){keys.clear();return false;}
   if(editable(event.target)){keys.clear();return false;}
   if(event.repeat)return false;
   if(movement.has(event.code)){
    if(!canMove())return false;
    event.preventDefault();keys.add(event.code);return true;
   }
   const action=event.code==='KeyQ'?hook:event.code==='KeyF'?flash:event.code==='Escape'?interrupt:null;
   if(!action)return false;
   event.preventDefault();action();return true;
  },
  keyup(event){keys.delete(event.code);},
  clear(){keys.clear();}
 });
}
