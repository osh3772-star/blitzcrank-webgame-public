// Isolated fixed-plane trial. Reuses the real destination resolver, not game authority.
import {resolveFlashDestination,FLASH_TUNING} from './flash-controller.js';
export function createAuditedFlash({spawn,bounds,landingAudit,pathAudit,boundaryAudit}={}){
 const point=p=>Array.isArray(p)&&p.length===2&&p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024);
 for(const callback of [landingAudit,pathAudit,boundaryAudit])if(typeof callback!=='function')throw Error('Explicit audits required');
 if(!bounds||![bounds.minX,bounds.maxX,bounds.minZ,bounds.maxZ].every(Number.isFinite)||bounds.minX>=bounds.maxX||bounds.minZ>=bounds.maxZ)throw Error('Finite map bounds required');
 const stableBounds={...bounds};
 function check(callback,...points){const r=callback(...points.map(p=>p.slice()));if(!r||typeof r.pass!=='boolean')throw Error('Audit must return boolean pass');return r;}
 if(!point(spawn)||!check(landingAudit,spawn).pass)throw Error('Invalid or blocked spawn');
 let position=spawn.slice(),remaining=0,casts=0;
 const snapshot=()=>({position:position.slice(),remaining,casts,ready:remaining===0,planeY:0,gameplayIntegrated:false});
 function preview({aim,policy='clear-path'}={}){
  const reject=reason=>({accepted:false,reason,policy});
  if(!['clear-path','landing-only'].includes(policy))return reject('invalid-policy');
  if(!point(aim))return reject('invalid-aim');
  const from=position.slice(),dx=aim[0]-from[0],dz=aim[1]-from[1],length=Math.hypot(dx,dz);
  if(length<FLASH_TUNING.minDistance)return reject('too-short');
  const resolved=resolveFlashDestination({position:{x:from[0],y:0,z:from[1]},yaw:Math.atan2(-dx,-dz),
   range:Math.min(length,FLASH_TUNING.range),minDistance:FLASH_TUNING.minDistance,searchStep:FLASH_TUNING.searchStep,bounds:stableBounds,
   isBlocked:(x,z)=>!check(landingAudit,[x,z]).pass});
  if(!resolved)return reject('no-valid-landing');
  const destination=[resolved.position.x,resolved.position.z];
  if(!check(boundaryAudit,from,destination).pass)return reject('boundary-crossing');
  // Recheck the final destination after the resolver's search/refinement.
  if(!check(landingAudit,destination).pass)return reject('landing-changed');
  const path=check(pathAudit,from,destination);
  if(policy==='clear-path'&&!path.pass)return reject('path-blocked');
  return {accepted:true,from,position:destination,distance:resolved.distance,policy,
   crossesRejectedPath:!path.pass,range:FLASH_TUNING.range,verticalPhysicsIntegrated:false,gameplayChanged:false};
 }
 return Object.freeze({snapshot,preview,cast(options){
  if(remaining>0)return {accepted:false,reason:'cooldown'};
  const result=preview(options);if(!result.accepted)return result;
  position=result.position.slice();remaining=FLASH_TUNING.cooldown;casts++;return {...result,state:snapshot()};
 },step(dt){if(!Number.isFinite(dt)||dt<0)throw Error('Finite nonnegative dt required');remaining=Math.max(0,remaining-dt);if(remaining<1e-12)remaining=0;return snapshot();}});
}
