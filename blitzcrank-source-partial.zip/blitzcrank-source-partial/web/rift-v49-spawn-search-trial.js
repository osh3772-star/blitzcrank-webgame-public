import {createRespawnTrial} from './rift-v49-respawn-trial.js';
import {auditActorEnvelopes} from './rift-v49-actor-envelope.js';
// Bounded diagnostic grid search; closest means closest among sampled candidates.
export function createSpawnSearchTrial(options){
 const base=createRespawnTrial(options);
 function findRespawn({preferred,maxRadius=2,step=.25,maxCandidates=289}={}){
  const state=base.snapshot();if(state.disposed)throw Error('Trial disposed');if(state.paused)return {found:false,reason:'paused',checked:0};
  if(!Array.isArray(preferred)||preferred.length!==2||!preferred.every(v=>Number.isFinite(v)&&Math.abs(v)<=1024)||!Number.isFinite(maxRadius)||maxRadius<0||maxRadius>4||!Number.isFinite(step)||step<.125||step>2||!Number.isInteger(maxCandidates)||maxCandidates<1||maxCandidates>4096)throw Error('Bounded finite search parameters required');
  const n=Math.floor(maxRadius/step);if((2*n+1)**2>4096)throw Error('Grid budget exceeded');
  const candidates=[];
  for(let x=-n;x<=n;x++)for(let z=-n;z<=n;z++){const d=Math.hypot(x*step,z*step);if(d<=maxRadius)candidates.push({p:[preferred[0]+x*step,preferred[1]+z*step],d,x,z});}
  candidates.sort((a,b)=>a.d-b.d||a.x-b.x||a.z-b.z);
  const {bounds,movementAudit,boundaryAudit,bodyCollider}=options;
  if(!bounds||![bounds.minX,bounds.maxX,bounds.minZ,bounds.maxZ].every(Number.isFinite)||bounds.minX>bounds.maxX||bounds.minZ>bounds.maxZ)throw Error('Valid search bounds required');
  const passes=(fn,p)=>{const r=fn(p.slice(),p.slice());if(!r||typeof r.pass!=='boolean')throw Error('Explicit search audit required');return r.pass;};
  let checked=0;const rejected={bounds:0,boundary:0,terrain:0,body:0,actor:0};
  for(const {p,d} of candidates){
   if(checked>=maxCandidates)return {found:false,reason:'candidate-budget-exhausted',checked,rejected,totalCandidates:candidates.length};checked++;
   if(p.some(v=>Math.abs(v)>1024)||p[0]<bounds.minX||p[0]>bounds.maxX||p[1]<bounds.minZ||p[1]>bounds.maxZ){rejected.bounds++;continue;}
   if(!passes(boundaryAudit,p)){rejected.boundary++;continue;}
   if(!passes(movementAudit,p)){rejected.terrain++;continue;}
   if(bodyCollider.sweep(p,p).blockedBy){rejected.body++;continue;}
   if(state.pull.target&&!auditActorEnvelopes([p],[state.pull.target.center]).pass){rejected.actor++;continue;}
   return {found:true,position:p.slice(),distance:d,checked,rejected,totalCandidates:candidates.length,gridOnly:true};
  }
  return {found:false,reason:'no-safe-grid-candidate',checked,rejected,totalCandidates:candidates.length};
 }
 return Object.freeze({...base,findRespawn,respawnNear(request){
  const search=findRespawn(request);if(!search.found)return {accepted:false,reason:search.reason,search};
  // No cached approval: destination checks execute again at the state-changing entry point.
  const result=base.respawn({destination:search.position});return {...result,search};
 }});
}
