// Isolated diagnostic controller. Never passed to the game's simulation.
import {MAP_STUDY,createMapProbe} from './rift-map-study.js';
export const PLANAR_TRIAL=Object.freeze({radius:.7,speed:5,maxDt:.05,planeY:0,spawnA:Object.freeze([-8,0]),spawnB:Object.freeze([8,0])});
export function createPlanarTrial(layout,{spawn=PLANAR_TRIAL.spawnA,study=MAP_STUDY}={}){
 const probe=createMapProbe(structuredClone(layout),{radius:PLANAR_TRIAL.radius,study});
 function point(p){if(!Array.isArray(p)||p.length!==2||!p.every(Number.isFinite))throw Error('시험 시작점은 유한한 XZ 좌표여야 합니다.');if(probe.probe(p).blockedBy)throw Error('시험 시작점이 연구 충돌 안에 있습니다.');return p.slice();}
 let position=point(spawn),origin=position.slice(),ticks=0;
 const snapshot=()=>({position:position.slice(),origin:origin.slice(),ticks,planeY:0,radius:PLANAR_TRIAL.radius,heightCollision:false,hookEnabled:false,flashEnabled:false,networked:false});
 return Object.freeze({snapshot,reset(p=origin){const v=point(p);position=v;origin=v.slice();ticks=0;return snapshot();},advance(input,dt){
  if(!input||![input.x,input.z,dt].every(Number.isFinite)||dt<0)throw Error('유한한 방향과 음수가 아닌 시간이 필요합니다.');
  const seconds=Math.min(dt,PLANAR_TRIAL.maxDt),length=Math.hypot(input.x,input.z),scale=length>1?1/length:1,dx=input.x*scale*PLANAR_TRIAL.speed*seconds,dz=input.z*scale*PLANAR_TRIAL.speed*seconds;
  const from=position.slice(),segments=[],blocked=[];let remaining=PLANAR_TRIAL.speed*seconds;
  function attempt(to){const d=Math.hypot(to[0]-position[0],to[1]-position[1]);if(d>remaining&&d>0)to=position.map((v,i)=>v+(to[i]-v)*remaining/d);const wall=probe.probe(position,to).blockedBy;if(wall){blocked.push(wall);return false;}if(position[0]!==to[0]||position[1]!==to[1]){segments.push({from:position.slice(),to:to.slice()});remaining=Math.max(0,remaining-Math.hypot(to[0]-position[0],to[1]-position[1]));position=to;}return true;}
  if(dx||dz){const full=[position[0]+dx,position[1]+dz];if(!attempt(full)){// Axis sliding is ordered and every accepted segment is swept again.
   if(dx)attempt([position[0]+dx,position[1]]);if(dz)attempt([position[0],position[1]+dz]);
  }}
  ticks++;return{...snapshot(),from,seconds,requestedDt:dt,segments,blockedBy:[...new Set(blocked)],distance:Math.hypot(position[0]-from[0],position[1]-from[1])};
 }});
}
