import {createIsolatedPlayerSpatialTrial} from './rift-v49-isolated-player-spatial.js';
import {isolateSweepCollider} from './rift-v49-isolated-collider.js';
export function createColliderIsolatedTrial(THREE,components,options){
 return createIsolatedPlayerSpatialTrial(THREE,components,{...options,bodyCollider:isolateSweepCollider(options.bodyCollider),hookCollider:isolateSweepCollider(options.hookCollider)});
}
