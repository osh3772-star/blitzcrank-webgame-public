// Explicit ownership is relinquished BEFORE calling user-supplied destructors.
export function createResilientVisualSession({load,parse,install,releaseParsed}){
 let generation=0,controller=null,current=null,disposed=false;
 function cancel(){generation++;controller?.abort();controller=null;const old=current;current=null;old?.dispose();}
 return Object.freeze({current:()=>current,cancel,dispose(){disposed=true;cancel();},async start(){
  if(disposed)throw Error('Visual session disposed');cancel();const token=generation,abort=new AbortController();controller=abort;let parsed=null,installed=false,cleanupFailure=null;
  function release(){const owned=parsed;parsed=null;if(owned)try{releaseParsed(owned);}catch(cause){cleanupFailure=new Error('Parsed scene cleanup failed',{cause});cleanupFailure.cleanupFailure=true;cleanupFailure.superseded=token!==generation;throw cleanupFailure;}}
  try{
   const inputs=await load(abort.signal);if(token!==generation)return null;
   parsed=await parse(inputs.glb);if(token!==generation){release();return null;}
   const view=install(parsed,inputs);
   if(!view||typeof view.dispose!=='function')throw Error('Disposable view required');installed=true;parsed=null;
   if(token!==generation){try{view.dispose();}catch(cause){cleanupFailure=new Error('Stale view cleanup failed',{cause});cleanupFailure.cleanupFailure=true;cleanupFailure.superseded=true;throw cleanupFailure;}return null;}
   current=view;return view;
  }catch(error){
   if(parsed&&!installed)try{release();}catch(cleanup){const combined=new AggregateError([error,cleanup],'Visual installation and cleanup failed');combined.cleanupFailure=true;combined.superseded=token!==generation;throw combined;}
   if(cleanupFailure)throw cleanupFailure;
   if(token!==generation)return null;throw error;
  }finally{if(token===generation)controller=null;}
 }});
}
