import {createDuelMatch,transitionDuel,getDuelScope} from './duel-round-rules.js?v=0.24.70';
import {createSkillController} from './skill-controller.js?v=0.24.81';
import {evaluateDuelSkillContact} from './duel-skill-contacts.js?v=0.24.70';
import {evaluateHookFrame} from './duel-hook-contacts.js?v=0.24.70';

export const DUEL_PLAYERS=Object.freeze(['human','bot']);
// Identical, explicit torso volumes for both opponents; detached hands do not
// extend the body hitbox. Relative to eye origin (grounded eye height 1.7).
export const DUEL_SHAPE=Object.freeze({type:'aabb',min:Object.freeze({x:-.7,y:-1.7,z:-.7}),max:Object.freeze({x:.7,y:.4,z:.7})});
export const DUEL_TIE_FRACTION=64*Number.EPSILON;
const copy=p=>({x:p.x,y:p.y,z:p.z});
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const lerp=(a,b,t)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t});
const smooth=t=>t*t*(3-2*t);
const snapshot=value=>structuredClone(value);

/** Local gameplay authority. Only geometric contacts generated inside step()
 * can award a point. Command sources request casts, never supply hit flags.
 * No transport, wall clock, async callback, storage or renderer is owned here.
 */
export function createDuelSimulation({sessionId,config,countdownMs=1600,roundResetMs=3000,skillClips=null}){
 if(!config||!['hookSpeed','returnSpeed','maxRange','cooldown'].every(k=>Number.isFinite(config[k])&&config[k]>0)||!Number.isFinite(roundResetMs)||roundResetMs<=0)throw new TypeError('Duel requires positive physics and return delay');
 let match=createDuelMatch({sessionId,playerIds:DUEL_PLAYERS,countdownMs,roundResetMs}).state;
 if(!match)throw new TypeError('Invalid duel identity');
 let hooks={human:null,bot:null},cooldowns={human:0,bot:0},time=0,frame=0,serial=0,tieRemaining=0,lastContact=null,pendingGrab=null,resultStartedAt=null,events=[];
 function dispatch(type,extra={}){const r=transitionDuel(match,{type,scope:getDuelScope(match),...extra});if(r.accepted){match=r.state;events.push(...r.effects);}return r.accepted;}
 const skillControllers={},skillScopes={},skillFacades={};let impactQueue=[],skillStep=null;
 for(const id of DUEL_PLAYERS)if(skillClips){
  skillControllers[id]=createSkillController(skillClips,{onEvent(event){
   const before=skillStep?.id===id?skillStep.animation:null,scope=skillScopes[id];
   // Events belong to the clip/sequence and round captured at cast, never the
   // callback arrival order. No offensive clip starts inside controller.step.
   if(!before||!scope||event.clip!==before.name||event.sequence!==before.sequence)return;
   let offset=event.time-before.time;
   const epsilon=16*Number.EPSILON*Math.max(1,before.duration);
   if(Math.abs(offset-skillStep.dt)<=epsilon)offset=skillStep.dt;
   else if(Math.abs(offset)<=epsilon)offset=0;
   if(offset<-1e-9||offset>skillStep.dt+1e-9)return;
   const skill=event.type==='power_fist_hit'?'E':event.type==='static_field_discharge'?'R':null;
   if(skill)impactQueue.push({attackerId:id,skill,scope,epsilonMs:epsilon*1000,eventId:`${scope.roundId}/${scope.phaseNumber}/${id}/${event.sequence}/${skill}`,offset:Math.max(0,Math.min(skillStep.dt,offset))});
  }});
  const controller=skillControllers[id];
  const blockReason=(key,{busy=false}={})=>!api.active?'round':controller.blockReason(key,{busy:busy||(key!=='W'&&!!hooks[id])});
  function command(key,options={}){if(blockReason(key,options))return false;const accepted=controller['cast'+key](options);if(accepted&&key!=='W')skillScopes[id]=getDuelScope(match);return accepted;}
  skillFacades[id]=Object.freeze({blockReason,castW:()=>command('W'),castE:options=>command('E',options),castR:options=>command('R',options),
   strikeE({busy=false}={}){if(!api.active||hooks[id]||busy||!controller.strikeE())return false;skillScopes[id]=getDuelScope(match);return true;},
   // Reset is only a presentation lifecycle convenience outside live play.
   // The authority owns all steps and live-round cooldown resets.
   reset(){if(!api.active){controller.reset();delete skillScopes[id];}},
   get status(){return controller.status;},get animation(){return controller.animation;},
   get blocksAttack(){return controller.blocksAttack;},get moveMultiplier(){return controller.moveMultiplier;},get attackMultiplier(){return controller.attackMultiplier;}});
 }
 function resetCombat(){hooks={human:null,bot:null};cooldowns={human:0,bot:0};tieRemaining=0;lastContact=null;pendingGrab=null;resultStartedAt=null;impactQueue=[];skillStep=null;for(const id of DUEL_PLAYERS){skillControllers[id]?.reset();delete skillScopes[id];}}
 function sameScope(scope){const current=getDuelScope(match);return current&&Object.keys(current).every(k=>current[k]===scope[k]);}
 function returnHook(h,home){if(!h||['return','recover'].includes(h.phase))return;h.phase='return';h.phaseTime=0;h.returnStart=copy(h.position);h.returnDuration=.22+distance(h.position,home)/config.returnSpeed;}
 const api={
  get state(){return match;},get active(){return match.phase==='active'&&tieRemaining===0&&!pendingGrab;},
  get pendingGrab(){return pendingGrab&&snapshot(pendingGrab);},
  get resultReady(){return match.phase==='matchComplete'&&resultStartedAt!==null&&time-resultStartedAt+1e-9>=roundResetMs/1000;},
  getSkills(id){return skillFacades[id]??null;},
  get tieRemaining(){return tieRemaining;},get contact(){return lastContact&&snapshot(lastContact);},
  getHook(id){return hooks[id]?snapshot(hooks[id]):null;},cooldown(id){return cooldowns[id]??Infinity;},
  drainEvents(){const out=events;events=[];return out;},
  prepare(){if(match.phase!=='preparing')return false;resetCombat();return dispatch('prepareRound');},
  restart(){events=[];resetCombat();return dispatch('restartMatch');},
  cancel(){events=[];resetCombat();return dispatch('cancelMatch');},
  cast(id){if(!DUEL_PLAYERS.includes(id)||!api.active||hooks[id]||cooldowns[id]>0||skillControllers[id]?.blocksAttack)return false;hooks[id]={id:`${match.matchId}/q/${++serial}`,scope:getDuelScope(match),attackerId:id,phase:'windup',phaseTime:0,position:{x:0,y:0,z:0},direction:{x:0,y:0,z:0},travel:0,hit:false};cooldowns[id]=config.cooldown;return true;},
  step(dt,{actors,obstacles,sockets}){
   if(!Number.isFinite(dt)||dt<=0||dt>.05)return false;
   if(match.phase==='cancelled')return false;
   const wasActive=api.active,startMs=time*1000;time+=dt;frame++;
   if(tieRemaining>0){tieRemaining=Math.max(0,tieRemaining-dt);if(tieRemaining===0){dispatch('replayRound');resetCombat();return true;}}
   else if(['countdown','roundReset'].includes(match.phase)){dispatch('step',{deltaMs:dt*1000});if(match.phase==='preparing')return true;}
   const contacts=[];impactQueue=[];
   for(const id of DUEL_PLAYERS)if(skillControllers[id]){
    skillStep={id,dt,animation:skillControllers[id].animation};skillControllers[id].step(dt);
   }
   skillStep=null;
   const skillHits=[];
   if(wasActive)for(const impact of impactQueue){
    if(!sameScope(impact.scope))continue;
    const fraction=impact.offset/dt;
    const contact=evaluateDuelSkillContact({skill:impact.skill,attackerId:impact.attackerId,actors,obstacles,aim:sockets[impact.attackerId].aimDirection??sockets[impact.attackerId].direction,fraction});
    const candidate={...impact,impactOffsetMs:impact.offset*1000,contact};
    if(contact)skillHits.push(candidate);
   }
   for(const id of DUEL_PLAYERS){
    if(wasActive){cooldowns[id]=Math.max(0,cooldowns[id]-dt);if(cooldowns[id]<1e-12)cooldowns[id]=0;}
    const h=hooks[id];if(!h)continue;h.phaseTime+=dt;const socket=sockets[id];
    if(h.phase==='windup'){
     h.position=copy(socket.origin);
     if(wasActive&&h.phaseTime>=.25){h.phase='outbound';h.phaseTime=0;h.direction=copy(socket.direction);const length=Math.hypot(...Object.values(h.direction));if(!(length>0)){returnHook(h,socket.home);continue;}for(const k of ['x','y','z'])h.direction[k]/=length;h.bodyOrientation=socket.bodyOrientation?.slice();h.orientation=socket.orientation?.slice();if(socket.blockedAim){returnHook(h,socket.home);events.push({type:'hook-blocked',playerId:id});}}
    }else if(h.phase==='outbound'&&wasActive){
     const to={x:h.position.x+h.direction.x*config.hookSpeed*dt,y:h.position.y+h.direction.y*config.hookSpeed*dt,z:h.position.z+h.direction.z*config.hookSpeed*dt};
     const result=evaluateHookFrame({scope:getDuelScope(match),frameId:`frame-${frame}`,startMs,durationMs:dt*1000,playerIds:DUEL_PLAYERS,actors,obstacles,hook:{hookId:h.id,scope:h.scope,attackerId:id,phase:'outbound',from:copy(h.position),to,travelled:h.travel,maxRange:config.maxRange}});
     if(!result.accepted)throw new Error('Duel frame rejected: '+result.reason);
     if(result.contact){h.position=copy(result.contact.position);h.travel=result.contact.totalTravelled;contacts.push({id,result});returnHook(h,socket.home);}
     else{h.position=copy(result.sweep.endPosition);h.travel+=result.sweep.distance;if(result.sweep.rangeReached)returnHook(h,socket.home);}
    }else if(h.phase==='return'){
     const u=Math.min(1,h.phaseTime/h.returnDuration);h.position=lerp(h.returnStart,socket.home,smooth(u));if(u>=1){h.phase='recover';h.phaseTime=0;}
    }else if(h.phase==='recover'&&h.phaseTime>=.26)hooks[id]=null;
   }
   const hits=[...skillHits,...contacts.filter(c=>c.result.kind==='opponent').map(c=>({skill:'Q',attackerId:c.id,scope:hooks[c.id].scope,eventId:hooks[c.id].id,impactOffsetMs:c.result.contact.elapsedMs,contact:{attackerId:c.id,targetId:c.result.source.opponentId,position:copy(c.result.contact.position)}}))].sort((a,b)=>a.impactOffsetMs-b.impactOffsetMs);
   // Offset comparison avoids a tolerance growing with match elapsed time.
   // Only opposing equally early impacts replay; own simultaneous attacks do not.
   const first=hits[0];
   // Clip clocks can accumulate a few ulps independently. Carry that numerical
   // bound, not a gameplay tie window (about 1e-11ms for these authored clips).
   const tolerance=(a,b)=>Math.max(dt*1000*DUEL_TIE_FRACTION,(a.epsilonMs||0)+(b.epsilonMs||0));
   const tied=first&&hits.some(h=>h.attackerId!==first.attackerId&&Math.abs(h.impactOffsetMs-first.impactOffsetMs)<=tolerance(h,first));
   if(wasActive){
    for(const impact of impactQueue){
     if(!sameScope(impact.scope))continue;
     const impactOffsetMs=impact.offset*1000;
     if(first&&impactOffsetMs>first.impactOffsetMs+tolerance(impact,first))continue;
     const validated=skillHits.find(h=>h.eventId===impact.eventId);
     events.push({type:'skill-impact',skill:impact.skill,playerId:impact.attackerId,hit:!!validated,position:validated?.contact.position??null,origin:lerp(actors.find(a=>a.playerId===impact.attackerId).motion.from,actors.find(a=>a.playerId===impact.attackerId).motion.to,impact.offset/dt),offset:impact.offset,tied:!!tied});
    }
   }
   if(wasActive&&first){
    if(tied){tieRemaining=roundResetMs/1000;lastContact={kind:'tie',frame};events.push({type:'simultaneous-replay'});}
    else{
     if(first.skill==='Q')hooks[first.attackerId].hit=true;
     lastContact={kind:first.skill==='Q'?'grab':'skill',skill:first.skill,attackerId:first.attackerId,targetId:first.contact.targetId,position:copy(first.contact.position),frame,impactMs:startMs+first.impactOffsetMs};
     const award={scope:first.scope,eventId:first.eventId,attackerId:first.attackerId,targetId:first.contact.targetId,skill:first.skill,result:'success',validated:true};
     if(first.skill==='Q'){
      // Contact fixes the winner now. Only this authority's return phase may
      // complete the award; presentation callbacks cannot submit a score.
      pendingGrab=award;
      events.push({type:'grab-started',scope:first.scope,attackerId:first.attackerId,targetId:first.contact.targetId,eventId:first.eventId});
     }else if(dispatch('confirmHit',award))resultStartedAt=time;
    }
    for(const id of DUEL_PLAYERS)returnHook(hooks[id],sockets[id].home);
   }
   if(pendingGrab){
    const pending=pendingGrab,h=hooks[pending.attackerId];
    if(!sameScope(pending.scope)||!h||h.id!==pending.eventId)pendingGrab=null;
    else if(h.phase==='recover'){
     pendingGrab=null;
     if(dispatch('confirmHit',pending))resultStartedAt=time;
    }
   }
   for(const c of contacts)if(c.result.kind==='blocked')events.push({type:'hook-blocked',playerId:c.id});
   return true;
  },
 };
 return api;
}
