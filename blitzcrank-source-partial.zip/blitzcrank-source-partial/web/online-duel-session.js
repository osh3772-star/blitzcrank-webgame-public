import {ONLINE_PROTOCOL,boundedJSON,validateInput} from './online-duel-protocol.js';
import {isDuelState} from './duel-round-rules.js';
const ids=['human','bot'],clips=new Set(['W_Start','W_Loop','W_Loop_Slow','W_End','E_Charge','E_Hold','E_Strike','R_Cast']);
const record=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const scalar=x=>Number.isFinite(x)&&x>=0&&x<10000;
const vector=p=>record(p)&&['x','y','z'].every(k=>Number.isFinite(p[k])&&Math.abs(p[k])<10000);
function animation(x,depth=0){
 if(x===null)return true;
 if(!record(x)||depth>2||!clips.has(x.name)||!scalar(x.time))return false;
 return x.presentation==null||animation(x.presentation,depth+1);
}
function orientation(x){
 if(x==null)return true;
 if(!Array.isArray(x)||x.length!==4||!x.every(Number.isFinite))return false;
 const length=Math.hypot(...x);return Number.isFinite(length)&&length>1e-12;
}
function event(e){
 if(!record(e)||!Number.isSafeInteger(e.serial)||e.serial<1)return false;
 if(e.type==='cast')return ids.includes(e.id)&&['W','E','R','Q','E_Strike','PUNCH','FLASH'].includes(e.skill);
 if(['round-reset','paused','disconnected'].includes(e.type))return true;
 if(e.type!=='authority'||!record(e.event)||typeof e.event.type!=='string')return false;
 const a=e.event;if(a.type!=='skill-impact')return true;
 return ids.includes(a.playerId)&&['E','R'].includes(a.skill)&&typeof a.hit==='boolean'&&typeof a.tied==='boolean'&&vector(a.origin)&&(a.hit?vector(a.position):a.position==null||vector(a.position))&&scalar(a.offset)&&a.offset<=1;
}
function actor(a){
 if(!record(a)||!vector(a.position)||!vector(a.velocity)||!Number.isFinite(a.yaw)||Math.abs(a.yaw)>Math.PI||!Number.isFinite(a.pitch)||Math.abs(a.pitch)>1.25||typeof a.grounded!=='boolean')return false;
 if(![a.punchTime,a.punchCooldown,a.punchDuration,a.qCooldown,a.flash?.remaining].every(scalar)||a.punchDuration<=0||a.punchTime>a.punchDuration)return false;
 const k=a.skills;if(!record(k)||![k.boost,k.slow,k.armed].every(scalar)||!animation(k.animation)||!['W','E','R'].every(key=>scalar(k.cooldown?.[key])))return false;
 const h=a.hook;if(h==null)return true;
 return record(h)&&['windup','outbound','return','recover'].includes(h.phase)&&vector(h.position)&&scalar(h.phaseTime)&&orientation(h.bodyOrientation)&&(h.phase!=='return'||(scalar(h.returnDuration)&&h.returnDuration>0));
}
// This validates the renderer's structural/numeric contract, not host honesty.
// A legitimate-looking but dishonest host still requires server authority.
export function validSnapshot(s,session){
 if(!record(s)||s.type!=='state'||s.protocol!==ONLINE_PROTOCOL||s.session!==session||!Number.isSafeInteger(s.tick)||s.tick<0||!Number.isSafeInteger(s.epoch)||s.epoch<0)return false;
 if(!['paused','closed','active','resultReady'].every(k=>typeof s[k]==='boolean')||(s.closed&&!s.paused)||!scalar(s.tieRemaining)||(s.pendingGrab!==null&&!record(s.pendingGrab)))return false;
 if(!isDuelState(s.match)||s.match.sessionId!==session||!ids.every((id,i)=>s.match.playerIds[i]===id)||(s.resultReady&&s.match.phase!=='matchComplete'))return false;
 if(s.active!==(s.match.phase==='active'&&s.tieRemaining===0&&!s.pendingGrab))return false;
 if(!Array.isArray(s.events)||s.events.length>64||!s.events.every(event))return false;
 return ids.every(id=>actor(s.actors?.[id]));
}
/** One connection owns exactly one guest slot. Caller sends through its specific
 * invited DataChannel; no payload can select another player's identity. */
export function createOnlineSession({role,session,world=null,send,onState=()=>{},onStatus=()=>{}}){
 if(!['host','guest'].includes(role)||typeof send!=='function'||(role==='host'&&!world))throw TypeError('Invalid session');
 let connected=true,lastTick=-1,lastEpoch=-1,latest=null,rematch={human:false,bot:false},rematchEpoch=world?.scope.epoch;
 let pendingPause=false,sendingPause=false;
 const control=(type,extra={})=>send({type,protocol:ONLINE_PROTOCOL,session,...extra});
 function syncRematch(){if(world&&rematchEpoch!==world.scope.epoch){rematchEpoch=world.scope.epoch;rematch={human:false,bot:false};}}
 // A failed send has not entered the reliable ordered channel. Keep the pause
 // intent until it is queued, blocking later input/consent from overtaking it.
 // Host snapshots are the retry opportunity; no extra timer or network service.
 function flushPause(){
  if(!connected||!pendingPause||sendingPause)return false;
  sendingPause=true;try{const queued=control('ready',{ready:false,epoch:latest?.epoch});if(queued)pendingPause=false;return queued;}finally{sendingPause=false;}
 }
 function requestPause(){pendingPause=true;return flushPause();}
 function publish(){syncRematch();const state=JSON.parse(JSON.stringify(world.snapshot())); /* Both renderers consume the same JSON wire representation. */ onState(state);if(!send(state)){world.pause();syncRematch();onStatus('backpressure');return false;}world.drainEvents();return true;}
 function receive(value){
  if(!connected||!value||value.protocol!==ONLINE_PROTOCOL||value.session!==session)return false;
  if(role==='host'){
   syncRematch();
   if(value.type==='input')return validateInput(value,world.scope)&&world.submit('bot',value);
   if(value.type==='ready'&&typeof value.ready==='boolean'){if(value.ready&&value.epoch!==world.scope.epoch)return false;if(!value.ready)world.pause();else world.setReady('bot',true);publish();return true;}
   if(value.type==='rematch'&&value.epoch===world.scope.epoch&&world.snapshot().resultReady&&!world.snapshot().paused){rematch.bot=true;tryRematch();return true;}
   return false;
  }
  if(!validSnapshot(value,session)){disconnect('invalid-state');return false;}
  if(value.tick<lastTick||value.epoch<lastEpoch)return false;
  lastTick=value.tick;lastEpoch=value.epoch;latest=value;onState(value);
  if(value.closed){connected=false;pendingPause=false;onStatus('remote-closed');}
  else flushPause();
  return true;
 }
 function disconnect(reason='disconnected'){
  if(!connected)return;connected=false;pendingPause=false;world?.disconnect();rematch={human:false,bot:false};
  if(world)onState(world.snapshot());else if(latest){latest={...latest,paused:true,closed:true};onState(latest);}
  onStatus(reason);
 }
 function tryRematch(){syncRematch();if(rematch.human&&rematch.bot&&world.restart()){rematch={human:false,bot:false};publish();}}
 return {
  receive,
  receiveText(text){const value=boundedJSON(text);return value?receive(value):false;},
  input(value){if(!connected||pendingPause)return false;return role==='host'?world.submit('human',value):send(value);},
  ready(value){if(!connected)return false;if(role==='host'){if(!value)world.pause();else world.setReady('human',true);return publish();}if(!value)return requestPause();if(!latest||pendingPause)return false;return control('ready',{ready:true,epoch:latest.epoch});},
  rematch(){if(!connected||pendingPause||(role==='host'?(!world.snapshot().resultReady||world.snapshot().paused):(!latest?.resultReady||latest.paused)))return false;if(role==='host'){syncRematch();rematch.human=true;tryRematch();return true;}return control('rematch',{epoch:latest.epoch});},
  step(){if(role!=='host'||!connected)return false;world.step();return publish();},
  disconnect,
  interrupt(reason='interrupted'){if(!connected)return;world?.pause();if(role==='guest')requestPause();else publish();onStatus(reason);},
  get snapshot(){return role==='host'?world.snapshot():latest;}
 };
}
