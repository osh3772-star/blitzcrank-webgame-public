// User-selected excerpt from the 2024 community demonstration's Flash chapter.
// Not claimed as an official isolated game-bank asset or licensed game reuse.
// See assets/audio/flash/source-manifest.json. No generated audio fallback.
export const FLASH_AUDIO_CUES=Object.freeze({
 flashCast:Object.freeze({url:'./assets/audio/flash/flash-cast.wav',channel:'sfx',group:'flash',gain:.65,maxDuration:1.81}),
});
export const FLASH_AUDIO_EVENTS=Object.freeze({flashCast:'flashCast'});
