// Camera-only inspection; never relocate an actor or relax terrain validation.
export function createMapInspection({current,clearInput}){
 let owner=null,target=null;
 function refresh(){if(owner!==current()){owner=null;target=null;}}
 return Object.freeze({target(){refresh();return target?.slice()??null;},enter(point){
  if(!Array.isArray(point)||point.length!==2||!point.every(v=>Number.isFinite(v)&&Math.abs(v)<=80))throw Error('Finite map inspection target required');
  const view=current();if(!view)return {accepted:false,reason:'not-loaded'};
  clearInput();view.trial.pause();if(current()!==view)return {accepted:false,reason:'view-changed'};
  owner=view;target=point.slice();return {accepted:true,inspection:true};
 },exit(){clearInput();owner=null;target=null;return {accepted:true,resumed:false};}});
}
