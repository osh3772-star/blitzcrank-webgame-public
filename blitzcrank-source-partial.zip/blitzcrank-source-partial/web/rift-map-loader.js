// One load owner for the diagnostic only. No frame-loop/network/production state.
import {assertMapStudy} from './rift-map-revisions.js';
import {createMapProbe} from './rift-map-study.js';
export function disposeMapScene(scene){
 const geometries=new Set(),materials=new Set(),textures=new Set(),images=new Set();
 scene?.traverse(o=>{if(o.geometry)geometries.add(o.geometry);for(const m of o.material?(Array.isArray(o.material)?o.material:[o.material]):[]){materials.add(m);for(const value of Object.values(m))if(value?.isTexture){textures.add(value);if(value.image)images.add(value.image);}}});
 for(const item of [...geometries,...materials,...textures])item.dispose();
 for(const image of images)image.close?.();
}
export function createStudyLoader({parse,fetchImpl=globalThis.fetch,cryptoImpl=globalThis.crypto,dispose=disposeMapScene,baseURL=import.meta.url}){
 let generation=0,controller=null;
 const cancel=()=>{generation++;controller?.abort();controller=null;};
 return Object.freeze({cancel,async load(study){
  assertMapStudy(study);cancel();const token=generation,abort=new AbortController();controller=abort;
  const current=()=>generation===token&&!abort.signal.aborted;
  async function bytes(path,sha){
   if(!/^[a-f0-9]{64}$/.test(sha))throw Error('Invalid pinned asset hash');
   const response=await fetchImpl(new URL(path,baseURL),{signal:abort.signal});if(!response.ok)throw Error('자산 요청 실패 '+response.status);
   const data=await response.arrayBuffer();if(!current())return null;
   const digest=await cryptoImpl.subtle.digest('SHA-256',data),actual=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');
   if(actual!==sha)throw Error('고정 자산 해시 불일치: '+path);return data;
  }
  let parsed=null;
  try{
   const [bin,json,recordBytes]=await Promise.all([bytes(study.glb,study.glbSHA),bytes(study.collision,study.collisionSHA),bytes(study.record,study.recordSHA)]);
   if(!current())return null;
   const layout=JSON.parse(new TextDecoder().decode(json)),record=JSON.parse(new TextDecoder().decode(recordBytes));createMapProbe(layout,{study});
   if(study.revision==='0.36'&&(record.sourceVersion!==study.revision||record.sourceGLBSHA!==study.glbSHA||record.sourceCollisionSHA!==study.collisionSHA))throw Error('Probe record provenance mismatch');
   parsed=await parse(bin);if(!current()){dispose(parsed.scene);parsed=null;return null;}
   const result={gltf:parsed,layout,record,byteCounts:{glb:bin.byteLength,collision:json.byteLength,record:recordBytes.byteLength}};parsed=null;return result;
  }catch(error){if(parsed)dispose(parsed.scene);if(!current())return null;abort.abort();throw error;}
  finally{if(generation===token)controller=null;}
 }});
}
