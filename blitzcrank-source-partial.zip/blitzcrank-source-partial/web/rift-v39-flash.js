// Isolated destination study. This does not change game Flash or official rules.
import {FLASH_TUNING} from './flash-controller.js';
import {PULL_TRIAL,createPullBodyCollider} from './rift-v39-pull.js';
export const FLASH_TRIAL=Object.freeze({radius:PULL_TRIAL.radius,range:FLASH_TUNING.range,minDistance:FLASH_TUNING.minDistance,distanceTolerance:1e-12,defaultPolicy:'clear-path'});
const point=p=>Array.isArray(p)&&p.length===2&&p.every(x=>Number.isFinite(x)&&Math.abs(x)<=1024);
export function createMapFlashAdapter(layout,options={}){
 const source=structuredClone(layout),body=createPullBodyCollider(source,options),boundary=createPullBodyCollider({...source,walls:[],baseWalls:[],rearBackdropWalls:[],propColliders:[]},options);
 return Object.freeze({resolve({origin,aim,policy=FLASH_TRIAL.defaultPolicy}={}){
  const limits={planarOnly:true,heightCollision:false,gameplayChanged:false,networked:false,policy,range:FLASH_TRIAL.range,radius:FLASH_TRIAL.radius};
  const reject=reason=>({accepted:false,reason,...limits});
  if(!['clear-path','landing-only'].includes(policy))return reject('invalid-policy');
  if(!point(origin)||!point(aim))return reject('invalid-coordinates');
  origin=origin.slice();aim=aim.slice();const length=Math.hypot(aim[0]-origin[0],aim[1]-origin[1]);
  if(length+FLASH_TRIAL.distanceTolerance<FLASH_TRIAL.minDistance)return reject('too-short');
  if(body.sweep(origin,origin).blockedBy)return reject('blocked-origin');
  const requestedDistance=Math.min(length,FLASH_TRIAL.range),wanted=origin.map((x,i)=>x+(aim[i]-x)*requestedDistance/length),edge=boundary.sweep(origin,wanted),end=edge.position,path=body.sweep(origin,end);
  let destination=end,wallClamped=false;
  if(policy==='clear-path'){destination=path.position;wallClamped=!!path.blockedBy;}
  else if(body.sweep(end,end).blockedBy)return{...reject('blocked-landing'),from:origin,requested:wanted,landing:end,boundaryClamped:!!edge.blockedBy,blockedBy:body.sweep(end,end).blockedBy};
  const distance=Math.hypot(destination[0]-origin[0],destination[1]-origin[1]);
  if(distance+FLASH_TRIAL.distanceTolerance<FLASH_TRIAL.minDistance)return{...reject('insufficient-clearance'),from:origin,blockedBy:path.blockedBy??edge.blockedBy};
  return{accepted:true,reason:wallClamped?'wall-clamped':edge.blockedBy?'boundary-clamped':'clear',from:origin,position:destination.slice(),aim,requested:wanted,distance,requestedDistance,rangeClamped:length>FLASH_TRIAL.range,boundaryClamped:!!edge.blockedBy,wallClamped,blockedBy:path.blockedBy??edge.blockedBy,crossesInteriorObstacle:policy==='landing-only'&&!!path.blockedBy,...limits};
 }});
}
