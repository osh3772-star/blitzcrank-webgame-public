import {sweptFootprint,triangleIntersectsPrism} from './rift-v39-footprint-coverage.js';
import {buildClosedComponents,classifyContainment} from './rift-v49-containment-audit.js';
// Analysis only. A closed topology alone does not certify a solid or grant gameplay permission.
export function createCapBodyStudy(THREE,mesh){
 if(!mesh||mesh.cutHeight!==2.5||mesh.bodyTop!==2.1||!Array.isArray(mesh.positions)||!Array.isArray(mesh.faces)||mesh.faces.length>10000||!mesh.faces.length||!mesh.positions.every(p=>Array.isArray(p)&&p.length===3&&p.every(v=>Number.isFinite(v)&&Math.abs(v)<=1024))||!mesh.faces.every(f=>Array.isArray(f)&&f.length===3&&new Set(f).size===3&&f.every(i=>Number.isInteger(i)&&i>=0&&i<mesh.positions.length)))throw Error('Bounded cap mesh required');
 const triangles=mesh.faces.map(f=>{const triangle=new THREE.Triangle(...f.map(i=>new THREE.Vector3(...mesh.positions[i])));if(triangle.getArea()<=1e-12)throw Error('Degenerate surface');return {triangle,mesh:'derived-cap-study',normal:triangle.getNormal(new THREE.Vector3()),bounds:new THREE.Box3().setFromPoints([triangle.a,triangle.b,triangle.c])};});
 const components=buildClosedComponents(THREE,triangles);if(components.length!==1||!components[0].topologicallyClosed)throw Error('Single oriented closed component required');
 return Object.freeze({audit(from,to){
  if(![from,to].every(p=>Array.isArray(p)&&p.length===2&&p.every(v=>Number.isFinite(v)&&Math.abs(v)<=80)))throw Error('Bounded finite XZ segment required');
  const footprint=sweptFootprint(from,to,.7),xs=footprint.map(p=>p[0]),zs=footprint.map(p=>p[1]),box=new THREE.Box3(new THREE.Vector3(Math.min(...xs),.01,Math.min(...zs)),new THREE.Vector3(Math.max(...xs),2.1,Math.max(...zs)));
  const intersections=[];for(let i=0;i<triangles.length;i++){const t=triangles[i];if(t.bounds.intersectsBox(box)&&triangleIntersectsPrism(t.triangle,footprint,.01,2.1))intersections.push(i);}
  const containment=classifyContainment(THREE,components,[from[0],1.05,from[1]]),reason=intersections.length?'body-surface':containment.uncertain.length?'containment-uncertain':containment.insideCandidate?'inside-solid':null;
  return {from:from.slice(),to:to.slice(),reason,componentClear:reason===null,intersections,containment,body:{halfExtent:.7,minY:.01,maxY:2.1},continuousSweptPrism:true,spawnPermission:false,runtimeAdopted:false,wholeMapSafetyVerified:false};
 }});
}
