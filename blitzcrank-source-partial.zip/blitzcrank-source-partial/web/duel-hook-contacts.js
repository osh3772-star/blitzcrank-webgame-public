/** Continuous point-hook contacts for one authority-supplied linear frame.
 * Geometry only: no score commit, networking, authentication, or grab success.
 */
const AXES = ['x', 'y', 'z'];
const SCOPE_KEYS = ['sessionId', 'matchId', 'matchNumber', 'roundId', 'roundNumber', 'phaseNumber'];
// Numerical input envelope, not gameplay tuning or a collider-size default.
export const MAX_COORDINATE = 1e9;
// Cover-only numerical tie margin, in fractions of the original frame. This is
// not an opposing-player hit arbitration rule or an expanded collision shape.
export const COVER_TIE_FRACTION = 64 * Number.EPSILON;
const record = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const keys = (v, names) => record(v) && Object.keys(v).length === names.length && names.every((k) => Object.hasOwn(v, k));
const id = (v) => typeof v === 'string' && v.length > 0 && v.length <= 200 && v.trim() === v && !/[\u0000-\u001f\u007f]/.test(v);
const finite = (v, min, max) => typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max;
const dimension = (v) => finite(v, 0, MAX_COORDINATE);
const vector = (v) => keys(v, AXES) && AXES.every((k) => finite(v[k], -MAX_COORDINATE, MAX_COORDINATE));
const sameVector = (a, b) => AXES.every((k) => a[k] === b[k]);
const subtract = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
const at = (p, v, t) => ({ x: p.x + v.x * t, y: p.y + v.y * t, z: p.z + v.z * t });

function freeze(v) {
  if (record(v) || Array.isArray(v)) {
    for (const child of Object.values(v)) freeze(child);
    Object.freeze(v);
  }
  return v;
}

function validScope(scope) {
  return keys(scope, SCOPE_KEYS) && id(scope.sessionId)
    && Number.isSafeInteger(scope.matchNumber) && scope.matchNumber >= 1
    && Number.isSafeInteger(scope.roundNumber) && scope.roundNumber >= 1 && scope.roundNumber <= 5
    && Number.isSafeInteger(scope.phaseNumber) && scope.phaseNumber >= 1
    && scope.matchId === `${scope.sessionId}/match/${scope.matchNumber}`
    && scope.roundId === `${scope.matchId}/round/${scope.roundNumber}`;
}

function validBox(box) {
  return vector(box.min) && vector(box.max) && AXES.every((k) => box.min[k] <= box.max[k]);
}

function validShape(shape) {
  return (keys(shape, ['type', 'radius']) && shape.type === 'sphere' && dimension(shape.radius))
    || (keys(shape, ['type', 'min', 'max']) && shape.type === 'aabb' && validBox(shape));
}

function invalid(reason) {
  return Object.freeze({ accepted: false, reason, kind: null, source: null, contact: null, sweep: null });
}

function validate(input) {
  if (!keys(input, ['scope', 'frameId', 'startMs', 'durationMs', 'playerIds', 'actors', 'obstacles', 'hook'])) return 'invalid_frame';
  if (!validScope(input.scope)) return 'invalid_scope';
  if (!id(input.frameId)) return 'invalid_frame_id';
  if (!finite(input.startMs, 0, Number.MAX_SAFE_INTEGER)
    || !finite(input.durationMs, 0, Number.MAX_SAFE_INTEGER)
    || input.startMs + input.durationMs > Number.MAX_SAFE_INTEGER) return 'invalid_time';
  if (!Array.isArray(input.playerIds) || input.playerIds.length !== 2
    || !input.playerIds.every(id) || input.playerIds[0] === input.playerIds[1]) return 'invalid_players';
  if (!keys(input.hook, ['hookId', 'scope', 'attackerId', 'phase', 'from', 'to', 'travelled', 'maxRange'])) return 'invalid_hook';
  const h = input.hook;
  if (!id(h.hookId) || !input.playerIds.includes(h.attackerId)) return 'invalid_hook_identity';
  if (!validScope(h.scope)) return 'invalid_hook_scope';
  if (!SCOPE_KEYS.every((k) => h.scope[k] === input.scope[k])) return 'stale_hook_scope';
  if (h.phase !== 'outbound') return 'not_outbound';
  if (!vector(h.from) || !vector(h.to)) return 'invalid_hook_motion';
  if (!dimension(h.travelled) || !dimension(h.maxRange) || h.travelled > h.maxRange) return 'invalid_range';
  if (!Array.isArray(input.actors) || input.actors.length !== 2) return 'invalid_actors';
  const actorIds = new Set();
  for (const actor of input.actors) {
    if (!keys(actor, ['playerId', 'shape', 'motion']) || !input.playerIds.includes(actor.playerId)
      || actorIds.has(actor.playerId) || !validShape(actor.shape)) return 'invalid_actor';
    actorIds.add(actor.playerId);
    if (!keys(actor.motion, ['type', 'from', 'to']) || !vector(actor.motion.from) || !vector(actor.motion.to)) return 'invalid_actor_motion';
    if (actor.motion.type === 'teleport') return 'discontinuous_motion';
    if (actor.motion.type !== 'linear') return 'invalid_actor_motion';
    if (input.durationMs === 0 && !sameVector(actor.motion.from, actor.motion.to)) return 'motion_in_zero_time';
  }
  if (input.durationMs === 0 && !sameVector(h.from, h.to)) return 'motion_in_zero_time';
  if (!Array.isArray(input.obstacles)) return 'invalid_obstacles';
  const obstacleIds = new Set();
  for (const box of input.obstacles) {
    if (!keys(box, ['obstacleId', 'min', 'max']) || !id(box.obstacleId)
      || obstacleIds.has(box.obstacleId) || !validBox(box)) return 'invalid_obstacle';
    obstacleIds.add(box.obstacleId);
  }
  return null;
}

// Inclusive closed-box slab intersection. v is full-frame displacement, not a
// normalized ray direction. No epsilon expands a box or turns a miss into a hit.
function boxEntry(p, v, min, max, limit) {
  let near = 0;
  let far = limit;
  for (const k of AXES) {
    if (v[k] === 0) {
      if (p[k] < min[k] || p[k] > max[k]) return null;
    } else {
      let a = (min[k] - p[k]) / v[k];
      let b = (max[k] - p[k]) / v[k];
      if (a > b) [a, b] = [b, a];
      near = Math.max(near, a);
      far = Math.min(far, b);
      if (near > far) return null;
    }
  }
  return near;
}

function sphereEntry(p, v, radius, limit) {
  // Scale before squaring and use the stable entry-root form c / q. All input
  // subtraction is bounded by validation. This is still IEEE-754 arithmetic.
  const size = Math.max(Math.abs(p.x), Math.abs(p.y), Math.abs(p.z), Math.abs(v.x), Math.abs(v.y), Math.abs(v.z), radius);
  if (size === 0) return 0;
  p = { x: p.x / size, y: p.y / size, z: p.z / size };
  v = { x: v.x / size, y: v.y / size, z: v.z / size };
  radius /= size;
  const c = dot(p, p) - radius * radius;
  if (c <= 0) return 0;
  const a = dot(v, v);
  const b = dot(p, v);
  if (a === 0 || b >= 0) return null;
  const closestTime = -b / a;
  const closest = at(p, v, closestTime);
  const remainder = radius * radius - dot(closest, closest);
  if (remainder < 0) return null;
  let fraction = closestTime - Math.sqrt(remainder / a);
  if (fraction < closestTime / 2) fraction = c / (-b + Math.sqrt(a * remainder));
  return fraction >= 0 && fraction <= limit ? fraction : null;
}

/**
 * Evaluate one outbound point hook over one authority-supplied frame.
 * Unknown fields are rejected. See CONTRACT.md for interpolation, scope,
 * discontinuity, numerical limits, tie policy, and required caller validation.
 */
export function evaluateHookFrame(input) {
  const error = validate(input);
  if (error) return invalid(error);
  const h = input.hook;
  const target = input.actors.find((a) => a.playerId !== h.attackerId);
  const displacement = subtract(h.to, h.from);
  const length = Math.hypot(displacement.x, displacement.y, displacement.z);
  const remaining = h.maxRange - h.travelled;
  const limit = remaining === 0 || input.durationMs === 0 ? 0 : length === 0 ? 1 : Math.min(1, remaining / length);
  const source = {
    scope: Object.fromEntries(SCOPE_KEYS.map((k) => [k, h.scope[k]])),
    frameId: input.frameId, startMs: input.startMs, durationMs: input.durationMs,
    hookId: h.hookId, attackerId: h.attackerId, opponentId: target.playerId,
  };
  const sweep = {
    throughFraction: limit,
    endPosition: at(h.from, displacement, limit),
    distance: Math.min(length, remaining),
    rangeReached: length >= remaining,
  };
  // A hook that exhausted its range before this frame cannot acquire a new hit.
  if (remaining === 0) return freeze({ accepted: true, reason: 'range_exhausted', kind: 'none', source, contact: null, sweep });

  const relativeStart = subtract(h.from, target.motion.from);
  const relativeTravel = subtract(displacement, subtract(target.motion.to, target.motion.from));
  const opponentFraction = target.shape.type === 'sphere'
    ? sphereEntry(relativeStart, relativeTravel, target.shape.radius, limit)
    : boxEntry(relativeStart, relativeTravel, target.shape.min, target.shape.max, limit);
  let earliest = opponentFraction;
  const blockers = [];
  for (const obstacle of input.obstacles) {
    const fraction = boxEntry(h.from, displacement, obstacle.min, obstacle.max, limit);
    if (fraction !== null) {
      blockers.push({ obstacleId: obstacle.obstacleId, fraction });
      if (earliest === null || fraction < earliest) earliest = fraction;
    }
  }
  if (earliest === null) return freeze({ accepted: true, reason: null, kind: 'none', source, contact: null, sweep });
  // Compare everything to the global earliest time (not pairwise epsilon
  // comparisons, which are nontransitive and can depend on iteration order).
  const tiedBlockers = blockers.filter((b) => b.fraction - earliest <= COVER_TIE_FRACTION);
  const blockerIds = tiedBlockers.map((b) => b.obstacleId).sort();
  const kind = blockerIds.length ? 'blocked' : 'opponent';
  const first = kind === 'blocked' ? tiedBlockers.reduce((minimum, b) => Math.min(minimum, b.fraction), 1) : opponentFraction;
  const distance = Math.min(remaining, length * first);
  const elapsedMs = input.durationMs * first;
  return freeze({
    accepted: true, reason: null, kind, source, sweep,
    contact: {
      fraction: first, elapsedMs, timeMs: input.startMs + elapsedMs,
      position: at(h.from, displacement, first), distance,
      totalTravelled: h.travelled + distance,
      blockerIds,
      opponentAtSameTime: kind === 'blocked' && opponentFraction !== null && Math.abs(opponentFraction - first) <= COVER_TIE_FRACTION,
    },
  });
}
