import {registerStaticComponents} from './rift-v49-static-component-index.js';
import {createStationaryFallbackTrial} from './rift-v49-stationary-fallback-trial.js';
import {buildClosedComponents} from './rift-v49-containment-audit.js';
import {createCollisionStudy} from './assets/map-study-v20/collision-study.mjs';
import {collectStaticTriangles} from './rift-v39-support-audit.js';
import {sweptFootprint,triangleIntersectsPrism,auditStraightCorridor} from './rift-v39-footprint-coverage.js';
import {createTriangleIndex} from './rift-v39-route-search.js';
import {createAuditedHookCollider} from './rift-v49-hook-collider.js';
export function createV49SceneAdapter(THREE,{scene,inputs}){
 const triangles=collectStaticTriangles(THREE,scene),index=createTriangleIndex(triangles),components=buildClosedComponents(THREE,triangles),bodyProbe=inputs.createProbe(),hookProbe=inputs.createProbe({radius:.12}),policy=inputs.foliagePolicy;
 registerStaticComponents(components);
 const bodyAudit=(from,to)=>{const a=auditStraightCorridor(THREE,index.query(from,to),bodyProbe,{from,to});return {pass:a.conservativeChecksPassed,reason:a.blockedBy??(!a.coverage.covered?'support-gap':a.intersectionCount?'body-surface':null)};};
 const hookAudit=(from,to)=>{const blockedBy=hookProbe.probe(from,to).blockedBy;if(blockedBy)return {pass:false,reason:blockedBy};const footprint=sweptFootprint(from,to,.12),xs=footprint.map(p=>p[0]),zs=footprint.map(p=>p[1]),box=new THREE.Box3(new THREE.Vector3(Math.min(...xs),.68,Math.min(...zs)),new THREE.Vector3(Math.max(...xs),.92,Math.max(...zs)));for(const t of index.query(from,to,.12).filter(t=>policy.blocksSurface(t)))if(t.bounds.intersectsBox(box)&&triangleIntersectsPrism(t.triangle,footprint,.68,.92))return {pass:false,reason:'mesh:'+t.mesh};return {pass:true};};
 const boundary=createCollisionStudy({...inputs.layout,walls:[],baseWalls:[],rearBackdropWalls:[],propColliders:[]},{radius:Math.hypot(.7,.7)}),xs=inputs.layout.mapBoundaryXZ.map(p=>p[0]),zs=inputs.layout.mapBoundaryXZ.map(p=>p[1]),bounds={minX:Math.min(...xs),maxX:Math.max(...xs),minZ:Math.min(...zs),maxZ:Math.max(...zs)};
 return Object.freeze({stats:Object.freeze({triangles:triangles.length,components:components.length,revision:inputs.revision}),createTrial({spawn=[-.25,6.5]}={}){return createStationaryFallbackTrial(THREE,components,{spawn,movementAudit:bodyAudit,landingAudit:p=>bodyAudit(p,p),pathAudit:bodyAudit,boundaryAudit:(a,b)=>({pass:!boundary.blockedSweep(a,b)}),bounds,bodyCollider:createAuditedHookCollider({auditSegment:bodyAudit}),hookCollider:createAuditedHookCollider({auditSegment:hookAudit})});}});
}
