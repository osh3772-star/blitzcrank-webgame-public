// Pure scheduler boundary. A failed view is latched until a different view loads.
// No simulation, paint or pause retries occur on subsequent animation frames.
export function createFrameDriver({current,input,onError}) {
 let previous=null,last=null,running=false,failed=false;
 return Object.freeze({failed:()=>failed&&current()===previous,tick(time){
  const view=current();
  if(view!==previous){previous=view;last=null;running=false;failed=false;}
  if(!view||failed)return;
  try {
   if(!Number.isFinite(time)||time<0)throw Error('Invalid frame timestamp');
   const active=!view.trial.snapshot().paused;
   const dt=active&&running&&last!==null?Math.max(0,(time-last)/1000):0;
   last=time;running=active;
   if(active)view.trial.step(input(),dt);
   view.paint();
  } catch(error) {
   failed=true;running=false;last=null;
   let pauseError=null;try{view.trial.pause();}catch(e){pauseError=e;}
   onError(error,{pauseError,reloadRequired:true});
  }
 }});
}
