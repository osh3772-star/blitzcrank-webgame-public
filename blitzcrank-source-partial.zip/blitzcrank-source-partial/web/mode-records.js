import {COMBO_PRACTICE_RULES,COMBO_ER_RULES,COMBO_PRACTICE_TUNING} from './combo-practice.js?v=0.24.87';

// Browser-local, per-mode personal bests. Never read, migrate or write the old
// rocket-hand-best key: its score may have come from unlimited free practice.
export const MODE_RECORD_KEYS=Object.freeze({challenge:'rocket-hand-record-challenge90-v1',combo:'rocket-hand-record-combo-v1',comboER:'rocket-hand-record-combo-er-v1',challengeFlash:'rocket-hand-record-challenge90-flash15-v1',comboFlash:'rocket-hand-record-combo-flash15-v1',comboERFlash:'rocket-hand-record-combo-er-flash15-v1'});
// Assisted records are a separate ruleset, never a migration of pre-Flash bests.
// Bump the assisted rule and key if Flash balance or eligibility changes.
export const MODE_RECORD_FLASH_RULES=Object.freeze({challengeFlash:'challenge90-flash15-v1',comboFlash:COMBO_PRACTICE_RULES+'+flash15-v1',comboERFlash:COMBO_ER_RULES+'+flash15-v1'});
const scoreValid=value=>Number.isSafeInteger(value)&&value>=0;
const comboValid=value=>Number.isFinite(value)&&value>0&&value<=COMBO_PRACTICE_TUNING.attemptDuration;
const modes={
 challenge:{valid:scoreValid,better:(a,b)=>a>b,fields:['version','mode','score'],encode:value=>({version:1,mode:'challenge90',score:value}),decode:record=>record.version===1&&record.mode==='challenge90'&&scoreValid(record.score)?record.score:null},
 combo:{valid:comboValid,better:(a,b)=>a<b,fields:['version','mode','rules','seconds'],encode:value=>({version:1,mode:'combo',rules:COMBO_PRACTICE_RULES,seconds:value}),decode:record=>record.version===1&&record.mode==='combo'&&record.rules===COMBO_PRACTICE_RULES&&comboValid(record.seconds)?record.seconds:null},
 comboER:{valid:comboValid,better:(a,b)=>a<b,fields:['version','mode','rules','seconds'],encode:value=>({version:1,mode:'combo-er',rules:COMBO_ER_RULES,seconds:value}),decode:record=>record.version===1&&record.mode==='combo-er'&&record.rules===COMBO_ER_RULES&&comboValid(record.seconds)?record.seconds:null},
 challengeFlash:{valid:scoreValid,better:(a,b)=>a>b,fields:['version','mode','rules','score'],encode:value=>({version:1,mode:'challenge90-flash',rules:MODE_RECORD_FLASH_RULES.challengeFlash,score:value}),decode:record=>record.version===1&&record.mode==='challenge90-flash'&&record.rules===MODE_RECORD_FLASH_RULES.challengeFlash&&scoreValid(record.score)?record.score:null},
 comboFlash:{valid:comboValid,better:(a,b)=>a<b,fields:['version','mode','rules','seconds'],encode:value=>({version:1,mode:'combo-flash',rules:MODE_RECORD_FLASH_RULES.comboFlash,seconds:value}),decode:record=>record.version===1&&record.mode==='combo-flash'&&record.rules===MODE_RECORD_FLASH_RULES.comboFlash&&comboValid(record.seconds)?record.seconds:null},
 comboERFlash:{valid:comboValid,better:(a,b)=>a<b,fields:['version','mode','rules','seconds'],encode:value=>({version:1,mode:'combo-er-flash',rules:MODE_RECORD_FLASH_RULES.comboERFlash,seconds:value}),decode:record=>record.version===1&&record.mode==='combo-er-flash'&&record.rules===MODE_RECORD_FLASH_RULES.comboERFlash&&comboValid(record.seconds)?record.seconds:null}
};
export function createModeRecords({getStorage=()=>globalThis.localStorage}={}){
 const records=Object.fromEntries(Object.keys(modes).map(mode=>[mode,{best:null,saved:false,issue:null}]));
 const merge=(mode,value)=>{const record=records[mode];if(record.best===null||modes[mode].better(value,record.best))record.best=value;};
 function read(mode){
  const record=records[mode],definition=modes[mode];
  try{
   // The property getter, getItem and setItem can all throw independently.
   const storage=getStorage(),raw=storage.getItem(MODE_RECORD_KEYS[mode]);
   if(raw===null){record.saved=false;record.issue=record.best===null?null:'unsaved';return{storage,value:null};}
   let data;try{data=JSON.parse(raw);}catch{record.saved=false;record.issue='invalid';return null;}
   const value=data&&typeof data==='object'&&!Array.isArray(data)&&Object.keys(data).length===definition.fields.length&&definition.fields.every(field=>Object.hasOwn(data,field))?definition.decode(data):null;
   if(value===null){record.saved=false;record.issue='invalid';return null;}
   merge(mode,value);record.saved=record.best===value;record.issue=record.saved?null:'unsaved';return{storage,value};
  }catch{record.saved=false;record.issue='unavailable';return null;}
 }
 function record(mode,value){
  if(!modes[mode].valid(value))return false;
  merge(mode,value);
  // Re-read immediately before writing so an already better other-tab record
  // wins. localStorage has no transaction: simultaneous writes remain best effort.
  const current=read(mode),state=records[mode];
  if(!current)return false; // Unknown/malformed bytes must stay untouched.
  if(state.saved)return true;
  try{current.storage.setItem(MODE_RECORD_KEYS[mode],JSON.stringify(modes[mode].encode(state.best)));state.saved=true;state.issue=null;return true;}
  catch{state.saved=false;state.issue='unavailable';return false;}
 }
 const api={
  refresh(){for(const mode of Object.keys(modes))read(mode);},
  recordChallenge(session){return session?.practice===false&&session.done===true?record(session.flashAssisted===true?'challengeFlash':'challenge',session.score):false;},
  recordCombo(result){const route=result?.route??'qer',mode=route==='er'?'comboER':'combo';return result?.success===true&&['qer','er'].includes(route)?record(mode+(result.flashAssisted===true?'Flash':''),result.elapsed):false;},
  snapshot(){return Object.fromEntries(Object.entries(records).map(([mode,value])=>[mode,{...value}]));}
 };
 api.refresh();return api;
}
